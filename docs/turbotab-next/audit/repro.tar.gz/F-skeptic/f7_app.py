from h import *
import pandas as pd, numpy as np
def main():
    df = pd.read_csv(SD/"metabolomics_untargeted.csv")
    print(df.sample_type.value_counts().to_dict(), "responder" in df, df.get("responder", pd.Series()).value_counts(dropna=False).to_dict())
    rng = np.random.default_rng(0)
    cls = np.where(df.sample_type.eq("pooled_qc"), "QC", np.where(rng.random(len(df)) < 0.5, "Case", "Control"))
    out = df.drop(columns=["sample_type", "bmi", "responder"], errors="ignore"); out.insert(1, "Class", cls)
    out.to_csv("met_class_qc.csv", index=False)
    with H() as h:
        d = h.driver("q")
        d.open(Path("/private/tmp/turbotab-audit/F-skeptic/met_class_qc.csv")); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["metabolomics"]})
        d.reach("target"); d.decide({"kind": "set_target", "column": "Class"})
        fs = findings(d)
        print("finding ids:", [f["id"] for f in fs])
        st = d.reach("task", 120); print("task step:", st["status"], st.get("reason")); print("event:", steps(d)["event"])
        for f in fs:
            if "sample_roles" in f["id"]: print("sample_roles:", f["severity"], f["summary"], "| routes:", f.get("routes_to"), "| repairs:", f.get("repairs"))
        code, js = post(d, "/decisions", {"kind": "set_task", "column": "Class", "task": "binary"})
        print("set_task binary ->", code, str(js)[:300])
        # The by-level workaround on a numeric column
        print("pooled_qc served text check:", [f.get("why_it_matters","")[:200] for f in fs if "pooled" in f["id"]])
    os._exit(0)
if __name__ == "__main__": main()
