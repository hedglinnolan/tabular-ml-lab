import numpy as np, pandas as pd
rng = np.random.default_rng(2024)
n, p = 60, 300
case = np.r_[np.ones(30), np.zeros(30)].astype(int); rng.shuffle(case)
sf = np.exp(rng.normal(0, 0.15, n)) * np.where(case==1, 1.4, 1.0)  # cases sequenced ~1.4x deeper
base = np.exp(rng.normal(np.log(150), 1.2, p))
disp = 0.1
mu = np.outer(sf, base)
r = 1/disp; prob = r/(r+mu)
X = rng.negative_binomial(r, prob)
df = pd.DataFrame(X, columns=[f"ENSG{100000+i:011d}" for i in range(p)])
df.insert(0, "sample_id", [f"S{i:03d}" for i in range(n)])
df["case"] = case
df.to_csv("depth_counts.csv", index=False)
print("max count", X.max(), "lib size ratio cases/controls", X[case==1].sum(1).mean()/X[case==0].sum(1).mean())
