from h import *
import pandas as pd
def main():
    src = SD/"survey_instrument.csv"; df = pd.read_csv(src); print(df.shape, list(df.columns[:6]), list(df.columns[-6:]))
    item = [c for c in df.columns if "01" in c or c.endswith("_1")][0]
    with H() as h:
        d = h.driver("s")
        d.open(src); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["survey"]})
        d.reach("target"); d.decide({"kind": "set_target", "column": item})
        st = d.reach("task", 120); print("outcome", item, "task:", st["status"], "|", st.get("reason"))
        ti = d.get("/stages/target_info")["artifact"] if True else None
        print("target_info:", {k: ti.get(k) for k in ("task","confidence","detected") if isinstance(ti, dict)})
    os._exit(0)
if __name__ == "__main__": main()
