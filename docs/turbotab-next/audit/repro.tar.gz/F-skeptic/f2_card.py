from h import *
def main():
    with H() as h:
        d = h.driver("g")
        d.open(Path("/private/tmp/turbotab-audit/F-skeptic/depth_counts.csv")); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["genomics"]})
        d.reach("target"); d.decide({"kind": "set_target", "column": "case"})
        for f in findings(d):
            if "data_type" in f["id"]:
                s = json.dumps(f); i = s.find("pre-normalize"); print("found 'pre-normalize' at", i); print(s[max(0,i-600):i+100])
    os._exit(0)
if __name__ == "__main__": main()
