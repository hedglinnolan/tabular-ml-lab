from h import *
import pandas as pd
def main():
    with H() as h:
        d = h.driver("met")
        d.open(SD/"metabolomics_untargeted.csv"); d.wait("ingest")
        d.decide({"kind": "set_lens", "lenses": ["metabolomics"]})
        d.reach("target")
        d.decide({"kind": "set_target", "column": "bmi"})
        fs = findings(d)
        for f in fs:
            if "censor" in f["id"] or "qc" in f["id"] or "acqui" in f["id"] or "drift" in f["id"] or "sample_role" in f["id"]:
                print(f["severity"], f["id"], "| routes:", f.get("routes_to"), "|", f.get("summary"))
        d.answer_the_task("bmi", "regression")
        d.reach("purpose"); d.decide({"kind": "set_purpose", "purpose": "inference"})
        st = d.reach("grain")
        if st["status"] in ("open","waiting"):
            d.decide({"kind": "set_grain", "grain": "one_row_per_unit", "id_column": "sample_id"})
        d.reach("roles")
        roles = d.accept_roles()
        from collections import Counter
        print("roles:", Counter(roles.values()), {k:v for k,v in roles.items() if not k.startswith("mz_")})
        d.decide({"kind": "set_roles", "roles": roles})
        d.reach("exclusions"); d.decide({"kind": "set_exclusions", "rules": []})
        st = d.reach("missing"); print("missing step:", st["status"], st.get("reason"))
        for strat in ("complete_case", "impute"):
            code, js = post(d, "/preview", {"kind": "set_missing", "strategy": strat})
            s = json.dumps(js)
            import re
            print("PREVIEW", strat, code)
            for m in re.findall(r'"(?:caption|sentence|text|label|summary)": "([^"]{0,200})"', s)[:12]:
                print("   ", m)
        df = pd.read_csv(SD/"metabolomics_untargeted.csv")
        c = df["mz_0121"]; print("mz_0121 blank", c.isna().mean().round(3), "min", c.min(), "median", c.median())
    os._exit(0)
if __name__ == "__main__": main()
