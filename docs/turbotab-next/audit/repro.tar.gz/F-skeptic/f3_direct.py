import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab import packs, survey
rng = np.random.default_rng(7)
def make(k, n=400, items=12, probs=None):
    probs = probs if probs is not None else np.ones(k)/k
    return pd.DataFrame({f"wb_{i+1:02d}": rng.choice(np.arange(1, k+1), size=n, p=probs) for i in range(items)})
cases = {
 "6pt balanced": make(6),
 "6pt skewed-low top (top 10%)": make(6, probs=np.array([.15,.2,.2,.2,.15,.10])),
 "7pt rare top (6:8%,7:6%)": make(7, probs=np.array([.14,.18,.2,.2,.14,.08,.06])),
 "7pt balanced": make(7),
 "5pt balanced (control)": make(5),
}
# 5-pt with real 9 sentinel (positive control)
d5 = make(5); m = rng.random(d5.shape) < 0.05; d5 = d5.mask(m, 9); cases["5pt + 5% code 9 (positive control)"] = d5
# 0-5 scale
d05 = pd.DataFrame({f"q{i}": rng.choice(np.arange(0,6), size=400) for i in range(12)}); cases["0-5 balanced"] = d05
d010 = pd.DataFrame({f"q{i}": rng.choice(np.arange(0,11), size=400) for i in range(12)}); cases["0-10 balanced"] = d010
for name, df in cases.items():
    b = packs.likert_block(df)
    f = survey.sentinel_codes_finding(df)
    print(f"{name:40s} scale={None if b is None else b['scale']} sentinels={None if b is None else sorted({v for vs in b['sentinels'].values() for v in vs})}")
    if f: print("    FINDING", f["severity"], "|", f["title"], "|", f["detail"][:220].replace("\n"," "))
cases["6pt balanced"].to_csv("six_point.csv", index=False)
