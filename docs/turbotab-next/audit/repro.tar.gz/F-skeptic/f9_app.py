from h import *
def main():
    with H() as h:
        d = h.driver("r")
        d.open(Path("/private/tmp/turbotab-audit/F-skeptic/one_concentrated.csv")); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["metabolomics"]})
        d.reach("target"); d.decide({"kind": "set_target", "column": "bmi"})
        for f in findings(d):
            if "redund" in f["id"]: print(f["severity"], f["id"], "|", f["summary"])
    os._exit(0)
if __name__ == "__main__": main()
