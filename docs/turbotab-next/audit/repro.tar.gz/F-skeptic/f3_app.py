from h import *
def main():
    with H() as h:
        d = h.driver("sur")
        import pandas as pd, numpy as np
        df = pd.read_csv("six_point.csv"); rng = np.random.default_rng(1)
        df["outcome"] = df.mean(axis=1) + rng.normal(0, 1, len(df)); df.to_csv("six_point_y.csv", index=False)
        d.open(Path("/private/tmp/turbotab-audit/F-skeptic/six_point_y.csv")); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["survey"]})
        d.reach("target"); d.decide({"kind": "set_target", "column": "outcome"})
        for f in findings(d):
            if "sentinel" in f["id"] or "ordinal" in f["id"]:
                print(f["severity"], f["id"], "|", f["summary"])
                for r in f.get("repairs", []):
                    print("  REPAIR", r.get("label"), "|", r.get("consequence"), "|", (r.get("sentence") or "")[:300])
        print("share of 6s:", float((df.drop(columns="outcome")==6).mean().mean()))
    os._exit(0)
if __name__ == "__main__": main()
