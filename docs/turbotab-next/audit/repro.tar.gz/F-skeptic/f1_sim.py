import numpy as np
from sklearn.impute import SimpleImputer
rng = np.random.default_rng(0)
def slope(x, y):
    X = np.c_[np.ones_like(x), x]; return np.linalg.lstsq(X, y, rcond=None)[0][1]
for scale in ("log", "raw"):
  for cens in (0.2, 0.4, 0.6):
    res = {k: [] for k in ("full","median","median+ind","halfmin","detected_only")}
    for r in range(300):
        n = 300
        lx = rng.normal(0, 1, n)                       # log concentration
        y = 0.5*lx + rng.normal(0, 1, n) if scale=="log" else 0.5*np.exp(lx) + rng.normal(0,1,n)
        xv = lx if scale=="log" else np.exp(lx)
        lod = np.quantile(xv, cens)
        obs = np.where(xv < lod, np.nan, xv)
        res["full"].append(slope(xv, y))
        med = SimpleImputer(strategy="median").fit_transform(obs[:,None])[:,0]
        res["median"].append(slope(med, y))
        ind = np.isnan(obs).astype(float)
        X = np.c_[np.ones(n), med, ind]; res["median+ind"].append(np.linalg.lstsq(X, y, rcond=None)[0][1])
        hm = np.where(np.isnan(obs), (np.nanmin(obs)/2 if scale=="raw" else np.nanmin(obs)-np.log(2)), obs)
        res["halfmin"].append(slope(hm, y))
        m = ~np.isnan(obs); res["detected_only"].append(slope(obs[m], y[m]))
    print(scale, cens, {k: round(float(np.mean(v)),3) for k,v in res.items()})
