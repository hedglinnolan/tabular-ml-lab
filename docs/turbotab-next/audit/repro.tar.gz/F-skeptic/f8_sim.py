import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd, warnings; warnings.filterwarnings("ignore")
from turbotab import packs
from scipy import stats
rng = np.random.default_rng(13)
for n in (16, 20, 24, 30, 40):
    fired, shares, sig = 0, [], 0
    for rep in range(40):
        X = np.exp(rng.normal(rng.normal(8, 1.5, 200), 0.4, (n, 200)))   # log-normal, no drift
        df = pd.DataFrame(X, columns=[f"mz_{i:04d}" for i in range(200)])
        df.insert(0, "run_order", rng.permutation(np.arange(1, n+1)))
        f = packs._acquisition_order(df)
        if f: fired += 1; shares.append(f["params"]["share_tracking"])
        # pack spec: Spearman + BH-FDR
        p = np.array([stats.spearmanr(df.run_order, df[c])[1] for c in df.columns[1:]])
        rho = np.array([stats.spearmanr(df.run_order, df[c])[0] for c in df.columns[1:]])
        from statsmodels.stats.multitest import multipletests
        q = multipletests(p, method="fdr_bh")[1]
        if ((np.abs(rho) > 0.3) & (q < 0.05)).mean() >= 0.15: sig += 1
    print(f"n={n}: fired {fired}/40, mean claimed share {np.mean(shares) if shares else float('nan'):.2f}; pack-spec (Spearman+BH) would fire {sig}/40")
