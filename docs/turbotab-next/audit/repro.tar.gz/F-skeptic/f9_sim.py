import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd, warnings; warnings.filterwarnings("ignore")
from turbotab import packs
rng = np.random.default_rng(4)
n, p = 80, 300
base = np.exp(rng.normal(rng.normal(8, 1.5, p), 0.5, (n, p)))   # independent log-normal features
for mult in (1, 5, 10, 20):
    X = base.copy(); X[0] *= mult                                     # one concentrated sample
    df = pd.DataFrame(X, columns=[f"mz_{i:04d}" for i in range(p)])
    df.insert(0, "sample_id", [f"S{i}" for i in range(n)]); df["bmi"] = rng.normal(25, 3, n)
    f = packs._redundancy(df)
    lc = np.corrcoef(np.log(X).T); np.fill_diagonal(lc, 0)
    sp = pd.DataFrame(X).corr(method="spearman").to_numpy(); np.fill_diagonal(sp, 0)
    print(f"x{mult:>2}: finding -> {f['title'] if f else 'silent'}; max |r| on log scale {np.abs(lc).max():.2f}; max |Spearman| {np.abs(sp).max():.2f}")
    if f and mult == 20: print("    detail:", f["detail"][:330].replace("\n", " "))
