import numpy as np, warnings; warnings.filterwarnings("ignore")
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score, StratifiedKFold
rng = np.random.default_rng(3)
m = make_pipeline(StandardScaler(), LogisticRegression(penalty="elasticnet", solver="saga", l1_ratio=0.5, C=0.1, max_iter=3000))
def pqn(X):
    ref = np.median(X, 0); q = np.median(X/ref, 1, keepdims=True); return X/q
raw, nrm = [], []
for rep in range(6):
    n,p = 80, 200; y = np.r_[np.ones(40), np.zeros(40)].astype(int)
    dil = np.exp(rng.normal(0, 0.3, n)) * np.where(y==1, 0.75, 1.0)
    conc = np.exp(rng.normal(rng.normal(3,1,p), 0.5, (n,p)))
    X = conc * dil[:,None]
    cv = StratifiedKFold(5, shuffle=True, random_state=rep)
    raw.append(cross_val_score(m, X, y, cv=cv, scoring="roc_auc").mean())
    nrm.append(cross_val_score(m, np.log2(pqn(X)), y, cv=cv, scoring="roc_auc").mean())
print(f"dilution null: raw AUC {np.mean(raw):.2f}, PQN+log2 AUC {np.mean(nrm):.2f}")
