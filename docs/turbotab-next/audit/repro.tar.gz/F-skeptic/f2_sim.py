import numpy as np, warnings
warnings.filterwarnings("ignore")
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score, StratifiedKFold
rng = np.random.default_rng(5)
def counts(depth_ratio):
    n,p=60,300; case=np.r_[np.ones(30),np.zeros(30)].astype(int)
    sf=np.exp(rng.normal(0,0.15,n))*np.where(case==1,depth_ratio,1.0)
    base=np.exp(rng.normal(np.log(60),1.2,p)); r=10; mu=np.outer(sf,base)
    X=rng.negative_binomial(r, r/(r+mu)); return X, case
def logcpm(X): return np.log2((X+0.5)/(X.sum(1,keepdims=True)+1)*1e6)
m = make_pipeline(StandardScaler(), LogisticRegression(penalty="elasticnet", solver="saga", l1_ratio=0.5, C=0.1, max_iter=3000))
for ratio in (1.0, 1.46):
    raw, lc = [], []
    for rep in range(5):
        X,y = counts(ratio); cv = StratifiedKFold(5, shuffle=True, random_state=rep)
        raw.append(cross_val_score(m, X, y, cv=cv, scoring="roc_auc").mean())
        lc.append(cross_val_score(m, logcpm(X), y, cv=cv, scoring="roc_auc").mean())
    print(f"depth ratio {ratio}: raw-count AUC {np.mean(raw):.2f}  log-CPM AUC {np.mean(lc):.2f}")
