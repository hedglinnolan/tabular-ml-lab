from h import *
import pandas as pd
def main():
    src = SD/"metabolomics_mzmine_zeros.csv"
    df = pd.read_csv(src); print(df.shape, list(df.columns[:8]))
    with H() as h:
        d = h.driver("z")
        d.open(src); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["metabolomics"]})
        d.reach("target")
        tgt = "bmi" if "bmi" in df.columns else df.columns[-1]
        d.decide({"kind": "set_target", "column": tgt})
        for f in findings(d):
            print(f["severity"], f["id"], "| routes:", f.get("routes_to"), "|", f["summary"], "| repairs:", [r.get("label") for r in f.get("repairs", [])])
    os._exit(0)
if __name__ == "__main__": main()
