from h import *
import pandas as pd
def main():
    src = SD/"genomics_single_cell.csv"; df = pd.read_csv(src)
    with H() as h:
        d = h.driver("sc")
        d.open(src); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["genomics"]})
        d.reach("target")
        tgt = [c for c in df.columns if not str(c).startswith(("ENSG","gene","cell"))][:5]
        print("candidate targets:", tgt)
        d.decide({"kind": "set_target", "column": tgt[-1]})
        for f in findings(d): print(f["severity"], f["id"], "|", f["summary"][:160])
    os._exit(0)
if __name__ == "__main__": main()
