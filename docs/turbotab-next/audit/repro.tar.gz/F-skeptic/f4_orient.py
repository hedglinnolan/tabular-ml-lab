import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab import orientation as o
SD = "/Users/nhedglin/tabular-ml-lab/turbotab/sample_data/"
def transpose(df, idcol):
    num = df.select_dtypes(include=[np.number])
    feats = [c for c in num.columns if c not in ("age","bmi","run_order","case","outcome","condition","responder")]
    t = df.set_index(idcol)[feats].T
    t.index.name = "feature"; return t.reset_index()
for name, idc in [("genomics_vst.csv","sample_id"),("genomics_microarray.csv","sample_id"),("metabolomics_paired_logged.csv",None),("metabolomics_untargeted.csv","sample_id"),("genomics_expression.csv","sample_id")]:
    df = pd.read_csv(SD+name)
    if idc is None or idc not in df.columns:
        idc = df.columns[0]
    t = transpose(df, idc)
    r0 = o.read(df); r = o.read(t)
    print(f"{name:32s} as-is: {r0['reading']:13s} ratio={r0['ratio'] and round(r0['ratio'],2)} | transposed: {r['reading']:13s} ratio={r['ratio'] and round(r['ratio'],1)} s_rows={r['s_rows'] and round(r['s_rows'],2)} s_cols={r['s_cols'] and round(r['s_cols'],3)}")
# MZmine-style: features in rows, with row m/z and RT columns, raw intensities
df = pd.read_csv(SD+"metabolomics_untargeted.csv")
t = transpose(df, "sample_id")
rng = np.random.default_rng(0)
mz = pd.DataFrame({"row ID": np.arange(1, len(t)+1), "row m/z": rng.uniform(80, 1200, len(t)), "row retention time": rng.uniform(0.5, 20, len(t))})
mzm = pd.concat([mz, t.drop(columns="feature")], axis=1)
r = o.read(mzm); print("mzmine-style (ID, m/z, RT + samples):", r["reading"], round(r["ratio"],2), round(r["s_rows"],2))
r = o.read(mzm.drop(columns="row ID")); print("mzmine-style (m/z, RT + samples):", r["reading"], round(r["ratio"],2), round(r["s_rows"],2))
r = o.read(t); print("plain transposed raw untargeted:", r["reading"], round(r["ratio"],1))
lt = t.copy(); lt.iloc[:,1:] = np.log2(lt.iloc[:,1:].astype(float)); r = o.read(lt); print("plain transposed log2 untargeted:", r["reading"], r["ratio"] and round(r["ratio"],1), r["s_rows"] and round(r["s_rows"],2))
