"""Skeptic harness: real TurboTab Next server in-process, fresh TURBOTAB_HOME under F-skeptic."""
import os, sys, time, json, tempfile
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
os.environ["TURBOTAB_WORKERS"] = "2"
from fastapi.testclient import TestClient
from turbotab.core.config import Settings
from turbotab.server.app import create_app
from turbotab.core.bench.run import Driver, Tap
SD = Path("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data")
class H:
    def __enter__(self):
        self.home = tempfile.mkdtemp(prefix="ttF-", dir="/private/tmp/turbotab-audit/F-skeptic")
        base = Settings.from_env()
        s = Settings(home=Path(self.home), mode="local", workers=2, memory_budget_bytes=base.memory_budget_bytes)
        self.app = create_app(s, frontend_dist=Path(self.home) / "nofront")
        self.cm = TestClient(self.app, base_url="http://127.0.0.1")
        self.client = self.cm.__enter__()
        self.tap = Tap(); self.tap.install(self.client.app.state.service.bus)
        return self
    def __exit__(self, *a):
        self.cm.__exit__(*a)
    def driver(self, name="x"):
        return Driver(self.client, self.tap, name, [])
def steps(d):
    return {s["key"]: (s["status"], s.get("reason")) for s in d.get("")["interview"]}
def findings(d):
    d.wait("findings", 300)
    return d.get("/stages/findings")["artifact"]["findings"]
def post(d, path, body):
    r = d.client.post(f"/api/projects/{d.pid}{path}", json=body)
    try: js = r.json()
    except Exception: js = r.text
    return r.status_code, js
