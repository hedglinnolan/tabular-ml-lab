from h import *
import sys
def main():
    src = Path(sys.argv[1])
    with H() as h:
        d = h.driver("g")
        d.open(src); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["genomics"]})
        st = d.reach("target"); 
        print("orientation:", steps(d).get("orientation"))
        d.decide({"kind": "set_target", "column": "case"})
        for f in findings(d):
            print("F", f["severity"], f["id"], "|", f["summary"][:200])
            if "data_type" in f["id"] or "raw" in f["id"]: print("    detail:", f.get("detail","")[:300].replace("\n"," "))
        st = d.reach("event")
        if st["status"] in ("open","waiting"):
            d.decide({"kind": "set_event", "column": "case", "level": "1"})
        d.answer_the_task("case", "binary")
        st = d.reach("purpose"); d.decide({"kind": "set_purpose", "purpose": "prediction"})
        st = d.reach("grain")
        if st["status"] in ("open","waiting"):
            d.decide({"kind": "set_grain", "grain": "one_row_per_unit", "id_column": "sample_id"})
        print({k:v for k,v in steps(d).items() if v[0] in ("open","waiting")})
        d.reach("roles"); d.wait("roles", 120); roles = d.accept_roles(); d.decide({"kind": "set_roles", "roles": roles})
        d.reach("exclusions"); d.decide({"kind": "set_exclusions", "rules": []})
        d.reach("missing"); d.decide({"kind": "set_missing", "strategy": "complete_case"})
        d.reach("split"); d.decide({"kind": "set_split", "holdout": 0.0, "seed": 0, "folds": 5})
        d.wait("shelf", 300)
        for fam in d.get("/stages/shelf")["artifact"]["families"]:
            print("SHELF", fam.get("key") or fam.get("family"), fam.get("fit"), fam.get("concerns"))
        d.reach("models"); d.decide({"kind": "select_models", "models": ["elastic_net"]})
        d.wait("fit", 280)
        fit = d.get("/stages/fit")["artifact"]
        for m in fit["models"]:
            print("FIT", m["family"], {k: (round(v["mean"],3) if v["mean"] is not None else None, [round(x,2) for x in v["folds"] if x is not None]) for k,v in m["cv"].items()})
            print("   baseline", m["baseline"], "concerns", m["concerns"])
    os._exit(0)
if __name__ == "__main__": main()
