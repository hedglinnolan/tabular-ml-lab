import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import pandas as pd, numpy as np, statsmodels.api as sm
from turbotab.core.methods.nesting import nested_components
d = pd.read_csv("/Users/nhedglin/tabular-ml-lab/_tt_tmp_nhanes.csv")
nut = ["protein","sugar","carb","fat_total","fat_sat","fat_mon","fat_poly"]
print("nested:", nested_components(d, nut))
d = d[(d.kcal>=500)&(d.kcal<=5000)].dropna(subset=["glucose","age","kcal",*nut])
def fit(cols):
    f = sm.OLS(d.glucose, sm.add_constant(d[["age","kcal",*cols]])).fit()
    return {c: (round(f.params[c],4), tuple(np.round(f.conf_int().loc[c].values,4))) for c in cols if c in ("fat_total","carb")}
print("n", len(d))
print("with parts:", fit(nut))
print("totals only:", fit(["protein","carb","fat_total"]))
rem = (d.fat_total - d.fat_sat - d.fat_mon - d.fat_poly)/d.fat_total
print("other-fat share median", round(rem.median(),3))
