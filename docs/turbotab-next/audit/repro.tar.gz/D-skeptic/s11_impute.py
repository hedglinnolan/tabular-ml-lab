import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.decisions import EnergyAdjustment, ProjectState, MissingSpec
from turbotab.core.models.pipeline import design_spec, shared_steps, transformer, model_predictors
rng = np.random.default_rng(21); n = 20000
E = rng.normal(2100, 500, n); age = rng.normal(50, 12, n)
prot = (0.16 + rng.normal(0, .03, n)) * E / 4
y = 0.03*prot + 0.002*E + 0.1*age + rng.normal(0, 5, n)
miss = rng.random(n) < 0.2
p_obs = prot.copy(); p_obs[miss] = np.nan
df = pd.DataFrame({"protein_g": p_obs, "energy_kcal": E, "age": age})
roles = {"protein_g": "exposure", "energy_kcal": "energy", "age": "covariate"}
for m in ["standard", "residual"]:
    for strat in ["complete_case", "impute"]:
        st = ProjectState(target="y", roles=roles, missing=MissingSpec(strategy=strat),
                          energy_adjustment=EnergyAdjustment(method=m, energy_column="energy_kcal", nutrients=["protein_g"]))
        spec = design_spec(st, df, model_predictors(st))
        rows = ~miss if strat == "complete_case" else np.ones(n, bool)
        steps = shared_steps(spec)
        M = transformer(steps).fit_transform(df.loc[rows, spec.inputs])
        col = [c for c in M.columns if c.startswith("protein")][0]
        f = sm.OLS(y[rows], sm.add_constant(M)).fit()
        extra = ""
        if strat == "impute":
            imp = M.loc[miss, col]
            extra = f" | imputed rows: corr(adj value, E) = {np.corrcoef(imp, E[miss])[0,1]:+.3f}; observed rows corr(raw N, E) = {np.corrcoef(prot[~miss], E[~miss])[0,1]:+.3f}; steps={[s for s,_ in steps]}"
        print(f"{m:9} {strat:13} b={f.params[col]:.5f} (se {f.bse[col]:.5f}) truth 0.03{extra}")
