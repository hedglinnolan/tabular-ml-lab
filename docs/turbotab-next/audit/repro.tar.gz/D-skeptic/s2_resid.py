import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.decisions import EnergyAdjustment, ProjectState
from turbotab.core.models.pipeline import design_spec, shared_steps, transformer, model_predictors
rng = np.random.default_rng(11); n = 40000
male = rng.integers(0, 2, n).astype(float)
E = 1800 + 500*male + rng.normal(0, 400, n)
prot = (0.15 + 0.03*male + rng.normal(0, .03, n)) * E / 4
def run(y, fam):
    df = pd.DataFrame({"protein_g": prot, "energy_kcal": E, "male": male})
    roles = {"protein_g": "exposure", "energy_kcal": "energy", "male": "covariate"}
    out = {}
    for m in ["standard", "residual"]:
        st = ProjectState(target="y", roles=roles, energy_adjustment=EnergyAdjustment(method=m, energy_column="energy_kcal", nutrients=["protein_g"]))
        spec = design_spec(st, df, model_predictors(st))
        M = transformer(shared_steps(spec)).fit_transform(df[spec.inputs])
        kw = {"disp": 0} if fam is sm.Logit else {}
        f = fam(y, sm.add_constant(M)).fit(**kw)
        col = [c for c in M.columns if c.startswith("protein")][0]
        out[m] = (list(M.columns), round(f.params[col], 5), round(f.bse[col], 5))
    return out
# Case A: E affects Y directly (E is a cause), sex affects both
y = 0.02*prot + 0.004*E + 3*male + rng.normal(0, 5, n)
print("A linear, E has own effect:", run(y, sm.OLS))
# Case B: E has no direct effect on Y beyond protein
y2 = 0.02*prot + 3*male + rng.normal(0, 5, n)
print("B linear, E no own effect:", run(y2, sm.OLS))
# Case C: no covariate correlated with E (sex independent of E)
