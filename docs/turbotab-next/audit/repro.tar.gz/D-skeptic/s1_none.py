import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.decisions import EnergyAdjustment, ProjectState
from turbotab.core.models.pipeline import design_spec, shared_steps, transformer, model_predictors, describe_steps
from turbotab.core.methods.energy import METHOD_TABLE
rng = np.random.default_rng(3); n = 5000
E = rng.normal(2100, 450, n); age = rng.normal(50, 12, n)
prot = (0.16 + rng.normal(0, .03, n)) * E / 4
y = 0.03*prot + 0.002*E + 0.1*age + rng.normal(0, 5, n)
df = pd.DataFrame({"protein_g": prot, "energy_kcal": E, "age": age})
roles = {"protein_g": "exposure", "energy_kcal": "energy", "age": "covariate"}
for m in ["none", "standard"]:
    adj = EnergyAdjustment(method=m, energy_column="energy_kcal", nutrients=["protein_g"]) if m != "none" else EnergyAdjustment(method="none")
    st = ProjectState(target="y", roles=roles, energy_adjustment=adj)
    preds = model_predictors(st)
    spec = design_spec(st, df, preds)
    M = transformer(shared_steps(spec)).fit_transform(df[spec.inputs])
    f = sm.OLS(y, sm.add_constant(M)).fit()
    print(m, "spec:", METHOD_TABLE[m]["specification"], "| matrix:", list(M.columns), "| b_prot=%.5f" % f.params["protein_g"])
# crude unadjusted Y ~ N + C
f = sm.OLS(y, sm.add_constant(df[["protein_g","age"]])).fit(); print("true Y~N+C b_prot=%.5f" % f.params["protein_g"])
