import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab.core.stages.proposals import build_proposals, _energy_unit
rng = np.random.default_rng(5); n = 800
kcal = np.clip(rng.normal(2100, 550, n), 600, None)
for variant in ["energy_only", "with_macros_g"]:
    df = pd.DataFrame({"energy": kcal*4.184, "sodium_mg": rng.normal(3300, 900, n),
                       "sex": rng.choice(["male","female"], n), "glucose": rng.normal(100, 15, n)})
    if variant == "with_macros_g":
        df["protein"] = kcal*0.16/4; df["carb"] = kcal*0.5/4; df["fat"] = kcal*0.34/9
    cols = [{"name": c, "dtype": ("categorical" if df[c].dtype == object else "numeric"), "n_unique": int(df[c].nunique()), "n_missing": 0} for c in df.columns]
    p = build_proposals(df, cols, lens=["dietary"], target="glucose")
    print(variant, "unit:", _energy_unit(df, "energy"), "energy col:", (p["energy"] or {}).get("energy_column"))
    for e in p["exclusions"]: print("   ", e["key"], e["affected"], "of", n)
    print("   coach:", p["coach"].get("exclusions", {}).get("text"))
