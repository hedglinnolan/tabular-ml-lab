import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
from turbotab.core.models.linear import statsmodels_fit
from sklearn.impute import SimpleImputer
rng = np.random.default_rng(21); reps, n = 600, 500
est=[]; hit=0; est_cc=[]; hit_cc=0
for _ in range(reps):
    age = rng.normal(50, 10, n)
    intake = 0.05*(age-50) + rng.normal(0, 1, n)
    y = 0.5*intake + 0.03*(age-50) + rng.normal(0, 1, n)
    p_miss = 1/(1+np.exp(-(-0.6 + 0.08*(age-50))))      # older people skip the intake item (MAR on age)
    miss = rng.random(n) < p_miss
    X = pd.DataFrame({"intake": np.where(miss, np.nan, intake), "age": age})
    Xi = pd.DataFrame(SimpleImputer(strategy="median").fit_transform(X), columns=X.columns)   # the app's numeric fill
    r = statsmodels_fit("regression", Xi, y, None, None)
    lo, hi = r.conf_int(0.05).loc["intake"]; est.append(r.params["intake"]); hit += lo<=0.5<=hi
    cc = ~miss
    r = statsmodels_fit("regression", X[cc], y[cc], None, None)
    lo, hi = r.conf_int(0.05).loc["intake"]; est_cc.append(r.params["intake"]); hit_cc += lo<=0.5<=hi
print(f"share blank {miss.mean():.2f}; median-fill: mean est {np.mean(est):.3f} (true 0.5), 95% CI coverage {hit/reps:.3f}; complete case: {np.mean(est_cc):.3f}, coverage {hit_cc/reps:.3f}")
