import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core.models.linear import statsmodels_fit, statsmodels_rows
from turbotab.core.stages.modeling import _concerns
out = {"table": 0, "error": 0}
shown = False
for seed in range(20):
    rng = np.random.default_rng(seed); n = 300
    exposed = (rng.random(n) < 0.08).astype(float); age = rng.normal(50, 10, n)
    y = np.where(exposed == 1, 1, (rng.random(n) < 1/(1+np.exp(-(-1 + 0.02*(age-50))))).astype(int))
    M = pd.DataFrame({"exposed": exposed, "age": age})
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        try:
            r = statsmodels_fit("binary", M, y, [0, 1], None)
        except Exception as e:
            out["error"] += 1
            if seed < 3: print(seed, "ERROR ->", type(e).__name__, e)
            continue
    out["table"] += 1
    rows = statsmodels_rows("binary", r, [0, 1]); ex = [x for x in rows if x["feature"] == "exposed"][0]
    if not shown:
        shown = True
        for w in caught: print("WARN:", w.category.__name__, "|", str(w.message)[:110])
        print(seed, "exposed row:", ex); print("concerns:", _concerns(caught, 6))
    else:
        print(seed, f"est {ex['estimate']:.1f} CI ({ex['ci_low']}, {ex['ci_high']}) p {ex['p']}")
print(out)
