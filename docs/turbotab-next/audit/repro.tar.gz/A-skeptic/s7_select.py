import sys, numpy as np, pandas as pd, warnings, time
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
from sklearn.base import clone
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
import turbotab.core.models
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import DesignSpec, build_pipeline
from turbotab.core.models.metrics import score
n, p, reps = 150, 10, int(sys.argv[1]) if len(sys.argv)>1 else 40
cols=[f"x{i}" for i in range(p)]
spec = DesignSpec(predictors=cols, inputs=cols, categorical=[], numeric=cols, energy=None, impute=False)
fams = ["linear", "elastic_net", "boosted_trees"]
pipes = {f: build_pipeline(spec, get_family(f), "binary", "prediction", n, p) for f in fams}
rng = np.random.default_rng(77); t=time.time()
best_cv=[]; own=[]; best_hold=[]; best_true=[]
for r in range(reps):
    X = pd.DataFrame(rng.normal(size=(n,p)), columns=cols); y=(rng.random(n)<0.3).astype(int)
    Xh = pd.DataFrame(rng.normal(size=(150,p)), columns=cols); yh=(rng.random(150)<0.3).astype(int)
    folds=np.zeros(n,int)
    for f,(_,te) in enumerate(StratifiedKFold(5,shuffle=True,random_state=r).split(X,y)): folds[te]=f
    cv={}; hold={}
    for fam in fams:
        cv[fam]=np.mean([score("binary", clone(pipes[fam]).fit(X[folds!=k],y[folds!=k]), X[folds==k], y[folds==k])["auc"] for k in range(5)])
        m=clone(pipes[fam]).fit(X,y); hold[fam]=score("binary",m,Xh,yh)["auc"]
    b=max(cv,key=cv.get); best_cv.append(cv[b]); own.append(np.mean(list(cv.values())))
    hb=max(hold,key=hold.get); best_hold.append(hold[hb])
print(f"null binary n={n}, {reps} datasets [{time.time()-t:.0f}s]: true AUC of every model = 0.500")
print(f"  mean CV AUC across families {np.mean(own):.3f}; CV AUC of CV-best family {np.mean(best_cv):.3f} (optimism {np.mean(best_cv)-0.5:+.3f}, MC SE {np.std(best_cv)/np.sqrt(reps):.3f})")
print(f"  holdout AUC of holdout-best family (picked after opening) {np.mean(best_hold):.3f} (optimism {np.mean(best_hold)-0.5:+.3f})")
