import sys, numpy as np, pandas as pd, warnings, math, time
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
from sklearn.base import clone
from sklearn.model_selection import StratifiedKFold
import turbotab.core.models
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import DesignSpec, build_pipeline
from turbotab.core.models.metrics import score
from turbotab.core.models.baseline import versus_baseline
from turbotab.core.stages.modeling import _baseline_scores
from scipy import stats
def rate(n, p, prev, reps, fam="linear", seed=123):
    rng = np.random.default_rng(seed); cols=[f"x{i}" for i in range(p)]
    spec = DesignSpec(predictors=cols, inputs=cols, categorical=[], numeric=cols, energy=None, impute=False)
    pipe = build_pipeline(spec, get_family(fam), "binary", "prediction", n, p)
    better = 0; means=[]; tstats=[]; nb=0
    for r in range(reps):
        X = pd.DataFrame(rng.normal(size=(n,p)), columns=cols); y = (rng.random(n) < prev).astype(int)
        folds = np.zeros(n, int)
        for f, (_, te) in enumerate(StratifiedKFold(5, shuffle=True, random_state=r).split(X, y)): folds[te]=f
        base = _baseline_scores("binary", X, y, folds, list(range(5)))
        pf = [score("binary", clone(pipe).fit(X[folds!=f], y[folds!=f]), X[folds==f], y[folds==f]) for f in range(5)]
        v = versus_baseline("auc", [a["auc"] for a in pf], [b["auc"] for b in base])
        better += v.verdict=="better"
        g = np.array([a["auc"]-b["auc"] for a,b in zip(pf,base)]); means.append(g.mean())
        nb += g.mean() > stats.t.ppf(.95,4)*math.sqrt(g.var(ddof=1)*(1/5+0.25))
    return better/reps, nb/reps, np.mean(means)
t=time.time()
for n, p, prev in ((150,10,0.3),(400,10,0.3),(150,3,0.3),(150,10,0.5)):
    b, nb, m = rate(n,p,prev,300)
    print(f"binary null n={n} p={p} prev={prev}: app 'better' {b:.3f} | NB-corrected one-sided 5% {nb:.3f} | mean CV AUC gain {m:+.4f}")
print(f"[{time.time()-t:.0f}s]")
