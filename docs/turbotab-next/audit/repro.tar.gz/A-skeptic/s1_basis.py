import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
from types import SimpleNamespace as NS
from turbotab.core.seal import decide_basis
frame = pd.DataFrame({"id": np.repeat(np.arange(300), 3)})
for g in ("unknown", "one_row", "repeated"):
    st = NS(grain=NS(grain=g, id_column=None), unit=None, aggregation=None)
    try:
        b, col = decide_basis(st, frame, ["id"])
        print(g, "->", b.state, "column returned:", col, "| exploratory", b.exploratory)
    except Exception as e: print(g, "ERR", e)
small = pd.DataFrame({"id": np.repeat(np.arange(6), 20)})
st = NS(grain=NS(grain="repeated", id_column="id"), unit=None, aggregation=None)
b, col = decide_basis(st, small, ["id"]); print("repeated 6 units ->", b.state, col)
