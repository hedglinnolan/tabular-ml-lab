import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
from turbotab.core.models.linear import statsmodels_fit
def run(G, per, sx_within, se_within, reps=600, seed=11):
    rng = np.random.default_rng(seed); a=b=0
    for _ in range(reps):
        g = np.repeat(np.arange(G), per)
        x = rng.normal(size=G)[g] + sx_within*rng.normal(size=G*per)
        y = rng.normal(size=G)[g] + se_within*rng.normal(size=G*per)
        M = pd.DataFrame({"x": x})
        lo, hi = statsmodels_fit("regression", M, y, None, None).conf_int(0.05).loc["x"]; a += lo<=0<=hi
        lo, hi = statsmodels_fit("regression", M, y, None, g).conf_int(0.05).loc["x"]; b += lo<=0<=hi
    return a/reps, b/reps
for G, per, sx, se in [(300,3,0.5,0.7),(300,2,1.0,1.0),(100,5,0.5,1.0),(300,3,2.0,2.0)]:
    p, c = run(G, per, sx, se)
    print(f"G={G} per={per} x_within_sd={sx} e_within_sd={se}: plain {p:.3f}  cluster {c:.3f}")
