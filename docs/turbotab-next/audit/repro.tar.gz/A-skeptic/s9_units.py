import sys, numpy as np, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
from turbotab.core.seal import chronological_holdout
rng = np.random.default_rng(4)
G = 300; ids=[]; ts=[]
for u in range(G):
    start = rng.uniform(0, 60); k = rng.integers(2, 6)
    v = start + np.sort(rng.uniform(0, 40, k))       # visits spread over up to 40 time units
    ids += [u]*k; ts += list(v)
ids = np.array(ids); ts = np.array(ts)
mask, chron = chronological_holdout(ts, ids, 0.2, 0, "visit", dated=False)
print(chron.sentence)
th, tt = ts[mask], ts[~mask]
print(f"held-out rows {mask.sum()} of {len(ts)}; share of held-out rows before the latest training row {np.mean(th < tt.max()):.2f}; before the median training row {np.mean(th < np.median(tt)):.2f}; earliest held-out {th.min():.1f} vs latest training {tt.max():.1f}")
