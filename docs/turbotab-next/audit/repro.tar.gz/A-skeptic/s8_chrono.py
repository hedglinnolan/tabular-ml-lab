import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
from turbotab.core.seal import chronological_holdout
from turbotab.core.stages.rows import draw_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import HistGradientBoostingRegressor
rng = np.random.default_rng(9); n = 1200
t = rng.uniform(0, 10, n)
x = rng.normal(size=(n, 3)); x[:, 2] += 0.3*t            # x2 trends with time (e.g. a secular intake trend)
y = 0.6*x[:, 0] + 0.4*np.sin(t*2.0) + rng.normal(size=n)   # outcome has a non-stationary time component
held, chron = chronological_holdout(t, None, 0.2, 0, "year", dated=False)
frame, info = draw_split(np.arange(n), holdout=0.2, seed=0, folds=5, held=held)
tr = frame.sort_values("row_id")["partition"].eq("train").to_numpy(); fold = frame.sort_values("row_id")["fold"].to_numpy()
print("fold time ranges:", [(round(t[tr&(fold==k)].min(),1), round(t[tr&(fold==k)].max(),1)) for k in range(info["folds"])])
def r2_trainmean(yt, p, ytr): return 1 - ((yt-p)**2).sum()/((yt-ytr.mean())**2).sum()
for name, M in (("linear", LinearRegression), ("boosted", lambda: HistGradientBoostingRegressor(random_state=0))):
    sse=sst=0
    for k in range(info["folds"]):
        a, b = tr&(fold!=k), tr&(fold==k); m = M().fit(x[a], y[a]); p = m.predict(x[b])
        sse += ((y[b]-p)**2).sum(); sst += ((y[b]-y[a].mean())**2).sum()
    rc = 1-sse/sst
    idx = np.flatnonzero(tr)[np.argsort(t[tr])]; bl = np.array_split(idx, 6); sse=sst=0
    for j in range(1,6):
        a = np.concatenate(bl[:j]); b = bl[j]; m = M().fit(x[a], y[a]); p = m.predict(x[b])
        sse += ((y[b]-p)**2).sum(); sst += ((y[b]-y[a].mean())**2).sum()
    rf = 1-sse/sst
    m = M().fit(x[tr], y[tr]); rh = r2_trainmean(y[~tr], m.predict(x[~tr]), y[tr])
    print(f"{name:8s}: random-fold CV R2 {rc:.3f} | forward-chaining CV R2 {rf:.3f} | chronological holdout R2 {rh:.3f}")
