import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
rng = np.random.default_rng(8); p=5; beta=np.ones(p); sig=np.sqrt(p*4)
a=[];b=[];tr=[]
for _ in range(3000):
    X=rng.normal(size=(300,p)); y=X@beta+sig*rng.normal(size=300)
    m=LinearRegression().fit(X[:240],y[:240]); pr=m.predict(X[240:]); yt=y[240:]
    a.append(r2_score(yt,pr)); b.append(1-((yt-pr)**2).sum()/((yt-y[:240].mean())**2).sum())
    mse=sig**2+((m.coef_-beta)**2).sum()+m.intercept_**2; tr.append(1-mse/(p+sig**2))
print(f"holdout 60: R2 vs holdout mean {np.mean(a):.3f}; vs training mean {np.mean(b):.3f}; target (fresh-sample R2 of this model) {np.mean(tr):.3f}")
