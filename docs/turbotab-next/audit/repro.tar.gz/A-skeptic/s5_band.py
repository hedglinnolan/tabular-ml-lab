import sys, numpy as np, pandas as pd, warnings, time
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
from sklearn.linear_model import LinearRegression
import statsmodels.api as sm
from turbotab.core.methods.substitution import Shift, refit_band, substitution_curve
from turbotab.core.stages.modeling import SUBSTITUTION_ROWS, BAND_ROWS, BAND_BOOT
print("BAND_ROWS", BAND_ROWS, "BAND_BOOT", BAND_BOOT, "SUBSTITUTION_ROWS", SUBSTITUTION_ROWS)
KPU = {"fat_g": 9.0, "carb_g": 4.0}
bf, bc = 0.02, 0.01
TRUE = 100*(bc/4 - bf/9)
def data(n, rng):
    E = rng.normal(2100, 450, n).clip(900, None)
    fat = E*0.33/9*rng.lognormal(0, .3, n); carb = E*0.5/4*rng.lognormal(0, .25, n)
    X = pd.DataFrame({"fat_g": fat, "carb_g": carb, "energy_kcal": E}, index=np.arange(n))
    y = 3 + bf*fat + bc*carb + 0.002*E + rng.normal(0, 4, n)
    return X, y
fp = lambda Xb, yb: LinearRegression().fit(Xb, yb).predict
ks = [0.0, 100.0]
def app_band(X, y, B, seed=0):
    N = len(X); model = LinearRegression().fit(X, y)
    cur = np.arange(N) if N <= SUBSTITUTION_ROWS else np.sort(np.random.default_rng(0).choice(N, SUBSTITUTION_ROWS, replace=False))
    Xc = X.iloc[cur]
    curve = substitution_curve(model.predict, Xc, donor="fat_g", recipient="carb_g", kcal_per_unit=KPU, ks=ks)
    bid = cur if len(cur) <= BAND_ROWS else np.sort(np.random.default_rng(1).choice(cur, BAND_ROWS, replace=False))
    shift = Shift(Xc, donor="fat_g", recipient="carb_g", kcal_per_unit=KPU)
    b = refit_band(fp, X.iloc[bid], y[bid], shift=shift, ks=ks, live=curve["live"], n_boot=B, random_state=seed, center=curve["delta"])
    return curve["delta"][1], b["ci_low"][1], b["ci_high"][1]
# (1) width vs analytic SE at N=10,000
rng = np.random.default_rng(42); X, y = data(10_000, rng)
r = sm.OLS(y, sm.add_constant(X)).fit()
c = np.array([0, -100/9, 100/4, 0]); se = float(np.sqrt(c @ r.cov_params().to_numpy() @ c))
d, lo, hi = app_band(X, y, BAND_BOOT)
print(f"N=10000: OLS SE of delta(100) {se:.4f} -> correct half-width {1.96*se:.4f}; app band half-width {(hi-lo)/2:.4f}; ratio {(hi-lo)/2/(1.96*se):.2f}; sqrt(N/2000)={np.sqrt(5):.2f}")
# (2) coverage at N=10,000 (40 datasets) and N=1500 B=50 (300 datasets)
t=time.time(); h=0
for s in range(40):
    X, y = data(10_000, np.random.default_rng(1000+s)); d, lo, hi = app_band(X, y, 50); h += lo<=TRUE<=hi
print(f"N=10000 B=50 coverage {h/40:.3f} (40 datasets) [{time.time()-t:.0f}s]")
for B, reps in ((50, 300), (500, 60)):
    t=time.time(); h=0
    for s in range(reps):
        X, y = data(1500, np.random.default_rng(5000+s)); d, lo, hi = app_band(X, y, B); h += lo<=TRUE<=hi
    print(f"N=1500 B={B} coverage {h/reps:.3f} over {reps} (MC SE {np.sqrt(.95*.05/reps):.3f}) [{time.time()-t:.0f}s]")
# theoretical: expected coverage of np.percentile 2.5/97.5 interval of B draws for a new draw
for B in (50, 200, 1000):
    pl, ph = 0.025*(B-1)+1, 0.975*(B-1)+1
    print(f"B={B}: percentile interval spans order stats {pl:.3f}..{ph:.3f} -> expected content {(ph-pl)/(B+1):.3f}")
