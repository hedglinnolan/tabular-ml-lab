import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
from turbotab.core.models.linear import statsmodels_fit
import statsmodels.api as sm
def run(n, kind, reps=800, seed=7):
    rng = np.random.default_rng(seed); a=h=0
    for _ in range(reps):
        x = rng.lognormal(0, 0.6, n)            # skewed intake
        z = rng.normal(size=n)                  # a covariate
        sd = x if kind=="sd" else np.sqrt(x)
        y = 0.5*z + sd*rng.normal(size=n)       # null slope on x
        M = pd.DataFrame({"x": x, "z": z})
        r = statsmodels_fit("regression", M, y, None, None)     # the app's call
        lo, hi = r.conf_int(0.05).loc["x"]; a += lo<=0<=hi
        r3 = sm.OLS(y, sm.add_constant(M)).fit(cov_type="HC3")
        lo, hi = r3.conf_int(0.05).loc["x"]; h += lo<=0<=hi
    return a/reps, h/reps
for kind in ("sd","var"):
    for n in (50, 200, 1000):
        print(kind, n, run(n, kind))
