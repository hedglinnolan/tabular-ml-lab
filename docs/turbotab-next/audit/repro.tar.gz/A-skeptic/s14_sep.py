import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core.models.linear import statsmodels_fit, statsmodels_rows
from turbotab.core.stages.modeling import _concerns
import statsmodels; print("statsmodels", statsmodels.__version__)
rng = np.random.default_rng(2); n = 300
exposed = (rng.random(n) < 0.08).astype(float)
age = rng.normal(50, 10, n)
y = np.where(exposed == 1, 1, (rng.random(n) < 1/(1+np.exp(-(-1 + 0.02*(age-50))))).astype(int))
M = pd.DataFrame({"exposed": exposed, "age": age})
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter("always")
    r = statsmodels_fit("binary", M, y, [0, 1], None)
for w in caught: print("WARN:", w.category.__name__, "|", str(w.message)[:120])
for row in statsmodels_rows("binary", r, [0, 1]): print(row)
print("concerns from these warnings:", _concerns(caught, 6))
