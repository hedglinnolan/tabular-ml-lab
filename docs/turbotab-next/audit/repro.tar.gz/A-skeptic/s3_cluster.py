import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
from turbotab.core.models.linear import statsmodels_fit
from scipy import stats
rng = np.random.default_rng(3)
G, per = 10, 20
g = np.repeat(np.arange(G), per)
x = rng.normal(size=G)[g] + 0.3*rng.normal(size=G*per); y = rng.normal(size=G)[g] + rng.normal(size=G*per)
r = statsmodels_fit("regression", pd.DataFrame({"x": x}), y, None, g)
lo, hi = r.conf_int(0.05).loc["x"]
print("use_t", r.use_t, "| half-width/SE", round((hi-lo)/2/r.bse['x'],4), "| t(G-1) crit", round(stats.t.ppf(.975,G-1),4))
yb = (y > 0).astype(int)
rb = statsmodels_fit("binary", pd.DataFrame({"x": x}), yb, [0,1], g)
lo, hi = rb.conf_int(0.05).loc["x"]; print("Logit use_t", rb.use_t, "half-width/SE", round((hi-lo)/2/rb.bse['x'],4))
def cover(G, per=20, reps=800):
    rng = np.random.default_rng(100+G); a=t=0
    for _ in range(reps):
        g = np.repeat(np.arange(G), per)
        x = rng.normal(size=G)[g] + 0.3*rng.normal(size=G*per)
        y = rng.normal(size=G)[g] + rng.normal(size=G*per)
        r = statsmodels_fit("regression", pd.DataFrame({"x": x}), y, None, g)
        b, s = r.params["x"], r.bse["x"]
        a += abs(b) <= 1.959964*s; t += abs(b) <= stats.t.ppf(.975, G-1)*s
    return a/reps, t/reps
for G in (8, 12, 20, 30, 50):
    print(G, cover(G))
