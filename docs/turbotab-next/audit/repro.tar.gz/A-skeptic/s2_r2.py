import numpy as np
from sklearn.model_selection import KFold
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
rng = np.random.default_rng(5)
p = 5; beta = np.ones(p); 
# pop R2 0.20: var(xb)=p=5 -> noise var = 5*(0.8/0.2)=20
sig = np.sqrt(p*0.8/0.2)
def one(n):
    X = rng.normal(size=(n,p)); y = X@beta + sig*rng.normal(size=n)
    per=[]; sse=0; sst_tr=0; sst_te=0
    for tr, te in KFold(5, shuffle=True, random_state=0).split(X):
        m = LinearRegression().fit(X[tr], y[tr]); pr = m.predict(X[te])
        per.append(r2_score(y[te], pr)); sse += ((y[te]-pr)**2).sum()
        sst_tr += ((y[te]-y[tr].mean())**2).sum(); sst_te += ((y[te]-y[te].mean())**2).sum()
    # true out-of-sample R2 of model fit on 80% of n (fresh large sample), approx analytically
    tr = rng.choice(n, int(0.8*n), replace=False)
    m = LinearRegression().fit(X[tr], y[tr])
    # population: E[(y - f)^2] = sig^2 + ||b - bhat||^2 + intercept^2 ; var(y)=p+sig^2
    mse = sig**2 + ((m.coef_-beta)**2).sum() + m.intercept_**2
    true80 = 1 - mse/(p+sig**2)
    m = LinearRegression().fit(X, y); mse = sig**2 + ((m.coef_-beta)**2).sum() + m.intercept_**2
    truefull = 1 - mse/(p+sig**2)
    return np.mean(per), 1-sse/sst_tr, 1-sse/sst_te, true80, truefull
for n in (60,100,300,1000):
    r = np.array([one(n) for _ in range(1000 if n<1000 else 300)])
    m = r.mean(0)
    print(f"n={n:5d}: mean per-fold {m[0]:.3f} | pooled(train-mean ref) {m[1]:.3f} | pooled(test-mean ref) {m[2]:.3f} | target(80%) {m[3]:.3f} | target(full n) {m[4]:.3f} | sd per-fold-mean {r[:,0].std():.3f}")
