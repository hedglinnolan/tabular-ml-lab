import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core import seal, repairs  # noqa
import turbotab.core.sequence  # noqa
from turbotab.core.decisions import ProjectState, Refusal, validate
for purpose in ("prediction", "inference"):
    st = ProjectState(lens=["clinical"], target="hba1c", task="regression", purpose=purpose,
                      grain={"grain": "repeated", "id_column": "pid"},
                      repeat_kind={"repeat_kind": "time_points", "time_column": "visit_date"}, unit="unit")
    structure = {"outcome": {"column": "hba1c", "varies": True, "n_units_varying": 80, "numeric": True}}
    ctx = {"columns": ["pid", "visit_date", "ldl", "hba1c"], "state": st, "target": "hba1c", "task": "regression",
           "column_info": {"hba1c": {"dtype": "numeric", "n_unique": 300, "n_missing": 0}},
           "artifact": lambda s: structure if s == "structure" else None}
    for m, o in [("last", "first"), ("mean", "first"), ("change", "first"), ("last", "mean")]:
        try:
            validate({"kind": "set_aggregation", "method": m, "outcome": o}, ctx); print(f"{purpose}: ACCEPTED predictors={m} outcome={o}")
        except Refusal as r:
            print(f"{purpose}: REFUSED predictors={m} outcome={o}: {r.code}")
