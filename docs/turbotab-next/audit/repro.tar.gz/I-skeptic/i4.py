import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *
def main():
    with client("i4") as c:
        pid = open_path(c, FX / "survey.csv")
        ans = {"lens": {"kind": "set_lens", "lenses": ["dietary", "survey"]},
               "target": {"kind": "set_target", "column": "LBXCRP"},
               "purpose": {"kind": "set_purpose", "purpose": "inference"},
               "models": {"kind": "select_models", "models": ["linear"]}}
        v, asked = walk(c, pid, ans, stop_before="split")
        wait_for(c, pid, {"seal_plan": "fresh"}, timeout=120)
        plan = art(c, pid, "seal_plan"); print("split options:", [o["label"] for o in plan["options"]])
        v, asked2 = walk(c, pid, ans, stop_before="open_seal")
        print("questions asked:", [k for k, _, _ in asked + asked2])
        print("roles:", v["state"]["roles"])
        wait_for(c, pid, {"fit": "fresh"}, timeout=240)
        fit = art(c, pid, "fit"); m = fit["models"][0]
        print("n_train", fit["n_train"], "n_holdout", fit["n_holdout"], "concerns", m.get("concerns"))
        for r in m.get("coefficients") or []: print("  ", r)
        f = art(c, pid, "findings"); print("findings:", [x.get("id") for x in f.get("findings", [])])
        d = art(c, pid, "design"); print("design steps:", json.dumps(d)[:600])
if __name__ == "__main__":
    import pandas as pd, numpy as np, statsmodels.api as sm
    df = pd.read_csv(FX / "survey.csv")
    X = sm.add_constant(df[["DR1TKCAL", "DR1TFIBE"]])
    ols = sm.OLS(df.LBXCRP, X).fit()
    print("unweighted OLS fiber %.4f CI %s" % (ols.params.DR1TFIBE, ols.conf_int().loc["DR1TFIBE"].round(4).tolist()))
    cl = (df.SDMVSTRA * 10 + df.SDMVPSU).to_numpy()
    wls = sm.WLS(df.LBXCRP, X, weights=df.WTDRD1).fit(cov_type="cluster", cov_kwds={"groups": cl})
    print("weighted, PSU-within-stratum clustered fiber %.4f CI %s" % (wls.params.DR1TFIBE, wls.conf_int().loc["DR1TFIBE"].round(4).tolist()))
    main()
