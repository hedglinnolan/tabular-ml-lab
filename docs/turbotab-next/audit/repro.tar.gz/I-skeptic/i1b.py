import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *
def main():
    with client("i1b") as c:
        pid = open_path(c, FX / "bmi.csv")
        ans = {"lens": {"kind": "set_lens", "lenses": ["dietary"]},
               "target": {"kind": "set_target", "column": "bmi"},
               "purpose": {"kind": "set_purpose", "purpose": "prediction"}}
        v, _ = walk(c, pid, ans, stop_before="exclusions", log=False)
        d = {"kind": "set_exclusions", "rules": [{"column": "bmi", "low": 18.5, "high": 30, "reason": "normal range"}]}
        pj = c.post(f"/api/projects/{pid}/preview", json=d).json()
        print("basis:", pj.get("basis")); print("note:", pj.get("note")); print("caution:", pj.get("caution"))
        print([ (vw.get("title"), vw.get("before_label")) for vw in pj["views"]])
        code, body = decide(c, pid, d); print("prediction purpose, decide ->", code)
        v = view(c, pid)
        recs = v.get("record") or v.get("records") or v.get("decisions")
        print("view keys:", list(v.keys()))
        log = c.get(f"/api/projects/{pid}/decisions").json()
        print(str(log)[-600:])
import pandas as pd, statsmodels.formula.api as smf
if __name__ == "__main__":
    df = pd.read_csv(FX / "bmi.csv")
    for lab, d in [("all", df), ("18.5-30", df[(df.bmi >= 18.5) & (df.bmi <= 30)])]:
        r = smf.ols("bmi ~ age + fiber_g", d).fit(); print(lab, len(d), r.params["fiber_g"].round(4), r.conf_int().loc["fiber_g"].round(4).tolist())
    main()
