import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *
import pandas as pd, pyarrow.parquet as pq, glob

def sealed_ids(c, pid):
    wait_for(c, pid, {"split": "fresh"}, timeout=200)
    st = view(c, pid)["stages"]["split"]
    files = glob.glob(str(S / "home_i2" / "**" / "split" / st["key"] / "frames" / "sealed.parquet"), recursive=True)
    return set(pd.read_parquet(files[0])["row_id"].tolist()), st["key"]

def main():
    with client("i2") as c:
        pid = open_path(c, FX / "sbp_imp.csv")
        ans = {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
               "target": {"kind": "set_target", "column": "sbp"},
               "purpose": {"kind": "set_purpose", "purpose": "prediction"},
               "models": {"kind": "select_models", "models": ["linear"]}}
        v, asked = walk(c, pid, ans, stop_before="open_seal", log=True)
        wait_for(c, pid, {"fit": "fresh"}, timeout=240)
        before, k1 = sealed_ids(c, pid)
        f = art(c, pid, "findings")
        imp = [x for x in f.get("findings", []) if "impossible" in (x.get("id") or x.get("code") or "")]
        print("impossible findings:", [(x.get("id"), x.get("disposition")) for x in imp])
        opts = imp[0]["repairs"] if imp else []
        for o in opts: print("  option:", o["key"], o["label"], "|", o["consequence"], "| effect", o["effect"])
        sm = next(o for o in opts if o["key"] == "set_missing")
        print("  decision:", json.dumps(sm["decision"])[:300])
        pv = c.post(f"/api/projects/{pid}/preview", json=sm["decision"]).json()
        print("  preview note/caution:", pv.get("note"), pv.get("caution"))
        code, body = decide(c, pid, sm["decision"])
        print("apply_repair set_missing on the outcome after split+fit ->", code, str(body)[:200] if code != 200 else "")
        after, k2 = sealed_ids(c, pid)
        print("split key changed:", k1 != k2)
        print("held-out before", len(before), "after", len(after), "kept", len(before & after),
              "moved held-out->training", len(before - after - {7, 333, 801}))
        v = view(c, pid)
        print("interview split:", next(s for s in v["interview"] if s["key"] == "split"))
        print("decisions sentences:", [d.get("sentence") for d in v["decisions"]][-2:])
        sp = art(c, pid, "split"); print("split note:", sp.get("note"), "| basis", sp.get("basis"))

if __name__ == "__main__":
    main()
