import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *

def main():
    with client("i1") as c:
        pid = open_path(c, FX / "bmi.csv")
        ans = {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
               "target": {"kind": "set_target", "column": "bmi"},
               "purpose": {"kind": "set_purpose", "purpose": "inference"}}
        v, _ = walk(c, pid, ans, stop_before="exclusions")
        st = next(s for s in v["interview"] if s["key"] == "exclusions"); print("exclusions step:", st["status"])
        # what the exclusions question offers
        pr = art(c, pid, "proposals"); print("proposals.exclusions keys:", list((pr.get("exclusions") or {}).keys())[:10])
        print("proposed exclusions:", json.dumps(pr.get("exclusions"))[:800])
        d = {"kind": "set_exclusions", "rules": [{"column": "bmi", "low": 18.5, "high": 30, "reason": "normal range"}]}
        p = c.post(f"/api/projects/{pid}/preview", json=d)
        print("preview status", p.status_code)
        pj = p.json()
        print("preview keys:", list(pj.keys()))
        for vw in pj.get("views", []):
            print(" VIEW", vw.get("kind") or vw.get("type"), "|", vw.get("title"), "|", vw.get("caption"), "| column:", vw.get("column"))
            if vw.get("column") == "bmi":
                print("   before counts:", (vw.get("before") or {}).get("counts")[:30], "edges0..", (vw.get("before") or {}).get("edges")[:3])
                print("   marks:", vw.get("marks")); print("   notes:", vw.get("notes"))
        print("refusal in preview:", pj.get("refusal"))
        code, body = decide(c, pid, d)
        print("DECIDE exclusions on outcome ->", code, str(body)[:300])
        v = view(c, pid)
        print("record sentence:", [r.get("sentence") for r in v.get("records", [])][-1:] if v.get("records") else None)
        v, _ = walk(c, pid, {"models": {"kind": "select_models", "models": ["linear"]},
                             "split": {"kind": "set_split", "holdout": 0, "seed": 0, "folds": 5},
                             "missing": {"kind": "set_missing", "strategy": "complete_case"}}, stop_before="open_seal")
        wait_for(c, pid, {"fit": "fresh"}, timeout=240)
        fit = art(c, pid, "fit")
        m = fit["models"][0]
        print("n_train", fit["n_train"], "concerns", m.get("concerns"))
        for r in m.get("coefficients") or []:
            print("  ", r)
        f = c.get(f"/api/projects/{pid}/stages/findings").json().get("artifact") or {}
        print("findings:", [x.get("code") or x.get("id") for x in (f.get("findings") or [])])

if __name__ == '__main__':
    main()
