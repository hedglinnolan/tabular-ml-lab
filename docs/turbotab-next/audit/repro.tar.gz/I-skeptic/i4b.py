import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *
def main():
    with client("i4") as c:
        pids = c.get("/api/projects").json()
        pid = (pids.get("projects") if isinstance(pids, dict) else pids)[0]["id"]
        f = art(c, pid, "findings")
        for x in f.get("findings", []):
            if "survey" in x.get("id", ""):
                print(json.dumps(x, indent=1)[:3000])
if __name__ == "__main__":
    main()
