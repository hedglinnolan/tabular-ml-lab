import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *
def main():
    with client("i3") as c:
        pid = open_path(c, FX / "tte.csv")
        ans = {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
               "target": {"kind": "set_target", "column": "cvd_event"},
               "purpose": {"kind": "set_purpose", "purpose": "inference"},
               "split": {"kind": "set_split", "holdout": 0, "seed": 0, "folds": 5},
               "models": {"kind": "select_models", "models": ["linear"]}}
        v, asked = walk(c, pid, ans, stop_before="open_seal")
        for s in notasked(v): print("  NOT ASKED:", s[0], s[1], (s[2] or "")[:110])
        print("roles:", v["state"]["roles"])
        rl = art(c, pid, "roles")
        for col in rl.get("columns", []):
            if col["column"] == "followup_years": print("followup proposal:", col)
        wait_for(c, pid, {"fit": "fresh"}, timeout=240)
        fit = art(c, pid, "fit"); m = fit["models"][0]
        print("task:", fit["task"], "n_train", fit["n_train"], "concerns", m.get("concerns"))
        for r in m.get("coefficients") or []: print("  ", r)
        f = art(c, pid, "findings"); print("findings:", [x.get("id") for x in f.get("findings", [])])
if __name__ == "__main__":
    import pandas as pd, numpy as np, statsmodels.api as sm
    from statsmodels.duration.hazard_regression import PHReg
    df = pd.read_csv(FX / "tte.csv")
    X = df[["age", "fiber_g"]]
    lg = sm.Logit(df.cvd_event, sm.add_constant(X)).fit(disp=0)
    print("events", df.cvd_event.sum(), "/", len(df), "followup range", df.followup_years.min(), df.followup_years.max())
    print("logit fiber: %.4f CI %s p=%.2g" % (lg.params.fiber_g, lg.conf_int().loc["fiber_g"].round(4).tolist(), lg.pvalues.fiber_g))
    cx = PHReg(df.followup_years, X, status=df.cvd_event).fit(); ci = cx.conf_int()
    print("Cox log-HR fiber: %.4f CI [%.4f, %.4f] p=%.2g" % (cx.params[1], ci[1][0], ci[1][1], cx.pvalues[1]))
    main()
