import numpy as np, pandas as pd
rng = np.random.default_rng(2026)
FX = "/private/tmp/turbotab-audit/I-skeptic/fx/"
# I1: BMI outcome; fiber exposure true slope -0.25 per g
n = 4000
age = rng.normal(50, 10, n).round(0)
fiber = rng.gamma(4, 5, n).round(1)
bmi = (27 - 0.25 * (fiber - 20) + 0.03 * (age - 50) + rng.normal(0, 5, n)).round(1)
pd.DataFrame({"participant_id": [f"P{i:05d}" for i in range(n)], "age": age, "fiber_g": fiber, "bmi": bmi}
             ).to_csv(FX + "bmi.csv", index=False)
# I3: staggered entry; fiber has HR=1; later entrants eat more fiber and are followed less
n = 3000
entry = rng.uniform(0, 14, n)
fiber = (15 + 1.0 * entry + rng.normal(0, 4, n)).clip(1)
age = rng.normal(55, 8, n)
haz = 0.03 * np.exp(0.04 * (age - 55))
te = rng.exponential(1 / haz)
cens = 15 - entry
t = np.minimum(te, cens); ev = (te <= cens).astype(int)
pd.DataFrame({"participant_id": [f"C{i:05d}" for i in range(n)], "age": age.round(1), "fiber_g": fiber.round(2),
              "followup_years": t.round(3), "cvd_event": ev}).to_csv(FX + "tte.csv", index=False)
# I4: survey, informative weights; slope differs by oversampled group
m = 2400
grp = rng.random(m) < 0.5
w = np.where(grp, 0.25, 1.75) * 9000
strata = rng.integers(1, 16, m); psu = rng.integers(1, 3, m)
kcal = rng.normal(2100, 500, m); fib = rng.gamma(4, 5, m)
slope = np.where(grp, -0.10, 0.02)
crp = 3 + slope * (fib - 20) + 0.4 * grp + rng.normal(0, 1, m)
pd.DataFrame({"SEQN": np.arange(1, m + 1), "DR1TKCAL": kcal.round(1), "DR1TFIBE": fib.round(2), "WTDRD1": w.round(2),
              "SDMVSTRA": strata, "SDMVPSU": psu, "LBXCRP": crp.round(3)}).to_csv(FX + "survey.csv", index=False)
# I5: multisite, sodium null within site, site confounds
n = 700
s = rng.integers(0, 10, n); se = rng.normal(0, 1, 10)[s]
x = rng.normal(0, 1, n) + 0.8 * se
y = 0 * x + 1.5 * se + rng.normal(0, 1, n)
pd.DataFrame({"participant_id": [f"M{i:04d}" for i in range(n)], "site": [f"S{k:02d}" for k in s],
              "sodium_g": (x + 3).round(3), "sbp_change": y.round(3)}).to_csv(FX + "multisite.csv", index=False)
# I9: longitudinal, visit index, no dates; outcome at last visit
k = 300
rows = []
for i in range(k):
    base = rng.normal(130, 12)
    slope = rng.normal(2, 3)
    prog = int(slope > 3)
    for v in (1, 2, 3):
        rows.append({"subject_id": f"S{i:04d}", "visit": v, "sbp": round(base + slope * (v - 1) * 3 + rng.normal(0, 4), 1),
                     "ldl": round(rng.normal(120, 20), 1), "progressed": prog})
pd.DataFrame(rows).to_csv(FX + "long_nodates.csv", index=False)
# I10: ordinal text outcome
n = 800
age = rng.normal(55, 8, n).round(0); fib = rng.gamma(4, 5, n).round(1)
lat = rng.normal(0, 1, n) + 0.03 * (age - 55) - 0.03 * (fib - 20)
sev = pd.cut(lat, [-np.inf, -0.5, 0.5, 1.2, np.inf], labels=["none", "mild", "moderate", "severe"]).astype(str)
pd.DataFrame({"participant_id": [f"O{i:04d}" for i in range(n)], "age": age, "fiber_g": fib, "severity": sev}
             ).to_csv(FX + "ordinal.csv", index=False)
# I2: impossible outcome values
n = 1000
age = rng.normal(55, 10, n).round(0); na = rng.normal(3, 1, n).round(2)
sbp = (110 + 0.5 * (age - 55) + 3 * na + rng.normal(0, 10, n)).round(0)
sbp[[7, 333, 801]] = [999, 0, 1200]
pd.DataFrame({"participant_id": [f"B{i:04d}" for i in range(n)], "age": age, "sodium_g": na, "sbp": sbp}
             ).to_csv(FX + "sbp_imp.csv", index=False)
print("ok")
