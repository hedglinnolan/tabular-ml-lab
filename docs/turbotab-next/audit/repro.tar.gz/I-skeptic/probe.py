import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core import seal, repairs  # registers validators
import turbotab.core.sequence  # noqa
from turbotab.core.decisions import ProjectState, Refusal, validate
def probe(label, d, ctx):
    try:
        validate(d, ctx); print(f"ACCEPTED  {label}")
    except Refusal as r:
        print(f"REFUSED   {label}: {r.code}: {r.message[:140]}")
cols = ["pid", "y", "x1", "x2", "w"]
info = {c: {"dtype": "numeric", "n_unique": 400, "n_missing": 5} for c in cols}
base = dict(lens=["clinical"], target="y", task="regression", purpose="inference",
            roles={"x1": "exposure", "x2": "covariate", "w": "design", "pid": "identifier"})
ctx = lambda st: {"columns": cols, "column_info": info, "state": st, "target": "y", "task": "regression"}
st = ProjectState(**base)
probe("inference: exclusion on outcome y", {"kind": "set_exclusions", "rules": [{"column": "y", "low": 1, "high": 5, "reason": "x"}]}, ctx(st))
probe("inference: impute + indicators", {"kind": "set_missing", "strategy": "impute", "indicators": True}, ctx(st))
probe("inference: impute (single)", {"kind": "set_missing", "strategy": "impute"}, ctx(st))
sealed = ProjectState(**base, split={"holdout": 0.2, "seed": 0, "folds": 5}, grain={"grain": "one_row_per_unit"})
probe("sealed(not opened): set_target x1", {"kind": "set_target", "column": "x1"}, ctx(sealed))
probe("sealed(not opened): set_task y binary", {"kind": "set_task", "column": "y", "task": "regression"}, ctx(sealed))
probe("sealed(not opened): set_grain repeated", {"kind": "set_grain", "grain": "repeated", "id_column": "pid"}, ctx(sealed))
opened = ProjectState(**base, split={"holdout": 0.2, "seed": 0, "folds": 5}, grain={"grain": "one_row_per_unit"}, seal_opened=True)
probe("opened: set_split seed 3", {"kind": "set_split", "holdout": 0.2, "seed": 3, "folds": 5}, ctx(opened))
probe("opened: set_target x1", {"kind": "set_target", "column": "x1"}, ctx(opened))
probe("opened: set_temporal", {"kind": "set_temporal", "temporal": False}, ctx(opened))
from turbotab.core.decisions import SetLens
try:
    SetLens(lenses=[]); print("ACCEPTED empty lens")
except Exception as e: print("REJECTED empty lens list:", str(e).splitlines()[0])
try:
    SetLens(lenses=["none"]); print("ACCEPTED lens none")
except Exception as e: print("REJECTED lens 'none':", str(e).splitlines()[0])
