import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *
SD = Path("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data")
def main():
    with client("i13") as c:
        for name, target in [("clinical_risk.csv", "readmit_30d"), ("clinical_labs.csv", "readmitted")]:
            pid = open_path(c, SD / name)
            ans = {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
                   "target": {"kind": "set_target", "column": target},
                   "purpose": {"kind": "set_purpose", "purpose": "inference"}}
            v, asked = walk(c, pid, ans, stop_before="grain", log=False)
            wait_for(c, pid, {"structure": "fresh"}, timeout=120)
            st = art(c, pid, "structure")
            g = st.get("grain") or {}
            print(name, "grain step:", next(s for s in view(c, pid)["interview"] if s["key"] == "grain")["status"])
            print("  suggested:", g.get("suggested"), "| stated:", g.get("stated"))
            for e in (g.get("evidence") or [])[:6]: print("   evidence:", str(e)[:200])
            if name == "clinical_risk.csv":
                sug = g.get("suggested") or []
                code, body = decide(c, pid, {"kind": "set_grain", "grain": "repeated", "id_column": sug[0]})
                print("  set_grain repeated by", sug[0], "->", code, str(body)[:300] if code != 200 else "")
                v, _ = walk(c, pid, {"models": {"kind": "select_models", "models": ["linear"]}}, stop_before="split", log=True)
                wait_for(c, pid, {"seal_plan": "fresh"}, timeout=120)
                plan = art(c, pid, "seal_plan"); print("  seal basis:", plan.get("basis"), "exploratory:", plan.get("exploratory"))
                print("  roles:", view(c, pid)["state"]["roles"])
if __name__ == "__main__":
    main()
