import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *
import numpy as np, pandas as pd
def main():
    rng = np.random.default_rng(5); n = 600
    pd.DataFrame({"participant_id": [f"Z{i:04d}" for i in range(n)], "age": rng.normal(50, 9, n).round(0),
                  "fiber_g": rng.gamma(4, 5, n).round(1), "hs_crp": np.exp(rng.normal(0.3, 1.1, n)).round(2)}).to_csv(FX / "crp.csv", index=False)
    with client("i10") as c:
        for f, t in [("ordinal.csv", "severity"), ("crp.csv", "hs_crp")]:
            pid = open_path(c, FX / f)
            ans = {"lens": {"kind": "set_lens", "lenses": ["clinical"]}, "target": {"kind": "set_target", "column": t},
                   "purpose": {"kind": "set_purpose", "purpose": "inference"}}
            v, asked = walk(c, pid, ans, stop_before="purpose", log=False)
            ti = art(c, pid, "target_info")
            print(f, "task step:", next(s for s in v["interview"] if s["key"] == "task"))
            print("   target_info task/conf/reason:", ti.get("task"), ti.get("confidence"), ti.get("reason"))
            print("   asked:", [k for k, _, _ in asked])
        x = pd.read_csv(FX / "crp.csv"); print("crp skew:", round(x.hs_crp.skew(), 2))
if __name__ == "__main__":
    main()
