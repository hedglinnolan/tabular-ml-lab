import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *
def main():
    with client("i9") as c:
        pid = open_path(c, FX / "long_nodates.csv")
        ans = {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
               "target": {"kind": "set_target", "column": "progressed"},
               "purpose": {"kind": "set_purpose", "purpose": "prediction"},
               "unit": {"kind": "set_unit", "unit": "unit"}}
        v, asked = walk(c, pid, ans, stop_before="aggregation")
        for s in notasked(v): print("  NOT ASKED:", s[0], s[1], (s[2] or "")[:200])
        st = art(c, pid, "structure"); print("repeats reading:", json.dumps(st.get("repeats"))[:500])
        print("state grain:", v["state"]["grain"])
        # aggregation options
        print("aggregation step:", next(s for s in v["interview"] if s["key"] == "aggregation"))
        for key in ("aggregation",):
            pj = c.post(f"/api/projects/{pid}/preview", json={"kind": "set_aggregation", "method": "mean", "outcome": None}).json()
            for vw in pj.get("views", []):
                print(" VIEW", vw.get("title"), "|", vw.get("caption"), "| notes:", [n.get("text") for n in (vw.get("notes") or [])])
        pr = art(c, pid, "proposals"); print("aggregation proposal:", json.dumps(pr.get("aggregation"))[:600])
        st2 = art(c, pid, "structure"); print("structure aggregation keys:", [k for k in st2.keys()])
        print("structure.aggregation:", json.dumps(st2.get("aggregation"))[:700])
if __name__ == "__main__":
    main()
