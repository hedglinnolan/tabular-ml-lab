"""Independent harness: drive the real server app (TestClient) through the Router."""
import json, os, sys, time
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.server.tests.conftest import make_client, wait_for, usual_answer, _artifact
from turbotab.core.interview import NEEDS

S = Path("/private/tmp/turbotab-audit/I-skeptic")
FX = S / "fx"
FX.mkdir(exist_ok=True)


def client(tag):
    home = S / f"home_{tag}"
    home.mkdir(exist_ok=True)
    return make_client(home, "local", 2, "http://127.0.0.1")


def open_path(c, path):
    r = c.post("/api/projects", json={"path": str(path)}); r.raise_for_status()
    pid = r.json()["id"]
    wait_for(c, pid, {"ingest": "fresh", "profile": "fresh"}, timeout=120)
    return pid


def view(c, pid):
    return c.get(f"/api/projects/{pid}").json()


def walk(c, pid, answers, stop_before=None, timeout=300, log=True):
    end = time.monotonic() + timeout
    asked = []
    while time.monotonic() < end:
        v = view(c, pid)
        first = next((s for s in v["interview"] if s["status"] in ("open", "waiting")), None)
        if first is None:
            return v, asked
        if stop_before and first["key"] == stop_before:
            return v, asked
        unread = [n for n in (*first["waiting_on"], *NEEDS.get(first["key"], ()))
                  if v["stages"].get(n, {}).get("status") not in (None, "fresh")]
        if first["status"] == "waiting" or unread:
            bad = [n for n in unread if v["stages"].get(n, {}).get("status") == "error"]
            if bad:
                raise RuntimeError(f"{bad}: {v['stages'][bad[0]].get('error')}")
            time.sleep(0.1); continue
        a = answers.get(first["key"])
        a = a(c, pid, v) if callable(a) else (a or usual_answer(c, pid, first["key"], v))
        r = c.post(f"/api/projects/{pid}/decisions", json=a)
        asked.append((first["key"], a, r.status_code))
        if log:
            print(f"  ASKED {first['key']:<18} -> {json.dumps(a)[:120]}  [{r.status_code}]")
        if r.status_code != 200:
            print("   refusal:", r.text[:400]); return v, asked
    raise TimeoutError(first)


def decide(c, pid, d):
    r = c.post(f"/api/projects/{pid}/decisions", json=d)
    return r.status_code, (r.json() if r.headers.get("content-type", "").startswith("application/json") else r.text)


def art(c, pid, stage):
    return _artifact(c, pid, stage)


def notasked(v):
    return [(s["key"], s["status"], s.get("reason")) for s in v["interview"]
            if s["status"] in ("skipped", "not_applicable")]
