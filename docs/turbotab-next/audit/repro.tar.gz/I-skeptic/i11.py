import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *
SD = Path("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data")
def scores(c, pid):
    wait_for(c, pid, {"fit": "fresh"}, timeout=240)
    fit = art(c, pid, "fit")
    return {m["family"]: m.get("holdout") for m in fit["models"]}, fit.get("holdout_sealed"), fit.get("changed_after_seal"), fit.get("post_seal_decisions"), fit.get("n_holdout")
def main():
    with client("i11") as c:
        pid = open_path(c, FX / "tte.csv")   # one row per person, binary outcome
        ans = {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
               "target": {"kind": "set_target", "column": "cvd_event"},
               "purpose": {"kind": "set_purpose", "purpose": "prediction"},
               "models": {"kind": "select_models", "models": ["linear"]}}
        v, asked = walk(c, pid, ans, stop_before="open_seal", log=False)
        print("before opening:", scores(c, pid))
        print("open_seal ->", decide(c, pid, {"kind": "open_seal"})[0])
        print("opened:", scores(c, pid))
        for seed in (1, 2, 3):
            code, _ = decide(c, pid, {"kind": "set_split", "holdout": 0.2, "seed": seed, "folds": 5})
            print(f"set_split seed {seed} after opening ->", code, scores(c, pid)[:3])
        code, body = decide(c, pid, {"kind": "set_target", "column": "fiber_g"})
        print("set_target fiber_g after opening ->", code, str(body)[:200] if code != 200 else "")
        s = scores(c, pid); print("  new outcome scores:", s)
        v = view(c, pid)
        print("  open_seal step:", next(x for x in v["interview"] if x["key"] == "open_seal")["status"])
        print("  last sentences:", [d.get("sentence") for d in v["decisions"]][-3:])
        print("  post_seal flags:", [d.get("post_seal") for d in v["decisions"]][-4:])
if __name__ == "__main__":
    main()
