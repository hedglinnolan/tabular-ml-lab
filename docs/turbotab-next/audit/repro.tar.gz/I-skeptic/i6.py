import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *
import numpy as np, pandas as pd
def mk():
    rng = np.random.default_rng(11); n = 1500
    age = rng.normal(55, 8, n).round(0); fib = rng.gamma(4, 5, n)
    y = 5 - 0.05 * (fib - 20) + 0.03 * (age - 55) + rng.normal(0, 1, n)
    fib = fib.round(1); miss = rng.random(n) < 1 / (1 + np.exp(-(y - 5)))  * 0.5
    fib[miss] = np.nan
    pd.DataFrame({"participant_id": [f"Q{i:04d}" for i in range(n)], "age": age, "fiber_g": fib, "crp": y.round(3)}).to_csv(FX / "mar.csv", index=False)
def main():
    mk()
    with client("i6") as c:
        pid = open_path(c, FX / "mar.csv")
        ans = {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
               "target": {"kind": "set_target", "column": "crp"},
               "purpose": {"kind": "set_purpose", "purpose": "inference"},
               "missing": {"kind": "set_missing", "strategy": "impute", "indicators": True},
               "models": {"kind": "select_models", "models": ["linear"]}}
        v, asked = walk(c, pid, ans, stop_before="open_seal")
        wait_for(c, pid, {"fit": "fresh"}, timeout=240)
        d = art(c, pid, "design")
        for p in d.get("pipelines", d.get("models", []))[:1]:
            for s in p.get("steps", []): print("design step:", s)
        fit = art(c, pid, "fit"); m = fit["models"][0]
        print("n_train", fit["n_train"], "concerns", m.get("concerns"))
        for r in m.get("coefficients") or []: print("  ", r)
        print("open_seal step:", next(s for s in view(c, pid)["interview"] if s["key"] == "open_seal"))
if __name__ == "__main__":
    main()
