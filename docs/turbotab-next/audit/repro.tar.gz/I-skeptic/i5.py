import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I-skeptic")
from h import *
def main():
    with client("i5") as c:
        pid = open_path(c, FX / "multisite.csv")
        ans = {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
               "target": {"kind": "set_target", "column": "sbp_change"},
               "purpose": {"kind": "set_purpose", "purpose": "inference"},
               "models": {"kind": "select_models", "models": ["linear"]}}
        v, asked = walk(c, pid, ans, stop_before="open_seal")
        for s in notasked(v): print("  NOT ASKED:", s[0], s[1], (s[2] or "")[:120])
        st = art(c, pid, "structure"); print("grain reading:", json.dumps(st.get("grain"))[:500])
        rl = art(c, pid, "roles")
        for col in rl.get("columns", []):
            if col["column"] == "site": print("site proposal:", col)
        wait_for(c, pid, {"fit": "fresh"}, timeout=240)
        fit = art(c, pid, "fit"); m = fit["models"][0]
        print("n_train", fit["n_train"], "n_holdout", fit["n_holdout"], "concerns", m.get("concerns"))
        for r in m.get("coefficients") or []: print("  ", r)
        sp = art(c, pid, "split"); print("basis:", sp.get("basis"))
        f = art(c, pid, "findings"); print("findings:", [x.get("id") for x in f.get("findings", [])])
if __name__ == "__main__":
    import pandas as pd, statsmodels.formula.api as smf
    df = pd.read_csv(FX / "multisite.csv")
    r0 = smf.ols("sbp_change ~ sodium_g", df).fit()
    r1 = smf.ols("sbp_change ~ sodium_g + C(site)", df).fit(cov_type="cluster", cov_kwds={"groups": df.site.astype("category").cat.codes})
    print("pooled %.3f %s | site FE + cluster %.3f %s" % (r0.params.sodium_g, r0.conf_int().loc["sodium_g"].round(3).tolist(), r1.params.sodium_g, r1.conf_int().loc["sodium_g"].round(3).tolist()))
    main()
