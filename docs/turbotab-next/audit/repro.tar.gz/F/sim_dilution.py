import sys, warnings, numpy as np
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.filterwarnings("ignore")
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedKFold, cross_val_score
from turbotab.core.models.elastic_net import ELASTIC_NET
rng = np.random.default_rng(9)
def pqn_log(X):
    ref = np.median(X, 0); q = np.median(X / ref, 1, keepdims=True); return np.log2(X / q)
raw, norm = [], []
for rep in range(6):
    n, p = 80, 300; y = np.repeat([0, 1], n // 2)
    conc = np.exp(rng.normal(rng.normal(8, 2, p), 0.6, (n, p)))      # no metabolite differs
    dil = np.exp(rng.normal(0, 0.4, n)) * np.where(y == 1, 0.75, 1.0) # cases' urine more dilute
    X = conc * dil[:, None]
    cv = StratifiedKFold(5, shuffle=True, random_state=rep)
    m = lambda: make_pipeline(StandardScaler(), ELASTIC_NET.build("binary", "prediction", 64, p))
    raw.append(cross_val_score(m(), X, y, cv=cv, scoring="roc_auc").mean())
    norm.append(cross_val_score(m(), pqn_log(X), y, cv=cv, scoring="roc_auc").mean())
print("No metabolite differs; cases' samples 25% more dilute (urine).")
print(f"raw intensities (app pipeline): {np.round(raw,2)} mean {np.mean(raw):.2f}")
print(f"PQN + log2, same model:         {np.round(norm,2)} mean {np.mean(norm):.2f}")
