from harness import *
from gen2 import ask
def main():
    src = Path("/private/tmp/turbotab-audit/F/depth_confounded_counts.csv")
    with H() as h:
        d = h.driver("gen")
        d.open(src); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["genomics"]})
        d.reach("target"); d.decide({"kind": "set_target", "column": "condition"})
        fs = findings(d)
        for f in fs: print("FINDING", f["severity"], f["id"], "|", f["summary"][:160])
        ask(d, "event", {"kind": "set_event", "column": "condition", "level": "case"})
        ask(d, "task", {"kind": "set_task", "column": "condition", "task": "binary"})
        ask(d, "purpose", {"kind": "set_purpose", "purpose": "prediction"})
        ask(d, "grain", {"kind": "set_grain", "grain": "one_row_per_unit", "id_column": "sample_id"})
        d.reach("roles"); d.wait("roles", 120); roles = d.accept_roles()
        ask(d, "roles", {"kind": "set_roles", "roles": roles})
        ask(d, "exclusions", {"kind": "set_exclusions", "rules": []})
        ask(d, "missing", {"kind": "set_missing", "strategy": "complete_case"})
        ask(d, "split", {"kind": "set_split", "holdout": 0.0, "seed": 0, "folds": 5})
        d.wait("shelf", 240)
        ask(d, "models", {"kind": "select_models", "models": ["elastic_net"]})
        d.wait("fit", 280)
        fit = d.get("/stages/fit")["artifact"]
        for m in fit["models"]:
            print("MODEL cv auc", m["cv"]["auc"]["mean"], m["cv"]["auc"]["folds"])
            print("  steps", [s["label"] + ": " + s["detail"] for s in m.get("steps", [])][:6])
        rec = d.get("")
        print("RECORD keys", list(rec.keys())[:20])
    import os; os._exit(0)
if __name__ == "__main__": main()
