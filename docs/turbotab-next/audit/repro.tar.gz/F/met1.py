from harness import *
def main():
    src = Path("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data/metabolomics_untargeted.csv")
    with H() as h:
        d = h.driver("met")
        d.open(src); d.wait("ingest")
        d.decide({"kind": "set_lens", "lenses": ["metabolomics"]})
        d.reach("target")
        print("orientation:", steps(d)["orientation"])
        d.decide({"kind": "set_target", "column": "bmi"})
        fs = findings(d)
        for f in fs:
            print(f["severity"], f["id"], "| routes:", f.get("routes_to"), "| repairs:", [r["key"] for r in f.get("repairs", [])])
            print("   ", f["summary"])
        d.answer_the_task("bmi", "regression")
        d.reach("purpose"); d.decide({"kind": "set_purpose", "purpose": "inference"})
        print(steps(d))
        st = d.reach("grain"); print("grain", st["status"])
        if st["status"] in ("open","waiting"):
            d.decide({"kind": "set_grain", "grain": "one_row_per_unit", "id_column": "sample_id"})
        d.reach("roles")
        roles = d.accept_roles()
        from collections import Counter
        print("roles proposed:", Counter(roles.values()), {k:v for k,v in roles.items() if not k.startswith("mz_")})
        d.decide({"kind": "set_roles", "roles": roles})
        d.reach("exclusions"); d.decide({"kind": "set_exclusions", "rules": []})
        d.reach("missing")
        for strat in ("complete_case", "impute"):
            r = d.client.post(f"/api/projects/{d.pid}/preview", json={"kind": "set_missing", "strategy": strat})
            js = r.json()
            print("PREVIEW", strat, r.status_code, json.dumps(js)[:1500])
        json.dump(fs, open("met_findings.json","w"), indent=1)
    
if __name__ == '__main__':
    main()