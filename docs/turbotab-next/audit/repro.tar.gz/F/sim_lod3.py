import numpy as np
from scipy import stats
rng = np.random.default_rng(21)
def qrilc_like(obs):
    p_miss = np.isnan(obs).mean()
    q = np.nanquantile(obs, [0.25, 0.75]); z = stats.norm.ppf(p_miss + (1 - p_miss) * np.array([.25, .75]))
    sd = (q[1] - q[0]) / (z[1] - z[0]); mu = q[0] - sd * z[0]
    b = (np.nanmin(obs) - mu) / sd
    f = obs.copy(); f[np.isnan(f)] = stats.truncnorm.rvs(-np.inf, b, loc=mu, scale=sd, size=int(np.isnan(obs).sum()), random_state=rng); return f
print("slope of y on log-metabolite (truth 0.5), mean of 300 reps, n=300")
print(f"{'censored':>9} {'median':>8} {'half-min':>9} {'QRILC-like':>11} {'detected-only':>14}")
for cens in (0.2, 0.4, 0.6):
    r = {k: [] for k in ("med", "hm", "q", "cc")}
    for _ in range(300):
        L = rng.normal(10, 1, 300); y = 0.5 * (L - 10) + rng.normal(0, 1, 300)
        lod = np.quantile(L, cens); obs = np.where(L >= lod, L, np.nan); m = np.isnan(obs)
        s = lambda x: np.polyfit(x, y, 1)[0]
        r["med"].append(s(np.where(m, np.log(np.nanmedian(np.exp(obs))), obs)))
        r["hm"].append(s(np.where(m, np.log(np.nanmin(np.exp(obs)) / 2), obs)))
        r["q"].append(s(qrilc_like(obs)))
        r["cc"].append(np.polyfit(obs[~m], y[~m], 1)[0])
    print(f"{cens:>9.0%} {np.mean(r['med']):>8.3f} {np.mean(r['hm']):>9.3f} {np.mean(r['q']):>11.3f} {np.mean(r['cc']):>14.3f}")
