import numpy as np, pandas as pd
rng = np.random.default_rng(4)
n = 300
lat = rng.normal(size=n)
def item(probs_shift):
    # 6-point agreement item; top category ~10%
    cuts = np.array([-1.3, -0.5, 0.2, 0.8, 1.4]) + probs_shift
    return 1 + (lat[:, None] + rng.normal(0, 0.8, n)[:, None] > cuts[None, :]).sum(1)
df = pd.DataFrame({"respondent_id": [f"R{i:03d}" for i in range(n)], "age": rng.integers(18, 80, n)})
for k in range(1, 13):
    df[f"wb_{k:02d}"] = item(rng.normal(0, 0.15))
df["outcome"] = (lat + rng.normal(0, 1, n) > 0).astype(int)
df.to_csv("survey_six_point.csv", index=False)
items = df.filter(like="wb_")
print("category shares (pooled):", (items.stack().value_counts(normalize=True).sort_index().round(3)).to_dict())
