from harness import *
from gen2 import ask
def main():
    with H() as h:
        d = h.driver("met")
        d.open(Path("/private/tmp/turbotab-audit/F/met_class_qc.csv")); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["metabolomics"]})
        d.reach("target"); d.decide({"kind": "set_target", "column": "Class"})
        for f in findings(d):
            if f["severity"] in ("critical", "warning") or "qc" in f["id"] or "role" in f["id"]:
                print(f["severity"], f["id"], "|", f["summary"], "| routes:", f.get("routes_to"), "| detail:", f["detail"][:300].replace("\n"," "))
        st = d.reach("task"); print("task step:", st["status"], st.get("reason"))
        code, body = try_post(d, {"kind": "set_task", "column": "Class", "task": "binary"})
        print("binary task:", code, json.dumps(body)[:500])
        code, body = try_post(d, {"kind": "set_exclusions", "rules": [{"kind": "range", "column": "Class", "low": 0, "reason": "drop QC"}]})
        print("exclude by text level:", code, json.dumps(body)[:400])
    import os; os._exit(0)
if __name__ == "__main__": main()
