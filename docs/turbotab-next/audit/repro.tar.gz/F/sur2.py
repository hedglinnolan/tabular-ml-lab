from harness import *
def main():
    with H() as h:
        d = h.driver("sur")
        d.open(Path("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data/survey_instrument.csv")); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["survey"]})
        d.reach("target"); d.decide({"kind": "set_target", "column": "item_01"})
        d.wait("target_info", 120); time.sleep(0.5)
        st = d.reach("task", 60)
        print("task step for 1-5 Likert outcome:", st["status"], "|", st.get("reason"))
        ti = d.get("/stages/target_info")["artifact"]
        print("target_info:", {k: ti.get(k) for k in ("task", "confidence", "reason")})
    import os; os._exit(0)
if __name__ == "__main__": main()
