import numpy as np
rng = np.random.default_rng(1)
n = 200000
x = rng.normal(size=n)
lam = 0.70
u = rng.normal(scale=np.sqrt(1/lam - 1), size=n)   # var(w)=1/lam, reliability = 1/(1/lam)=lam
w = x + u
beta_std = 0.30
y = beta_std * x + rng.normal(scale=np.sqrt(1 - beta_std**2), size=n)
b_unstd = np.cov(w, y)[0,1] / np.var(w)
b_std = np.corrcoef(w, y)[0,1]
print(f"reliability={np.var(x)/np.var(w):.3f}")
print(f"true standardized coef 0.30; observed unstandardized slope on W: {b_unstd:.3f} (0.30*lam={0.30*lam:.3f})")
print(f"observed standardized coef (corr): {b_std:.3f} (0.30*sqrt(lam)={0.30*np.sqrt(lam):.3f})")
