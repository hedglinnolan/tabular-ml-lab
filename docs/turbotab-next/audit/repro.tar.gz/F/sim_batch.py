import numpy as np
rng = np.random.default_rng(12)
est_no, est_with = [], []
for _ in range(500):
    n = 120
    batch = rng.integers(0, 2, n)
    y = 25 + 3 * batch + rng.normal(0, 4, n)          # BMI higher in batch 2 (recruited later / different site)
    logm = 10 + 0.8 * batch + rng.normal(0, 1, n)       # batch shifts intensity; metabolite unrelated to BMI
    X0 = np.column_stack([np.ones(n), logm]); X1 = np.column_stack([X0, batch])
    est_no.append(np.linalg.lstsq(X0, y, rcond=None)[0][1]); est_with.append(np.linalg.lstsq(X1, y, rcond=None)[0][1])
print(f"true metabolite effect 0; batch left out (app default role 'design'): mean slope {np.mean(est_no):.2f}")
print(f"batch as covariate:                                              mean slope {np.mean(est_with):.2f}")
