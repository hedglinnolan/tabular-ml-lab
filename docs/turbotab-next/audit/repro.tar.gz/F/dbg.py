from harness import *
import threading
src = Path("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data/metabolomics_untargeted.csv")
def watchdog():
    time.sleep(90); print("WATCHDOG timeout", flush=True); os._exit(3)
threading.Thread(target=watchdog, daemon=True).start()
with H() as h:
    d = h.driver("met")
    d.open(src); print("opened", flush=True)
    d.wait("ingest", 60); print("ingested", flush=True)
    d.decide({"kind": "set_lens", "lenses": ["metabolomics"]}); print("lens", flush=True)
    for i in range(20):
        s = d.get("")["interview"]
        print([(x["key"], x["status"]) for x in s][:6], flush=True)
        time.sleep(1)
    os._exit(0)
