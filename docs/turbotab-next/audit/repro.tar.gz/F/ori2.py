from harness import *
def main():
    with H() as h:
        d = h.driver("ori")
        d.open(Path("/private/tmp/turbotab-audit/F/mzmine_style_export.csv")); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["metabolomics"]})
        d.reach("target")
        code, body = try_post(d, {"kind": "set_orientation", "orientation": "feature_major"})
        print("set_orientation:", code)
        d.wait("oriented", 120)
        ori = d.get("/stages/oriented")["artifact"]
        print("oriented n_rows:", ori.get("n_rows"), "turn:", {k: ori.get("turn", {}).get(k) for k in ("label_column", "n_samples", "n_features")})
        tab = d.get("/table", offset=0, limit=100, columns="sample_id")
        rows = tab.get("rows") or tab.get("data") or tab
        print("sample ids:", str(rows)[:200], "...", str(rows)[-300:])
    import os; os._exit(0)
if __name__ == "__main__": main()
