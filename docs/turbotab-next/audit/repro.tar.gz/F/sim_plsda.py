import numpy as np, warnings
from sklearn.cross_decomposition import PLSRegression
warnings.filterwarnings("ignore")
rng = np.random.default_rng(0)
n = 40
print("n=40 pure-noise samples, random labels; share of 50 draws where a PLS-DA fit separates training labels perfectly")
for ncomp in (2, 3):
    row = []
    for p in (10, 20, 40, 60, 80, 160, 400):
        hits = 0
        for _ in range(50):
            X = rng.normal(size=(n, p)); y = rng.permutation(np.repeat([-1.0, 1.0], n // 2))
            f = PLSRegression(n_components=ncomp, scale=True).fit(X, y).predict(X).ravel()
            hits += int(np.all(np.sign(f) == y))
        row.append(f"p/n={p/n:.2f}:{hits/50:.0%}")
    print(f" {ncomp} components:", "  ".join(row))
