"""Raw counts into the app's own elastic-net pipeline (StandardScaler -> LogisticRegressionCV), when
sequencing depth differs by outcome and NO gene is differentially expressed. Compare log-CPM input."""
import sys, time, warnings, numpy as np
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.filterwarnings("ignore")
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import StratifiedKFold, cross_val_score
from turbotab.core.models.elastic_net import ELASTIC_NET
rng = np.random.default_rng(3)
def counts(n=60, p=300, depth_ratio=1.5):
    y = np.repeat([0, 1], n // 2)
    base = np.exp(rng.normal(3, 1.5, p))                      # gene means
    lib = np.exp(rng.normal(0, 0.25, n)) * np.where(y == 1, depth_ratio, 1.0)
    mu = lib[:, None] * base[None, :]
    disp = 0.2
    lam = rng.gamma(1 / disp, mu * disp)                      # NB via gamma-Poisson
    return rng.poisson(lam).astype(float), y
def logcpm(X):
    return np.log2((X + 0.5) / (X.sum(1, keepdims=True) + 1) * 1e6)
t = time.time(); raw, lc = [], []
for rep in range(6):
    X, y = counts()
    cv = StratifiedKFold(5, shuffle=True, random_state=rep)
    model = lambda: make_pipeline(StandardScaler(), ELASTIC_NET.build("binary", "prediction", 48, X.shape[1]))
    raw.append(cross_val_score(model(), X, y, cv=cv, scoring="roc_auc").mean())
    lc.append(cross_val_score(model(), logcpm(X), y, cv=cv, scoring="roc_auc").mean())
print("No gene differs between groups; cases sequenced 1.5x deeper.")
print(f"raw counts (the app's pipeline): CV AUC per rep {np.round(raw,2)} mean {np.mean(raw):.2f}")
print(f"log-CPM input, same model:       CV AUC per rep {np.round(lc,2)} mean {np.mean(lc):.2f}")
print(f"{time.time()-t:.0f}s")
