import numpy as np, pandas as pd
rng = np.random.default_rng(5)
n, p = 60, 300
y = np.repeat(["control", "case"], n // 2)
base = np.exp(rng.normal(3, 1.5, p))
lib = np.exp(rng.normal(0, 0.25, n)) * np.where(y == "case", 1.5, 1.0)
lam = rng.gamma(5.0, lib[:, None] * base[None, :] * 0.2)
X = rng.poisson(lam)
df = pd.DataFrame(X, columns=[f"ENSG{100000+i:011d}" for i in range(p)])
df.insert(0, "sample_id", [f"S{i:03d}" for i in range(n)])
df["condition"] = y
df.to_csv("depth_confounded_counts.csv", index=False)
print(df.shape, "library size ratio case/control:", X[y=="case"].sum(1).mean()/X[y=="control"].sum(1).mean())
