import sys, warnings, numpy as np
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.filterwarnings("ignore")
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold, cross_val_score
from turbotab.core.models.elastic_net import ELASTIC_NET
rng = np.random.default_rng(2)
raw, lg = [], []
for rep in range(5):
    n, p = 150, 200
    L = rng.normal(rng.normal(8, 2, p), 0.8, (n, p))            # log concentrations
    beta = np.zeros(p); beta[:10] = 1.0
    y = (L - L.mean(0)) @ beta + rng.normal(0, 1, n)
    X = np.exp(L)
    cv = KFold(5, shuffle=True, random_state=rep)
    m = lambda: make_pipeline(StandardScaler(), ELASTIC_NET.build("regression", "prediction", 120, p))
    raw.append(cross_val_score(m(), X, y, cv=cv, scoring="r2").mean())
    lg.append(cross_val_score(m(), np.log2(X), y, cv=cv, scoring="r2").mean())
print(f"raw intensities (app): CV R2 {np.round(raw,2)} mean {np.mean(raw):.2f}")
print(f"log2 intensities:      CV R2 {np.round(lg,2)} mean {np.mean(lg):.2f}")
