from harness import *
def main():
    with H() as h:
        d = h.driver("sur")
        d.open(Path("/private/tmp/turbotab-audit/F/survey_six_point.csv")); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["survey"]})
        d.reach("target"); d.decide({"kind": "set_target", "column": "outcome"})
        for f in findings(d):
            if "sentinel" in f["id"] or "ordinal" in f["id"]:
                print(f["severity"], f["id"], "|", f["summary"])
                for r in f.get("repairs", []):
                    print("  REPAIR", r["label"], "|", r["consequence"], "|", r["sentence"][:300])
    import os; os._exit(0)
if __name__ == "__main__": main()
