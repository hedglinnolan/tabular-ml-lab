from harness import *
def main():
    with H() as h:
        d = h.driver("met")
        d.open(Path("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data/metabolomics_mzmine_zeros.csv")); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["metabolomics"]})
        st = d.reach("target")
        cols = [c["name"] for c in d.get("/columns")]
        tgt = "bmi" if "bmi" in cols else cols[-1]
        d.decide({"kind": "set_target", "column": tgt})
        for f in findings(d):
            if "zero" in f["id"] or "censor" in f["id"]:
                print(f["severity"], f["id"], "|", f["summary"], "| routes:", f.get("routes_to"), "| repairs:", [r["label"] for r in f.get("repairs", [])])
                print("   detail:", f["detail"][:500].replace("\n", " "))
    import os; os._exit(0)
if __name__ == "__main__": main()
