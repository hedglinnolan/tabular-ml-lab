"""Left-censored metabolite: compare the app's only imputation (median, in-fold) against half-min,
a QRILC-like truncated-normal draw on the log scale, and the truth. Estimand: slope of outcome on log metabolite."""
import numpy as np
from scipy import stats
rng = np.random.default_rng(7)
def one(n=300, cens=0.4, beta=0.5):
    logm = rng.normal(10, 1, n)                      # log-intensity
    y = beta * (logm - 10) + rng.normal(0, 1, n)
    lod = np.quantile(logm, cens)
    obs = np.where(logm >= lod, logm, np.nan)
    raw_obs = np.exp(obs)
    out = {}
    def slope(xlog):
        return np.polyfit(xlog, y, 1)[0]
    out["truth (no censoring)"] = slope(logm)
    med = np.nanmedian(raw_obs); out["median fill (the app's 'impute')"] = slope(np.log(np.where(np.isnan(raw_obs), med, raw_obs)))
    hm = np.nanmin(raw_obs) / 2; out["half-minimum"] = slope(np.log(np.where(np.isnan(raw_obs), hm, raw_obs)))
    # QRILC-like: fit normal to observed upper part via quantiles, draw from truncated normal below LOD (log scale)
    p_miss = np.isnan(obs).mean()
    q = np.nanquantile(obs, [0.25, 0.75]); # observed quantiles correspond to p_miss + (1-p_miss)*[.25,.75]
    z = stats.norm.ppf(p_miss + (1 - p_miss) * np.array([0.25, 0.75]))
    sd = (q[1] - q[0]) / (z[1] - z[0]); mu = q[0] - sd * z[0]
    lo_lod = np.nanmin(obs)
    b = (lo_lod - mu) / sd
    draws = stats.truncnorm.rvs(-np.inf, b, loc=mu, scale=sd, size=int(np.isnan(obs).sum()), random_state=rng)
    f = obs.copy(); f[np.isnan(f)] = draws; out["QRILC-like truncated draw"] = slope(f)
    cc = ~np.isnan(obs); out["complete case (detected only)"] = np.polyfit(obs[cc], y[cc], 1)[0]
    return out
res = {}
for _ in range(400):
    for k, v in one().items(): res.setdefault(k, []).append(v)
print("true beta = 0.5 per log-unit; 40% below LOD; 400 replicates, n=300")
for k, v in res.items(): print(f"  {k:36s} mean slope {np.mean(v):.3f}  (bias {np.mean(v)-0.5:+.3f})")
