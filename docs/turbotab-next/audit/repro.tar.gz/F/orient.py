import sys, numpy as np, pandas as pd
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab import orientation as o
import glob, os
rows=[]
for p in sorted(glob.glob("turbotab/sample_data/*.csv")):
    df = pd.read_csv(p, low_memory=False)
    r = o.read(df)
    num = df.select_dtypes(include=[np.number])
    # transposed copy: numeric block only, with a label column
    t = num.T.reset_index().rename(columns={"index":"feature"})
    t.columns = ["feature"]+[f"s{i}" for i in range(t.shape[1]-1)]
    rt = o.read(t)
    rows.append((os.path.basename(p), df.shape, r["reading"], r["ratio"], rt["reading"], rt["ratio"], rt["s_rows"]))
for r in rows: print(r)
