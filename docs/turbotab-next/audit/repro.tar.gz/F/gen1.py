from harness import *
def main():
    src = Path("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data/genomics_expression.csv")
    with H() as h:
        d = h.driver("gen")
        d.open(src); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["genomics"]})
        d.reach("target")
        d.decide({"kind": "set_target", "column": "condition"})
        fs = findings(d)
        for f in fs:
            print(f["severity"], f["id"], "| routes:", f.get("routes_to"), "| repairs:", [r["key"] for r in f.get("repairs", [])])
            print("   ", f["summary"])
        json.dump(fs, open("gen_findings.json","w"), indent=1)
        st = d.reach("event")
        if st["status"] in ("open","waiting"):
            d.decide({"kind": "set_event", "level": "case"}) if False else None
        print({k:v for k,v in steps(d).items() if v[0] in ("open","waiting")})
    import os; os._exit(0)
if __name__ == "__main__": main()
