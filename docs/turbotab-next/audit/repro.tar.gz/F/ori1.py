from harness import *
def main():
    with H() as h:
        d = h.driver("ori")
        d.open(Path("/private/tmp/turbotab-audit/F/mzmine_style_export.csv")); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["metabolomics"]})
        d.wait("oriented", 120); time.sleep(1)
        print("orientation step:", steps(d)["orientation"])
        st = d.reach("target"); print("target step:", st["status"])
        code, body = try_post(d, {"kind": "set_orientation", "orientation": "feature_major"})
        print("POST set_orientation:", code, (json.dumps(body)[:300] if code != 200 else "recorded"))
    import os; os._exit(0)
if __name__ == "__main__": main()
