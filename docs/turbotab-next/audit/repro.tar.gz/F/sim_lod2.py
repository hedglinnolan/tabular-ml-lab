import numpy as np
rng = np.random.default_rng(11)
def fit(X, y):
    X1 = np.column_stack([np.ones(len(y)), X]); return np.linalg.lstsq(X1, y, rcond=None)[0][1]
res = {}
for _ in range(400):
    n=300; logm = rng.normal(10, 1, n); m = np.exp(logm)
    y = 0.5*(logm-10) + rng.normal(0,1,n)
    lod = np.quantile(m, 0.4); obs = np.where(m >= lod, m, np.nan); miss = np.isnan(obs)
    r = {}
    r["raw, full data (target)"] = fit(m, y)
    r["raw, median fill (app 'impute')"] = fit(np.where(miss, np.nanmedian(obs), obs), y)
    r["raw, median fill + indicator (app option)"] = fit(np.column_stack([np.where(miss, np.nanmedian(obs), obs), miss]), y)
    r["raw, half-min"] = fit(np.where(miss, np.nanmin(obs)/2, obs), y)
    for k,v in r.items(): res.setdefault(k,[]).append(v)
t = np.mean(res["raw, full data (target)"])
for k,v in res.items(): print(f"  {k:44s} mean slope {np.mean(v):.2e}  ratio to target {np.mean(v)/t:.2f}")
# where does the median land relative to the censored values?
logm = rng.normal(10,1,100000); m=np.exp(logm); lod=np.quantile(m,0.4); obs=m[m>=lod]
print(f"LOD={lod:.0f}; median fill={np.median(obs):.0f} = {np.median(obs)/lod:.1f}x the LOD; true below-LOD values all < {lod:.0f}")
print(f"share of DETECTED values below the fill value: {(obs<np.median(obs)).mean():.0%}")
