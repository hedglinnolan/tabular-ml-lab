from harness import *
def ask(d, key, decision):
    st = d.reach(key, 120)
    if st["status"] in ("open", "waiting"):
        code, body = try_post(d, decision)
        print(f"  {key}: {code}", "" if code == 200 else json.dumps(body)[:400])
def main():
    src = Path("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data/genomics_expression.csv")
    with H() as h:
        d = h.driver("gen")
        d.open(src); d.wait("ingest", 120)
        d.decide({"kind": "set_lens", "lenses": ["genomics"]})
        d.reach("target"); d.decide({"kind": "set_target", "column": "condition"})
        ask(d, "event", {"kind": "set_event", "column": "condition", "level": "case"})
        ask(d, "task", {"kind": "set_task", "column": "condition", "task": "binary"})
        ask(d, "purpose", {"kind": "set_purpose", "purpose": "inference"})
        ask(d, "grain", {"kind": "set_grain", "grain": "one_row_per_unit", "id_column": "sample_id"})
        d.reach("roles"); d.wait("roles", 120); roles = d.accept_roles()
        from collections import Counter
        print("roles:", Counter(roles.values()), {k:v for k,v in roles.items() if not k.startswith("gene_")})
        ask(d, "roles", {"kind": "set_roles", "roles": roles})
        ask(d, "exclusions", {"kind": "set_exclusions", "rules": []})
        ask(d, "missing", {"kind": "set_missing", "strategy": "complete_case"})
        ask(d, "split", {"kind": "set_split", "holdout": 0.0, "seed": 0, "folds": 5})
        d.wait("shelf", 240)
        shelf = d.get("/stages/shelf")["artifact"]
        for fam in shelf["families"]:
            print("SHELF", fam["key"], fam.get("fit"), fam.get("score"), fam.get("concerns"), fam.get("recommended"))
        ask(d, "models", {"kind": "select_models", "models": ["linear"]})
        d.wait("fit", 240)
        fit = d.get("/stages/fit")["artifact"]
        json.dump(fit, open("gen_fit.json", "w"), indent=1, default=str)
        for m in fit["models"]:
            print("MODEL", m.get("key"), "cv:", json.dumps(m.get("cv"))[:400])
            co = m.get("coefficients") or []
            print("  n coef rows", len(co)); print("  first rows", json.dumps(co[:6])[:900])
            print("  warnings", m.get("warnings"), m.get("concerns"))
    import os; os._exit(0)
if __name__ == "__main__": main()
