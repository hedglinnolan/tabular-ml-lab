import sys; sys.path.insert(0,'/Users/nhedglin/tabular-ml-lab')
import numpy as np, pandas as pd, warnings; warnings.filterwarnings("ignore")
from turbotab import packs
rng = np.random.default_rng(8)
def instrument(lo, hi, k=10, n=300, shift=0.0):
    lat = rng.normal(size=n); pts = hi - lo + 1
    cuts = np.linspace(-1.6, 1.6, pts - 1) + shift
    X = lo + ((lat[:, None] + rng.normal(0, .8, (n, k)))[:, :, None] > cuts[None, None, :]).sum(2)
    return pd.DataFrame(X, columns=[f"q{j:02d}" for j in range(1, k + 1)])
cases = {
  "PSS-10 style 0-4, 'never' rare (shift -0.6)": instrument(0, 4, shift=-0.6),
  "7-point, top two categories rare (shift +0.9)": instrument(1, 7, shift=0.9),
  "6-point balanced": instrument(1, 6),
  "1-5 with 9 refusals (true sentinel)": None,
}
d = instrument(1, 5); m = rng.random(d.shape) < 0.03; d = d.mask(m, 9); cases["1-5 with 9 refusals (true sentinel)"] = d
for name, df in cases.items():
    shares = df.stack().value_counts(normalize=True).sort_index().round(3).to_dict()
    b = packs.likert_block(df)
    fs = {f["id"]: f["title"] for f in packs.findings(df, ["survey"])}
    print(f"\n{name}\n  observed category shares {shares}")
    print(f"  block scale read as {b and b['scale']}; sentinels flagged in {b and len(b['sentinels'])} items: {b and sorted({v for vs in b['sentinels'].values() for v in vs})}")
    for k, t in fs.items(): print(f"  {k}: {t}")
