"""Exp 3: stratified residual (sex-specific constant) when sex is not a predictor (drop_strata)."""
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.models.steps import StratifiedEnergyAdjuster, energy_step
from turbotab.core.decisions import EnergyAdjustment

rng = np.random.default_rng(7)
n = 6000
male = rng.integers(0, 2, n)
E = np.exp(np.log(1750) + 0.25 * male + rng.normal(0, 0.22, n))   # men ~ 2200, women ~ 1720 kcal
prot_share = np.clip(rng.normal(0.16, 0.03, n), 0.05, 0.4)
prot_g = prot_share * E / 4
# outcome: sex matters, energy matters, protein composition has NO effect at fixed energy
y = 3.0 * male + 0.002 * E + rng.normal(0, 2, n)
df = pd.DataFrame({"protein_g": prot_g, "energy_kcal": E, "sex": np.where(male, "M", "F")})

step = energy_step(EnergyAdjustment(method="residual", energy_column="energy_kcal",
                                    nutrients=["protein_g"], strata="sex"), predictors=["protein_g", "energy_kcal"])
print(type(step).__name__, "drop_strata =", step.drop_strata)
out = step.fit_transform(df)
print("output columns:", list(out.columns))
for lvl, a in step.by_level_.items():
    p = a.params_["protein_g"]
    print(f"  level {lvl}: slope {p['slope']:.4f}, ref E {p['reference_energy']:.0f}, r_after {p['r_after']:.2e}")
r_pooled = np.corrcoef(out.protein_g_adj, df.energy_kcal)[0, 1]
r_sex = np.corrcoef(out.protein_g_adj, male)[0, 1]
print(f"pooled r(protein_g_adj, E) = {r_pooled:.3f};  r(protein_g_adj, male) = {r_sex:.3f}")
m = sm.OLS(y, sm.add_constant(out[["protein_g_adj"]])).fit()
print(f"Y ~ protein_g_adj (sex dropped): b = {m.params['protein_g_adj']:.4f}, p = {m.pvalues['protein_g_adj']:.1e}  (truth 0)")
# same with a common reference (overall mean energy) instead of each level's own
common = df.protein_g.copy()
Ebar = df.energy_kcal.mean()
for lvl, a in step.by_level_.items():
    msk = df.sex == lvl
    b = a.params_["protein_g"]["slope"]
    res = df.protein_g[msk] - (a.params_["protein_g"]["intercept"] + b * df.energy_kcal[msk])
    common[msk] = res + df.protein_g.mean()
m2 = sm.OLS(y, sm.add_constant(common.rename("adj_common"))).fit()
print(f"same residuals + one common constant: b = {m2.params['adj_common']:.4f}, p = {m2.pvalues['adj_common']:.2f}")
std = sm.OLS(y, sm.add_constant(pd.DataFrame({"protein_g": df.protein_g, "energy_kcal": df.energy_kcal}))).fit()
print(f"standard Y ~ N + E (sex also absent): b = {std.params['protein_g']:.4f}, p = {std.pvalues['protein_g']:.2f}")
print("lineage formula:", step.lineage()[0]["formula"][:200])
