"""Exp 4: method 'none' with an energy-role column: what enters the model, and what the label says."""
import numpy as np, pandas as pd
from turbotab.core.decisions import ProjectState, EnergyAdjustment, MissingSpec
from turbotab.core.models.pipeline import design_spec, shared_steps, transformer, model_predictors, describe_steps
from turbotab.core.methods.energy import METHOD_TABLE
from turbotab.core.models import get_family

rng = np.random.default_rng(0)
df = pd.DataFrame({"fat_g": rng.uniform(30, 120, 50), "energy_kcal": rng.uniform(1200, 3500, 50),
                   "age": rng.uniform(20, 80, 50)})
st = ProjectState(target="y", task="regression", purpose="inference",
                  roles={"fat_g": "exposure", "energy_kcal": "energy", "age": "covariate"},
                  energy_adjustment=EnergyAdjustment(method="none"), missing=MissingSpec(strategy="complete_case"))
preds = model_predictors(st)
spec = design_spec(st, df, preds)
X = transformer(shared_steps(spec)).fit_transform(df[spec.inputs])
print("predictors:", preds)
print("matrix columns:", list(X.columns))
print("estimand the design artifact carries:", METHOD_TABLE[st.energy_adjustment.method]["estimand"])
print("standard specification:", METHOD_TABLE["standard"]["specification"])
