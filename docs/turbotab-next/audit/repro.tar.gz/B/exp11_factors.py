from turbotab.core.methods.energy import energy_factor, nutrient_role, unit_of, _ROLE_PATTERNS
from turbotab.core.methods.nesting import candidates
print({k: v for k, v in _ROLE_PATTERNS.items()})
names = ["DR1TKCAL", "DR1TPROT", "DR1TCARB", "DR1TSUGR", "DR1TFIBE", "DR1TTFAT", "DR1TSFAT", "DR1TMFAT",
         "DR1TPFAT", "DR1TALCO", "DR1TCHOL", "protein_g", "carbohydrate_g", "fat_g", "sfa_g", "saturated_fat_g",
         "sugar_g", "added_sugars_g", "fiber_g", "alcohol_g", "omega3_g", "protein_pct_kcal", "chocolate_g",
         "cholesterol_mg", "fat_free_mass_kg", "body_fat_pct", "carotene_ug", "carnitine_mg", "starch_g",
         "total_fat", "fatty_fish_g", "protein_animal_g", "Fiber (g)", "fruit_juice_cups", "fatigue_score"]
for n in names:
    r = energy_factor(n)
    print(f"{n:22s} unit={r.unit:10s} role={str(r.role):12s} factor={r.factor} declared={r.declared}")
print("nesting candidates over NHANES names:", candidates(names[:11]))
