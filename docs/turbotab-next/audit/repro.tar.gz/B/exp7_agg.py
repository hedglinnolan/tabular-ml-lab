"""Exp 7: aggregation semantics through the real working stage (GraphRun, as the tests drive it)."""
import pandas as pd, numpy as np, shutil
from pathlib import Path
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun

base = Path("/private/tmp/turbotab-audit/B/agg")
def run(df, slots, name):
    src = base / f"{name}.csv"; df.to_csv(src, index=False)
    folder = base / f"p_{name}"; shutil.rmtree(folder, ignore_errors=True)
    g = GraphRun(src, folder)
    try:
        out = g.run(ProjectState.model_validate(slots), upto=["working"])
        w = out["working"]
        return pd.read_parquet(w.files["table.parquet"]), w.data["aggregation"], out["structure"]
    finally:
        g.close()

# (a) "first": a unit whose first record is blank, later records filled; time column as US-format text
rows = []
rng = np.random.default_rng(0)
for i in range(40):
    pid = f"P{i:03d}"
    for v, d in enumerate(["03/15/2023", "01/10/2023", "06/01/2023"]):   # file order is NOT time order
        rows.append({"pid": pid, "visit_date": d, "age": 40 + i % 30 + (v == 2),
                     "sex_code": 1 + (i % 2), "smoke_status": [1, 2, 3][(i + v) % 3],
                     "sbp": (np.nan if (v == 0 and i < 5) else 120 + i + 5 * v), "y": float(i % 7)})
df = pd.DataFrame(rows)
for method in ("first", "mean", "change"):
    t, rec, st = run(df, dict(lens=["clinical"], target="y", grain={"grain": "repeated", "id_column": "pid"}, unit="unit",
                               repeat_kind={"repeat_kind": "time_points", "time_column": "visit_date"},
                               aggregation={"method": method}), f"a_{method}")
    print(f"--- method={method}: ordered_by={rec['ordered_by']!r} time_column={rec['time_column']!r}")
    print(t[["pid", "visit_date", "age", "sex_code", "smoke_status", "sbp"]].head(6).to_string())
    print("varying:", rec["varying"])
