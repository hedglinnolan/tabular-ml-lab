import numpy as np, pandas as pd
from turbotab.core.methods.substitution import Shift, refit_band
rng = np.random.default_rng(0); n = 200
X = pd.DataFrame({"fat_g": rng.uniform(40, 120, n), "carb_g": rng.uniform(150, 350, n)})
y = rng.normal(size=n)
calls = {"n": 0}
def fit(Xb, yb):
    calls["n"] += 1
    if calls["n"] > 2:
        raise ValueError("resample held one class")
    b = rng.normal(0, 1)
    return lambda df: b * df["carb_g"].to_numpy() / 100
sh = Shift(X, donor="fat_g", recipient="carb_g", kcal_per_unit={"fat_g": 9, "carb_g": 4})
band = refit_band(fit, X, y, shift=sh, ks=[0, 100], live=[True, True], n_boot=50, center=[0.0, 0.1])
print(band)
