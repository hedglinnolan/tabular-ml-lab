import pandas as pd, numpy as np, shutil, sys
sys.path.insert(0, "/private/tmp/turbotab-audit/B")
from pathlib import Path
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
base = Path("/private/tmp/turbotab-audit/B/agg")
def run(df, slots, name):
    src = base / f"{name}.csv"; df.to_csv(src, index=False)
    folder = base / f"p_{name}"; shutil.rmtree(folder, ignore_errors=True)
    g = GraphRun(src, folder)
    try:
        out = g.run(ProjectState.model_validate(slots), upto=["working"])
        w = out["working"]
        cols = {c["name"]: c["dtype"] for c in g.info["columns"]}
        return pd.read_parquet(w.files["table.parquet"]), w.data["aggregation"], cols
    finally:
        g.close()
rows = []
for i in range(40):
    for v, label in enumerate(["V2", "V10", "V1"]):        # file order is not visit order; text labels
        rows.append({"pid": f"P{i:03d}", "visit": label, "age": 40 + i % 30,
                     "smoke_status": [1, 2, 3][(i + v) % 3],
                     "sbp": (np.nan if (label == "V2" and i < 5) else 120 + i + 5 * v), "y": float(i % 7)})
df = pd.DataFrame(rows)
for method in ("first", "mean"):
    t, rec, cols = run(df, dict(lens=["clinical"], target="y", grain={"grain": "repeated", "id_column": "pid"},
                               unit="unit", repeat_kind={"repeat_kind": "time_points", "time_column": "visit"},
                               aggregation={"method": method}), f"b_{method}")
    print(f"--- {method}: ordered_by={rec['ordered_by']!r}; dtypes={cols}")
    print(t[["pid", "visit", "smoke_status", "sbp"]].head(6).to_string())
    print("varying:", rec["varying"])

# which column did the structure reading take as the replicate index?
src = base / "b_mean.csv"; folder = base / "p_idx"; shutil.rmtree(folder, ignore_errors=True)
g = GraphRun(src, folder)
out = g.run(ProjectState.model_validate(dict(lens=["clinical"], target="y", grain={"grain": "repeated", "id_column": "pid"},
            unit="unit", repeat_kind={"repeat_kind": "time_points", "time_column": "visit"}, aggregation={"method": "mean"})), upto=["working"])
st = out["structure"]; st = getattr(st, "data", st)
print("replicate_index read as:", st["repeats"]["replicate_index"], "| time_column:", st["time_column"])
g.close()
