"""Exp 1: the app's residual method (E leaves the model) vs the standard model, with covariates
correlated with E; Exp 2: log residual back-transformed vs nutrient density."""
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.methods.energy import EnergyAdjuster

rng = np.random.default_rng(1)
n = 4000
male = rng.integers(0, 2, n)
age = rng.normal(50, 12, n)
pa = rng.normal(0, 1, n)                      # physical activity, a covariate the analyst has
logE = np.log(1700) + 0.25 * male + 0.10 * pa - 0.004 * (age - 50) + rng.normal(0, 0.22, n)
E = np.exp(logE)
fat_share = np.clip(rng.normal(0.34, 0.06, n), 0.1, 0.6)
fat_g = fat_share * E / 9
carb_g = (1 - fat_share - 0.16) * E / 4
y = 0.02 * fat_g + 0.004 * E + 1.5 * male + 0.8 * pa + 0.03 * age + rng.normal(0, 2, n)
df = pd.DataFrame({"fat_g": fat_g, "energy_kcal": E, "male": male.astype(float), "age": age, "pa": pa})

# standard model
X = sm.add_constant(df[["fat_g", "energy_kcal", "male", "age", "pa"]])
std = sm.OLS(y, X).fit()
# the app's residual step (E leaves the model)
adj = EnergyAdjuster("residual", "energy_kcal", ["fat_g"]).fit(df)
out = adj.transform(df)
print("residual step output columns:", list(out.columns))
Xr = sm.add_constant(out[["fat_g_adj", "male", "age", "pa"]])
res = sm.OLS(y, Xr).fit()
# residual WITH E kept (Willett's energy-adjusted model with total energy as a term)
Xre = sm.add_constant(pd.concat([out[["fat_g_adj", "male", "age", "pa"]], df[["energy_kcal"]]], axis=1))
rese = sm.OLS(y, Xre).fit()
print(f"standard  Y~N+E+C : b_fat={std.params['fat_g']:.5f} se={std.bse['fat_g']:.5f} p={std.pvalues['fat_g']:.2e}")
print(f"app resid Y~Nadj+C: b_fat={res.params['fat_g_adj']:.5f} se={res.bse['fat_g_adj']:.5f} p={res.pvalues['fat_g_adj']:.2e}")
print(f"resid+E  Y~Nadj+E+C: b_fat={rese.params['fat_g_adj']:.5f} se={rese.bse['fat_g_adj']:.5f}")
# no covariates
s0 = sm.OLS(y, sm.add_constant(df[["fat_g", "energy_kcal"]])).fit()
r0 = sm.OLS(y, sm.add_constant(out[["fat_g_adj"]])).fit()
print(f"no C: standard b={s0.params['fat_g']:.5f} se={s0.bse['fat_g']:.5f} | app residual b={r0.params['fat_g_adj']:.5f} se={r0.bse['fat_g_adj']:.5f}")

print("\n--- Exp 2: log residual vs density ---")
adjl = EnergyAdjuster("residual", "energy_kcal", ["fat_g"], log_transform=True).fit(df)
outl = adjl.transform(df)
print("log slope b =", round(adjl.params_["fat_g"]["slope"], 4))
dens = df.fat_g / df.energy_kcal
print("corr(log-residual fat_g_adj, fat_g/E) =", round(np.corrcoef(outl.fat_g_adj, dens)[0, 1], 5))
print("corr(linear-residual fat_g_adj, fat_g/E) =", round(np.corrcoef(out.fat_g_adj, dens)[0, 1], 5))
rl = sm.OLS(y, sm.add_constant(pd.concat([outl[["fat_g_adj"]], df[["male", "age", "pa"]]], axis=1))).fit()
dd = sm.OLS(y, sm.add_constant(pd.concat([(dens * np.exp(np.log(df.energy_kcal).mean())).rename("dens_scaled"), df[["male", "age", "pa"]]], axis=1))).fit()
print(f"app log-residual Y~Nadj+C: b={rl.params['fat_g_adj']:.5f} t={rl.tvalues['fat_g_adj']:.2f}")
print(f"density alone (rescaled by GM E) Y~N/E+C: b={dd.params['dens_scaled']:.5f} t={dd.tvalues['dens_scaled']:.2f}")
print(f"standard (truth for substitution of fat for other energy, per g at fixed E) b={std.params['fat_g']:.5f}")
print("estimand label shown for log residual:", adj.estimand()[:90], "...")
