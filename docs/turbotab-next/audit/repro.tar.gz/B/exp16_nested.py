import numpy as np, pandas as pd
from turbotab.core.methods.substitution import Shift
from turbotab.core.methods.nesting import nested_components
rng = np.random.default_rng(0); n = 50
sat = rng.uniform(10, 30, n); mufa = rng.uniform(10, 30, n); pufa = rng.uniform(5, 20, n)
sugar = rng.uniform(30, 90, n); starch = rng.uniform(80, 160, n)
X = pd.DataFrame({"fat_total_g": sat + mufa + pufa + 3, "sat_fat_g": sat, "mufa_g": mufa, "pufa_g": pufa,
                  "carb_g": sugar + starch + 5, "sugar_g": sugar, "starch_g": starch, "protein_g": rng.uniform(50, 100, n)})
nested = nested_components(X)
print("nested:", nested)
kc = {"fat_total_g": 9, "sat_fat_g": 9, "carb_g": 4, "sugar_g": 4, "starch_g": 4, "protein_g": 4, "mufa_g": 9, "pufa_g": 9}
s = Shift(X, donor="sugar_g", recipient="starch_g", kcal_per_unit=kc, nested=nested)
v = s.values(X, 40.0)
print("sugar->starch 40 kcal: carb change", np.allclose(v["carb_g"], X.carb_g), "carried", s.carried)
s2 = Shift(X, donor="fat_total_g", recipient="protein_g", kcal_per_unit=kc, nested=nested)
v2 = s2.values(X, 90.0)
print("fat_total -> protein 90 kcal: fat_total -10 g:", np.allclose(v2["fat_total_g"], X.fat_total_g - 10),
      "| sat share held:", np.allclose(v2["sat_fat_g"] / v2["fat_total_g"], X.sat_fat_g / X.fat_total_g))
s3 = Shift(X, donor="sat_fat_g", recipient="pufa_g", kcal_per_unit=kc, nested=nested)
v3 = s3.values(X, 45.0)
print("sat -> pufa 45 kcal: fat_total unchanged", np.allclose(v3["fat_total_g"], X.fat_total_g), "carried", s3.carried)
