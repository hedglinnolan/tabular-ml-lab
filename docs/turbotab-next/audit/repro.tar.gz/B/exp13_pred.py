"""Exp 13: under prediction, the residual and density methods drop E from the model."""
import numpy as np, pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import cross_val_score, KFold
from turbotab.core.methods.energy import EnergyAdjuster
rng = np.random.default_rng(5); n = 3000
E = np.exp(rng.normal(np.log(2000), 0.3, n))
fat = np.clip(rng.normal(0.34, 0.06, n), 0.1, 0.6) * E / 9
carb = np.clip(rng.normal(0.48, 0.07, n), 0.2, 0.7) * E / 4
y = 0.004 * E + 0.03 * fat + rng.normal(0, 2, n)        # e.g. a body-size-related outcome
X = pd.DataFrame({"fat_g": fat, "carb_g": carb, "energy_kcal": E})
cv = KFold(5, shuffle=True, random_state=0)
for method in ("none", "standard", "residual", "density_multivariate", "density", "partition"):
    for name, est in (("ols", LinearRegression()), ("gbm", HistGradientBoostingRegressor(max_iter=150))):
        pipe = Pipeline([("energy", EnergyAdjuster(method, "energy_kcal", ["fat_g", "carb_g"])), ("m", est)]).set_output(transform="pandas")
        r2 = cross_val_score(pipe, X, y, cv=cv, scoring="r2").mean()
        print(f"{method:22s} {name}: CV R2 = {r2:.3f}")
