"""Exp 14: 'standard' with several energy-bearing nutrients is the leave-one-out model; the label
'substitution for the average of all other energy sources' describes the single-nutrient model."""
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.methods.energy import METHOD_TABLE
rng = np.random.default_rng(4); n = 20000
E = np.exp(rng.normal(np.log(2000), 0.3, n))
sh = rng.dirichlet([34, 48, 16, 2], n)          # fat, carb, protein, alcohol shares
kf, kc, kp, ka = (sh * E[:, None]).T             # kcal from each
eff = {"fat": 0.004, "carb": 0.001, "protein": 0.006, "alcohol": 0.0}   # per kcal
y = eff["fat"] * kf + eff["carb"] * kc + eff["protein"] * kp + eff["alcohol"] * ka + rng.normal(0, 1, n)
df = pd.DataFrame({"fat_kcal": kf, "carb_kcal": kc, "protein_kcal": kp, "energy_kcal": E})
one = sm.OLS(y, sm.add_constant(df[["fat_kcal", "energy_kcal"]])).fit().params["fat_kcal"]
allm = sm.OLS(y, sm.add_constant(df)).fit().params["fat_kcal"]
w = np.array([kc.mean(), kp.mean(), ka.mean()]); w /= w.sum()
avg_other = w @ np.array([eff["carb"], eff["protein"], eff["alcohol"]])
print(f"label: {METHOD_TABLE['standard']['estimand']}")
print(f"truth fat minus average of all others = {eff['fat'] - avg_other:.5f}; fat minus alcohol (the omitted) = {eff['fat'] - eff['alcohol']:.5f}")
print(f"standard, fat alone + E:            b = {one:.5f}")
print(f"standard, fat+carb+protein + E:     b = {allm:.5f}")
from turbotab.core.methods.energy import EnergyAdjuster
out = EnergyAdjuster("residual", "energy_kcal", ["fat_kcal", "carb_kcal", "protein_kcal"]).fit_transform(df)
r = sm.OLS(y, sm.add_constant(out)).fit()
print("residual (E dropped), three nutrients: columns", list(out.columns))
print("  b_fat_adj =", round(r.params["fat_kcal_adj"], 5), " b_carb_adj =", round(r.params["carb_kcal_adj"], 5), " b_prot_adj =", round(r.params["protein_kcal_adj"], 5))
print("  same with E kept:", sm.OLS(y, sm.add_constant(pd.concat([out, df[["energy_kcal"]]], axis=1))).fit().params[["fat_kcal_adj", "carb_kcal_adj"]].round(5).to_dict())
