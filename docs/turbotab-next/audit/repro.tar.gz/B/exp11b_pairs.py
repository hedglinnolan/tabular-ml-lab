import numpy as np, pandas as pd
from turbotab.core.stages.modeling import substitution_pairs
from turbotab.core.methods.energy import partition_refusal, EnergyAdjuster
preds = ["fat_g", "carbohydrate_g", "fatty_fish_g", "fat_free_mass_kg", "fatigue_score", "body_fat_pct", "age", "energy_kcal"]
pairs = substitution_pairs(preds, "energy_kcal", {})
print(len(pairs), "pairs offered; donors/recipients:", sorted({p["donor"] for p in pairs}))
rng = np.random.default_rng(0); n = 400
E = rng.normal(2100, 400, n)
df = pd.DataFrame({"energy_kcal": E, "protein_g": 0.16 * E / 4, "carbohydrate_g": 0.48 * E / 4, "fat_g": 0.36 * E / 9,
                   "fatty_fish_g": rng.gamma(1.0, 25, n)})  # grams of FOOD, ~2 kcal/g in reality
print("partition refusal for fatty_fish_g:", partition_refusal(df, "energy_kcal", ["fatty_fish_g"]))
step = EnergyAdjuster("partition", "energy_kcal", ["fatty_fish_g"]).fit(df)
print([e["formula"] for e in step.lineage() if e["operation"].startswith("partition")])
