import numpy as np, pandas as pd
from turbotab.core.models.pipeline import DesignSpec, shared_steps, transformer
from turbotab.core.models.lineage import trace, missing_counts
rng = np.random.default_rng(2); n = 300
E = np.exp(rng.normal(np.log(2000), 0.3, n))
X = pd.DataFrame({"fat_g": 0.35 * E / 9 * np.exp(rng.normal(0, .2, n)), "energy_kcal": E,
                  "sex": rng.choice(["F", "M"], n), "smoker": rng.choice([0.0, 1.0, np.nan], n)})
X.loc[:20, "fat_g"] = np.nan
energy = {"method": "residual", "energy_column": "energy_kcal", "nutrients": ["fat_g"], "log_transform": True, "strata": "sex"}
spec = DesignSpec(predictors=["fat_g", "energy_kcal", "smoker"], inputs=["fat_g", "energy_kcal", "smoker", "sex"],
                  categorical=["sex"], numeric=["fat_g", "energy_kcal", "smoker"], energy=energy, impute=True,
                  roles={"fat_g": "exposure", "energy_kcal": "energy", "smoker": "covariate"}, levels=["smoker"], indicators=True)
pipe = transformer(shared_steps(spec))
M = pipe.fit_transform(X[spec.inputs])
print("matrix:", list(M.columns))
lin = trace(pipe.steps, spec.inputs, spec.roles, missing_counts(X[spec.inputs]))
for node in lin.nodes:
    if node.formula: print(node.id, "::", node.formula[:400])
for l in lin.links: print(l.source, "->", l.target, ":", l.operation)
# What the strat log step actually did vs the formula's "at that level's mean"
st = pipe.named_steps["energy"]
for lvl, a in st.by_level_.items():
    p = a.params_["fat_g"]
    sub = X[(X.sex == lvl)]
    print(lvl, "reference_energy (geometric) =", round(p["reference_energy"], 1), " arithmetic mean E =", round(sub.energy_kcal.mean(), 1))
