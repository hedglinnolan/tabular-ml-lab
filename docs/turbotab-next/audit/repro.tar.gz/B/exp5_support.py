"""Exp 5: the support mask checks each moved column's marginal [min,max] in grams, not the
composition (share of energy) that a move at fixed energy changes. Exp 6: the AME at each k is over
a different subset of rows, chosen by donor level."""
import numpy as np, pandas as pd
from turbotab.core.methods.substitution import Shift, substitution_curve

rng = np.random.default_rng(3)
n = 5000
E = np.exp(rng.normal(np.log(2000), 0.3, n))
fat_sh = np.clip(rng.normal(0.34, 0.05, n), 0.15, 0.55)
prot_sh = np.clip(rng.normal(0.16, 0.03, n), 0.08, 0.3)
carb_sh = 1 - fat_sh - prot_sh
X = pd.DataFrame({"fat_g": fat_sh * E / 9, "carb_g": carb_sh * E / 4, "protein_g": prot_sh * E / 4, "energy_kcal": E})
sh = Shift(X, donor="fat_g", recipient="carb_g", kcal_per_unit={"fat_g": 9.0, "carb_g": 4.0})
obs_fat = X.fat_g * 9 / X.energy_kcal
lo, hi = obs_fat.min(), obs_fat.max()
for k in (100, 200, 300, 400):
    moved, mask = sh.apply(X, k)
    new_share = moved.fat_g * 9 / moved.energy_kcal
    off_comp = mask & ((new_share < lo) | (new_share > hi))
    print(f"k={k}: on-support (marginal grams) {mask.mean():.1%}; of those, fat %E outside observed "
          f"[{lo:.1%},{hi:.1%}]: {off_comp.sum()} rows; min fat %E among kept rows {new_share[mask].min():.1%}")

# Exp 6: heterogeneous model: effect of fat depends on fat share (a plausible tree-like surface)
def predict(df):
    share = df.fat_g * 9 / df.energy_kcal
    return 5.0 * np.where(share > 0.30, share - 0.30, 0.0) * 100   # only high-fat diets respond
curve = substitution_curve(predict, X, donor="fat_g", recipient="carb_g",
                           kcal_per_unit={"fat_g": 9.0, "carb_g": 4.0}, ks=[0, 100, 200, 300, 400, 500, 600])
for k, d, f in zip(curve["ks"], curve["delta"], curve["on_support_fraction"]):
    if d is not None and k > 0:
        print(f"k={k:.0f}: AME={d:+.2f}  per 100 kcal={d*100/k:+.3f}  on-support={f:.0%}")
# the same contrast on a fixed population (rows on support at the largest live k)
live = [k for k, d in zip(curve["ks"], curve["delta"]) if d is not None]
kmax = max(live)
_, fixed = sh.apply(X, kmax)
base = predict(X)
for k in live[1:]:
    moved, _ = sh.apply(X, k)
    d = (predict(moved) - base)[fixed].mean()
    print(f"  fixed population (n={fixed.sum()}): k={k:.0f}: per 100 kcal={d*100/k:+.3f}")
