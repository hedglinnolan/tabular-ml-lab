import numpy as np, pandas as pd
from turbotab.core.decisions import ProjectState, MissingSpec
from turbotab.core.models.pipeline import design_spec, shared_steps, transformer
from turbotab.core.datastore import logical_dtype
rng = np.random.default_rng(0); n = 100
df = pd.DataFrame({"fat_g": rng.uniform(30, 120, n), "RIDRETH3": rng.choice([1, 2, 3, 4, 6, 7], n),
                   "DMDEDUC2": rng.choice([1, 2, 3, 4, 5], n)})
print("ingest dtype of RIDRETH3 (BIGINT):", logical_dtype("BIGINT", 6, n))
st = ProjectState(roles={"fat_g": "exposure", "RIDRETH3": "covariate", "DMDEDUC2": "covariate"},
                  missing=MissingSpec(strategy="complete_case"))
spec = design_spec(st, df, ["fat_g", "RIDRETH3", "DMDEDUC2"])
print("categorical:", spec.categorical, "numeric:", spec.numeric)
print("matrix columns:", list(transformer(shared_steps(spec)).fit_transform(df).columns))
