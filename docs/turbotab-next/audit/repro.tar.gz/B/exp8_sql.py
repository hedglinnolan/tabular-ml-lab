import duckdb, pandas as pd, numpy as np
from turbotab.core import repairs as R
con = duckdb.connect()
con.execute("CREATE TABLE t AS SELECT * FROM (VALUES ('7'), ('9'), ('12'), ('refused'), (NULL)) v(x)")
wrap = R._sentinel_values("set_missing", {"values": {"x": [7, 9]}})["x"]
try:
    print("sentinel on VARCHAR:", con.execute(f"SELECT x, {wrap('x')} AS y FROM t").fetchall())
except Exception as e:
    print("sentinel on VARCHAR raises:", type(e).__name__, str(e)[:120])
# pandas preview count for the same column
s = pd.Series(["7", "9", "12", "refused", None])
print("preview hits:", int(R._numeric(s).isin([7.0, 9.0]).sum()))
# float precision: a code stored as 9.0000001 / a value 99.0 in a DOUBLE column, and -0.0
con.execute("CREATE TABLE f AS SELECT * FROM (VALUES (99.0::DOUBLE), (98.99999999999999::DOUBLE), (7::INTEGER)) v(x)")
wrap2 = R._sentinel_values("set_missing", {"values": {"x": [99, 7]}})["x"]
print("sentinel on DOUBLE:", con.execute(f"SELECT x, {wrap2('x')} FROM f").fetchall())
# impossible-values band vs rule_keep boundary semantics
w = R._impossible_values("set_missing", {"bands": {"x": [0, 300]}})["x"]
con.execute("CREATE TABLE b AS SELECT * FROM (VALUES (0.0), (300.0), (300.0001), (-1.0), (NULL)) v(x)")
print("impossible band SQL:", con.execute(f"SELECT x, {w('x')} FROM b").fetchall())
from turbotab.core.stages.rows import rule_keep
from turbotab.core.decisions import ExclusionRule
fr = pd.DataFrame({"x": [0.0, 300.0, 300.0001, -1.0, np.nan]})
print("exclusion rule keeps:", list(rule_keep(fr, ExclusionRule(column="x", low=0, high=300, reason="r"))))
# kJ conversion then sentinel order: a 99999 code in an energy column in kJ
chain = R._kj_values("to_kcal", {"column": "e", "factor": 4.184})["e"]
s2 = R._sentinel_values("set_missing", {"values": {"e": [99999]}})["e"]
con.execute("CREATE TABLE k AS SELECT * FROM (VALUES (8368.0), (99999.0)) v(e)")
print("kJ then code:", con.execute(f"SELECT e, {s2(chain('e'))} FROM k").fetchall())
print("binary SQL:", R._binary_values("level", {"column": "c", "one": "Yes", "zero": "No"})["c"]('"c"'))
