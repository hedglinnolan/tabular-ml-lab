"""Exp 9: the app's impute -> energy-adjust order (median per column, E not in the imputation
model), then the residual step, then OLS; vs complete cases. MAR-on-energy missingness."""
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.models.pipeline import DesignSpec, shared_steps, transformer

rng = np.random.default_rng(11)
res = {"complete": [], "app_impute": [], "app_impute_ind": []}
ses = {"complete": [], "app_impute": []}
for rep in range(200):
    n = 1500
    E = np.exp(rng.normal(np.log(2000), 0.3, n))
    fat = np.clip(rng.normal(0.34, 0.06, n), 0.1, 0.6) * E / 9
    y = 0.03 * fat + 0.002 * E + rng.normal(0, 2, n)
    X = pd.DataFrame({"fat_g": fat, "energy_kcal": E})
    p = 1 / (1 + np.exp(-(np.log(E) - np.log(2000)) * 4))  # high eaters skip more items (MAR on E)
    X.loc[rng.uniform(size=n) < 0.4 * p, "fat_g"] = np.nan
    energy = {"method": "residual", "energy_column": "energy_kcal", "nutrients": ["fat_g"], "log_transform": False, "strata": None}
    cc = X.dropna()
    for name, impute, ind, frame, yy in (("complete", False, False, cc, y[cc.index]),
                                         ("app_impute", True, False, X, y),
                                         ("app_impute_ind", True, True, X, y)):
        spec = DesignSpec(predictors=["fat_g", "energy_kcal"], inputs=["fat_g", "energy_kcal"], categorical=[],
                          numeric=["fat_g", "energy_kcal"], energy=energy, impute=impute,
                          roles={"fat_g": "exposure", "energy_kcal": "energy"}, indicators=ind)
        M = transformer(shared_steps(spec)).fit_transform(frame)
        fit = sm.OLS(yy, sm.add_constant(M)).fit()
        res[name].append(fit.params["fat_g_adj"])
        if name in ses: ses[name].append(fit.bse["fat_g_adj"])
print("columns under impute+indicators:", list(M.columns))
for k, v in res.items():
    print(f"{k:16s} mean b = {np.mean(v):.4f} (truth 0.0300), empirical sd {np.std(v):.4f}" +
          (f", mean reported se {np.mean(ses[k]):.4f}" if k in ses else ""))
