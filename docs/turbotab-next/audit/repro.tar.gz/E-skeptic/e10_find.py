import sys, json; sys.path.insert(0, "/private/tmp/turbotab-audit/E-skeptic")
from drv import Drive, server, open_csv
with server() as client:
    d = Drive(client); open_csv(d, "/Users/nhedglin/tabular-ml-lab/_tt_tmp_nhanes.csv")
    d.decide({"kind": "set_lens", "lenses": ["dietary"]})
    d.reach("target")
    art = d.art("findings")
    txt = json.dumps(art)
    print("survey_design_absent in findings artifact:", "survey_design_absent" in txt)
    fs = art.get("findings") if isinstance(art, dict) else None
    for f in (fs or []):
        if "survey_design" in f.get("id", ""):
            print(json.dumps({k: f[k] for k in ("id", "severity", "title", "detail", "why_it_matters") if k in f}, indent=1))
