"""E3/E6/E10 skeptic: the real NHANES export through the real server, purpose=inference, proposed roles
accepted, complete cases, the seal option the plan puts first. What roles, estimand words, concerns,
and how many rows feed the coefficient table?"""
import json, sys, time
sys.path.insert(0, "/private/tmp/turbotab-audit/E-skeptic")
from drv import Drive, server, open_csv, opening

SRC = "/Users/nhedglin/tabular-ml-lab/_tt_tmp_nhanes.csv"


def main():
    t = time.time()
    with server() as client:
        d = Drive(client)
        open_csv(d, SRC)
        # Drive the opening by hand up to the split so the seal plan's own first option is used.
        d.decide({"kind": "set_lens", "lenses": ["dietary"]})
        d.reach("target"); d.decide({"kind": "set_target", "column": "glucose"})
        st = d.reach("task")
        if st["status"] in ("open", "waiting"):
            d.decide({"kind": "set_task", "column": "glucose", "task": "regression"})
        d.reach("purpose"); d.decide({"kind": "set_purpose", "purpose": "inference"})
        st = d.reach("grain")
        print("GRAIN step:", st["status"], st.get("reason"))
        if st["status"] in ("open", "waiting"):
            d.decide({"kind": "set_grain", "grain": "one_row_per_unit", "id_column": "SEQN"})
        for key in ("repeat_kind", "unit", "aggregation", "temporal"):
            st = d.reach(key)
            if st["status"] in ("open", "waiting"):
                if key == "temporal":
                    d.decide({"kind": "set_temporal", "temporal": False})
                else:
                    raise RuntimeError(f"open {key}")
        d.reach("roles")
        roles_art = d.art("roles")
        proposed = {c["column"]: c["proposed"] for c in roles_art["columns"]}
        print("PROPOSED ROLES:", json.dumps(proposed))
        d.decide({"kind": "set_roles", "roles": proposed})
        d.reach("exclusions"); d.decide({"kind": "set_exclusions", "rules": []})
        d.reach("missing"); d.decide({"kind": "set_missing", "strategy": "complete_case"})
        d.reach("split")
        plan = d.art("seal_plan")
        opts = plan["options"]
        print("SEAL PLAN options:", [o["label"] for o in opts], "cv_first:", plan.get("cv_first"))
        first = opts[0]
        print("FIRST option:", json.dumps(first)[:600])
        d.decide({"kind": "set_split", "holdout": float(first.get("holdout", 0.2)), "seed": 0, "folds": 5})
        st = d.reach("energy_adjustment")
        if st["status"] in ("open", "waiting"):
            d.decide({"kind": "set_energy_adjustment", "method": "none"})
        d.reach("models"); d.decide({"kind": "select_models", "models": ["linear"]})
        fit = d.art("fit")
        m = fit["models"][0]
        print("n_train", fit["n_train"], "n_holdout", fit["n_holdout"])
        for c in m["coefficients"]:
            print("COEF %-14s %+.5f [%+.5f, %+.5f] p=%.3g" % (c["feature"], c["estimate"], c["ci_low"], c["ci_high"], c["p"]))
        print("CONCERNS", m["concerns"])
        design = d.art("design")
        print("DESIGN WARNINGS", design["warnings"])
        print("ESTIMAND", design.get("estimand"))
        print("STEPS", [s["label"] + ": " + s["detail"] for s in design["models"][0]["steps"]])
        view = d.get("")
        txt = json.dumps(view)
        print("survey_design_absent in project view:", "survey_design_absent" in txt)
        for k in ("findings", "attention"):
            if k in view:
                print(k, "keys sample:", str(view[k])[:300])
    print(f"[{time.time()-t:.0f}s]")


if __name__ == "__main__":
    main()
