"""E1 skeptic: inference on repeated rows through the real server, two paths:
  U: grain answered "unknown" with 25 participants x 8 visits (plenty of units: undetermined, not abandoned)
  A: grain "repeated" by participant_id with 7 participants x 30 visits (abandoned: < min_groups)
Null exposure effect (varies mostly between participants); strong participant intercepts."""
import json, sys
import numpy as np, pandas as pd
sys.path.insert(0, "/private/tmp/turbotab-audit/E-skeptic")
from drv import Drive, server, open_csv, opening, OUT


def fixture(units, per, seed):
    rng = np.random.default_rng(seed)
    pid = np.repeat(np.arange(units) + 5001, per)
    ux = rng.normal(0, 1, units)
    uy = rng.normal(0, 1.5, units)
    x = np.repeat(ux, per) + rng.normal(0, 0.3, units * per)
    y = 100 + 4 * np.repeat(uy, per) + rng.normal(0, 3, units * per)  # no x effect
    bmi = np.repeat(rng.normal(27, 3, units), per)
    return pd.DataFrame({"participant_id": pid, "potassium_mg": 2500 + 400 * x, "bmi": bmi, "dbp": y})


def run(tag, frame, grain):
    path = OUT / f"e1_{tag}.csv"
    frame.to_csv(path, index=False)
    with server() as client:
        d = Drive(client)
        open_csv(d, path)
        roles = {"participant_id": "identifier", "potassium_mg": "exposure", "bmi": "covariate"}
        split = {"kind": "set_split", "holdout": 0.0, "seed": 0, "folds": 5}
        opening(d, lens=["clinical"], target="dbp", task="regression", purpose="inference",
                grain=grain, roles=roles, split=split)
        sp = d.art("split")
        print(f"[{tag}] basis state={sp['basis']['state']} grouped_by={sp.get('grouped_by')} exploratory={sp.get('exploratory')}")
        print(f"[{tag}] basis sentence: {sp['basis']['sentence']}")
        fit = d.art("fit")
        m = fit["models"][0]
        for c in m["coefficients"]:
            print(f"[{tag}] COEF {c['feature']:14s} {c['estimate']:+.5f} [{c['ci_low']:+.5f},{c['ci_high']:+.5f}] p={c['p']:.3g}")
        print(f"[{tag}] CONCERNS {m['concerns']}  n_train={fit['n_train']}")
    import statsmodels.formula.api as smf
    mm = smf.mixedlm("dbp ~ potassium_mg + bmi", frame, groups=frame["participant_id"]).fit()
    cl = smf.ols("dbp ~ potassium_mg + bmi", frame).fit(cov_type="cluster", cov_kwds={"groups": frame["participant_id"]}, use_t=True)
    print(f"[{tag}] mixed  potassium [{mm.conf_int().loc['potassium_mg'][0]:+.5f},{mm.conf_int().loc['potassium_mg'][1]:+.5f}] p={mm.pvalues['potassium_mg']:.3g}")
    print(f"[{tag}] CR+t   potassium [{cl.conf_int().loc['potassium_mg'][0]:+.5f},{cl.conf_int().loc['potassium_mg'][1]:+.5f}] p={cl.pvalues['potassium_mg']:.3g}")


if __name__ == "__main__":
    run("U", fixture(25, 8, 3), {"grain": "unknown"})
    run("A", fixture(7, 30, 4), {"grain": "repeated", "id_column": "participant_id"})
