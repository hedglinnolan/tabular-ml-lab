"""E3/E6 skeptic, offline on the same NHANES export: complete-case rows on the app's predictor set.
(1) all rows vs random 80% subsets for the sugar coefficient (E6);
(2) fat_total with and without its parts co-adjusted (E3)."""
import numpy as np, pandas as pd, statsmodels.api as sm

df = pd.read_csv("/Users/nhedglin/tabular-ml-lab/_tt_tmp_nhanes.csv")
P = ["gender", "age", "bp_sys", "bp_di", "weight", "height", "bmi", "waist", "kcal", "protein", "sugar",
     "carb", "fat_total", "fat_sat", "fat_mon", "fat_poly", "hdl", "triglycerides", "meds_hbp", "meds_chol"]
print("meds_hbp values:", df["meds_hbp"].value_counts(dropna=False).to_dict())
cc = df.dropna(subset=P + ["glucose"]).copy()
print("complete cases on P+glucose:", len(cc))
cc["gender_male"] = (cc["gender"] == "male").astype(float)
for c in ("meds_hbp", "meds_chol"):
    cc[c] = cc[c].map(lambda v: 1.0 if str(v).upper() == "TRUE" else 0.0)
X = cc[["gender_male"] + [p for p in P if p != "gender"]].astype(float)
y = cc["glucose"].astype(float)


def ols(Xs, ys, cols=None):
    cols = cols or list(Xs.columns)
    return sm.OLS(ys, sm.add_constant(Xs[cols])).fit()


full = ols(X, y)
ci = full.conf_int().loc["sugar"]
print(f"ALL {len(y)} rows: sugar {full.params['sugar']:+.4f} CI [{ci[0]:+.4f},{ci[1]:+.4f}] width {ci[1]-ci[0]:.4f} p={full.pvalues['sugar']:.3f}")
rng = np.random.default_rng(2026)
ests, widths, sig = [], [], 0
for _ in range(20):
    idx = rng.permutation(len(y))[: int(round(0.8 * len(y)))]
    r = ols(X.iloc[idx], y.iloc[idx])
    c = r.conf_int().loc["sugar"]
    ests.append(r.params["sugar"]); widths.append(c[1] - c[0]); sig += r.pvalues["sugar"] < 0.05
print(f"20 random 80% draws: sugar range {min(ests):+.4f} .. {max(ests):+.4f}; mean width ratio {np.mean(widths)/(ci[1]-ci[0]):.3f}; p<0.05 in {sig}/20")

with_parts = ols(X, y)
no_parts = ols(X, y, [c for c in X.columns if c not in ("fat_sat", "fat_mon", "fat_poly")])
print(f"fat_total with parts {with_parts.params['fat_total']:+.3f}; without parts {no_parts.params['fat_total']:+.3f}")
no_med = ols(X, y, [c for c in X.columns if c not in ("bmi", "waist", "weight", "hdl", "triglycerides", "bp_sys", "bp_di", "meds_hbp", "meds_chol")])
for v in ("sugar", "carb", "fat_total"):
    print(f"{v}: full-adjusted {full.params[v]:+.4f} (p={full.pvalues[v]:.3f})  vs without body/lipid/BP covariates {no_med.params[v]:+.4f} (p={no_med.pvalues[v]:.3f})")
