"""E2 skeptic: the app's own 'impute' (median, optional indicator) vs complete cases, under purpose=inference,
through the real design_spec -> build_pipeline -> Linear.coefficients path.
DGP (different from the original auditor): sodium exposure x, confounder bmi (z) and fully observed age (a).
  y = 0.4*x + 0.8*z + 0.3*a + e ; z missing ~40%.
Mechanisms: MCAR (most favourable to single imputation) and MAR on age (observed covariate)."""
import sys, time, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
import numpy as np, pandas as pd
import turbotab.core.models  # noqa: registers families
from turbotab.core.decisions import ProjectState, MissingSpec
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import design_spec, build_pipeline

LIN = get_family("linear")
COLS = ["x", "z", "a"]
ROLES = {"x": "exposure", "z": "covariate", "a": "covariate"}
B = 0.4


def fit(frame, ms):
    st = ProjectState(target="y", task="regression", purpose="inference", roles=ROLES, missing=ms)
    X = frame[COLS]
    y = frame["y"].to_numpy()
    if ms.strategy == "complete_case":
        keep = X.notna().all(axis=1).to_numpy()
        X, y = X[keep], y[keep]
    spec = design_spec(st, X, COLS)
    pipe = build_pipeline(spec, LIN, "regression", "inference", len(X), X.shape[1]).fit(X, y)
    r = {c["feature"]: c for c in LIN.coefficients(pipe, X, y, task="regression", purpose="inference")}["x"]
    return r["estimate"], r["ci_low"], r["ci_high"]


def draw(n, mech, rng):
    a = rng.normal(size=n)
    z = 0.5 * a + rng.normal(size=n)
    x = 0.6 * z + rng.normal(size=n)
    y = B * x + 0.8 * z + 0.3 * a + rng.normal(size=n)
    if mech == "MCAR":
        p = np.full(n, 0.4)
    else:
        p = 1 / (1 + np.exp(-(-0.45 + 1.2 * a)))
    z = np.where(rng.random(n) < p, np.nan, z)
    return pd.DataFrame({"x": x, "z": z, "a": a, "y": y})


OPTS = {"complete cases": MissingSpec(strategy="complete_case"),
        "impute (median)": MissingSpec(strategy="impute"),
        "impute + indicator": MissingSpec(strategy="impute", indicators=True)}
t = time.time()
for mech in ("MCAR", "MAR-on-age"):
    rng = np.random.default_rng(7 if mech == "MCAR" else 8)
    res = {k: [] for k in OPTS}
    miss = []
    for _ in range(120):
        f = draw(800, mech, rng)
        miss.append(f["z"].isna().mean())
        for k, ms in OPTS.items():
            res[k].append(fit(f, ms))
    print(f"\n{mech}: z missing {np.mean(miss):.2f}; true beta_x = {B}")
    for k, v in res.items():
        a = np.asarray(v)
        cov = np.mean((a[:, 1] <= B) & (B <= a[:, 2]))
        print(f"  {k:20s} mean {a[:,0].mean():.3f} bias {a[:,0].mean()-B:+.3f} coverage {cov:.2f}")
print(f"[{time.time()-t:.0f}s]")
