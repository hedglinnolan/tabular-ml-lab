import sys, warnings; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
import numpy as np, pandas as pd, statsmodels.api as sm
import turbotab.core.models
from turbotab.core.decisions import ProjectState, MissingSpec
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import design_spec, build_pipeline
rng = np.random.default_rng(5); n = 1500
fiber = rng.normal(20, 6, n); age = rng.normal(50, 10, n)
p = 1/(1+np.exp(-(-1 - 0.08*(fiber-20) + 0.04*(age-50))))
y = np.where(rng.random(n) < p, "diabetic", "not_diabetic")
X = pd.DataFrame({"fiber_g": fiber, "age": age})
st = ProjectState(target="dm", task="binary", purpose="inference", roles={"fiber_g": "exposure", "age": "covariate"}, missing=MissingSpec(strategy="complete_case"))
spec = design_spec(st, X, ["fiber_g", "age"]); LIN = get_family("linear")
pipe = build_pipeline(spec, LIN, "binary", "inference", n, 2).fit(X, y)
rows = LIN.coefficients(pipe, X, y, task="binary", purpose="inference")
for r in rows: print("APP", r)
print("classes_", list(pipe[-1].classes_), "-> event modelled = classes[1]")
ref = sm.Logit((y == sorted(set(y))[1]).astype(float), sm.add_constant(X)).fit(disp=0)
print("sm.Logit params (log-odds):", ref.params.round(5).to_dict())
print("OR per g fiber:", float(np.exp(ref.params['fiber_g'])))
print("describe():", LIN.describe("binary", "inference"))
