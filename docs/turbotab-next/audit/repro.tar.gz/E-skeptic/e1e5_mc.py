"""E1/E5 skeptic: type-I error of the app's statsmodels_fit (the function the inference table calls)
for a null between-unit exposure, with and without groups, plus t(G-1) and CR2-like corrections for contrast.
Different DGP from the original auditor: ICC ~0.3, unbalanced cluster sizes."""
import sys, time, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
import numpy as np, pandas as pd
from scipy import stats
from turbotab.core.models.linear import statsmodels_fit


def draw(G, rng, task):
    sizes = rng.integers(5, 25, G)
    ids = np.repeat(np.arange(G), sizes)
    n = len(ids)
    x = np.repeat(rng.normal(size=G), sizes) + rng.normal(0, 0.5, n)
    z = rng.normal(size=n)  # a within-row covariate
    u = np.repeat(rng.normal(0, np.sqrt(0.43), G), sizes)  # ICC ~0.3 on latent scale for OLS
    if task == "regression":
        y = u + 0.3 * z + rng.normal(0, 1, n); classes = None
    else:
        y = (rng.random(n) < 1 / (1 + np.exp(-(-0.3 + 1.2 * u / np.sqrt(0.43) * 0.8 + 0.3 * z)))).astype(int); classes = [0, 1]
    return pd.DataFrame({"x": x, "z": z}), y, ids


def run(G, reps, task, seed):
    rng = np.random.default_rng(seed)
    iid = cl = clt = 0; k = 0
    for _ in range(reps):
        X, y, ids = draw(G, rng, task)
        try:
            a = statsmodels_fit(task, X, y, [0, 1] if task != "regression" else None, None)
            b = statsmodels_fit(task, X, y, [0, 1] if task != "regression" else None, ids)
        except Exception:
            continue
        k += 1
        lo, hi = np.asarray(a.conf_int(0.05))[1]; iid += not (lo <= 0 <= hi)
        lo, hi = np.asarray(b.conf_int(0.05))[1]; cl += not (lo <= 0 <= hi)
        # same cluster-robust SE, but t(G-1) critical value
        se = np.asarray(b.bse)[1]; est = np.asarray(b.params)[1]
        clt += abs(est / se) > stats.t.ppf(0.975, G - 1)
    return k, iid / k, cl / k, clt / k, getattr(b, "use_t", None)


t = time.time()
print("task        G   reps  iid    cluster(app)  cluster+t(G-1)  use_t")
for task in ("regression", "binary"):
    for G in (8, 12, 30):
        k, a, b, c, ut = run(G, 300, task, 100 + G)
        print(f"{task:10s} {G:3d} {k:5d}  {a:.3f}  {b:.3f}         {c:.3f}           {ut}")
print(f"[{time.time()-t:.0f}s]")
