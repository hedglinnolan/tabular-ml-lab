import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.methods.energy import EnergyAdjuster
rng = np.random.default_rng(7); n = 5000
sex = rng.integers(0, 2, n).astype(float)
E = 1700 + 700*sex + rng.normal(0, 350, n)
P = 0.035*E + 12*sex + rng.normal(0, 12, n)   # men higher protein density
Y = 0.3*P - 0.01*E + 3*sex + rng.normal(0, 5, n)
df = pd.DataFrame({"protein_g": P, "energy_kcal": E, "sex": sex})
adj = EnergyAdjuster("residual", "energy_kcal", ["protein_g"]).fit(df).transform(df)
std = sm.OLS(Y, sm.add_constant(df[["protein_g","energy_kcal","sex"]])).fit()
res = sm.OLS(Y, sm.add_constant(adj[["protein_g_adj","sex"]])).fit()
resE = sm.OLS(Y, sm.add_constant(pd.concat([adj[["protein_g_adj","sex"]], df[["energy_kcal"]]],axis=1))).fit()
print("transformer output columns:", list(adj.columns))
print("standard  beta=%.4f CI=%s" % (std.params["protein_g"], std.conf_int().loc["protein_g"].round(4).tolist()))
print("app residual (E dropped) beta=%.4f CI=%s" % (res.params["protein_g_adj"], res.conf_int().loc["protein_g_adj"].round(4).tolist()))
print("residual + E beta=%.4f" % resE.params["protein_g_adj"])
print("truth (substitution at fixed E, sex) = 0.30")
