import numpy as np, warnings
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score
warnings.filterwarnings("ignore")
rng = np.random.default_rng(1)
def draw(n):
    X = rng.normal(size=(n, 6)); lin = 0.6*X[:,0] + 0.4*X[:,1] + 0.3*X[:,2]
    y = (rng.random(n) < 1/(1+np.exp(-lin))).astype(int); return X, y
for n in [50, 100, 200, 500]:
    a, b, d = [], [], []
    for r in range(120):
        X, y = draw(n)
        cv = StratifiedKFold(5, shuffle=True, random_state=r)
        s1 = cross_val_score(LogisticRegression(max_iter=500), X[:, :3], y, cv=cv, scoring="roc_auc").mean()
        s2 = cross_val_score(LogisticRegression(max_iter=500), X, y, cv=cv, scoring="roc_auc").mean()
        a.append(s1); b.append(s2); d.append(s1 - s2)
    a, d = np.array(a), np.array(d)
    print(f"n={n:4d} mean AUC={a.mean():.3f} SD single CV AUC={a.std():.3f}  SD of paired diff (3 vs 6 predictors)={d.std():.3f}  mean diff={d.mean():.3f}")
