import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.decisions import ProjectState, EnergyAdjustment
from turbotab.core.models.pipeline import model_predictors, design_spec, build_pipeline
from turbotab.core.models.linear import model_matrix, statsmodels_fit
import turbotab.core.models.linear as L

rng = np.random.default_rng(42)
n = 4000
sex = rng.integers(0, 2, n).astype(float)           # covariate correlated with energy
E = 1800 + 500*sex + rng.normal(0, 400, n)
P = 0.04*E + 8*sex + rng.normal(0, 15, n)          # protein density depends on sex
age = rng.normal(50, 10, n)
y = 0.3*P - 0.01*E + 2*sex + 0.05*age + rng.normal(0, 5, n)
df = pd.DataFrame({"protein_g": P, "energy_kcal": E, "sex": sex, "age": age})
roles = {"protein_g": "exposure", "energy_kcal": "energy", "sex": "covariate", "age": "covariate"}

fam = L.Linear()
def fit(method, E_col="energy_kcal", nutrients=("protein_g",)):
    adj = EnergyAdjustment(method=method, energy_column=(None if method=="none" else E_col),
                           nutrients=([] if method=="none" else list(nutrients)))
    st = ProjectState(target="y", task="regression", purpose="inference", roles=roles,
                      energy_adjustment=adj, missing="complete_case")
    preds = model_predictors(st)
    spec = design_spec(st, df, preds)
    pipe = build_pipeline(spec, fam, "regression", "inference", n, len(preds))
    pipe.fit(df[spec.inputs], y)
    M = model_matrix(pipe, df[spec.inputs])
    r = statsmodels_fit("regression", M, y, None)
    return preds, list(M.columns), r

for m in ["none", "standard", "residual"]:
    preds, cols, r = fit(m)
    nm = [c for c in cols if c.startswith("protein")][0]
    lo, hi = r.conf_int().loc[nm]
    print(f"{m:9s} predictors={preds} matrix={cols} beta_{nm}={r.params[nm]:.4f} CI=[{lo:.4f},{hi:.4f}]")

# true absolute-intake model Y ~ N + C (no E)
X = sm.add_constant(df[["protein_g","sex","age"]]); r = sm.OLS(y, X).fit()
print("Y~N+C (truly unadjusted) beta=", round(r.params["protein_g"],4))
# residual + E
from turbotab.core.methods.energy import EnergyAdjuster
adjd = EnergyAdjuster("residual","energy_kcal",["protein_g"]).fit(df).transform(df)
X = sm.add_constant(pd.concat([adjd, df[["energy_kcal"]]],axis=1)); r=sm.OLS(y,X).fit()
print("residual + E beta=", round(r.params["protein_g_adj"],4))
# no-covariate residual vs standard CI
X1 = sm.add_constant(df[["protein_g","energy_kcal"]]); r1=sm.OLS(y,X1).fit()
X2 = sm.add_constant(adjd[["protein_g_adj"]]); r2=sm.OLS(y,X2).fit()
print("no covariates: standard", r1.params["protein_g"].round(4), r1.conf_int().loc["protein_g"].round(4).tolist(),
      "| residual", r2.params["protein_g_adj"].round(4), r2.conf_int().loc["protein_g_adj"].round(4).tolist())
