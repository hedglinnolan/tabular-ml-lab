import numpy as np, pandas as pd
from turbotab.core.decisions import ProjectState
from turbotab.core.models.pipeline import model_predictors, design_spec, build_pipeline
from turbotab.core.models.linear import model_matrix, statsmodels_fit
import turbotab.core.models.linear as L
fam = L.Linear()
roles = {"x": "exposure", "c": "covariate"}
def run(strategy, seed, n=1000):
    rng = np.random.default_rng(seed)
    c = rng.normal(0, 1, n); x = 0.7*c + rng.normal(0, 0.7, n)
    y = 1.0*x + 1.5*c + rng.normal(0, 1, n)
    # covariate c missing MAR depending on x (observed)
    p = 1/(1+np.exp(-(x*1.2 - 0.3)))
    cm = c.copy(); cm[rng.random(n) < p] = np.nan
    df = pd.DataFrame({"x": x, "c": cm})
    st = ProjectState(target="y", task="regression", purpose="inference", roles=roles, missing=strategy)
    preds = model_predictors(st)
    if strategy == "complete_case":
        keep = df.notna().all(axis=1); df, y = df[keep], y[keep.to_numpy()]
    spec = design_spec(st, df, preds)
    pipe = build_pipeline(spec, fam, "regression", "inference", len(df), len(preds)).fit(df[spec.inputs], y)
    M = model_matrix(pipe, df[spec.inputs]); r = statsmodels_fit("regression", M, y, None)
    lo, hi = r.conf_int().loc["x"]
    return r.params["x"], lo <= 1.0 <= hi, float(np.isnan(cm).mean())
for s in ["impute", "complete_case"]:
    out = np.array([run(s, k) for k in range(300)])
    print(f"{s:14s} mean beta_x={out[:,0].mean():.3f} coverage={out[:,1].mean():.3f} missing share={out[:,2].mean():.2f}")
