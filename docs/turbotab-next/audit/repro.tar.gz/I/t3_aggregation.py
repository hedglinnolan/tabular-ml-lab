import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core import seal  # noqa
from turbotab.core.decisions import ProjectState, Refusal, validate
st = ProjectState(lens=["clinical"], target="progressed", task="binary", purpose="prediction",
                  grain={"grain": "repeated", "id_column": "subject_id"},
                  repeat_kind={"repeat_kind": "time_points", "time_column": "visit_date"}, unit="unit")
structure = {"outcome": {"column": "progressed", "varies": True, "n_units_varying": 40, "numeric": True}}
ctx = {"columns": ["subject_id", "visit_date", "sbp", "progressed"], "state": st, "target": "progressed", "task": "binary",
       "column_info": {"progressed": {"dtype": "integer", "n_unique": 2, "n_missing": 0}},
       "artifact": lambda s: structure if s == "structure" else None}
for m, o in [("last", "first"), ("mean", "first"), ("change", "first"), ("first", "last")]:
    try:
        validate({"kind": "set_aggregation", "method": m, "outcome": o}, ctx); print(f"ACCEPTED predictors={m:<7} outcome={o}")
    except Refusal as r:
        print(f"REFUSED  predictors={m:<7} outcome={o}: {r.code} {r.message}")
