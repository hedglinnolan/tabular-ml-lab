import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I")
from harness import *
DIET = Path("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data/clinical_risk.csv")

def served(c, pid):
    wait_for(c, pid, {"fit": "fresh"}, timeout=240)
    r = c.get(f"/api/projects/{pid}/stages/fit").json()
    a = r["artifact"]
    return {m["family"]: (m.get("holdout") or {}) for m in a["models"]}, a.get("holdout_sealed"), a.get("changed_after_seal", r.get("changed_after_seal"))

def main():
    with client() as c:
        pid = open_path(c, DIET)
        answers = {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
                   "target": {"kind": "set_target", "column": "readmit_30d"},
                   "models": {"kind": "select_models", "models": ["linear", "boosted_trees"]}}
        view, _ = walk(c, pid, answers, stop_before="open_seal")
        s, sealed, ch = served(c, pid)
        print("before opening: holdout_sealed", sealed, "scores", s)
        r = c.post(f"/api/projects/{pid}/decisions", json={"kind": "open_seal"}); print("open_seal", r.status_code)
        s, sealed, ch = served(c, pid)
        print("opened seed=0:", {k: round(v.get('auc', float('nan')), 4) for k, v in s.items()}, "changed_after_seal", ch)
        seen = []
        for seed in (1, 2, 3, 4, 5):
            r = c.post(f"/api/projects/{pid}/decisions", json={"kind": "set_split", "holdout": 0.2, "seed": seed, "folds": 5})
            sentence = r.json()["decisions"][-1]["sentence"] if r.status_code == 200 else r.text[:200]
            s, sealed, ch = served(c, pid)
            seen.append((seed, {k: round(v.get('auc', float('nan')), 4) for k, v in s.items()}))
            print(f"  re-drawn seed={seed} [{r.status_code}] sealed={sealed} changed={ch} AUC={seen[-1][1]}")
            print("     sentence:", sentence[:160])
        # a new outcome after opening: are its held-out scores served without any opening?
        r = c.post(f"/api/projects/{pid}/decisions", json={"kind": "set_target", "column": "length_of_stay_days"})
        print("set_target after opening:", r.status_code)
        view, _ = walk(c, pid, {}, stop_before="open_seal", log=False)
        st = c.get(f"/api/projects/{pid}").json()
        print("  interview open_seal step:", [x for x in st["interview"] if x["key"] == "open_seal"])
        s, sealed, ch = served(c, pid)
        print("  new outcome held-out scores served:", sealed, s)

if __name__ == "__main__":
    main()
