import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I")
from harness import *
F = Path("/private/tmp/turbotab-audit/I/fixtures")
def main():
    with client() as c:
        pid = open_path(c, F / "mar_missing.csv")
        view, asked = walk(c, pid, {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
                                    "target": {"kind": "set_target", "column": "crp"},
                                    "purpose": {"kind": "set_purpose", "purpose": "inference"},
                                    "roles": {"kind": "set_roles", "roles": {"participant_id": "identifier", "age": "covariate", "fiber_g": "exposure"}},
                                    "missing": {"kind": "set_missing", "strategy": "impute", "indicators": True},
                                    "split": {"kind": "set_split", "holdout": 0.0, "seed": 0, "folds": 5},
                                    "models": {"kind": "select_models", "models": ["linear"]}}, stop_before="open_seal")
        wait_for(c, pid, {"fit": "fresh", "design": "fresh"}, timeout=240)
        fit = c.get(f"/api/projects/{pid}/stages/fit").json()["artifact"]
        m = fit["models"][0]
        print("n_train", fit["n_train"], "concerns", m["concerns"])
        for r in m["coefficients"]:
            print("  ", r["feature"], round(r["estimate"], 4), (round(r["ci_low"], 4), round(r["ci_high"], 4)))
        recs = c.get(f"/api/projects/{pid}").json()["decisions"]
        print("missing sentence:", [d["sentence"] for d in recs if d["decision"]["kind"] == "set_missing"])
        des = c.get(f"/api/projects/{pid}/stages/design").json()["artifact"]
        print("design steps:", [ (s.get("label"), s.get("detail")) for s in (des.get("models") or [{}])[0].get("steps", [])][:6])
if __name__ == "__main__":
    main()
