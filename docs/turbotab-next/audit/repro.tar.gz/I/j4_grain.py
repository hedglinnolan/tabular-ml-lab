import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I")
from harness import *
S = Path("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data")
def main():
    with client() as c:
        for name, target, lens in [("clinical_risk.csv", "readmit_30d", ["clinical"]),
                                   ("clinical_labs.csv", None, ["clinical"])]:
            pid = open_path(c, S / name)
            cols = [x["name"] for x in c.get(f"/api/projects/{pid}/columns").json()]
            target = target or cols[-1]
            view, _ = walk(c, pid, {"lens": {"kind": "set_lens", "lenses": lens},
                                    "target": {"kind": "set_target", "column": target}}, stop_before="grain", log=False)
            wait_for(c, pid, {"structure": "fresh"}, timeout=120)
            st = c.get(f"/api/projects/{pid}/stages/structure").json()["artifact"]
            g = st.get("grain") or {}
            print(f"=== {name} target={target} cols={cols}")
            print("  grain reading:", {k: g.get(k) for k in ("stated", "suggested", "if_one_row", "reading", "sentence")})
            r = c.post(f"/api/projects/{pid}/decisions", json={"kind": "set_grain", "grain": "one_row_per_unit"})
            print("  answer 'one row each' ->", r.status_code, r.text[:400])
if __name__ == "__main__":
    main()
