import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I")
from harness import *
F = Path("/private/tmp/turbotab-audit/I/fixtures")
def main():
    with client() as c:
        for name, target, lens in [("cohort_tte.csv", "cvd_event", ["clinical"]),
                                   ("ordinal_text.csv", "symptom_severity", ["clinical"])]:
            print(f"=== {name}  target={target}")
            pid = open_path(c, F / name)
            view, asked = walk(c, pid, {"lens": {"kind": "set_lens", "lenses": lens},
                                        "target": {"kind": "set_target", "column": target},
                                        "purpose": {"kind": "set_purpose", "purpose": "inference"}},
                               stop_before="roles")
            ti = c.get(f"/api/projects/{pid}/stages/target_info").json()["artifact"]
            print("  target_info:", {k: ti.get(k) for k in ("task", "detected_task", "confidence", "reason")})
            for s in skipped(view): print("  NOT ASKED:", s)
            wait_for(c, pid, {"roles": "fresh"}, timeout=120)
            roles = c.get(f"/api/projects/{pid}/stages/roles").json()["artifact"]
            print("  proposed roles:", {r["column"]: (r["proposed"], r.get("reason")) for r in roles["columns"]})
            # findings mentioning time / survival?
            fnd = c.get(f"/api/projects/{pid}/stages/findings").json().get("artifact") or {}
            items = fnd.get("findings") or fnd.get("items") or []
            print("  findings:", [ (f.get("id") or f.get("code"), (f.get("summary") or f.get("title") or "")[:90]) for f in items][:10])

if __name__ == '__main__':
    main()
