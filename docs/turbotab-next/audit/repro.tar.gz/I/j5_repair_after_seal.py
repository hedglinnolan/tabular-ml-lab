import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I")
from harness import *
import pandas as pd
F = Path("/private/tmp/turbotab-audit/I/fixtures")
def assignment(c, pid):
    wait_for(c, pid, {"split": "fresh"}, timeout=120)
    svc_home = HOME
    a = c.get(f"/api/projects/{pid}/stages/split").json()["artifact"]
    return a
def main():
    with client() as c:
        pid = open_path(c, F / "sbp_impossible.csv")
        view, _ = walk(c, pid, {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
                                "target": {"kind": "set_target", "column": "sbp"},
                                "models": {"kind": "select_models", "models": ["linear"]}}, stop_before="open_seal")
        wait_for(c, pid, {"fit": "fresh", "findings": "fresh"}, timeout=240)
        fnd = c.get(f"/api/projects/{pid}/stages/findings").json()["artifact"]
        items = fnd.get("findings") or []
        print("findings:", [(f.get("id"), [o.get("option") or o.get("key") for o in (f.get("options") or [])]) for f in items])
        a1 = assignment(c, pid)
        print("split before repair:", {k: a1.get(k) for k in ("n_train", "n_holdout", "note")})
        # the server's sealed rows before
        import json
        from turbotab.core.graph import artifact_dir
        st = c.get(f"/api/projects/{pid}").json()["stages"]["split"]
        p1 = list((HOME / "projects" / pid / "cache" / "split" / st["key"]).rglob("sealed.parquet"))
        s1 = set(pd.read_parquet(p1[0])["row_id"]) if p1 else None
        imp = [f for f in items if "impossible" in (f.get("id") or "") or "plausib" in (f.get("id") or "")]
        print("impossible findings:", [f.get("id") for f in imp])
        for f in imp:
            r = c.post(f"/api/projects/{pid}/decisions", json={"kind": "apply_repair", "finding_id": f["id"], "option": "set_missing"})
            print("apply_repair set_missing after the seal ->", r.status_code, (r.json().get("decisions") or [{}])[-1].get("sentence") if r.status_code == 200 else r.text[:300])
            break
        import time; time.sleep(1)
        a2 = assignment(c, pid)
        st = c.get(f"/api/projects/{pid}").json()["stages"]["split"]
        p2 = list((HOME / "projects" / pid / "cache" / "split" / st["key"]).rglob("sealed.parquet"))
        s2 = set(pd.read_parquet(p2[0])["row_id"]) if p2 else None
        print("split after repair:", {k: a2.get(k) for k in ("n_train", "n_holdout", "note")})
        if s1 is not None and s2 is not None:
            print(f"held-out rows before {len(s1)}, after {len(s2)}, kept {len(s1 & s2)}, moved held-out->training {len(s1 - s2)}")
        else:
            print("sealed parquet paths:", p1, p2)
if __name__ == "__main__":
    main()
