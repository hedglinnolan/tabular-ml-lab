import numpy as np, pandas as pd, statsmodels.api as sm, statsmodels.formula.api as smf
F = "/private/tmp/turbotab-audit/I/fixtures/"
d = pd.read_csv(F + "survey_weighted.csv")
X = sm.add_constant(d[["DR1TKCAL", "DR1TFIBE"]])
ols = sm.OLS(d.LBXCRP, X).fit()
# design-based: weighted point estimate, SE clustered on PSU-within-stratum (Taylor-linearization approximation)
cl = pd.factorize(d.SDMVSTRA.astype(str) + "_" + d.SDMVPSU.astype(str))[0]
wls = sm.WLS(d.LBXCRP, X, weights=d.WTDRD1).fit(cov_type="cluster", cov_kwds={"groups": cl})
print("survey: unweighted OLS fiber slope %.4f (CI %.4f, %.4f)" % (ols.params.DR1TFIBE, *ols.conf_int().loc["DR1TFIBE"]))
print("survey: weighted, design-clustered  %.4f (CI %.4f, %.4f)" % (wls.params.DR1TFIBE, *wls.conf_int().loc["DR1TFIBE"]))
m = pd.read_csv(F + "multisite.csv")
a = smf.ols("sbp_change ~ sodium_g", m).fit()
b = smf.ols("sbp_change ~ sodium_g + C(site)", m).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(m.site)[0]})
print("multisite: no site term   %.3f (CI %.3f, %.3f)" % (a.params.sodium_g, *a.conf_int().loc["sodium_g"]))
print("multisite: site FE + cluster %.3f (CI %.3f, %.3f)" % (b.params.sodium_g, *b.conf_int().loc["sodium_g"]))
