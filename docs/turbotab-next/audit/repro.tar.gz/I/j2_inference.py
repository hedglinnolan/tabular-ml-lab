import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I")
from harness import *
F = Path("/private/tmp/turbotab-audit/I/fixtures")

def fit_coefs(c, pid, timeout=240):
    wait_for(c, pid, {"fit": "fresh"}, timeout=timeout)
    fit = c.get(f"/api/projects/{pid}/stages/fit").json()["artifact"]
    return fit

def run(c, name, target, lens, roles_override=None, extra=None):
    print(f"=== {name} target={target} purpose=inference")
    pid = open_path(c, F / name)
    answers = {"lens": {"kind": "set_lens", "lenses": lens},
               "target": {"kind": "set_target", "column": target},
               "purpose": {"kind": "set_purpose", "purpose": "inference"},
               "models": {"kind": "select_models", "models": ["linear"]}}
    if roles_override:
        def roles(c, pid, view):
            cols = _artifact(c, pid, "roles").get("columns") or []
            r = {x["column"]: x["proposed"] for x in cols}
            r.update(roles_override); return {"kind": "set_roles", "roles": r}
        answers["roles"] = roles
    answers.update(extra or {})
    view, asked = walk(c, pid, answers, stop_before="split")
    plan = c.get(f"/api/projects/{pid}/stages/seal_plan").json()
    wait_for(c, pid, {"seal_plan": "fresh"}, timeout=120)
    plan = c.get(f"/api/projects/{pid}/stages/seal_plan").json()["artifact"]
    print("  split options offered (in order):", [o["label"] for o in plan["options"]], "cv_first:", plan["cv_first"])
    print("  reason:", plan["reason"])
    view, asked2 = walk(c, pid, answers, stop_before="open_seal")
    print("  questions asked:", [k for k, _, _ in asked + asked2])
    for s in skipped(view): print("  NOT ASKED:", s[0], s[1], (s[2] or "")[:100])
    fit = fit_coefs(c, pid)
    m = fit["models"][0]
    print("  n_train:", fit["n_train"], "n_holdout:", fit["n_holdout"], "concerns:", m["concerns"])
    for row in (m["coefficients"] or [])[:8]:
        print("   coef:", {k: row.get(k) for k in row if k in ("term", "feature", "estimate", "coef", "low", "high", "ci_low", "ci_high", "p", "p_value", "odds_ratio", "scale")})
    st = c.get(f"/api/projects/{pid}").json()["state"]
    print("  roles recorded:", st["roles"])
    return pid

def main():
    with client() as c:
        run(c, "cohort_tte_null.csv", "cvd_event", ["clinical"])
        run(c, "survey_weighted.csv", "LBXCRP", ["dietary", "clinical"])
        run(c, "multisite.csv", "sbp_change", ["clinical"])

if __name__ == "__main__":
    main()
