import numpy as np, pandas as pd
rng = np.random.default_rng(7)
n = 3000
entry = rng.uniform(0, 14, n)                         # calendar year of enrolment (0..14)
fiber = (15 + 1.0 * entry + rng.normal(0, 4, n)).clip(1)   # secular trend: later enrolees eat more fiber
age = rng.normal(55, 8, n)
haz = 0.03 * np.exp(0.04 * (age - 55))                # fiber has NO effect on the hazard (HR = 1)
t_event = rng.exponential(1 / haz)
admin_cens = 15 - entry                               # study closes at year 15: later enrolees followed less
time = np.minimum(t_event, admin_cens)
event = (t_event <= admin_cens).astype(int)
pd.DataFrame({"participant_id": [f"P{i:05d}" for i in range(n)], "age": age.round(1),
              "fiber_g": fiber.round(2), "followup_years": time.round(3), "cvd_event": event}
             ).to_csv("/private/tmp/turbotab-audit/I/fixtures/cohort_tte_null.csv", index=False)
import statsmodels.api as sm
from statsmodels.duration.hazard_regression import PHReg
X = pd.DataFrame({"age": age, "fiber_g": fiber})
lg = sm.Logit(event, sm.add_constant(X)).fit(disp=0)
cox = PHReg(time, X, status=event).fit()
print("events:", event.sum(), "of", n)
print("logistic OR per g fiber: %.4f  95%% CI %.4f-%.4f  p=%.2g" % (np.exp(lg.params['fiber_g']), *np.exp(lg.conf_int().loc['fiber_g']), lg.pvalues['fiber_g']))
ci = cox.conf_int()
print("Cox HR per g fiber:      %.4f  95%% CI %.4f-%.4f  p=%.2g" % (np.exp(cox.params[1]), np.exp(ci[1][0]), np.exp(ci[1][1]), cox.pvalues[1]))
