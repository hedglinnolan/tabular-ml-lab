import numpy as np, pandas as pd
rng = np.random.default_rng(42)
out = "/private/tmp/turbotab-audit/I/fixtures/"

# F2: cohort with censored follow-up; event status + follow-up years
n = 600
age = rng.normal(55, 8, n).round(0)
fiber = rng.gamma(4, 5, n).round(1)
haz = 0.02 * np.exp(0.04 * (age - 55) - 0.03 * (fiber - 20))
t_event = rng.exponential(1 / haz)
t_cens = rng.uniform(1, 15, n)              # staggered entry -> variable follow-up
time = np.minimum(t_event, t_cens).round(2)
event = (t_event <= t_cens).astype(int)
pd.DataFrame({"participant_id": [f"P{i:04d}" for i in range(n)], "age": age, "fiber_g": fiber,
              "followup_years": time, "cvd_event": event}).to_csv(out + "cohort_tte.csv", index=False)

# F3: ordinal text outcome
sev = pd.cut(rng.normal(0, 1, n) + 0.02 * (age - 55), [-np.inf, -0.5, 0.5, 1.2, np.inf],
             labels=["none", "mild", "moderate", "severe"]).astype(str)
pd.DataFrame({"participant_id": [f"P{i:04d}" for i in range(n)], "age": age, "fiber_g": fiber,
              "symptom_severity": sev}).to_csv(out + "ordinal_text.csv", index=False)

# F4: multi-site, one row per person, strong site effect
sites = rng.integers(0, 12, n)
site_eff = rng.normal(0, 1.0, 12)[sites]
x = rng.normal(0, 1, n) + 0.8 * site_eff
y = 0.0 * x + 1.5 * site_eff + rng.normal(0, 1, n)
pd.DataFrame({"participant_id": [f"P{i:04d}" for i in range(n)], "site": [f"S{s:02d}" for s in sites],
              "sodium_g": (x + 3).round(3), "sbp_change": y.round(3)}).to_csv(out + "multisite.csv", index=False)

# F5: survey with informative weights (NHANES-like): oversampled group differs in slope
m = 2000
grp = rng.random(m) < 0.5               # sample is 50/50, population is 10/90
w = np.where(grp, 0.2, 1.8) * 10000
psu = rng.integers(1, 3, m); strata = rng.integers(1, 15, m)
kcal = rng.normal(2100, 500, m)
fiberw = rng.gamma(4, 5, m)
slope = np.where(grp, -0.10, 0.02)       # heterogeneous effect
crp = 3 + slope * (fiberw - 20) + 0.4 * grp + rng.normal(0, 1, m)
pd.DataFrame({"SEQN": np.arange(1, m + 1), "DR1TKCAL": kcal.round(1), "DR1TFIBE": fiberw.round(2),
              "WTDRD1": w.round(2), "SDMVSTRA": strata, "SDMVPSU": psu, "LBXCRP": crp.round(3)}
             ).to_csv(out + "survey_weighted.csv", index=False)
print("ok")
