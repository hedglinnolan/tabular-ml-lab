"""Validator-level probes: what the refuse rung lets through, by purpose."""
from turbotab.core import decisions as D
from turbotab.core import seal  # registers Decision A etc.
from turbotab.core.decisions import ProjectState, Refusal, validate

def probe(label, decision, ctx):
    try:
        out = validate(decision, ctx)
        print(f"ACCEPTED  {label}: {out.model_dump()}")
    except Refusal as r:
        print(f"REFUSED   {label}: {r.code}: {r.message}")

base = dict(lens=["dietary"], target="bmi", task="regression", purpose="inference",
            roles={"kcal": "energy", "fat": "exposure", "age": "covariate", "wt": "design"})
st = ProjectState(**base)
cols = ["bmi", "kcal", "fat", "age", "wt"]
info = {c: {"dtype": "numeric", "n_unique": 500, "n_missing": 0} for c in cols}
ctx = {"columns": cols, "column_info": info, "state": st, "target": "bmi", "task": "regression"}

# 1. Eligibility rule on the OUTCOME itself, under inference
probe("exclusion on the outcome (bmi 18.5-30) under inference",
      {"kind": "set_exclusions", "rules": [{"column": "bmi", "low": 18.5, "high": 30, "reason": "normal range"}]}, ctx)
# 2. Missing indicators under inference (spec: blocked with two exits)
probe("missing indicators under inference",
      {"kind": "set_missing", "strategy": "impute", "indicators": True}, ctx)
# 3. Exclusion on the survey weight / design column
probe("exclusion on a design column",
      {"kind": "set_exclusions", "rules": [{"column": "wt", "low": 0.0001, "reason": "positive weight"}]}, ctx)

# 4. After the seal is opened: re-draw split with new seed
st_open = ProjectState(**base, split={"holdout": 0.2, "seed": 0, "folds": 5}, seal_opened=True,
                       grain={"grain": "one_row_per_unit"})
ctx_open = {**ctx, "state": st_open}
probe("set_split new seed AFTER opening", {"kind": "set_split", "holdout": 0.2, "seed": 7, "folds": 5}, ctx_open)
probe("set_split holdout 0.3 AFTER opening", {"kind": "set_split", "holdout": 0.3, "seed": 0, "folds": 5}, ctx_open)
probe("set_target change AFTER opening", {"kind": "set_target", "column": "fat"}, ctx_open)
probe("set_purpose flip AFTER opening", {"kind": "set_purpose", "purpose": "prediction"}, ctx_open)
probe("set_exclusions AFTER opening", {"kind": "set_exclusions", "rules": [{"column": "age", "low": 20, "reason": "adults"}]}, ctx_open)
probe("set_task AFTER opening", {"kind": "set_task", "column": "bmi", "task": "regression"}, ctx_open)
# 5. Sealed but not opened: target change
st_sealed = ProjectState(**base, split={"holdout": 0.2, "seed": 0, "folds": 5}, grain={"grain": "one_row_per_unit"})
probe("set_target change after seal drawn (not opened)", {"kind": "set_target", "column": "fat"}, {**ctx, "state": st_sealed})
probe("set_temporal after seal drawn", {"kind": "set_temporal", "temporal": True, "time_column": "age"},
      {**ctx, "state": ProjectState(**base, split={"holdout": 0.2, "seed": 0, "folds": 5}, grain={"grain": "repeated", "id_column": "age"}, unit="row")})
print("DECISION_A kinds:", list(seal.DECISION_A))
