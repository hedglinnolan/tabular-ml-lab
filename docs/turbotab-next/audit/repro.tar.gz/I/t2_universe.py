import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np
from turbotab.core.stages.rows import draw_split
u = np.arange(1000)
_, a = draw_split(u, holdout=0.2, seed=0, folds=5, universe=u)
# an exclusion: analysed rows shrink, universe fixed
_, b = draw_split(u[50:], holdout=0.2, seed=0, folds=5, universe=u)
# the universe itself shrinks by 3 rows (an outcome value set to missing after the seal)
u2 = np.setdiff1d(u, [5, 500, 900])
_, c = draw_split(u2, holdout=0.2, seed=0, folds=5, universe=u2)
A, B, C = set(a["sealed"]), set(b["sealed"]), set(c["sealed"])
print("exclusion keeps the seal identical:", A == B)
print("universe minus 3 rows: held-out rows kept", len(A & C), "of", len(A), "-> rows that crossed from held-out to training:", len(A - C - {5,500,900}))
