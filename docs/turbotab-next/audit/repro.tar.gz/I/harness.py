"""Drive the real server (TestClient) through the Router; log every step's status."""
import json, os, sys, time
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.server.tests.conftest import make_client, wait_for, usual_answer, _artifact
from turbotab.core.interview import NEEDS

HOME = Path(os.environ.get("TT_HOME", "/private/tmp/turbotab-audit/I/home"))
HOME.mkdir(parents=True, exist_ok=True)

def client():
    return make_client(HOME, "local", 2, "http://127.0.0.1")

def steps_line(view):
    return " | ".join(f"{s['key']}:{s['status']}" for s in view["interview"])

def walk(c, pid, answers, stop_before=None, timeout=240, log=True):
    """Answer the Router's first unanswered question with answers[key] (callable or dict) or the usual one."""
    end = time.monotonic() + timeout
    asked = []
    while time.monotonic() < end:
        view = c.get(f"/api/projects/{pid}").json()
        first = next((s for s in view["interview"] if s["status"] in ("open", "waiting")), None)
        if first is None:
            return view, asked
        if stop_before and first["key"] == stop_before:
            return view, asked
        unread = [n for n in (*first["waiting_on"], *NEEDS.get(first["key"], ()))
                  if view["stages"].get(n, {}).get("status") not in (None, "fresh")]
        if first["status"] == "waiting" or unread:
            bad = [n for n in unread if view["stages"].get(n, {}).get("status") == "error"]
            if bad:
                raise RuntimeError(f"{bad}: {view['stages'][bad[0]].get('error')}")
            time.sleep(0.1); continue
        a = answers.get(first["key"])
        a = a(c, pid, view) if callable(a) else (a or usual_answer(c, pid, first["key"], view))
        r = c.post(f"/api/projects/{pid}/decisions", json=a)
        asked.append((first["key"], a, r.status_code))
        if log:
            print(f"  ASKED {first['key']:<18} -> {json.dumps(a)[:110]}  [{r.status_code}]")
        if r.status_code != 200:
            print("   refusal:", r.text[:300]); return view, asked
    raise TimeoutError(first)

def open_path(c, path):
    r = c.post("/api/projects", json={"path": str(path)}); r.raise_for_status()
    pid = r.json()["id"]
    wait_for(c, pid, {"ingest": "fresh", "profile": "fresh"}, timeout=120)
    return pid

def skipped(view):
    return [(s["key"], s["status"], s.get("reason")) for s in view["interview"]
            if s["status"] in ("skipped", "not_applicable")]
