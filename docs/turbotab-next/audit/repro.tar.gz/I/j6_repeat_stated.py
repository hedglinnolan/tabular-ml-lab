import sys; sys.path.insert(0, "/private/tmp/turbotab-audit/I")
from harness import *
F = Path("/private/tmp/turbotab-audit/I/fixtures")
def main():
    with client() as c:
        pid = open_path(c, F / "longitudinal_no_dates.csv")
        view, asked = walk(c, pid, {"lens": {"kind": "set_lens", "lenses": ["clinical"]},
                                    "target": {"kind": "set_target", "column": "progressed"},
                                    "grain": {"kind": "set_grain", "grain": "repeated", "id_column": "subject_id"},
                                    "unit": {"kind": "set_unit", "unit": "unit"}}, stop_before="aggregation")
        wait_for(c, pid, {"structure": "fresh"}, timeout=120)
        st = c.get(f"/api/projects/{pid}/stages/structure").json()["artifact"]
        print("repeats reading:", {k: st["repeats"].get(k) for k in ("reading", "stated", "confidence", "sentence")})
        print("aggregation menu:", st.get("aggregation"))
        v = c.get(f"/api/projects/{pid}").json()
        print("steps:", [(s["key"], s["status"], (s.get("reason") or "")[:90]) for s in v["interview"] if s["key"] in ("repeat_kind", "unit", "aggregation", "temporal")])
        # and with unit=row: is temporal asked?
        r = c.post(f"/api/projects/{pid}/decisions", json={"kind": "set_unit", "unit": "row"})
        v = c.get(f"/api/projects/{pid}").json()
        print("unit=row ->", [(s["key"], s["status"], (s.get("reason") or "")[:90]) for s in v["interview"] if s["key"] in ("aggregation", "temporal")])
if __name__ == "__main__":
    main()
