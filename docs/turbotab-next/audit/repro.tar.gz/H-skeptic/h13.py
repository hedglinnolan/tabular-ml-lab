import sys, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab import orientation as o
rng = np.random.default_rng(8)
F, S = 3000, 30
base = rng.lognormal(np.log(300), 2.2, F)
raw = base[:, None] * rng.lognormal(0, 0.35, (F, S))
def show(name, mat):
    df = pd.DataFrame(mat, columns=[f"GSM{j:05d}" for j in range(S)]); df.insert(0, "ID_REF", [f"{i}_at" for i in range(F)])
    r = o.read(df)
    print(f"{name:26s} reading={r['reading']:13s} ratio={r['ratio']} s_rows={r['s_rows']} s_cols={r['s_cols']} | {r['sentence'][:90]}")
show("raw", raw)
show("log2", np.log2(raw + 1))
show("log2 sample-major (T)", np.log2(raw + 1).T)
l = np.log2(raw+1); show("autoscaled", (l - l.mean(1, keepdims=True))/l.std(1, keepdims=True))
