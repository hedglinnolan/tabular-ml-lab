import sys, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from ml.import_doctor import check_numeric_sentinels
rng = np.random.default_rng(2024)
gens = {
 "DBP N(72,11)":  lambda n: rng.normal(72, 11, n).round(),
 "HR N(72,11)":   lambda n: rng.normal(72, 11, n).round(),
 "glucose LN(100,.15)": lambda n: rng.lognormal(np.log(100), 0.15, n).round(),
 "admissions NB(1,.45)": lambda n: rng.negative_binomial(1, 0.45, n),
 "age N(70,7) clip": lambda n: rng.normal(70, 7, n).round().clip(50, 100),
}
reps = 200
examples = {}
for name, g in gens.items():
    row = []
    for n in (100, 300, 1000):
        hits = 0
        for _ in range(reps):
            df = pd.DataFrame({"x": g(n)})
            f = check_numeric_sentinels(df)
            if f:
                hits += 1
                examples.setdefault((name, n), (f[0].detail, f[0].severity, f[0].fix_label,
                    {v: (int((df.x > v).sum()), int((df.x < v).sum())) for v in f[0].params["values"]}))
        row.append(f"{hits/reps:6.1%}")
    print(f"{name:24s}", " ".join(row))
for k, v in list(examples.items()):
    print(k, v)
