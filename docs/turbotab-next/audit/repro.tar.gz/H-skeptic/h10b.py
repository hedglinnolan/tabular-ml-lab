import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab.core.tests.stage_harness import Ingested
from turbotab.core.stages.rows import propose_roles, _energy_reading, _acquisition_columns
codes = "KCAL PROT CARB SUGR FIBE TFAT SFAT MFAT PFAT CHOL ATOC ATOA RET VARA ACAR BCAR CRYP LYCO LZ VB1 VB2 NIAC VB6 FOLA FA FF FDFE CHL VB12 B12A VC VD VK CALC PHOS MAGN IRON ZINC COPP SODI POTA SELE CAFF THEO ALCO MOIS".split()
rng = np.random.default_rng(1); n = 200
df = pd.DataFrame({"SEQN": np.arange(n), **{f"DR1T{c}": rng.lognormal(3, .5, n).round(2) for c in codes}, "LBXGLU": rng.normal(100,15,n)})
p = Path("/private/tmp/turbotab-audit/H-skeptic/fx/dr1t.csv"); df.to_csv(p, index=False)
t = Ingested(p, Path(tempfile.mkdtemp()))
with t.store() as st: cols = st.summaries()
props = propose_roles(cols, lens=["dietary"], target="LBXGLU", n_rows=n, energy_column=_energy_reading(cols), acquisition=_acquisition_columns(cols))
from collections import Counter
print(Counter((x["proposed"], x["confidence"]) for x in props))
print("covariate:", [x["column"] for x in props if x["proposed"] == "covariate"])
print("other:", [(x["column"], x["proposed"]) for x in props if x["proposed"] not in ("covariate","exposure")])
