import sys, warnings, logging; warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab import packs
rng = np.random.default_rng(3)
G, N = 800, 40
mu = rng.lognormal(2.0, 2.2, G)          # gene means in counts-per-library units
lib = rng.lognormal(np.log(2e7), 0.3, N)
counts = rng.negative_binomial(5, 5/(5 + (mu[None,:]/mu.sum()) * lib[:,None]))
cpm = counts / counts.sum(1, keepdims=True) * 1e6
tpm = cpm  # length-agnostic stand-in
cols = [f"ENSG{100000+i:011d}" for i in range(G)]
def show(name, m):
    df = pd.DataFrame(np.round(m, 4), columns=cols); df.insert(0, "sample_id", [f"S{i}" for i in range(N)])
    card = packs.data_type_card(df)
    keys = card and card.get("classification", {}).get("keys")
    f = [x["id"] for x in packs.findings(df, ["genomics"]) if "data_type" in x["id"]]
    print(f"{name:14s} zeros={np.mean(m==0):.3f} min={m.min():.2f} max={m.max():.1f} read={card and card.get('read')} keys={keys} finding={f} hints={[h['lens'] for h in packs.suggest(df)['hints']]}")
show("counts", counts.astype(float))
show("tpm", tpm)
show("log2(tpm+1)", np.log2(tpm + 1))
show("voom logCPM", np.log2((counts + 0.5) / (counts.sum(1, keepdims=True) + 1) * 1e6))
