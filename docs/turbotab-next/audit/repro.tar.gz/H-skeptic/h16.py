import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab.core.tests.stage_harness import Ingested
from turbotab.core.stages.rows import propose_roles, _energy_reading, _acquisition_columns
rng = np.random.default_rng(6); n = 300
df = pd.DataFrame({"steps_per_day": rng.normal(7000,2500,n).round(), "servings_fruit_per_day": rng.poisson(2,n), "drinks_per_week": rng.poisson(3,n),
  "baseline_glucose": rng.normal(100,12,n).round(), "glucose_followup": rng.normal(98,12,n).round(), "birth_weight": rng.normal(3300,450,n).round(),
  "met": rng.normal(25,6,n).round(1), "methionine_umol": rng.normal(25,6,n).round(1), "hba1c": rng.normal(5.6,.5,n).round(1)})
p = Path("/private/tmp/turbotab-audit/H-skeptic/fx/tokens.csv"); df.to_csv(p, index=False)
t = Ingested(p, Path(tempfile.mkdtemp()))
with t.store() as st: cols = st.summaries()
for lens in (["clinical"], ["dietary"]):
    props = propose_roles(cols, lens=lens, target="hba1c", n_rows=n, energy_column=_energy_reading(cols), acquisition=_acquisition_columns(cols))
    for x in props: print(lens, f"{x['column']:24s} {x['proposed']:10s} {x['confidence']:6s} {x['reason']}")
