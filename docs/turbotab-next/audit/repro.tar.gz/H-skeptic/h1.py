import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab import packs
from turbotab.core.decisions import ProjectState
from turbotab.core.stages.findings import findings_stage
from turbotab.core.tests.stage_harness import Ingested
rng = np.random.default_rng(11)
n = 300
# 6-point forced choice, mildly varied across items
d6 = pd.DataFrame({f"att_{i+1}": rng.choice(range(1,7), n, p=np.array([1,2,3,3,2,1.2])/12.2) for i in range(10)})
# 7-point skewed: few 6s/7s
p7 = np.array([10,18,22,22,17,7,4])/100
d7 = pd.DataFrame({f"freq_{i+1}": rng.choice(range(1,8), n, p=p7) for i in range(10)})
# control: clean 1-5 with genuine 9 codes in 3% of cells
d5 = pd.DataFrame({f"q{i+1}": rng.choice(range(1,6), n) for i in range(10)})
mask = rng.random(d5.shape) < 0.03
d5 = d5.mask(mask, 9)
for name, df in [("six", d6), ("seven_skew", d7), ("five_with_9", d5)]:
    p = Path(f"/private/tmp/turbotab-audit/H-skeptic/fx/{name}.csv"); df.to_csv(p, index=False)
    b = packs.likert_block(df)
    print("==", name, "block scale:", b and b["scale"], "support:", b and b["observed_support"], "sentinels:", b and sorted({v for vs in b["sentinels"].values() for v in vs}))
    t = Ingested(p, Path(tempfile.mkdtemp()))
    art = t.run(findings_stage, ProjectState(lens=["survey"], target=None))
    for f in art["findings"]:
        if "sentinel" in f["id"] or "survey" in f["id"]:
            print(f"  [{f['severity']}] {f['id']}: {f['title']}")
            if f["id"] == "pack::survey::sentinel_codes":
                print("    detail:", f["detail"][:400])
                for r in f.get("repairs") or []:
                    print("    repair:", r.get("key"), r.get("label"), "|", r.get("consequence"), "|", (r.get("sentence") or "")[:200])
    print("  hints:", [h["lens"] for h in packs.suggest(df)["hints"]], [h["because"][:90] for h in packs.suggest(df)["hints"]])
