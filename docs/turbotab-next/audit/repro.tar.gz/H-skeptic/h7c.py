import sys, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import pandas as pd
from ml.card_evidence import plausibility_report
from ml.physiology_reference import load_reference_bundle
df = pd.read_csv("/private/tmp/turbotab-audit/H-skeptic/fx/peds1.csv")
r = plausibility_report(df, columns=list(df.columns), reference=load_reference_bundle()["nhanes"])
for tier in ("impossible","improbable"):
    for b in r.get(tier) or []:
        print(tier, b["column"], b["n_flagged"], b.get("reading"), b.get("whole_column_suspect"), (b.get("reading_statement") or "")[:300])
