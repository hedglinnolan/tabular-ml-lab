import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab import packs, nutrition
rng = np.random.default_rng(10); n = 300
P=rng.normal(80,20,n).clip(20); C=rng.normal(250,60,n).clip(50); F=rng.normal(75,20,n).clip(15)
E = (4*P+4*C+9*F).round(0); E[:12] = rng.uniform(5100, 6500, 12).round()
for ename in ["DR1TKCAL","DR2TKCAL","DRXTKCAL","total_energy","kcal_day","TotalKcal","ENERC_KCAL","energy","energy_kj"]:
    df = pd.DataFrame({ename: E if ename != "energy_kj" else E*4.184, "protein_g": P.round(1), "carb_g": C.round(1), "fat_g": F.round(1), "age": rng.integers(20,70,n)})
    ids = [f["id"].split("::")[-1] for f in packs.findings(df, ["dietary"])]
    hints = [h["lens"] for h in packs.suggest(df)["hints"]]
    print(f"{ename:14s} nutrition._energy_column={nutrition._energy_column(df)!s:12s} hints={hints} pack findings={ids}")
