import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from ml.physiology_reference import DEFAULT_NHANES_REFERENCE as R
df = pd.read_csv("/Users/nhedglin/tabular-ml-lab/_tt_tmp_nhanes.csv")
print("age range", df.age.min(), df.age.max())
for col, key in [("triglycerides","triglyceride"),("kcal","kcal"),("bp_di","bp_di"),("glucose","glucose"),("bp_sys","bp_sys"),("bmi","bmi"),("weight","weight")]:
    s = df[col].dropna(); b = R["variables"][key]
    s2 = s[s > 1e-10]
    out = ((s < b["p01"]) | (s > b["p99"])).mean()
    print(f"{col:14s} band {b['p01']}-{b['p99']}  outside={out:.1%}  empirical p01/p99={s2.quantile(.01):.0f}/{s2.quantile(.99):.0f}")
from turbotab import clinical
rng = np.random.default_rng(4); n = 300
age = rng.integers(2, 11, n)
wt = (8 + 2.6*age + rng.normal(0, 2.5, n)).round(1)
wt[:1] = [0.2]
ped = pd.DataFrame({"age": age, "weight_kg": wt, "height_cm": (75 + 6.5*age + rng.normal(0,4,n)).round(1)})
p = Path("/private/tmp/turbotab-audit/H-skeptic/fx/peds.csv"); ped.to_csv(p, index=False)
from turbotab.core.decisions import ProjectState
from turbotab.core.stages.findings import findings_stage
from turbotab.core.tests.stage_harness import Ingested
t = Ingested(p, Path(tempfile.mkdtemp()))
art = t.run(findings_stage, ProjectState(lens=["clinical"], target=None))
for f in art["findings"]:
    print(f"[{f['severity']}] {f['id']}: {f['title']} | {f['detail'][:500]}")
# HbA1c mixed
h = np.r_[rng.normal(5.8, 0.8, 480).round(1), rng.normal(40, 9, 20).round(0)]
hb = pd.DataFrame({"hba1c": h, "age": rng.integers(30,70,500)})
p2 = Path("/private/tmp/turbotab-audit/H-skeptic/fx/hba1c_mixed.csv"); hb.to_csv(p2, index=False)
t = Ingested(p2, Path(tempfile.mkdtemp()))
art = t.run(findings_stage, ProjectState(lens=["clinical"], target=None))
for f in art["findings"]:
    print(f"[{f['severity']}] {f['id']}: {f['title']} | {f['detail'][:400]}")
