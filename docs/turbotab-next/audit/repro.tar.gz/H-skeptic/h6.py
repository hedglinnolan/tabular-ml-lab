import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import pandas as pd
from turbotab.core.decisions import ProjectState
from turbotab.core.stages.findings import findings_stage
from turbotab.core.tests.stage_harness import Ingested
p = Path("/Users/nhedglin/tabular-ml-lab/_tt_tmp_nhanes.csv")
df = pd.read_csv(p)
print("kcal<100:", sorted(df.kcal[df.kcal < 100].tolist()))
print("kcal outside 800-4500:", int(((df.kcal < 800) | (df.kcal > 4500)).sum()), " outside 500-5000:", int(((df.kcal < 500) | (df.kcal > 5000)).sum()), "n kcal", int(df.kcal.notna().sum()))
t = Ingested(p, Path(tempfile.mkdtemp()))
art = t.run(findings_stage, ProjectState(lens=["dietary","clinical"], target=None))
for f in art["findings"]:
    if f["id"] in ("pack::clinical::impossible_vs_extreme", "pack::dietary::implausible_intake") or "bp_di" in str(f.get("columns")):
        print(f"[{f['severity']}] {f['id']}: {f['title']}")
        print("   detail:", f["detail"][:900])
        print("   evidence:", f.get("evidence") or f.get("badge"))
        for r in f.get("repairs") or []:
            print("   repair:", r.get("key"), r.get("label"), "|", (r.get("consequence") or "")[:300], "|", (r.get("sentence") or "")[:300])
        print("   keys:", list(f.keys()))
