import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab import clinical
from turbotab.core.decisions import ProjectState
from turbotab.core.stages.findings import findings_stage
from turbotab.core.tests.stage_harness import Ingested
rng = np.random.default_rng(4); n = 300
age = rng.integers(2, 11, n)
for k in (1, 3):
    wt = (8 + 2.6*age + rng.normal(0, 2.5, n)).round(1)
    wt[:k] = [0.2, 1500, 0.1][:k]
    ped = pd.DataFrame({"age": age, "weight": wt, "dbp": rng.normal(60, 8, n).round()})
    print(k, "errors; impossible_vs_extreme:", clinical.impossible_vs_extreme_finding(ped) and clinical.impossible_vs_extreme_finding(ped)["detail"][:400])
    p = Path(f"/private/tmp/turbotab-audit/H-skeptic/fx/peds{k}.csv"); ped.to_csv(p, index=False)
    t = Ingested(p, Path(tempfile.mkdtemp()))
    art = t.run(findings_stage, ProjectState(lens=["clinical"], target=None))
    for f in art["findings"]:
        print(f"   [{f['severity']}] {f['id']}: {f['title']} | {f['detail'][:300]}")
