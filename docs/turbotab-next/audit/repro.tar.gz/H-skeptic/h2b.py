import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from ml.import_doctor import check_numeric_sentinels
from turbotab.core.decisions import ProjectState
from turbotab.core.stages.findings import findings_stage
from turbotab.core.tests.stage_harness import Ingested
rng = np.random.default_rng(2024)
# find a seed producing a DBP false positive at n=300
for i in range(500):
    x = rng.normal(72, 11, 300).round()
    df = pd.DataFrame({"dbp": x, "sbp": (x*1.5+rng.normal(10,8,300)).round(), "age": rng.integers(30,70,300)})
    if any(f.id == "sentinel_missing__dbp" for f in check_numeric_sentinels(df)): break
p = Path("/private/tmp/turbotab-audit/H-skeptic/fx/dbp_fp.csv"); df.to_csv(p, index=False)
print("values >= 95:", sorted(df.dbp[df.dbp>=95].tolist()))
t = Ingested(p, Path(tempfile.mkdtemp()))
art = t.run(findings_stage, ProjectState(lens=["clinical"], target=None))
for f in art["findings"]:
    if "sentinel" in f["id"]:
        print(f"[{f['severity']}] {f['id']}: {f['title']} | {f['detail'][:300]}")
        for r in f.get("repairs") or []:
            print("   repair:", r.get("key"), r.get("label"), "|", r.get("consequence"), "|", (r.get("sentence") or "")[:200])
