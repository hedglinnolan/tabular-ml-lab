import sys, tempfile, warnings, logging, json
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab.core.methods.energy import nutrient_role, energy_factor
from turbotab.core.stages.proposals import energy_bearing, nutrient_candidates, energy_reading
names = ["fat_mass_kg","body_fat_pct","fat_free_mass","liver_fat","visceral_fat_area","total_protein","serum_protein_g_dl",
 "c_reactive_protein","crp","fibrinogen","fib4_score","bicarbonate","carbon_monoxide","carbamazepine","alcohol_use_disorder",
 "lipid_lowering_meds","hdl_cholesterol","prothrombin_time","carboxyhemoglobin","fatigue_score","statin","cholesterol_mg"]
for n in names:
    try: r = nutrient_role(n)
    except ValueError as e: r = f"ERR {e}"
    print(f"{n:24s} role={r!s:14s} factor={energy_factor(n).factor} bearing={energy_bearing(n)}")
from turbotab.core.tests.stage_harness import Ingested
from turbotab.core.stages.rows import propose_roles, _energy_reading, _acquisition_columns
rng = np.random.default_rng(7); n = 300
P=rng.normal(80,20,n).clip(20); C=rng.normal(250,60,n).clip(50); F=rng.normal(75,20,n).clip(15)
df = pd.DataFrame({"id": np.arange(n), "age": rng.integers(30,70,n), "sex": rng.choice(["F","M"], n),
    "energy_kcal": (4*P+4*C+9*F).round(0), "protein_g": P.round(1), "carbohydrate_g": C.round(1), "fat_g": F.round(1),
    "fat_mass_kg": rng.normal(25,8,n).round(1), "crp_mg_l": rng.lognormal(0.5,0.8,n).round(2),
    "c_reactive_protein": rng.lognormal(0.5,0.8,n).round(2),
    "fibrinogen": rng.normal(320,60,n).round(0), "hba1c": rng.normal(5.6,0.5,n).round(1)})
p = "/private/tmp/turbotab-audit/H-skeptic/fx/diet_bc.csv"; df.to_csv(p, index=False)
t = Ingested(Path(p), Path(tempfile.mkdtemp()))
with t.store() as st: cols = st.summaries()
for lens in (["dietary"], ["dietary","clinical"], ["clinical"]):
    props = propose_roles(cols, lens=lens, target="hba1c", n_rows=n, energy_column=_energy_reading(cols), acquisition=_acquisition_columns(cols))
    roles = {x["column"]: x["proposed"] for x in props}
    print(lens, [(x["column"], x["proposed"], x["confidence"]) for x in props if x["column"] in ("fat_mass_kg","c_reactive_protein","fibrinogen","crp_mg_l")])
    info = {str(c["name"]): c for c in cols}
    nut = nutrient_candidates(info, roles, energy="energy_kcal", target="hba1c")
    print("   nutrient candidates:", nut)
props = propose_roles(cols, lens=["dietary"], target="hba1c", n_rows=n, energy_column=_energy_reading(cols), acquisition=_acquisition_columns(cols))
roles = {x["column"]: x["proposed"] for x in props}
info = {str(c["name"]): c for c in cols}
nut = nutrient_candidates(info, roles, energy="energy_kcal", target="hba1c")
import inspect
print(inspect.signature(energy_reading))
r = energy_reading(df, info, roles, energy="energy_kcal", nutrients=nut, sex="sex", target="hba1c")
print(json.dumps({k: r[k] for k in r if k in ("usual","recommended","default","nutrients")}, default=str))
s = json.dumps(r, default=str)
import re
for m in re.finditer(r"[^\"]*fat_mass_kg[^\"]*", s):
    print("  >>", m.group(0)[:400])
