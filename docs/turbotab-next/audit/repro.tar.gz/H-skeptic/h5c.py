import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core.decisions import ProjectState
from turbotab.core.stages.findings import findings_stage
from turbotab.core.tests.stage_harness import Ingested
t = Ingested(Path("/private/tmp/turbotab-audit/H-skeptic/fx/ids.csv"), Path(tempfile.mkdtemp()))
art = t.run(findings_stage, ProjectState(lens=["clinical"], target=None))
for f in art["findings"]:
    print(f"[{f['severity']}] {f['id']}: {f['title']} | {f['detail'][:200]}")
