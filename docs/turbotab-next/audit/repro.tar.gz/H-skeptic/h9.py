import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab import packs
df = pd.read_csv("/Users/nhedglin/tabular-ml-lab/turbotab/sample_data/nhanes_kilojoules.csv")
print(df.columns.tolist()[:20])
for f in packs.findings(df, ["dietary"]):
    if f["id"] in ("pack::dietary::implausible_intake", "pack::dietary::atwater"):
        print(f["id"], "|", f["title"], "|", f["detail"][:300])
# natural kJ column named 'energy'
rng = np.random.default_rng(9); n = 300
P=rng.normal(80,20,n).clip(20); C=rng.normal(250,60,n).clip(50); F=rng.normal(75,20,n).clip(15)
kj = pd.DataFrame({"energy": ((4*P+4*C+9*F)*4.184).round(0), "protein": P.round(1), "carbohydrate": C.round(1), "fat": F.round(1), "age": rng.integers(20,70,n)})
p = Path("/private/tmp/turbotab-audit/H-skeptic/fx/kj.csv"); kj.to_csv(p, index=False)
for f in packs.findings(kj, ["dietary"]):
    if f["id"] in ("pack::dietary::implausible_intake", "pack::dietary::atwater"):
        print(f["id"], "|", f["title"], "|", f["detail"][:300])
from turbotab.core.decisions import ProjectState
from turbotab.core.stages.findings import findings_stage
from turbotab.core.tests.stage_harness import Ingested
t = Ingested(p, Path(tempfile.mkdtemp()))
art = t.run(findings_stage, ProjectState(lens=["dietary"], target=None))
for f in art["findings"]:
    print(f"[{f['severity']}] {f['id']}: {f['title']} | {f['detail'][:200]}")
    for r in f.get("repairs") or []: print("     repair", r.get("key"), r.get("label"))
