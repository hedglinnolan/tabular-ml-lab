import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab.core.tests.stage_harness import Ingested
from turbotab.core.stages.rows import propose_roles, _energy_reading, _acquisition_columns, PREDICTOR_ROLES
rng = np.random.default_rng(3); n = 200
df = pd.DataFrame({"participant_id": np.arange(n), "treatment": rng.choice(["placebo","fish_oil"], n),
   "arm": rng.integers(0,2,n), "diet_group": rng.choice(["med","control"], n), "condition": rng.choice(["case","control"], n),
   "phenotype": rng.choice(["lean","obese"], n), "fasting": rng.integers(0,2,n), "group": rng.choice(["A","B"], n),
   "plate_reader_od": rng.normal(1.2,0.3,n).round(3), "site": rng.integers(1,5,n),
   "age": rng.integers(30,70,n), "sex": rng.choice(["F","M"], n), "ldl_change": rng.normal(-5,10,n).round(1)})
p = "/private/tmp/turbotab-audit/H-skeptic/fx/rct.csv"; df.to_csv(p, index=False)
t = Ingested(Path(p), Path(tempfile.mkdtemp()))
with t.store() as st: cols = st.summaries()
print("acquisition:", _acquisition_columns(cols))
for lens in (["clinical"], ["dietary"], ["metabolomics"], ["genomics"], []):
    props = propose_roles(cols, lens=lens, target="ldl_change", n_rows=n, energy_column=_energy_reading(cols), acquisition=_acquisition_columns(cols))
    print(lens, [(x["column"], x["proposed"], x["confidence"]) for x in props])
    print("   reasons:", {x["column"]: x["reason"] for x in props if x["column"] in ("treatment","plate_reader_od")})
