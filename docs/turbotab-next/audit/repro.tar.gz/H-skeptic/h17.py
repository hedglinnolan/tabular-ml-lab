import sys, warnings, logging; warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab import packs
rng = np.random.default_rng(12); n = 400
# PHQ-9 general-population: item response probs for 0..3, floor-heavy (published community samples ~ 60-90% 'not at all')
probs = [[.55,.30,.10,.05],[.62,.25,.08,.05],[.50,.30,.12,.08],[.45,.33,.13,.09],[.60,.25,.09,.06],[.68,.20,.08,.04],[.66,.22,.08,.04],[.80,.13,.05,.02],[.93,.05,.015,.005]]
phq = pd.DataFrame({f"phq_{i+1}": rng.choice(4, n, p=p) for i, p in enumerate(probs)})
phq9c = phq.mask(rng.random(phq.shape) < 0.01, 9)
gad = pd.DataFrame({f"gad_{i+1}": rng.choice(4, n, p=[.45,.30,.15,.10]) for i in range(7)})
nrs = pd.DataFrame({f"pain_{i+1}": rng.integers(0, 11, n) for i in range(10)})
hed = pd.DataFrame({f"liking_{i+1}": np.clip(np.round(rng.normal(6, 1.8, n)), 1, 9).astype(int) for i in range(10)})
balanced03 = pd.DataFrame({f"phq_{i+1}": rng.choice(4, n, p=[.4,.3,.2,.1]) for i in range(9)})
for name, df in [("phq9 floor-heavy", phq), ("phq9 + 9 codes", phq9c), ("gad7", gad), ("nrs 0-10", nrs), ("hedonic 1-9", hed), ("phq9 balanced", balanced03)]:
    modal = df.apply(lambda s: s[s != 9].value_counts(normalize=True).max())
    b = packs.likert_block(df)
    print(f"{name:18s} modal shares {modal.min():.2f}-{modal.max():.2f}; block={b and (b['scale'], len(b['columns']))}; hints={[h['lens'] for h in packs.suggest(df)['hints']]}; survey findings={[f['id'].split('::')[-1] for f in packs.findings(df, ['survey'])]}")
