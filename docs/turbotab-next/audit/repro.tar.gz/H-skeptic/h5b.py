import sys, tempfile, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab.core.decisions import ProjectState, GrainSpec
from turbotab.core.seal import decide_basis
from turbotab.core.tests.stage_harness import Ingested
from turbotab.core.stages.rows import propose_roles, _energy_reading, _acquisition_columns
rng = np.random.default_rng(1); n = 400
df = pd.DataFrame({"participant_id": np.arange(1000, 1000+n), "site_id": rng.integers(1,6,n), "household_id": rng.integers(1,200,n),
  "eid": rng.permutation(np.arange(1000000, 1000000+n)), "MRN": rng.permutation(np.arange(5000, 5000+n)), "patid": np.arange(n)*7+3,
  "Participant": np.arange(1,n+1), "age": rng.integers(30,70,n), "ldl": rng.normal(130,30,n).round()})
p = "/private/tmp/turbotab-audit/H-skeptic/fx/ids.csv"; df.to_csv(p, index=False)
t = Ingested(Path(p), Path(tempfile.mkdtemp()))
with t.store() as st: cols = st.summaries()
props = propose_roles(cols, lens=["clinical"], target="ldl", n_rows=n, energy_column=_energy_reading(cols), acquisition=_acquisition_columns(cols))
for x in props: print(f"  {x['column']:16s} {x['proposed']:10s} {x['confidence']:6s} {x['reason']}")
roles = {x["column"]: x["proposed"] for x in props}
ids = [c for c, r in roles.items() if r == "identifier"]
print("identifiers:", ids)
for g in (GrainSpec(grain="one_row_per_unit", id_column="participant_id"), GrainSpec(grain="repeated")):
    st_ = ProjectState(grain=g, roles=roles)
    b, col = decide_basis(st_, df[ids], ids)
    print(g.grain, "->", b.state, "| group col:", col, "|", b.sentence)
