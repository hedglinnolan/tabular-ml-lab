import sys, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab import repeats
rng = np.random.default_rng(5)
rows = []
for pid in range(40):
    start = pd.Timestamp("2024-01-01") + pd.Timedelta(days=int(rng.integers(0, 60)))
    for d in range(10):
        rows.append({"pid": pid, "date": (start + pd.Timedelta(days=d)).date().isoformat(), "glucose": 120 - 1.5*d + rng.normal(0, 3)})
daily = pd.DataFrame(rows)
r = repeats.read(daily, "pid"); print("daily:", r["reading"], r["stated"], r["confidence"], "|", r["sentence"][:300])
m = repeats.menu(r["reading"] or "repeats", ["clinical"]); print("   menu:", m["recommended"], m["marker"], m["reason"][:150])
rows = []
for pid in range(40):
    start = pd.Timestamp("2024-01-01") + pd.Timedelta(days=int(rng.integers(0, 60)))
    seq = ["A","B","A","B"] if pid % 2 else ["B","A","B","A"]
    for k in range(4):
        rows.append({"pid": pid, "date": (start + pd.Timedelta(weeks=k)).date().isoformat(), "treatment": seq[k], "sbp": 130 + (-5 if seq[k]=="B" else 0) + rng.normal(0,4)})
xo = pd.DataFrame(rows)
r = repeats.read(xo, "pid"); print("crossover:", r["reading"], r["stated"], r["confidence"], "|", r["sentence"][:250])
rows = []
for pid in range(40):
    start = pd.Timestamp("2024-01-01") + pd.Timedelta(days=int(rng.integers(0, 60)))
    for k in range(4):
        rows.append({"pid": pid, "recall": k+1, "date": (start + pd.Timedelta(days=91*k + int(rng.integers(-5,6)))).date().isoformat(), "kcal": rng.normal(2000, 400)})
q = pd.DataFrame(rows)
r = repeats.read(q, "pid"); print("quarterly recalls:", r["reading"], r["stated"], r["confidence"], "|", r["sentence"][:250])
m = repeats.menu(r["reading"], ["dietary"]); print("   menu:", m["recommended"], m["reason"][:150])
print("   dietary repeats menu:", repeats.menu("repeats", ["dietary"])["reason"][:300])
