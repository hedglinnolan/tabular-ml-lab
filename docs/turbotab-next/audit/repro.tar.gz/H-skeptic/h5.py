import sys, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core.stages.rows import _id_like
from turbotab.core.stages.finding_words import is_identifier_name
from utils.test_lockbox import _id_kind
names = ["eid","f.eid","MRN","patid","ptid","Participant","subjid","USUBJID","ResponseId","record","Subject","pid",
 "person_number","Study Number","case_no","HHID","IDNO","participant_id","batch_id","site_id","plate_id","household_id","family_id","SEQN"]
dis = 0
for n in names:
    a, b, c = _id_like(n), is_identifier_name(n), _id_kind(n)
    flag = "" if (a == b == (c is not None)) else "  <-- disagree"
    dis += bool(flag)
    print(f"{n:16s} rows={a!s:6s} words={b!s:6s} lockbox={c}{flag}")
print("disagreements", dis)
