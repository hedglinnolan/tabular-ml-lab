import sys, warnings, logging; warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab import packs
S = "/Users/nhedglin/tabular-ml-lab/turbotab/sample_data/"
for f in ["genomics_cpm","genomics_estimated_counts","genomics_fpkm","genomics_tmm_cpm","genomics_vst","genomics_microarray","genomics_expression","genomics_single_cell","genomics_gene_ids",
          "survey_instrument","survey_sentinels","clinical_risk","leaky_sepsis","clinical_labs","metabolomics_untargeted","nhanes_dietary"]:
    df = pd.read_csv(S + f + ".csv")
    h = packs.suggest(df)["hints"]
    print(f"{f:28s} {df.shape} -> {[x['lens'] for x in h]}  {[x['because'][:60] for x in h]}")
# realistic log2 TPM with ENSG ids, samples in rows
rng = np.random.default_rng(2)
G, N = 500, 40
base = rng.lognormal(1.5, 2.0, G)
tpm = base[None, :] * rng.lognormal(0, .4, (N, G))
tpm = tpm / tpm.sum(1, keepdims=True) * 1e6
cols = [f"ENSG{100000+i:011d}" for i in range(G)]
for name, m in [("tpm", tpm), ("log2tpm", np.log2(tpm+1))]:
    df = pd.DataFrame(m.round(3), columns=cols); df.insert(0, "sample_id", [f"S{i}" for i in range(N)])
    h = packs.suggest(df)["hints"]
    print(name, [x["lens"] for x in h], [x["because"][:80] for x in h])
# wide clinical labs table
labs = pd.DataFrame({f"lab_{k}": rng.normal(100, 15, 300) for k in ["sodium","potassium","chloride","bicarb","bun","creatinine","glucose","calcium","albumin","alt","ast","alp","bili","hgb","hct","wbc","plt","mcv","rdw","inr","ptt","crp","esr","ferritin","tsat","b12","folate","tsh","ft4","hba1c","ldl","hdl","tg","tc","uric","phos","mg","lactate"]})
labs.insert(0, "patient_id", range(300))
print("38 labs", [x["lens"] for x in packs.suggest(labs)["hints"]])
