import sys, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import pandas as pd
from turbotab import packs
df = pd.read_csv("turbotab/sample_data/nhanes_kilojoules.csv")
for f in packs.findings(df, ["dietary"]):
    print(f["id"], "|", f["title"], "|", f["detail"][:300])
    print("   params:", {k: v for k, v in (f.get("params") or {}).items() if k != "rows"})
