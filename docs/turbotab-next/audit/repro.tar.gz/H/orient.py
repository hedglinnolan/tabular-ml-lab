import sys, warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd
from turbotab import orientation as o
rng = np.random.default_rng(5)
F, S = 2000, 24
base = rng.lognormal(np.log(500), 2.0, F)              # feature abundances span orders of magnitude
raw = base[:, None] * rng.lognormal(0, 0.3, (F, S))   # features in rows
def show(name, mat):
    df = pd.DataFrame(mat, columns=[f"S{j:02d}" for j in range(S)])
    df.insert(0, "feature", [f"F{i:05d}" for i in range(F)])
    r = o.read(df)
    print(f"{name:34s} reading={r['reading']:13s} ratio={r['ratio']} s_rows={r['s_rows']} s_cols={r['s_cols']}")
show("feature-major raw intensities", raw)
show("feature-major log2 (GEO-style)", np.log2(raw + 1))
show("feature-major log10", np.log10(raw + 1))
z = (np.log2(raw+1) - np.log2(raw+1).mean(1, keepdims=True)) / np.log2(raw+1).std(1, keepdims=True)
show("feature-major autoscaled", z)
show("feature-major Pareto (mean-centred)", (raw - raw.mean(1, keepdims=True)) / np.sqrt(raw.std(1, keepdims=True)))
