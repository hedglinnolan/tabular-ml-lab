import sys, tempfile, warnings, json
warnings.filterwarnings("ignore")
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import logging; logging.disable(logging.WARNING)
from turbotab.core.decisions import ProjectState
from turbotab.core.stages.findings import findings_stage
from turbotab.core.stages.rows import propose_roles, _energy_reading, _acquisition_columns
from turbotab.core.tests.stage_harness import Ingested
from turbotab import packs
FX = Path("/private/tmp/turbotab-audit/H/fx")
LENS = {"likert6": ["survey"], "likert7_skewed": ["survey"], "likert5_nine": ["survey"], "likert7_89": ["survey"],
        "hedonic9": ["survey"], "nrs10_99": ["survey"], "nhanes_yesno_79": ["survey", "clinical"],
        "clinical_counts": ["clinical"], "numeric_ids": ["clinical"], "roles_edge": ["clinical"],
        "kj_natural": ["dietary"], "kj_suffixed": ["dietary"], "kj_infoods": ["dietary"], "kcal_spaced_names": ["dietary"],
        "kcal_abbrev": ["dietary"], "wide_dietary": ["dietary"], "wide_clinical": ["clinical"],
        "rnaseq_tpm_ensg": ["genomics"], "rnaseq_log2tpm_ensg": ["genomics"], "pediatric": ["clinical"],
        "daily_timecourse": ["clinical"], "weekly_crossover": ["clinical"], "quarterly_recalls": ["dietary"]}
names = sys.argv[1:] or sorted(LENS)
for name in names:
    t = Ingested(FX / f"{name}.csv", Path(tempfile.mkdtemp()))
    fr = t.frame().reset_index(drop=True)
    hints = packs.suggest(fr)["hints"]
    lens = LENS[name]
    print("=====", name, fr.shape, "| hints:", [(h["lens"], h["because"][:70]) for h in hints], "| lens used:", lens)
    art = t.run(findings_stage, ProjectState(lens=lens, target=None))
    for f in art["findings"]:
        print(f"  [{f['severity']}] {f['id']}: {f.get('summary') or f['title']}")
        reps = [r["key"] for r in f.get("repairs") or []]
        if reps: print("        repairs:", reps)
    with t.store() as st:
        cols = st.summaries()
    props = propose_roles(cols, lens=lens, target=None, n_rows=len(fr), energy_column=_energy_reading(cols), acquisition=_acquisition_columns(cols))
    print("  roles:", [(p["column"], p["proposed"], p["confidence"]) for p in props][:20])
