import sys, tempfile, traceback, warnings
warnings.filterwarnings("ignore")
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core.decisions import ProjectState
from turbotab.core.stages.findings import findings_stage
from turbotab.core.tests.stage_harness import Ingested, SAMPLES
from turbotab import packs
for name in ["clinical_risk.csv", "leaky_sepsis.csv"]:
    t = Ingested(SAMPLES / name, Path(tempfile.mkdtemp()))
    fr = t.frame()
    print(name, fr.shape, list(fr.columns)[:20])
    try:
        print(packs.suggest(fr.reset_index(drop=True)))
        t.run(findings_stage, ProjectState(lens=["clinical"], target=None))
    except Exception:
        traceback.print_exc()
