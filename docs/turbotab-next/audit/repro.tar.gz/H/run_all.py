import sys, json, tempfile, warnings
from pathlib import Path
warnings.filterwarnings("ignore")
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core.decisions import ProjectState
from turbotab.core.stages.findings import findings_stage
from turbotab.core.tests.stage_harness import Ingested, SAMPLES, NHANES
from turbotab import packs

files = sorted(SAMPLES.glob("*.csv"))
if NHANES.is_file(): files.append(NHANES)
if len(sys.argv) > 1:
    files = [Path(a) for a in sys.argv[1:]]
out = {}
for f in files:
    tmp = Path(tempfile.mkdtemp())
    try:
        t = Ingested(f, tmp)
        frame = t.frame().reset_index(drop=True)
        sug = packs.suggest(frame)
        hints = [h["lens"] for h in sug.get("hints", [])]
        res = {}
        for label, lens in (("suggested", hints or []), ("all", list(packs.normalize(["metabolomics","genomics","dietary","clinical","survey"])) if False else ["metabolomics","genomics","dietary","clinical","survey"])):
            art = t.run(findings_stage, ProjectState(lens=lens, target=None))
            res[label] = [(x["id"], x["severity"], x["affected_columns"][:4]) for x in art["findings"]]
        out[f.name] = {"shape": frame.shape, "hints": hints, **res}
        print("=====", f.name, frame.shape, "hints:", hints)
        for x in res["suggested"]:
            print("  S", x[0], x[1], x[2])
        extra = [x for x in res["all"] if x[0] not in {y[0] for y in res["suggested"]}]
        for x in extra:
            print("  A+", x[0], x[1], x[2])
    except Exception as e:
        print("=====", f.name, "ERROR", type(e).__name__, e)
