import sys, warnings; warnings.filterwarnings("ignore")
import pandas as pd
from turbotab import packs
S = "turbotab/sample_data/"; F = "/private/tmp/turbotab-audit/H/fx/"
cases = [(S+"genomics_fpkm.csv", ["genomics"]), (S+"genomics_fpkm.csv", ["metabolomics"]), (S+"genomics_vst.csv", ["genomics"]),
         (S+"survey_instrument.csv", ["survey"]), (S+"survey_instrument.csv", ["metabolomics"]), (F+"wide_clinical.csv", ["clinical"]),
         (F+"wide_dietary.csv", ["dietary"]), (F+"rnaseq_tpm_ensg.csv", ["genomics"]), (S+"metabolomics_untargeted.csv", ["genomics"]),
         (S+"nhanes_dietary.csv", ["metabolomics"]), (S+"clinical_labs.csv", ["survey"])]
for p, lens in cases:
    df = pd.read_csv(p)
    c = packs.contradiction(df, lens)
    print(f"{p.split('/')[-1]:28s} lens={lens!s:18s} contradiction={'YES: ' + (c.get('title') or c.get('headline') or str(c)[:150]) if c else None}")
