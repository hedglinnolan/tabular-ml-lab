import numpy as np, pandas as pd, warnings; warnings.filterwarnings("ignore")
from ml.import_doctor import check_numeric_sentinels
rng = np.random.default_rng(0)
gens = {
 "adult DBP N(72,11)":      lambda n: rng.normal(72, 11, n).round(),
 "pediatric DBP N(60,8)":   lambda n: rng.normal(60, 8, n).round(),
 "heart rate N(72,11)":     lambda n: rng.normal(72, 11, n).round(),
 "age older cohort N(70,7)":lambda n: rng.normal(70, 7, n).round().clip(50, 100),
 "fasting glucose LN(100,.15)": lambda n: rng.lognormal(np.log(100), 0.15, n).round(),
 "n_children Poisson(2)":   lambda n: rng.poisson(2.0, n),
 "drinks/week NB":          lambda n: rng.negative_binomial(1, 0.2, n),
 "prior admissions NB":     lambda n: rng.negative_binomial(1, 0.45, n),
}
reps = 200
print(f"{'variable':30s} " + " ".join(f"n={n:<5d}" for n in (100, 300, 1000)))
for name, g in gens.items():
    row = []
    for n in (100, 300, 1000):
        hits = 0
        for _ in range(reps):
            df = pd.DataFrame({"x": g(n)})
            hits += bool(check_numeric_sentinels(df))
        row.append(f"{hits/reps:6.1%}")
    print(f"{name:30s} " + " ".join(row))
