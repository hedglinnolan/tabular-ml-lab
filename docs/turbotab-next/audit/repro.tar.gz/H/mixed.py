import sys, tempfile, warnings; warnings.filterwarnings("ignore")
import numpy as np, pandas as pd
from pathlib import Path
rng = np.random.default_rng(3); n = 400
P=rng.normal(80,20,n).clip(20); C=rng.normal(250,60,n).clip(50); F=rng.normal(75,20,n).clip(15)
df = pd.DataFrame({"participant_id": np.arange(n), "age": rng.integers(30,70,n), "sex": rng.choice(["F","M"], n),
    "energy_kcal": (4*P+4*C+9*F).round(0), "protein_g": P.round(1), "carbohydrate_g": C.round(1), "fat_g": F.round(1),
    "fat_mass_kg": rng.normal(25,8,n).round(1), "c_reactive_protein": rng.lognormal(0.5,0.8,n).round(2),
    "total_protein": rng.normal(7.1,0.4,n).round(1), "fibrinogen": rng.normal(320,60,n).round(0),
    "hba1c": rng.normal(5.6,0.5,n).round(1)})
p = "/private/tmp/turbotab-audit/H/fx/diet_bodycomp.csv"; df.to_csv(p, index=False)
from turbotab.core.tests.stage_harness import Ingested
from turbotab.core.stages.rows import propose_roles, _energy_reading, _acquisition_columns
from turbotab.core.stages.proposals import nutrient_candidates, energy_reading
t = Ingested(Path(p), Path(tempfile.mkdtemp()))
with t.store() as st: cols = st.summaries()
props = propose_roles(cols, lens=["dietary","clinical"], target="hba1c", n_rows=n, energy_column=_energy_reading(cols), acquisition=_acquisition_columns(cols))
roles = {x["column"]: x["proposed"] for x in props}
for x in props: print(f"  {x['column']:20s} {x['proposed']:10s} {x['confidence']:6s} {x['reason']}")
info = {str(c["name"]): c for c in cols}
nut = nutrient_candidates(info, roles, energy="energy_kcal", target="hba1c")
print("energy-adjustment nutrient candidates:", nut)
r = energy_reading(df, info, roles, energy="energy_kcal", nutrients=nut, sex="sex", target="hba1c")
print({k: (v if k not in ("methods", "options") else "...") for k, v in r.items() if k in ("nutrients", "not_adjusted", "recommended", "default")})
import json
print(json.dumps({k: v for k, v in r.items() if k not in ("not_adjusted",)}, default=str)[:2500])
