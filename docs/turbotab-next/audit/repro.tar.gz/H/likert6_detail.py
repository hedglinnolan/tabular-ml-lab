import sys, tempfile, warnings, json
warnings.filterwarnings("ignore")
from pathlib import Path
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core.decisions import ProjectState
from turbotab.core.stages.findings import findings_stage
from turbotab.core.tests.stage_harness import Ingested
import pandas as pd
for name in ["likert6", "likert7_skewed"]:
    t = Ingested(Path(f"/private/tmp/turbotab-audit/H/fx/{name}.csv"), Path(tempfile.mkdtemp()))
    art = t.run(findings_stage, ProjectState(lens=["survey"], target=None))
    f = [x for x in art["findings"] if x["id"] == "pack::survey::sentinel_codes"][0]
    print(name, "|", f["title"]); print(" detail:", f["detail"][:600])
    for r in f["repairs"]:
        print(" repair:", r["label"], "|", r["consequence"], "|", r["sentence"][:300])
    df = pd.read_csv(f"/private/tmp/turbotab-audit/H/fx/{name}.csv")
    cols = [c for c in df.columns if c.startswith(("q", "freq"))]
    print(" share of valid answers the repair would blank:", round(float((df[cols] >= 6).mean().mean()), 3))
