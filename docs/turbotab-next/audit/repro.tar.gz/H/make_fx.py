import numpy as np, pandas as pd
rng = np.random.default_rng(7)
D = "/private/tmp/turbotab-audit/H/fx/"
n = 300

def likert(k, n, p=None, start=1):
    vals = np.arange(start, start + k)
    return rng.choice(vals, size=n, p=p)

# A. 6-point Likert instrument, uniform-ish, plus a 9=missing code on a few items
df = pd.DataFrame({"respondent_id": [f"R{i:04d}" for i in range(n)], "age": rng.integers(18, 80, n)})
for j in range(12):
    df[f"q{j+1:02d}"] = likert(6, n)
df.to_csv(D + "likert6.csv", index=False)

# B. 7-point skewed instrument (symptom frequency; few 6/7)
df = pd.DataFrame({"respondent_id": [f"R{i:04d}" for i in range(n)]})
p7 = np.array([0.25, 0.22, 0.18, 0.14, 0.10, 0.07, 0.04])
for j in range(12):
    df[f"freq_{j+1:02d}"] = likert(7, n, p7)
df.to_csv(D + "likert7_skewed.csv", index=False)

# C. 1-5 items with 9 = missing (canonical), and 1-5 with 7/8/9
df = pd.DataFrame({"respondent_id": [f"R{i:04d}" for i in range(n)]})
for j in range(10):
    x = likert(5, n)
    idx = rng.choice(n, 12, replace=False)
    x[idx] = 9
    df[f"item_{j+1:02d}"] = x
df.to_csv(D + "likert5_nine.csv", index=False)

# D. 1-7 items with 8=don't know, 9=refused (adjacent codes)
df = pd.DataFrame({"respondent_id": [f"R{i:04d}" for i in range(n)]})
for j in range(10):
    x = likert(7, n)
    idx = rng.choice(n, 15, replace=False)
    x[idx[:8]] = 8; x[idx[8:]] = 9
    df[f"att_{j+1:02d}"] = x
df.to_csv(D + "likert7_89.csv", index=False)

# E. 9-point hedonic scale (food science), realistic skew toward liking, no codes
df = pd.DataFrame({"panelist": [f"P{i:03d}" for i in range(n)]})
p9 = np.array([0.01, 0.02, 0.03, 0.05, 0.08, 0.14, 0.25, 0.25, 0.17])
for j in range(10):
    df[f"liking_sample_{j+1:02d}"] = likert(9, n, p9)
df.to_csv(D + "hedonic9.csv", index=False)

# F. 0-10 numeric rating scale items with 99 = missing
df = pd.DataFrame({"id": range(n)})
for j in range(10):
    x = rng.integers(0, 11, n)
    x[rng.choice(n, 10, replace=False)] = 99
    df[f"nrs_{j+1:02d}"] = x
df.to_csv(D + "nrs10_99.csv", index=False)

# G. NHANES-like yes/no 1/2 with 7 refused, 9 don't know
df = pd.DataFrame({"SEQN": np.arange(80000, 80000 + n)})
for name in ["DIQ010", "BPQ020", "MCQ160B", "SMQ020", "ALQ101", "PAQ605", "DBQ700", "HIQ011"]:
    x = rng.choice([1, 2], n, p=[0.3, 0.7])
    x[rng.choice(n, 6, replace=False)] = 9
    x[rng.choice(n, 3, replace=False)] = 7
    df[name] = x
df.to_csv(D + "nhanes_yesno_79.csv", index=False)

# H. Clinical counts: Poisson/NB tails (prior admissions, children, drinks/week, ED visits)
df = pd.DataFrame({"patient_id": [f"P{i:05d}" for i in range(n)],
                   "age": rng.integers(30, 85, n),
                   "prior_admissions": rng.negative_binomial(1, 0.45, n),
                   "n_children": rng.poisson(2.0, n),
                   "drinks_per_week": rng.negative_binomial(1, 0.2, n),
                   "ed_visits_12mo": rng.negative_binomial(0.8, 0.4, n),
                   "sbp": rng.normal(130, 18, n).round(),
                   "glucose": rng.lognormal(np.log(100), 0.2, n).round()})
df.to_csv(D + "clinical_counts.csv", index=False)

# I. Numeric ids with real-world names
m = 400
df = pd.DataFrame({"eid": rng.choice(np.arange(1000000, 6000000), m, replace=False),
                   "MRN": rng.choice(np.arange(10000000, 99999999), m, replace=False),
                   "patid": np.arange(1, m + 1),
                   "Participant": np.arange(5001, 5001 + m),
                   "age": rng.integers(40, 70, m),
                   "bmi": rng.normal(27, 4, m).round(1),
                   "outcome": rng.integers(0, 2, m)})
df.to_csv(D + "numeric_ids.csv", index=False)

# J. Role edge cases
df = pd.DataFrame({"participant_id": np.arange(m),
                   "birth_weight": rng.normal(3300, 500, m).round(),
                   "steps_per_day": rng.normal(7000, 2500, m).round(),
                   "baseline_glucose": rng.normal(100, 15, m).round(),
                   "glucose_followup": rng.normal(102, 16, m).round(),
                   "sleep_hours_per_night": rng.normal(7, 1, m).round(1),
                   "servings_fruit_per_day": rng.poisson(2, m),
                   "batch_id": rng.integers(1, 9, m),
                   "site_id": rng.integers(1, 6, m),
                   "met": rng.normal(25, 5, m).round(1),  # methionine µmol/L
                   "hdl": rng.normal(55, 12, m).round(),
                   "outcome": rng.integers(0, 2, m)})
df.to_csv(D + "roles_edge.csv", index=False)

# K. kJ dietary table with natural names (no DR1T*)
k = 300
prot, carb, fat, alc = rng.normal(80, 20, k).clip(20), rng.normal(250, 60, k).clip(50), rng.normal(75, 20, k).clip(15), rng.exponential(5, k)
kcal = 4*prot + 4*carb + 9*fat + 7*alc
df = pd.DataFrame({"id": np.arange(k), "energy": (kcal * 4.184).round(0), "protein": prot.round(1),
                   "carbohydrate": carb.round(1), "fat": fat.round(1), "alcohol": alc.round(1),
                   "fibre": rng.normal(22, 6, k).round(1), "sex": rng.choice(["F", "M"], k)})
df.to_csv(D + "kj_natural.csv", index=False)
df2 = df.rename(columns={"energy": "energy_kj", "protein": "protein_g", "carbohydrate": "carbohydrate_g", "fat": "fat_g", "alcohol": "alcohol_g", "fibre": "fibre_g"})
df2.to_csv(D + "kj_suffixed.csv", index=False)
df3 = df.rename(columns={"energy": "ENERC_KJ", "protein": "PROCNT", "carbohydrate": "CHOAVL", "fat": "FAT", "alcohol": "ALC", "fibre": "FIBTG"})
df3.to_csv(D + "kj_infoods.csv", index=False)
df4 = df.copy(); df4["energy"] = kcal.round(0)
df4 = df4.rename(columns={"energy": "Energy (kcal)", "protein": "Protein (g)", "carbohydrate": "Carbohydrate (g)", "fat": "Total fat (g)", "alcohol": "Alcohol (g)", "fibre": "Fibre (g)"})
df4.to_csv(D + "kcal_spaced_names.csv", index=False)
df5 = df.copy(); df5["energy"] = kcal.round(0)
df5 = df5.rename(columns={"energy": "total_energy", "protein": "prot", "carbohydrate": "carb", "fat": "tfat", "alcohol": "alc", "fibre": "fib"})
df5.to_csv(D + "kcal_abbrev.csv", index=False)

# L. Wide non-assay dietary table (NHANES full DR1T* style: ~60 nutrient columns)
names = ["DR1TKCAL","DR1TPROT","DR1TCARB","DR1TSUGR","DR1TFIBE","DR1TTFAT","DR1TSFAT","DR1TMFAT","DR1TPFAT","DR1TCHOL","DR1TATOC","DR1TATOA","DR1TRET","DR1TVARA","DR1TACAR","DR1TBCAR","DR1TCRYP","DR1TLYCO","DR1TLZ","DR1TVB1","DR1TVB2","DR1TNIAC","DR1TVB6","DR1TFOLA","DR1TFA","DR1TFF","DR1TFDFE","DR1TCHL","DR1TVB12","DR1TB12A","DR1TVC","DR1TVD","DR1TVK","DR1TCALC","DR1TPHOS","DR1TMAGN","DR1TIRON","DR1TZINC","DR1TCOPP","DR1TSODI","DR1TPOTA","DR1TSELE","DR1TCAFF","DR1TTHEO","DR1TALCO","DR1TMOIS"]
k = 400
base = rng.lognormal(np.log(2000), 0.35, k)
df = pd.DataFrame({"SEQN": np.arange(90000, 90000 + k), "RIDAGEYR": rng.integers(20, 80, k), "RIAGENDR": rng.integers(1, 3, k)})
for nm in names:
    df[nm] = (base * rng.lognormal(0, 0.3, k) * rng.uniform(0.001, 0.1)).round(3)
df["DR1TKCAL"] = base.round(0)
df["WTDRD1"] = rng.uniform(5000, 60000, k).round(1)
df["SDMVPSU"] = rng.integers(1, 3, k); df["SDMVSTRA"] = rng.integers(134, 149, k)
df.to_csv(D + "wide_dietary.csv", index=False)

# M. Wide clinical table: 35 labs with recognizable names
labs = ["glucose","hba1c","cholesterol","triglycerides","hdl","ldl","creatinine","bun","sodium","potassium","chloride","bicarbonate","calcium","albumin","total_protein","alt","ast","alp","bilirubin","ggt","wbc","rbc","hemoglobin","hematocrit","mcv","platelets","crp","ferritin","tsh","vitamin_d","uric_acid","insulin","sbp","dbp","bmi","weight","height","waist"]
df = pd.DataFrame({"patient_id": [f"P{i:04d}" for i in range(k)], "age": rng.integers(20, 85, k), "sex": rng.choice(["F","M"], k)})
for nm in labs:
    df[nm] = rng.lognormal(np.log(50), 0.3, k).round(2)
df["glucose"] = rng.lognormal(np.log(98), 0.2, k).round(); df["sbp"] = rng.normal(128, 16, k).round(); df["dbp"] = rng.normal(78, 10, k).round()
df["bmi"] = rng.normal(27, 5, k).round(1); df["weight"] = rng.normal(78, 15, k).round(1); df["height"] = rng.normal(170, 9, k).round(1)
df.to_csv(D + "wide_clinical.csv", index=False)

# N. Genomics TPM with ENSG names (non-integer, normalized)
g = 600; s = 40
counts = rng.negative_binomial(2, 0.02, (s, g)).astype(float)
tpm = counts / counts.sum(1, keepdims=True) * 1e6
df = pd.DataFrame(tpm.round(3), columns=[f"ENSG{rng.integers(10**10, 10**11):011d}" for _ in range(g)])
df.insert(0, "sample_id", [f"S{i:02d}" for i in range(s)])
df.insert(1, "group", rng.choice(["case", "control"], s))
df.to_csv(D + "rnaseq_tpm_ensg.csv", index=False)
logtpm = df.copy(); logtpm.iloc[:, 2:] = np.log2(tpm + 1).round(4)
logtpm.to_csv(D + "rnaseq_log2tpm_ensg.csv", index=False)

# O. Pediatric anthropometry (ages 2-10) with one entry error
k = 300
age = rng.uniform(2, 10, k)
ht = (85 + 6.5 * (age - 2) + rng.normal(0, 4, k)).round(1)
wt = (12 + 2.3 * (age - 2) + rng.normal(0, 2, k)).round(1)
df = pd.DataFrame({"child_id": np.arange(k), "age": age.round(1), "height": ht, "weight": wt})
df["bmi"] = (df.weight / (df.height / 100) ** 2).round(1)
df.loc[3, "weight"] = 0.2  # entry error
df["sbp"] = rng.normal(100, 9, k).round(); df["dbp"] = rng.normal(60, 8, k).round()
df.to_csv(D + "pediatric.csv", index=False)

# P. Daily time course (10 days, CV 0) and weekly crossover periods
rows = []
for pid in range(60):
    start = pd.Timestamp("2024-01-01") + pd.Timedelta(days=int(rng.integers(0, 60)))
    for d in range(10):
        rows.append({"participant_id": f"P{pid:03d}", "date": (start + pd.Timedelta(days=d)).date().isoformat(),
                     "glucose": round(float(100 - 1.5 * d + rng.normal(0, 4)), 1), "diet": "A" if pid % 2 else "B"})
pd.DataFrame(rows).to_csv(D + "daily_timecourse.csv", index=False)
rows = []
for pid in range(40):
    start = pd.Timestamp("2024-03-01") + pd.Timedelta(days=int(rng.integers(0, 30)))
    for d in range(4):
        rows.append({"participant_id": f"P{pid:03d}", "visit_date": (start + pd.Timedelta(days=7 * d)).date().isoformat(),
                     "period": d + 1, "ldl": round(float(130 - (8 if d % 2 else 0) + rng.normal(0, 6)), 1)})
pd.DataFrame(rows).to_csv(D + "weekly_crossover.csv", index=False)
# Q. Quarterly 24h recalls (usual-intake design): scheduled replicates
rows = []
for pid in range(80):
    start = pd.Timestamp("2023-01-01") + pd.Timedelta(days=int(rng.integers(0, 30)))
    for q in range(4):
        rows.append({"participant_id": f"P{pid:03d}", "recall_date": (start + pd.Timedelta(days=91 * q + int(rng.integers(-5, 6)))).date().isoformat(),
                     "energy_kcal": round(float(rng.normal(2100, 450)), 0), "protein_g": round(float(rng.normal(80, 20)), 1),
                     "fat_g": round(float(rng.normal(75, 20)), 1), "carbohydrate_g": round(float(rng.normal(250, 60)), 1)})
pd.DataFrame(rows).to_csv(D + "quarterly_recalls.csv", index=False)
print("ok")
