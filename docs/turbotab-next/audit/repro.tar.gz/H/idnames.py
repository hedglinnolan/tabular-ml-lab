import sys, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core.stages.rows import _id_like
from turbotab.core.stages.finding_words import is_identifier_name
from utils.test_lockbox import _id_kind
names = ["eid", "f.eid", "MRN", "mrn", "patid", "ptid", "pt_id", "Participant", "ParticipantID", "participantId", "subjid", "SUBJID", "USUBJID", "ResponseId", "record", "Subject", "id", "ID", "SEQN", "seqn", "pid", "hhid", "HHID", "person_number", "studyno", "Study Number", "case_no", "Sample Name", "SampleID", "sample", "batch_id", "site_id", "plate_id", "visit_id", "household_id", "family_id", "lipid", "uric_acid", "fatty_acid_id", "RIDAGEYR", "rid", "RID", "idno", "IDNO", "barcode", "accession"]
print(f"{'name':16s} rows._id_like  finding_words  lockbox._id_kind")
for n in names:
    print(f"{n:16s} {str(_id_like(n)):13s} {str(is_identifier_name(n)):14s} {_id_kind(n)}")
