import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
import turbotab.core.models
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import DesignSpec, build_pipeline
from turbotab.core.decisions import EnergyAdjustment

rng = np.random.default_rng(0)
n = 800
E = rng.normal(2000, 400, n)
sex = rng.choice(["F", "M"], n)
fat = E * 0.035 * rng.lognormal(0, 0.25, n) * np.where(sex == "M", 1.1, 1.0)
carb = E * 0.12 * rng.lognormal(0, 0.2, n)
y = 0.04 * fat - 0.01 * carb + 0.002 * E + (sex == "M") * 1.0 + rng.normal(0, 3, n)
X = pd.DataFrame({"fat_g": fat, "carb_g": carb, "energy_kcal": E, "sex": sex})
fam = get_family("linear")

def table(method, strata=None, log=False):
    adj = EnergyAdjustment(method=method, energy_column="energy_kcal", nutrients=["fat_g", "carb_g"],
                           strata=strata, log_transform=log)
    cols = ["fat_g", "carb_g", "energy_kcal", "sex"]
    spec = DesignSpec(predictors=cols, inputs=cols, categorical=["sex"], numeric=cols[:3],
                      energy=adj.model_dump(), impute=False)
    pipe = build_pipeline(spec, fam, "regression", "inference", n, 4).fit(X, y)
    rows = fam.coefficients(pipe, X, y, task="regression", purpose="inference")
    return {r["feature"]: (round(r["estimate"], 5), round(r["ci_low"], 5), round(r["ci_high"], 5)) for r in rows}

std = table("standard")
res = table("residual")
print("standard:", {k: v for k, v in std.items() if "fat" in k or "carb" in k or "energy" in k})
print("residual:", {k: v for k, v in res.items() if "fat" in k or "carb" in k or "energy" in k})
strat = table("residual", strata="sex")
print("residual within sex:", {k: v for k, v in strat.items() if "fat" in k or "carb" in k})
