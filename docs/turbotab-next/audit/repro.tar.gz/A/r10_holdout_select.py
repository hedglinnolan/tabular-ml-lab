import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from sklearn.base import clone
import turbotab.core.models
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import DesignSpec, build_pipeline
from turbotab.core.models.metrics import score

rng = np.random.default_rng(0)
p = 10
cols = [f"x{i}" for i in range(p)]
spec = DesignSpec(predictors=cols, inputs=cols, categorical=[], numeric=cols, energy=None, impute=False)
keys = ["linear", "elastic_net", "boosted_trees"]
pipes = {k: build_pipeline(spec, get_family(k), "binary", "prediction", 400, p) for k in keys}
best_hold, best_true = [], []
for r in range(150):
    def draw(n):
        X = pd.DataFrame(rng.normal(size=(n, p)), columns=cols)
        y = (rng.random(n) < 1 / (1 + np.exp(-(0.6 * X["x0"] - 0.8)))).astype(int).to_numpy()
        return X, y
    (X, y), (Xh, yh), (Xn, yn) = draw(400), draw(150), draw(20000)
    hold, true = {}, {}
    for k in keys:
        m = clone(pipes[k]).fit(X, y)
        hold[k] = score("binary", m, Xh, yh)["auc"]
        true[k] = score("binary", m, Xn, yn)["auc"]
    b = max(keys, key=hold.get)
    best_hold.append(hold[b]); best_true.append(true[b])
print(f"holdout of 150 rows, all three families revealed, best picked on the holdout: "
      f"reported AUC {np.mean(best_hold):.3f} vs its true AUC {np.mean(best_true):.3f} "
      f"(optimism {np.mean(best_hold) - np.mean(best_true):+.3f}, 150 datasets)")
