import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from sklearn.base import clone
from sklearn.model_selection import KFold
import turbotab.core.models
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import DesignSpec, build_pipeline
from turbotab.core.models.metrics import score

rng = np.random.default_rng(0)
n, p = 1000, 20
cols = [f"x{i}" for i in range(p)]
X = pd.DataFrame(rng.normal(size=(n, p)), columns=cols)
y = X.iloc[:, :5].sum(axis=1).to_numpy() * 0.3 + rng.normal(size=n)
spec = DesignSpec(predictors=cols, inputs=cols, categorical=[], numeric=cols, energy=None, impute=False)
pipe = build_pipeline(spec, get_family("elastic_net"), "regression", "prediction", n, p)
print("inner cv param as built:", pipe[-1].get_params()["cv"])

def cv_r2(Xs, ys):
    folds = np.zeros(len(ys), int)
    for f, (_, te) in enumerate(KFold(5, shuffle=True, random_state=0).split(Xs)):
        folds[te] = f
    out, alphas = [], []
    for f in range(5):
        m = clone(pipe).fit(Xs[folds != f], ys[folds != f])
        out.append(score("regression", m, Xs[folds == f], ys[folds == f])["r2"])
        alphas.append(m[-1].alpha_)
    return np.mean(out), np.median(alphas)

# same rows, two file orders (outer folds are shuffled by the app either way)
r_shuf, a_shuf = cv_r2(X, y)
order = np.argsort(y)  # a file sorted by the outcome (or by anything correlated with it)
Xs, ys = X.iloc[order].reset_index(drop=True), y[order]
r_sort, a_sort = cv_r2(Xs, ys)
print(f"file in random order: CV R2 {r_shuf:.3f}, median chosen alpha {a_shuf:.4f}")
print(f"same rows sorted by y: CV R2 {r_sort:.3f}, median chosen alpha {a_sort:.4f}")
