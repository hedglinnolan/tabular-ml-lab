import numpy as np, statsmodels.api as sm
rng = np.random.default_rng(0)
for n in (200, 1000):
    a = h = 0; reps = 2000
    for _ in range(reps):
        x = rng.lognormal(0, 0.5, n)
        y = 1 + rng.normal(size=n) * np.sqrt(x)      # milder: variance proportional to intake
        X = sm.add_constant(x)
        lo, hi = sm.OLS(y, X).fit().conf_int(0.05)[1]; a += lo <= 0 <= hi
        lo, hi = sm.OLS(y, X).fit(cov_type="HC3").conf_int(0.05)[1]; h += lo <= 0 <= hi
    print(f"variance proportional to x, n={n}: classical {a/reps:.3f} | HC3 {h/reps:.3f}")
