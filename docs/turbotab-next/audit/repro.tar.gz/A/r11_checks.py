import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from sklearn.base import clone
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import f1_score
import statsmodels.api as sm
import turbotab.core.models
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import DesignSpec, build_pipeline
from turbotab.core.models.linear import statsmodels_fit, statsmodels_rows
from turbotab.core.models.metrics import score, summarize

rng = np.random.default_rng(0)
# 1. elastic net: back-transformed coefficients reproduce the pipeline's predictions on raw columns
n, p = 500, 6
cols = [f"x{i}" for i in range(p)]
X = pd.DataFrame(rng.normal(size=(n, p)) * rng.uniform(0.1, 50, p) + 10, columns=cols)
y = X.to_numpy() @ rng.normal(size=p) * 0.05 + rng.normal(size=n)
spec = DesignSpec(predictors=cols, inputs=cols, categorical=[], numeric=cols, energy=None, impute=False)
en = get_family("elastic_net")
pipe = build_pipeline(spec, en, "regression", "prediction", n, p).fit(X, y)
rows = en.coefficients(pipe, X, y, task="regression", purpose="prediction")
b0 = rows[0]["estimate"]; b = np.array([r["estimate"] for r in rows[1:]])
print("elastic net back-transform: max |pred(raw coef) - pipeline.predict| =",
      float(np.max(np.abs(b0 + X.to_numpy() @ b - pipe.predict(X)))))

# 2. MNLogit: row/CI alignment and cluster support
k = 3
Xm = pd.DataFrame(rng.normal(size=(600, 2)), columns=["a", "b"])
eta = np.column_stack([np.zeros(600), 1.0 * Xm["a"], -1.0 * Xm["b"]])
pr = np.exp(eta) / np.exp(eta).sum(1, keepdims=True)
ym = np.array(["c0", "c1", "c2"])[[rng.choice(3, p=pp) for pp in pr]]
g = np.repeat(np.arange(100), 6)
for groups in (None, g):
    res = statsmodels_fit("multiclass", Xm, ym, ["c0", "c1", "c2"], groups)
    rws = statsmodels_rows("multiclass", res, ["c0", "c1", "c2"])
    ci = res.conf_int(0.05)
    ok = True
    for kk, lab in enumerate(["c1", "c2"]):
        for j, nm in enumerate(["const", "a", "b"]):
            row = rws[kk * 3 + j]
            lo, hi = ci.loc[(str(kk + 1) if (str(kk + 1), nm) in ci.index else kk + 1, nm)] if isinstance(ci.index, pd.MultiIndex) else (None, None)
            ok &= abs(row["estimate"] - res.params.iloc[j, kk]) < 1e-12 and (lo is None or abs(row["ci_low"] - lo) < 1e-12)
    print(f"MNLogit groups={'yes' if groups is not None else 'no'}: rows align with params/conf_int: {ok}; "
          f"cov_type={res.cov_type}; e.g. {rws[1]['feature']} est {rws[1]['estimate']:.3f} CI ({rws[1]['ci_low']:.3f}, {rws[1]['ci_high']:.3f})")

# 3. macro-F1: mean of per-fold vs pooled with a rare class (app's summarize = mean of folds)
lr = get_family("linear")
c3 = ["a", "b"]
spec3 = DesignSpec(predictors=c3, inputs=c3, categorical=[], numeric=c3, energy=None, impute=False)
pipe3 = build_pipeline(spec3, lr, "multiclass", "prediction", 300, 2)
gaps = []
for r in range(100):
    Xr = pd.DataFrame(rng.normal(size=(300, 2)), columns=c3)
    eta = np.column_stack([np.zeros(300), 1.5 * Xr["a"] - 0.5, 2.0 * Xr["b"] - 3.5])
    pr = np.exp(eta) / np.exp(eta).sum(1, keepdims=True)
    yr = np.array(["c0", "c1", "rare"])[[rng.choice(3, p=pp) for pp in pr]]
    pred = np.empty(300, dtype=object); pf = []
    for tr, te in StratifiedKFold(5, shuffle=True, random_state=r).split(Xr, yr):
        m = clone(pipe3).fit(Xr.iloc[tr], yr[tr])
        pf.append(score("multiclass", m, Xr.iloc[te], yr[te])); pred[te] = m.predict(Xr.iloc[te])
    gaps.append((summarize("multiclass", pf)["macro_f1"]["mean"], f1_score(yr, pred, average="macro"), (yr == "rare").sum()))
gaps = np.array(gaps, dtype=float)
print(f"multiclass, rare class ~{gaps[:,2].mean():.0f}/300 rows: mean per-fold macro-F1 {gaps[:,0].mean():.3f} vs pooled-prediction macro-F1 {gaps[:,1].mean():.3f}")
