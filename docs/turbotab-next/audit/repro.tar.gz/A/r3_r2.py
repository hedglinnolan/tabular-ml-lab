import sys, numpy as np, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score
from turbotab.core.models.metrics import score, summarize

# Population: y = x b + e, p=5 predictors; true population R2 = 0.20. Out-of-sample R2 of a model fit on
# n_train rows, evaluated on a large fresh sample = the estimand ("how well does this pipeline predict").
def sim(n, k=5, reps=400, p=5, R2=0.2, seed=0):
    rng = np.random.default_rng(seed)
    beta = np.ones(p) * np.sqrt(R2/(1-R2)/p)
    perfold, pooled, popr2 = [], [], []
    for _ in range(reps):
        X = rng.normal(size=(n, p)); y = X@beta + rng.normal(size=n)
        folds = KFold(k, shuffle=True, random_state=0).split(X)
        pf = []; pred = np.empty(n)
        for tr, te in folds:
            mdl = LinearRegression().fit(X[tr], y[tr])
            pf.append(score("regression", mdl, X[te], y[te]))
            pred[te] = mdl.predict(X[te])
        perfold.append(summarize("regression", pf)["r2"]["mean"])
        pooled.append(r2_score(y, pred))
        # estimand: model fit on (k-1)/k n rows, R2 on fresh population vs population mean/variance
        mdl = LinearRegression().fit(X[: int(n*(k-1)/k)], y[: int(n*(k-1)/k)])
        Xn = rng.normal(size=(20000, p)); yn = Xn@beta + rng.normal(size=20000)
        popr2.append(1 - np.mean((yn - mdl.predict(Xn))**2) / np.var(yn))
    return np.mean(perfold), np.mean(pooled), np.mean(popr2)
for n in (60, 100, 300, 1000):
    a, b, c = sim(n)
    print(f"n={n:5d}: mean per-fold R2 {a:.3f} | pooled-prediction R2 {b:.3f} | target (fresh-sample R2) {c:.3f}")

# Holdout R2: sklearn uses the HOLDOUT's own mean as the reference.
rng = np.random.default_rng(3)
gap = []
for _ in range(2000):
    n_tr, n_h = 240, 60
    X = rng.normal(size=(n_tr+n_h, 5)); y = X@np.full(5, 0.2236) + rng.normal(size=n_tr+n_h)
    mdl = LinearRegression().fit(X[:n_tr], y[:n_tr])
    yh, ph = y[n_tr:], mdl.predict(X[n_tr:])
    r2_hold_mean = r2_score(yh, ph)
    r2_train_mean = 1 - np.sum((yh-ph)**2)/np.sum((yh - y[:n_tr].mean())**2)
    gap.append((r2_hold_mean, r2_train_mean))
gap = np.array(gap)
print("holdout n=60: mean R2(holdout mean ref) %.3f  vs  R2(training mean ref) %.3f" % tuple(gap.mean(0)))
