import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from scipy import stats
import statsmodels.api as sm
import turbotab.core.models
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import DesignSpec, build_pipeline
from turbotab.core.stages.modeling import _concerns

# --- 1. heteroskedastic errors: coverage of the app's (classical) OLS interval vs HC3 ---
def coverage(n, reps=2000, seed=0):
    rng = np.random.default_rng(seed)
    hit_app = hit_hc3 = 0
    for _ in range(reps):
        x = rng.lognormal(0, 0.6, n)                    # skewed intake-like exposure
        y = 1 + 0.0 * x + rng.normal(size=n) * x        # error SD grows with intake
        X = sm.add_constant(x)
        r = sm.OLS(y, X).fit()                          # what statsmodels_fit does without groups
        lo, hi = r.conf_int(0.05)[1]
        hit_app += lo <= 0 <= hi
        r3 = sm.OLS(y, X).fit(cov_type="HC3")
        lo, hi = r3.conf_int(0.05)[1]
        hit_hc3 += lo <= 0 <= hi
    return hit_app / reps, hit_hc3 / reps
for n in (50, 200, 1000):
    a, h = coverage(n)
    print(f"heteroskedastic, n={n}: 95% CI coverage, classical (app) {a:.3f} | HC3 {h:.3f}")

# --- 2. quasi-complete separation in the linear family's inference table ---
rng = np.random.default_rng(1)
n = 300
cols = ["exposed", "age"]
X = pd.DataFrame({"exposed": (rng.random(n) < 0.08).astype(float), "age": rng.normal(50, 10, n)})
y = ((rng.random(n) < 0.3) | (X["exposed"] == 1)).astype(int).to_numpy()   # every exposed row is an event
spec = DesignSpec(predictors=cols, inputs=cols, categorical=[], numeric=cols, energy=None, impute=False)
fam = get_family("linear")
pipe = build_pipeline(spec, fam, "binary", "inference", n, 2)
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter("always")
    pipe.fit(X, y)
    rows = fam.coefficients(pipe, X, y, task="binary", purpose="inference")
for r in rows:
    print("   ", {k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()})
print("warnings raised:", sorted({type(w.message).__name__ + ": " + str(w.message)[:70] for w in caught}))
print("concerns the fit stage would attach:", _concerns(caught, 6))
