import sys, numpy as np, pandas as pd, warnings, time
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from sklearn.linear_model import LinearRegression
from turbotab.core.methods.substitution import Shift, refit_band, substitution_curve
from turbotab.core.stages.modeling import SUBSTITUTION_ROWS, BAND_ROWS

KPU = {"fat_g": 9.0, "carb_g": 4.0}
B_FAT, B_CARB = 0.03, 0.0  # outcome units per gram
TRUE = 100 * (B_CARB/4 - B_FAT/9)   # true delta at k = 100 kcal
def data(n, rng):
    E = rng.normal(2000, 400, n).clip(800, None)
    fat = (E*0.35/9) * rng.lognormal(0, 0.25, n)
    carb = (E*0.50/4) * rng.lognormal(0, 0.2, n)
    prot = (E*0.15/4) * rng.lognormal(0, 0.2, n)
    X = pd.DataFrame({"fat_g": fat, "carb_g": carb, "protein_g": prot, "energy_kcal": E})
    y = 5 + B_FAT*fat + B_CARB*carb + 0.001*E + rng.normal(0, 3, n)
    return X, y
def fitpred(Xb, yb):
    m = LinearRegression().fit(Xb, yb); return m.predict
ks = [0.0, 100.0]

def one(N, B, seed, band_rows=BAND_ROWS):
    rng = np.random.default_rng(seed)
    X, y = data(N, rng)
    X.index = np.arange(N)
    model = LinearRegression().fit(X, y)
    cur_ids = np.arange(N) if N <= SUBSTITUTION_ROWS else np.sort(np.random.default_rng(0).choice(N, SUBSTITUTION_ROWS, replace=False))
    Xc = X.iloc[cur_ids]
    curve = substitution_curve(model.predict, Xc, donor="fat_g", recipient="carb_g", kcal_per_unit=KPU, ks=ks)
    band_ids = cur_ids if len(cur_ids) <= band_rows else np.sort(np.random.default_rng(1).choice(cur_ids, band_rows, replace=False))
    Xb, yb = X.loc[band_ids], y[band_ids]
    shift = Shift(Xc, donor="fat_g", recipient="carb_g", kcal_per_unit=KPU)
    band = refit_band(fitpred, Xb, yb, shift=shift, ks=ks, live=curve["live"], n_boot=B, random_state=0, center=curve["delta"])
    return curve["delta"][1], band["ci_low"][1], band["ci_high"][1], model

# 1) True sampling SD of the full-N point estimate vs band half-width at N = 10,000
N = 10_000
est = [one(N, 2, s)[0] for s in range(150)]  # B tiny; we only want the point estimate's spread
sd_true = np.std(est, ddof=1)
d, lo, hi, _ = one(N, 50, 999)
print(f"N={N}: true SD of delta(100) = {sd_true:.4f}; correct 95% half-width = {1.96*sd_true:.4f}; "
      f"app band half-width (2,000-row refits, B=50) = {(hi-lo)/2:.4f}; ratio = {(hi-lo)/2/(1.96*sd_true):.2f} (sqrt(N/2000)={np.sqrt(N/2000):.2f})")

# 2) Coverage at N=10,000 (subsampled band) and N=1,500 (no subsample), B=50 as the Results offer
for N, reps in ((10_000, 200), (1_500, 400)):
    hits = 0; widths = []
    t = time.time()
    for s in range(reps):
        d, lo, hi, _ = one(N, 50, 10_000 + s)
        hits += lo <= TRUE <= hi; widths.append(hi - lo)
    print(f"N={N}: coverage of the nominal 95% band (B=50) = {hits/reps:.3f} over {reps} datasets; mean width {np.mean(widths):.4f}  [{time.time()-t:.0f}s]")

# 3) Monte Carlo noise of the endpoints at B=50: same dataset, different bootstrap seeds
rng = np.random.default_rng(5); X, y = data(1500, rng); X.index = np.arange(1500)
model = LinearRegression().fit(X, y)
curve = substitution_curve(model.predict, X, donor="fat_g", recipient="carb_g", kcal_per_unit=KPU, ks=ks)
shift = Shift(X, donor="fat_g", recipient="carb_g", kcal_per_unit=KPU)
for B in (50, 1000):
    ws = []
    for rs in range(30 if B == 50 else 5):
        b = refit_band(fitpred, X, y, shift=shift, ks=ks, live=curve["live"], n_boot=B, random_state=rs, center=curve["delta"])
        ws.append(b["ci_high"][1] - b["ci_low"][1])
    print(f"B={B}: band width across bootstrap seeds: mean {np.mean(ws):.4f}, CV {np.std(ws)/np.mean(ws):.1%}, range {min(ws):.4f}-{max(ws):.4f}")
