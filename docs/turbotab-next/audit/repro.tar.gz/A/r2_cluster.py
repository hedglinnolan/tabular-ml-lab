import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from turbotab.core.models.linear import statsmodels_fit, statsmodels_rows
import statsmodels.api as sm
from scipy import stats

# What distribution does the app's cluster-robust OLS use?
rng = np.random.default_rng(1)
G, per = 10, 30
g = np.repeat(np.arange(G), per)
u = rng.normal(size=G)[g]
x = rng.normal(size=G)[g] + rng.normal(size=G*per)*0.5   # cluster-level-ish exposure
y = 0.0*x + u + rng.normal(size=G*per)
M = pd.DataFrame({"x": x})
res = statsmodels_fit("regression", M, y, None, groups=g)
print("use_t:", res.use_t, "df_resid_inference:", getattr(res, "df_resid_inference", None))
lo, hi = res.conf_int(0.05).loc["x"]
se = res.bse["x"]
print(f"app CI half-width/SE = {(hi-lo)/2/se:.4f} (z=1.96); t(G-1={G-1}) would be {stats.t.ppf(.975, G-1):.4f}")

# Monte Carlo coverage of the app's 95% CI for a null cluster-level effect with G clusters
def cover(G, per, reps=1500, seed=0):
    rng = np.random.default_rng(seed)
    hit_app = hit_t = 0
    for _ in range(reps):
        g = np.repeat(np.arange(G), per)
        x = rng.normal(size=G)[g] + 0.3*rng.normal(size=G*per)
        y = rng.normal(size=G)[g] + rng.normal(size=G*per)
        r = sm.OLS(y, sm.add_constant(x)).fit(cov_type="cluster", cov_kwds={"groups": g})
        b, s = r.params[1], r.bse[1]
        hit_app += abs(b) <= 1.959964*s
        hit_t += abs(b) <= stats.t.ppf(.975, G-1)*s
    return hit_app/reps, hit_t/reps
for G in (8, 12, 20, 50):
    a, t = cover(G, 20)
    print(f"G={G:3d}: coverage app(z) {a:.3f}   with t(G-1) {t:.3f}")
