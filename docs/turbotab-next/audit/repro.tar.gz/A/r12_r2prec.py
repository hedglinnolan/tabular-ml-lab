import numpy as np
from sklearn.metrics import r2_score
rng = np.random.default_rng(0)
for rho in (0.0, 0.1, 0.3):
    for n in (100, 500):
        vals = []
        for _ in range(4000):
            f = rng.normal(size=n) * np.sqrt(rho)            # the model's prediction = true signal
            y = f + rng.normal(size=n) * np.sqrt(1 - rho)
            vals.append(r2_score(y, f))
        sd = np.std(vals)
        app = (1 - 0) * np.sqrt(2 / n)                         # the app's SE, evaluated at R2 = 0
        print(f"true R2={rho:.1f} n={n}: empirical SD of holdout R2 {sd:.3f}; app's SE (1-R2)*sqrt(2/n) at R2=0 {app:.3f}; at true R2 {(1-rho)*np.sqrt(2/n):.3f}")
