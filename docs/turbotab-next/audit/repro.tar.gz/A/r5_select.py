import sys, time, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from sklearn.base import clone
from sklearn.model_selection import StratifiedKFold
import turbotab.core.models  # registers families
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import DesignSpec, build_pipeline
from turbotab.core.models.metrics import score, summarize
from turbotab.core.models.baseline import versus_baseline
from turbotab.core.stages.modeling import _baseline_scores

def run(n, p, signal, reps, seed=0, task="binary"):
    rng = np.random.default_rng(seed)
    cols = [f"x{i}" for i in range(p)]
    spec = DesignSpec(predictors=cols, inputs=cols, categorical=[], numeric=cols, energy=None, impute=False)
    keys = ["linear", "elastic_net", "boosted_trees"]
    rows = []
    for r in range(reps):
        X = pd.DataFrame(rng.normal(size=(n, p)), columns=cols)
        lin = signal * X["x0"].to_numpy()
        y = (rng.random(n) < 1/(1+np.exp(-lin))).astype(int)
        Xn = pd.DataFrame(rng.normal(size=(20000, p)), columns=cols)
        yn = (rng.random(20000) < 1/(1+np.exp(-signal*Xn["x0"].to_numpy()))).astype(int)
        folds = np.zeros(n, int)
        for f, (_, te) in enumerate(StratifiedKFold(5, shuffle=True, random_state=r).split(X, y)): folds[te] = f
        base = _baseline_scores(task, X, y, folds, list(range(5)))
        out = {}
        for k in keys:
            fam = get_family(k)
            pipe = build_pipeline(spec, fam, task, "prediction", n, p)
            pf = []
            for f in range(5):
                m = clone(pipe).fit(X[folds != f], y[folds != f]); pf.append(score(task, m, X[folds == f], y[folds == f]))
            cv = summarize(task, pf)["auc"]["mean"]
            vb = versus_baseline("auc", [d["auc"] for d in pf], [b["auc"] for b in base]).verdict
            true = score(task, clone(pipe).fit(X, y), Xn, yn)["auc"]
            out[k] = (cv, vb, true)
        best = max(keys, key=lambda k: out[k][0])
        rows.append({"best": best, "best_cv": out[best][0], "best_true": out[best][2],
                     **{f"{k}_cv": out[k][0] for k in keys}, **{f"{k}_true": out[k][2] for k in keys},
                     **{f"{k}_vb": out[k][1] for k in keys}})
    return pd.DataFrame(rows)
t = time.time()
for n, p, sig, reps in ((150, 10, 0.0, 60), (150, 10, 0.5, 60)):
    d = run(n, p, sig, reps)
    print(f"n={n}, p={p}, signal={sig}: E[CV AUC of the CV-best family] {d.best_cv.mean():.3f} vs its true AUC {d.best_true.mean():.3f} "
          f"(optimism {d.best_cv.mean()-d.best_true.mean():+.3f}); per-family CV-true: " +
          ", ".join(f"{k} {(d[k+'_cv']-d[k+'_true']).mean():+.3f}" for k in ["linear","elastic_net","boosted_trees"]))
    if sig == 0.0:
        print("   null data: share of fits called 'better' than the class prior: " +
              ", ".join(f"{k} {(d[k+'_vb']=='better').mean():.2f}" for k in ["linear","elastic_net","boosted_trees"]) +
              f"; any of the three 'better': {((d[['linear_vb','elastic_net_vb','boosted_trees_vb']]=='better').any(axis=1)).mean():.2f}")
print(f"[{time.time()-t:.0f}s]")
