import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from turbotab.core.stages.rows import draw_split
from turbotab.core.seal import chronological_holdout

rng = np.random.default_rng(0)
units = 300
per = rng.integers(1, 6, units)
g = np.repeat([f"p{i}" for i in range(units)], per)
n = len(g)
ids = rng.permutation(np.arange(10_000, 10_000 + n))
y = np.where(rng.random(n) < 0.2, "case", "control")
universe = ids.copy()
cohort = np.sort(rng.choice(ids, int(n * 0.9), replace=False))
frame, info = draw_split(cohort, holdout=0.2, seed=7, folds=5, y=y, groups=g, grouped_by="pid", universe=universe)
f = frame.set_index("row_id")
gm = pd.Series(g, index=ids).loc[f.index]
side = f.groupby(gm.values)["partition"].nunique()
fold_per_unit = f[f.partition == "train"].groupby(gm[f.partition == "train"].values)["fold"].nunique()
print("units on both sides of the seal:", int((side > 1).sum()), "| training units in >1 fold:", int((fold_per_unit > 1).sum()))
yy = pd.Series(y, index=ids).loc[f.index]
print("case share: holdout %.3f, train %.3f; per fold:" % ((yy[f.partition == "holdout"] == "case").mean(), (yy[f.partition == "train"] == "case").mean()),
      [round((yy[(f.partition == "train") & (f.fold == k)] == "case").mean(), 3) for k in range(5)])
print("info:", {k: v for k, v in info.items() if k not in ("sealed",)})
# determinism
frame2, _ = draw_split(cohort, holdout=0.2, seed=7, folds=5, y=y, groups=g, grouped_by="pid", universe=universe)
print("same inputs, same split:", frame.equals(frame2))
# a sealed row excluded from the cohort stays sealed (never moves across the seal)
sealed = set(info["sealed"].tolist()); held_now = set(frame.loc[frame.partition == "holdout", "row_id"])
print("held-out cohort rows all in sealed set:", held_now <= sealed, "| sealed rows outside the cohort:", len(sealed - set(cohort)))

# chronological + grouped: whole units, latest last-observation held out
t = rng.uniform(0, 100, n)
mask, chron = chronological_holdout(t, g, 0.2, 0, "visit", dated=False)
last = pd.Series(t).groupby(g).max()
held_units = set(pd.unique(g[mask])); train_units = set(pd.unique(g[~mask]))
print("chronological: units split across:", len(held_units & train_units),
      "| min last-visit of held units %.2f >= max last-visit of train units %.2f" % (last[list(held_units)].min(), last[list(train_units)].max()))
print(chron.sentence)
# but: a held-out unit's EARLIER visits are held out too, and a training unit's visits can be later than
# a held-out unit's earlier visits: the boundary is by unit, not by time
print("earliest held-out visit %.2f vs latest training visit %.2f" % (t[mask].min(), t[~mask].max()))
print("share of held-out rows observed before the latest training row: %.2f" % (t[mask] < t[~mask].max()).mean())
print("share of held-out rows observed before the median training row: %.2f" % (t[mask] < np.median(t[~mask])).mean())
