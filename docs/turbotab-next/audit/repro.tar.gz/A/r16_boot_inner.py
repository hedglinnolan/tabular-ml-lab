import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from sklearn.base import clone
import turbotab.core.models
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import DesignSpec, build_pipeline
from turbotab.core.models.inner_cv import with_grouped_inner_cv

rng = np.random.default_rng(0)
n, p = 1000, 30
cols = [f"x{i}" for i in range(p)]
X = pd.DataFrame(rng.normal(size=(n, p)), columns=cols)
y = X.iloc[:, :3].sum(axis=1).to_numpy() * 0.15 + rng.normal(size=n)
spec = DesignSpec(predictors=cols, inputs=cols, categorical=[], numeric=cols, energy=None, impute=False)
pipe = build_pipeline(spec, get_family("elastic_net"), "regression", "prediction", n, p)
point = clone(pipe).fit(X, y)[-1].alpha_
boot = []
for b in range(30):
    idx = rng.integers(0, n, n)
    # the band's refit with no groups: with_grouped_inner_cv(clone(pipe), None) leaves cv=int (KFold on the resample)
    m = with_grouped_inner_cv(clone(pipe), None).fit(X.iloc[idx], y[idx])
    boot.append(m[-1].alpha_)
print(f"elastic net penalty: point fit alpha {point:.4f}; bootstrap refits (duplicates on both sides of the inner folds): "
      f"median alpha {np.median(boot):.4f}, share of refits with a smaller alpha than the point fit {np.mean(np.array(boot) < point):.2f}")
