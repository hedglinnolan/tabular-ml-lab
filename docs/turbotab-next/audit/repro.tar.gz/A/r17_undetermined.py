import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab"); warnings.simplefilter("ignore")
from turbotab.core.models.linear import statsmodels_fit
rng = np.random.default_rng(0)
G, per, reps = 300, 3, 1000
hit_plain = hit_cl = 0
for _ in range(reps):
    g = np.repeat(np.arange(G), per)
    x = rng.normal(size=G)[g] + 0.5 * rng.normal(size=G * per)       # habitual intake + day-to-day
    y = rng.normal(size=G)[g] + 0.7 * rng.normal(size=G * per)       # person effect, no true association
    M = pd.DataFrame({"x": x})
    r0 = statsmodels_fit("regression", M, y, None, None)              # grain undetermined/abandoned: groups=None
    lo, hi = r0.conf_int(0.05).loc["x"]; hit_plain += lo <= 0 <= hi
    r1 = statsmodels_fit("regression", M, y, None, g)
    lo, hi = r1.conf_int(0.05).loc["x"]; hit_cl += lo <= 0 <= hi
print(f"{G} people x {per} rows, grouping not applied: 95% CI coverage {hit_plain/reps:.3f}; cluster-robust {hit_cl/reps:.3f}")
