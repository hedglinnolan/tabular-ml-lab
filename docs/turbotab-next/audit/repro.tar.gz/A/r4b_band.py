import sys, time, numpy as np
sys.path.insert(0, "/private/tmp/turbotab-audit/A")
exec(open("/private/tmp/turbotab-audit/A/r4_band.py").read().split("# 1) True sampling")[0])
for B, reps in ((50, 400), (400, 120)):
    hits = 0; t = time.time()
    for s in range(reps):
        d, lo, hi, _ = one(1500, B, 10_000 + s)
        hits += lo <= TRUE <= hi
    se = np.sqrt(0.95*0.05/reps)
    print(f"N=1500, B={B}: coverage {hits/reps:.3f} (MC SE ~{se:.3f}) over {reps} datasets [{time.time()-t:.0f}s]")
