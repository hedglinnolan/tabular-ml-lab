import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
import turbotab.core.models
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import DesignSpec, build_pipeline

fam = get_family("linear")
cols = ["intake", "age"]
spec = DesignSpec(predictors=cols, inputs=cols, categorical=[], numeric=cols, energy=None, impute=True)
rng = np.random.default_rng(0)
TRUE = 0.5
hits = 0; est = []
reps = 500
for r in range(reps):
    n = 600
    age = rng.normal(size=n)
    intake = 0.5 * age + rng.normal(size=n)
    y = TRUE * intake + 0.5 * age + rng.normal(size=n)
    miss = rng.random(n) < 1 / (1 + np.exp(-(age - 0.5)))   # MAR on age: ~40% of intake blank
    X = pd.DataFrame({"intake": np.where(miss, np.nan, intake), "age": age})
    pipe = build_pipeline(spec, fam, "regression", "inference", n, 2).fit(X, y)
    rows = {row["feature"]: row for row in fam.coefficients(pipe, X, y, task="regression", purpose="inference")}
    b = rows["intake"]
    est.append(b["estimate"]); hits += b["ci_low"] <= TRUE <= b["ci_high"]
print(f"median-filled intake (MAR ~{miss.mean():.0%} blank), inference table: mean estimate {np.mean(est):.3f} "
      f"(true {TRUE}); 95% CI coverage {hits / reps:.3f}")
