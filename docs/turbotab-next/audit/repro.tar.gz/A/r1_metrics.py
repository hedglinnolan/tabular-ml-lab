import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from turbotab.core.models.metrics import score, summarize
from turbotab.core.stages.modeling import coded_outcome, baseline_model, _baseline_scores
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn import metrics as m

rng = np.random.default_rng(0)
# --- binary, string labels, event = "case" (sorts first) ---
n = 400
x = rng.normal(size=(n, 2))
p = 1/(1+np.exp(-(x[:,0]*1.5 - 0.5)))
ev = rng.random(n) < p
y_str = np.where(ev, "case", "control")
X = pd.DataFrame(x, columns=["a","b"])
# with event named
y_coded = coded_outcome("binary", y_str, "case")
mdl = LogisticRegression().fit(X, y_coded)
s = score("binary", mdl, X, y_coded)
ref_auc = m.roc_auc_score(ev, mdl.predict_proba(X)[:,1])
print("event named: app auc", round(s["auc"],6), "ref auc(event=case)", round(ref_auc,6))
# without event named: falls back to sorted classes -> 'control' is positive
mdl2 = LogisticRegression().fit(X, y_str)
s2 = score("binary", mdl2, X, y_str)
print("no event: classes", list(mdl2.classes_), "app auc", round(s2["auc"],6), "brier", round(s2["brier"],4),
      "| brier for event 'case':", round(m.brier_score_loss(ev, mdl2.predict_proba(X)[:,0]),4))
# event named but not a level (typo / different key): silently falls back
y_c3 = coded_outcome("binary", y_str, "Case ")
print("event 'Case ' -> coded?", set(np.unique(y_c3)))
y_c4 = coded_outcome("binary", y_str, "cases")
print("event 'cases' -> coded?", set(np.unique(y_c4)))
