import sys, numpy as np, pandas as pd, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from turbotab.core.seal import chronological_holdout
from turbotab.core.stages.rows import draw_split
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import r2_score

rng = np.random.default_rng(0)
n = 1500
t = np.sort(rng.uniform(0, 10, n))            # e.g. survey year / visit date, one row per unit
x = rng.normal(size=(n, 3))
# drifting relation: the effect of x0 changes over time, plus a level shift (non-stationarity)
y = (1.0 - 0.06 * t) * x[:, 0] + 0.08 * t + 0.5 * x[:, 1] + rng.normal(size=n)
ids = np.arange(n)

held, chron = chronological_holdout(t, None, 0.2, 0, "year", dated=False)
frame, info = draw_split(ids, holdout=0.2, seed=0, folds=5, held=held)
print("chronology:", chron.sentence)
tr = frame["partition"].eq("train").to_numpy()
fold = frame["fold"].to_numpy()
print("training-fold time ranges (min-max) per fold:",
      [(round(t[tr & (fold == k)].min(), 1), round(t[tr & (fold == k)].max(), 1)) for k in range(info["folds"])])
print("split note facts: stratified", info["stratified"], "| folds", info["folds"])

X = np.column_stack([x, t])  # the time column is not a predictor here; x only
X = x
cv = []
for k in range(info["folds"]):
    fit, test = tr & (fold != k), tr & (fold == k)
    m = HistGradientBoostingRegressor(random_state=0).fit(X[fit], y[fit])
    cv.append(r2_score(y[test], m.predict(X[test])))
m = HistGradientBoostingRegressor(random_state=0).fit(X[tr], y[tr])
hold = r2_score(y[~tr], m.predict(X[~tr]))
# forward-chaining folds within the training rows (expanding window, 5 blocks by time)
order = np.argsort(t[tr]); idx = np.flatnonzero(tr)[order]; blocks = np.array_split(idx, 6)
fwd = []
for j in range(1, 6):
    fit = np.concatenate(blocks[:j]); test = blocks[j]
    mm = HistGradientBoostingRegressor(random_state=0).fit(X[fit], y[fit])
    fwd.append(r2_score(y[test], mm.predict(X[test])))
print(f"app CV (random folds over time) mean R2 {np.mean(cv):.3f} | forward-chaining CV mean R2 {np.mean(fwd):.3f} | "
      f"chronological holdout R2 {hold:.3f}")
