import sys, numpy as np, pandas as pd, warnings, time, math
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
from sklearn.base import clone
from sklearn.model_selection import StratifiedKFold, KFold
import turbotab.core.models
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import DesignSpec, build_pipeline
from turbotab.core.models.metrics import score
from turbotab.core.models.baseline import versus_baseline
from turbotab.core.stages.modeling import _baseline_scores


def null_rate(task, n, p, reps, seed=0):
    rng = np.random.default_rng(seed)
    cols = [f"x{i}" for i in range(p)]
    spec = DesignSpec(predictors=cols, inputs=cols, categorical=[], numeric=cols, energy=None, impute=False)
    pipe = build_pipeline(spec, get_family("linear"), task, "prediction", n, p)
    metric = "auc" if task == "binary" else "r2"
    app = nb = 0
    for r in range(reps):
        X = pd.DataFrame(rng.normal(size=(n, p)), columns=cols)
        y = (rng.random(n) < 0.3).astype(int) if task == "binary" else rng.normal(size=n)
        sp = (StratifiedKFold(5, shuffle=True, random_state=r).split(X, y) if task == "binary"
              else KFold(5, shuffle=True, random_state=r).split(X))
        folds = np.zeros(n, int)
        for f, (_, te) in enumerate(sp):
            folds[te] = f
        base = _baseline_scores(task, X, y, folds, list(range(5)))
        pf = [score(task, clone(pipe).fit(X[folds != f], y[folds != f]), X[folds == f], y[folds == f])
              for f in range(5)]
        g = np.array([a[metric] - b[metric] for a, b in zip(pf, base)])
        v = versus_baseline(metric, [a[metric] for a in pf], [b[metric] for b in base])
        app += v.verdict == "better"
        # Nadeau & Bengio (2003) corrected resampled t: var * (1/K + n_test/n_train), one-sided 5%
        K = 5
        corr = math.sqrt(g.var(ddof=1) * (1 / K + 0.25))
        nb += g.mean() > 2.132 * corr  # t(4) one-sided 95%
    return app / reps, nb / reps


t = time.time()
for task, n, p in (("binary", 150, 10), ("binary", 400, 10), ("regression", 150, 10), ("regression", 400, 10)):
    a, b = null_rate(task, n, p, 400)
    print(f"{task:10s} n={n} p={p} (no signal): app verdict 'better' {a:.2f}; "
          f"Nadeau-Bengio corrected t, one-sided 5%: {b:.2f}")
print(f"[{time.time()-t:.0f}s]")
