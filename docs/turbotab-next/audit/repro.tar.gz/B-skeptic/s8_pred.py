import numpy as np, pandas as pd
from sklearn.model_selection import cross_val_score, KFold
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.pipeline import Pipeline
from turbotab.core.methods.energy import EnergyAdjuster
rng = np.random.default_rng(3); n = 3000
E = np.exp(rng.normal(np.log(2000), 0.3, n))
sh = rng.dirichlet([33, 47, 16, 4], n)
df = pd.DataFrame({"fat_g": sh[:, 0] * E / 9, "carbohydrate_g": sh[:, 1] * E / 4, "protein_g": sh[:, 2] * E / 4,
                   "energy_kcal": E, "age": rng.uniform(20, 80, n)})
y = 0.01 * E + 0.05 * df.age + 0.05 * df.protein_g + rng.normal(0, 4, n)
cv = KFold(5, shuffle=True, random_state=0)
nut = ["fat_g", "carbohydrate_g", "protein_g"]
for method in ["none", "standard", "residual", "density_multivariate", "density", "partition"]:
    row = []
    for est in (LinearRegression(), HistGradientBoostingRegressor(max_iter=150)):
        steps = [] if method == "none" else [("e", EnergyAdjuster(method, "energy_kcal", nut))]
        if method == "none":
            from sklearn.preprocessing import FunctionTransformer
            steps = [("id", FunctionTransformer())]
        p = Pipeline(steps + [("m", est)])
        row.append(cross_val_score(p, df, y, cv=cv, scoring="r2").mean())
    print(f"{method:22s} OLS R2={row[0]:.3f}  GBM R2={row[1]:.3f}")
