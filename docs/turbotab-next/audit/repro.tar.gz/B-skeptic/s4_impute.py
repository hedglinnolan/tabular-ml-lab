"""Skeptic B4: app's median impute -> residual, MAR on E and MCAR, vs complete case. Also standard."""
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.models.pipeline import DesignSpec, shared_steps, transformer
rng = np.random.default_rng(2024)
def run(mech, method, reps=100):
    bs, ses, bcc = [], [], []
    for rep in range(reps):
        n = 1500
        E = np.exp(rng.normal(np.log(2000), 0.3, n))
        fat = np.clip(rng.normal(0.34, 0.06, n), 0.1, 0.6) * E / 9
        y = 0.03 * fat + 0.002 * E + rng.normal(0, 2, n)
        X = pd.DataFrame({"fat_g": fat, "energy_kcal": E})
        if mech == "MAR_E":
            p = 0.4 / (1 + np.exp(-(np.log(E) - np.log(2000)) * 4))
        else:
            p = np.full(n, 0.2)
        X.loc[rng.uniform(size=n) < p, "fat_g"] = np.nan
        energy = {"method": method, "energy_column": "energy_kcal", "nutrients": ["fat_g"], "log_transform": False, "strata": None}
        spec = DesignSpec(predictors=["fat_g", "energy_kcal"], inputs=["fat_g", "energy_kcal"], categorical=[],
                          numeric=["fat_g", "energy_kcal"], energy=energy, impute=True,
                          roles={"fat_g": "exposure", "energy_kcal": "energy"})
        M = transformer(shared_steps(spec)).fit_transform(X)
        col = "fat_g_adj" if method == "residual" else "fat_g"
        f = sm.OLS(y, sm.add_constant(M)).fit(); bs.append(f.params[col]); ses.append(f.bse[col])
        cc = X.dropna(); spec.impute = False
        Mc = transformer(shared_steps(spec)).fit_transform(cc)
        bcc.append(sm.OLS(y[cc.index], sm.add_constant(Mc)).fit().params[col])
    print(f"{mech:6s} {method:9s} complete-case mean b {np.mean(bcc):.4f} | app impute mean b {np.mean(bs):.4f} "
          f"(empirical sd {np.std(bs):.4f}, mean reported se {np.mean(ses):.4f}); truth 0.0300")
for mech in ("MAR_E", "MCAR"):
    for method in ("residual", "standard"):
        run(mech, method)
