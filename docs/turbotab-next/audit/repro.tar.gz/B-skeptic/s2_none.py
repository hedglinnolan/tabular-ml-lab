"""Skeptic B2: method 'none' with an energy-role column."""
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.decisions import ProjectState, EnergyAdjustment, MissingSpec
from turbotab.core.models.pipeline import design_spec, shared_steps, transformer, model_predictors
from turbotab.core.methods.energy import METHOD_TABLE
rng = np.random.default_rng(1)
n = 4000
E = rng.normal(2000, 400, n).clip(800)
fat = (rng.normal(0.33, 0.05, n).clip(0.1, 0.6) * E / 9)
age = rng.uniform(20, 80, n)
y = 0.02 * fat + 0.003 * E + 0.05 * age + rng.normal(0, 2, n)   # absolute effect of fat 0.02/g; E also matters
df = pd.DataFrame({"fat_g": fat, "energy_kcal": E, "age": age})
for method in ("none", "standard"):
    st = ProjectState(target="y", task="regression", purpose="inference",
                      roles={"fat_g": "exposure", "energy_kcal": "energy", "age": "covariate"},
                      energy_adjustment=EnergyAdjustment(method=method, energy_column="energy_kcal" if method!="none" else None,
                                                         nutrients=["fat_g"] if method!="none" else []),
                      missing=MissingSpec(strategy="complete_case"))
    preds = model_predictors(st)
    spec = design_spec(st, df, preds)
    X = transformer(shared_steps(spec)).fit_transform(df[spec.inputs])
    m = sm.OLS(y, sm.add_constant(X)).fit()
    print(method, "predictors", preds, "matrix", list(X.columns), "b_fat = %.4f" % m.params["fat_g"])
    print("    label:", METHOD_TABLE[method]["estimand"][:90])
m = sm.OLS(y, sm.add_constant(df[["fat_g", "age"]])).fit()
print("truly unadjusted Y ~ fat + age: b_fat = %.4f" % m.params["fat_g"])
