import numpy as np, pandas as pd
from turbotab.core.methods.substitution import Shift
rng = np.random.default_rng(8); n = 5000
E = np.exp(rng.normal(np.log(2100), 0.35, n))
fs = np.clip(rng.normal(0.34, 0.05, n), 0.18, 0.5); cs = 1 - fs - 0.16
df = pd.DataFrame({"fat_g": fs * E / 9, "carbohydrate_g": cs * E / 4, "protein_g": 0.16 * E / 4, "energy_kcal": E})
pct = 9 * df.fat_g / E
print("observed fat %%E range %.3f - %.3f; carb %%E %.3f - %.3f" % (pct.min(), pct.max(), (4*df.carbohydrate_g/E).min(), (4*df.carbohydrate_g/E).max()))
sh = Shift(df, donor="fat_g", recipient="carbohydrate_g", kcal_per_unit={"fat_g": 9, "carbohydrate_g": 4})
for k in (100, 200, 300, 400):
    new, mask = sh.apply(df, k)
    newpct = 9 * new.fat_g / E; cpct = 4 * new.carbohydrate_g / E
    out = mask & ((newpct < pct.min()) | (cpct > (4*df.carbohydrate_g/E).max()))
    print(f"k={k}: on-support {mask.mean():.1%}; of those, {out.sum()} rows have fat or carb %E outside observed composition (min new fat %E {newpct[mask].min():.3f})")
