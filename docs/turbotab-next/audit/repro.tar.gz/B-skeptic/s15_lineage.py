import numpy as np, pandas as pd
from turbotab.core.models.pipeline import DesignSpec, shared_steps, transformer
from turbotab.core.models.lineage import trace, missing_counts
rng = np.random.default_rng(2); n = 400
E = np.exp(rng.normal(np.log(2000), 0.3, n))
df = pd.DataFrame({"fat_g": 0.34 * E / 9 * np.exp(rng.normal(0, .15, n)), "energy_kcal": E,
                   "sex": rng.choice(["F", "M"], n), "smoker": rng.choice(["yes", "no", None], n)})
df.loc[:30, "fat_g"] = np.nan
energy = {"method": "residual", "energy_column": "energy_kcal", "nutrients": ["fat_g"], "log_transform": True, "strata": "sex"}
spec = DesignSpec(predictors=["fat_g", "energy_kcal", "smoker"], inputs=["fat_g", "energy_kcal", "sex", "smoker"],
                  categorical=["sex", "smoker"], numeric=["fat_g", "energy_kcal"], energy=energy, impute=True,
                  roles={"fat_g": "exposure", "energy_kcal": "energy", "smoker": "covariate"}, levels=["smoker"], indicators=True)
pipe = transformer(shared_steps(spec)); M = pipe.fit_transform(df[spec.inputs])
lin = trace(pipe.steps, spec.inputs, spec.roles, missing_counts(df[spec.inputs]))
for l in lin.links: print(f"{l.source:22s} -> {l.target:34s} : {l.operation}")
for nd in lin.nodes:
    if nd.formula: print("FORMULA", nd.id, ":", nd.formula[:260])
print("arith mean E by sex:", df.groupby("sex").energy_kcal.mean().round(0).to_dict(), " geo:", np.exp(np.log(df.energy_kcal).groupby(df.sex).mean()).round(0).to_dict())
