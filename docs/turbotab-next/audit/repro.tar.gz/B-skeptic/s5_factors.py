import numpy as np, pandas as pd
from turbotab.core.methods.energy import energy_factor, partition_refusal, nutrient_role, EnergyAdjuster
from turbotab.core.stages.modeling import substitution_pairs
from turbotab.core.stages.proposals import energy_bearing
for c in ["fatty_fish_g", "fat_free_mass_kg", "body_fat_pct", "fatigue_score", "lowfat_dairy_g", "fat_g",
          "sfa_g", "mufa_g", "pufa_g", "DR1TSFAT", "DR1TMFAT", "DR1TPFAT", "DR1TSUGR", "DR1TTFAT", "DR1TPROT",
          "DR1TCARB", "DR1TFIBE", "DR1TALCO", "saturated_fat_g", "carbonated_drinks_g", "protein_shake_servings",
          "fiber_supplement_use", "prothrombin_time", "carbamazepine_mg", "fibrinogen_g"]:
    r = energy_factor(c)
    print(f"{c:24s} role={r.role!s:12s} factor={r.factor!s:6s} declared={r.declared!s:5s} bearing={energy_bearing(c)}  | {r.reason}")
print(substitution_pairs(["fat_g", "carbohydrate_g", "fatty_fish_g", "fat_free_mass_kg", "fatigue_score", "body_fat_pct", "age"], "energy_kcal"))
rng = np.random.default_rng(0); n = 500
E = rng.normal(2000, 300, n)
df = pd.DataFrame({"energy_kcal": E, "fatty_fish_g": rng.gamma(1.5, 20, n)})
print("partition_refusal fatty_fish_g:", partition_refusal(df, "energy_kcal", ["fatty_fish_g"]))
a = EnergyAdjuster("partition", "energy_kcal", ["fatty_fish_g"]).fit(df)
print([e["formula"] for e in a.lineage()])
