import pandas as pd, numpy as np, shutil
from pathlib import Path
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
base = Path("/private/tmp/turbotab-audit/B-skeptic/agg")
def run(df, slots, name):
    src = base / f"{name}.csv"; df.to_csv(src, index=False)
    folder = base / f"p_{name}"; shutil.rmtree(folder, ignore_errors=True)
    g = GraphRun(src, folder)
    try:
        out = g.run(ProjectState.model_validate(slots), upto=["working"])
        w = out["working"]
        cols = {c["name"]: (c["dtype"], c.get("physical_type")) for c in g.info["columns"]}
        return pd.read_parquet(w.files["table.parquet"]), w.data["aggregation"], cols
    finally:
        g.close()
rows = []
# visit labels "baseline", "month 6", "month 12" in file order month 12, baseline, month 6
for i in range(30):
    for label, val in [("month_12", 3.0), ("baseline", 1.0), ("month_6", 2.0)]:
        rows.append({"pid": f"P{i:03d}", "visit": label, "age": 40 + i, "sex_code": i % 2 + 1, "ldl": val + i * 0.01, "y": float(i % 5)})
df = pd.DataFrame(rows)
for method in ("first", "change"):
    t, rec, cols = run(df, dict(lens=["clinical"], target="y", grain={"grain": "repeated", "id_column": "pid"},
                               unit="unit", repeat_kind={"repeat_kind": "time_points", "time_column": "visit"},
                               aggregation={"method": method}), f"v_{method}")
    print(f"--- {method}: receipt ordered_by={rec['ordered_by']!r}; visit dtype={cols['visit']}")
    print(t[["pid", "visit", "age", "sex_code", "ldl"]].head(4).to_string())
