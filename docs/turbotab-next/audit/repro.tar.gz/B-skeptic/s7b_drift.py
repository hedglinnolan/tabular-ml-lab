"""Does Y ~ N_adj + C (app residual, E dropped) drift from Y ~ N + E + C under milder, realistic correlations?"""
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.methods.energy import EnergyAdjuster
rng = np.random.default_rng(31)
res = {"std": [], "app": [], "cov_std": 0, "cov_app": 0}
R = 200
for r in range(R):
    n = 3000
    male = rng.integers(0, 2, n); age = rng.uniform(25, 75, n)
    pa = rng.normal(0, 1, n)                                    # physical activity
    E = np.exp(np.log(1800) + 0.2 * male - 0.004 * (age - 50) + 0.08 * pa + rng.normal(0, 0.25, n))
    fat_share = np.clip(0.34 - 0.0015 * (age - 50) - 0.01 * pa + rng.normal(0, 0.05, n), 0.1, 0.6)
    fat = fat_share * E / 9
    y = 0.02 * fat + 0.002 * E + 1.0 * male + 0.03 * age - 0.5 * pa + rng.normal(0, 3, n)  # substitution effect 0.02/g at fixed E
    df = pd.DataFrame({"fat_g": fat, "energy_kcal": E, "male": male, "age": age, "pa": pa})
    m1 = sm.OLS(y, sm.add_constant(df[["fat_g", "energy_kcal", "male", "age", "pa"]])).fit()
    out = EnergyAdjuster("residual", "energy_kcal", ["fat_g"]).fit_transform(df)
    m2 = sm.OLS(y, sm.add_constant(out)).fit()
    res["std"].append(m1.params["fat_g"]); res["app"].append(m2.params["fat_g_adj"])
    lo, hi = m1.conf_int().loc["fat_g"]; res["cov_std"] += lo <= 0.02 <= hi
    lo, hi = m2.conf_int().loc["fat_g_adj"]; res["cov_app"] += lo <= 0.02 <= hi
print("columns:", list(out.columns))
print("standard  mean b %.4f  95%% CI coverage %.2f" % (np.mean(res["std"]), res["cov_std"] / R))
print("app resid mean b %.4f  95%% CI coverage %.2f" % (np.mean(res["app"]), res["cov_app"] / R))
