import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.methods.energy import EnergyAdjuster
rng = np.random.default_rng(77); n = 4000
E = np.exp(rng.normal(np.log(2000), 0.3, n))
age = rng.uniform(20, 80, n) + 0.004 * (E - 2000)       # covariate correlated with E
fat = np.clip(rng.normal(0.34, 0.06, n), 0.1, 0.6) * E / 9 + 0.1 * age
y = 0.02 * fat + 0.004 * E + 0.05 * age + rng.normal(0, 2, n)
df = pd.DataFrame({"fat_g": fat, "energy_kcal": E, "age": age})
st = EnergyAdjuster("residual", "energy_kcal", ["fat_g"]).fit(df)
out = st.transform(df)
print("app output columns:", list(out.columns), "dropped:", st.dropped_columns_)
def fit(X, col):
    m = sm.OLS(y, sm.add_constant(X)).fit(); return m.params[col], m.bse[col], m.pvalues[col]
for name, X, col in [("standard Y~N+E+C", df[["fat_g", "energy_kcal", "age"]], "fat_g"),
                     ("app residual Y~Nadj+C", out[["fat_g_adj", "age"]], "fat_g_adj"),
                     ("residual + E kept", pd.concat([out[["fat_g_adj", "age"]], df.energy_kcal], axis=1), "fat_g_adj"),
                     ("standard no C Y~N+E", df[["fat_g", "energy_kcal"]], "fat_g"),
                     ("residual no C Y~Nadj", out[["fat_g_adj"]], "fat_g_adj")]:
    b, se, p = fit(X, col); print(f"{name:24s} b={b:.5f} se={se:.5f} p={p:.2e}")
