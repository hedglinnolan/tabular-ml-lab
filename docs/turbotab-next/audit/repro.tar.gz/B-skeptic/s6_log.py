import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.methods.energy import EnergyAdjuster, METHOD_TABLE
rng = np.random.default_rng(5); n = 5000
E = np.exp(rng.normal(np.log(2000), 0.3, n))
fat = np.exp(np.log(0.34 * E / 9) + rng.normal(0, 0.18, n))
age = rng.uniform(20, 80, n)
y = 0.02 * fat - 0.002 * E + 0.03 * age + rng.normal(0, 2, n)   # linear truth
df = pd.DataFrame({"fat_g": fat, "energy_kcal": E, "age": age})
a = EnergyAdjuster("residual", "energy_kcal", ["fat_g"], log_transform=True).fit(df)
out = a.transform(df)
b = a.params_["fat_g"]["slope"]; gm = a.params_["fat_g"]["reference_energy"]
print("log-log slope b = %.3f, GM = %.0f, mean E = %.0f" % (b, gm, E.mean()))
print("max |N_adj - N*(E/GM)^-b| =", np.max(np.abs(out.fat_g_adj - fat * (E / gm) ** (-b))))
print("corr(N_adj, N/E) = %.5f" % np.corrcoef(out.fat_g_adj, fat / E)[0, 1])
m_log = sm.OLS(y, sm.add_constant(out[["fat_g_adj", "age"]])).fit()
m_std = sm.OLS(y, sm.add_constant(df[["fat_g", "energy_kcal", "age"]])).fit()
m_den = sm.OLS(y, sm.add_constant(pd.DataFrame({"d": gm * fat / E, "age": age}))).fit()
lin = EnergyAdjuster("residual", "energy_kcal", ["fat_g"]).fit_transform(df)
m_lin = sm.OLS(y, sm.add_constant(lin[["fat_g_adj", "age"]])).fit()
print("standard b(fat)=%.4f se %.4f | linear residual b=%.4f se %.4f | log residual b=%.4f se %.4f | GM*density b=%.4f" % (
    m_std.params["fat_g"], m_std.bse["fat_g"], m_lin.params["fat_g_adj"], m_lin.bse["fat_g_adj"],
    m_log.params["fat_g_adj"], m_log.bse["fat_g_adj"], m_den.params["d"]))
print("estimand under log:", a.estimand()[:80])
