"""Skeptic B3: several energy-bearing exposures through the app's design path (grams)."""
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.decisions import ProjectState, EnergyAdjustment, MissingSpec
from turbotab.core.models.pipeline import design_spec, shared_steps, transformer, model_predictors
from turbotab.core.methods.energy import METHOD_TABLE
from turbotab.core.stages.proposals import nutrient_candidates
rng = np.random.default_rng(99); n = 20000
E = np.exp(rng.normal(np.log(2100), 0.3, n))
sh = rng.dirichlet([33, 47, 16, 4], n)  # fat, carb, protein, alcohol energy shares
kf, kc, kp, ka = (sh * E[:, None]).T
# per-kcal effects: fat 0.004, carb 0.001, protein 0.006, alcohol 0.0
y = 0.004 * kf + 0.001 * kc + 0.006 * kp + 0.0 * ka + rng.normal(0, 1, n)
df = pd.DataFrame({"fat_g": kf / 9, "carbohydrate_g": kc / 4, "protein_g": kp / 4, "energy_kcal": E})
roles = {"fat_g": "exposure", "carbohydrate_g": "exposure", "protein_g": "exposure", "energy_kcal": "energy"}
cols = {c: {"dtype": "float"} for c in df.columns}
print("nutrient_candidates:", nutrient_candidates({c: {"dtype": "float", "n_unique": n} for c in df.columns}, roles, energy="energy_kcal", target="y"))
w = np.array([kc.mean(), kp.mean(), ka.mean()]); w /= w.sum()
avg_other = w @ np.array([0.001, 0.006, 0.0])
print("truth per kcal: fat - avg(all others) = %.5f ; fat - alcohol (omitted) = %.5f" % (0.004 - avg_other, 0.004))
for method in ("standard", "residual"):
    st = ProjectState(target="y", task="regression", purpose="inference", roles=roles,
                      energy_adjustment=EnergyAdjustment(method=method, energy_column="energy_kcal",
                                                         nutrients=["fat_g", "carbohydrate_g", "protein_g"]),
                      missing=MissingSpec(strategy="complete_case"))
    spec = design_spec(st, df, model_predictors(st))
    X = transformer(shared_steps(spec)).fit_transform(df[spec.inputs])
    m = sm.OLS(y, sm.add_constant(X)).fit()
    f = [c for c in X.columns if c.startswith("fat")][0]
    print(method, list(X.columns), "b(fat) per kcal = %.5f" % (m.params[f] / 9))
    print("   label:", METHOD_TABLE[method]["estimand"])
one = sm.OLS(y, sm.add_constant(df[["fat_g", "energy_kcal"]])).fit().params["fat_g"] / 9
print("standard with fat alone + E: b per kcal = %.5f" % one)
