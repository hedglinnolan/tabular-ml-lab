"""Skeptic B1: stratified residual with drop_strata; independent fixture (different seed, design)."""
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.models.steps import energy_step
from turbotab.core.decisions import EnergyAdjustment

rng = np.random.default_rng(12345)
n = 3000
male = rng.integers(0, 2, n)
E = rng.normal(1800 + 450 * male, 350, n).clip(600)
fat_share = rng.normal(0.33, 0.05, n).clip(0.1, 0.6)
fat_g = fat_share * E / 9
age = rng.uniform(20, 80, n)
# outcome: sex effect + age effect; fat (at fixed energy) has NO effect; energy NO effect
y = 5.0 * male + 0.05 * age + rng.normal(0, 3, n)
df = pd.DataFrame({"fat_g": fat_g, "energy_kcal": E, "age": age, "sex": np.where(male, "M", "F")})
adj = EnergyAdjustment(method="residual", energy_column="energy_kcal", nutrients=["fat_g"], strata="sex")
for preds in (["fat_g", "energy_kcal", "age"], ["fat_g", "energy_kcal", "age", "sex"]):
    step = energy_step(adj, predictors=preds)
    out = step.fit_transform(df[[c for c in df.columns]])
    X = out.drop(columns=[c for c in out.columns if c == "sex"])
    if "sex" in out.columns:
        X = X.assign(male=(out["sex"] == "M").astype(float))
    m = sm.OLS(y, sm.add_constant(X)).fit()
    print("predictors", preds, "drop_strata", step.drop_strata, "cols", list(out.columns))
    print("   b(fat_g_adj) = %.4f  se %.4f  p = %.2e" % (m.params["fat_g_adj"], m.bse["fat_g_adj"], m.pvalues["fat_g_adj"]))
    print("   r(fat_adj, male) = %.3f, r(fat_adj,E) = %.3f" % (np.corrcoef(out.fat_g_adj, male)[0,1], np.corrcoef(out.fat_g_adj, E)[0,1]))
    for lvl, a in step.by_level_.items():
        p = a.params_["fat_g"]; print("   level", lvl, "r_after %.1e const_added %.2f refE %.0f" % (p["r_after"], p["constant_added"], p["reference_energy"]))
# standard model without sex
m = sm.OLS(y, sm.add_constant(df[["fat_g", "energy_kcal", "age"]])).fit()
print("standard (no sex): b(fat_g) = %.4f p = %.2f" % (m.params["fat_g"], m.pvalues["fat_g"]))
