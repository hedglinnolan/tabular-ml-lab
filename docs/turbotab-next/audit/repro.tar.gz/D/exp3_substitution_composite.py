"""D-audit experiment 3: the app's substitution curve (carb -> protein, 100 kcal) through the app's
own pipelines, when the model holds only some energy sources versus all of them.

Truth (per kcal): protein 0.010, carb 0.004, fat 0.000, alcohol 0.020. Direct substitution of
100 kcal carb -> protein = 100*(0.010-0.004) = 0.60. Alcohol and fat intake are correlated with
the protein/carb mix (as in real diets), so omitted components bias a model that leaves them in a
composite."""
import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np
import pandas as pd

from turbotab.core.decisions import EnergyAdjustment, ProjectState
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import design_spec, build_pipeline, model_predictors
from turbotab.core.methods.substitution import substitution_curve

rng = np.random.default_rng(3)
n = 20000
z = rng.normal(0, 1, (n, 4))
# shared "lifestyle" factor: more alcohol & fat go with more protein, less carb
L = rng.normal(0, 1, n)
kp = 330 + 60 * z[:, 0] + 40 * L
kc = 1000 + 200 * z[:, 1] - 80 * L
kf = 750 + 150 * z[:, 2] + 70 * L
ka = np.clip(80 + 60 * z[:, 3] + 50 * L, 0, None)
kcal = kp + kc + kf + ka
y = 0.010 * kp + 0.004 * kc + 0.0 * kf + 0.020 * ka + rng.normal(0, 3, n)
df = pd.DataFrame({"protein_g": kp / 4, "carb_g": kc / 4, "fat_g": kf / 9, "alcohol_g": ka / 7,
                   "kcal": kcal, "y": y})
TRUE = 100 * (0.010 - 0.004)
fam = get_family("linear")


def curve(exposures, method):
    roles = {e: "exposure" for e in exposures}
    roles["kcal"] = "energy"
    adj = EnergyAdjustment(method=method, energy_column="kcal",
                           nutrients=exposures if method != "none" else [])
    state = ProjectState(target="y", roles=roles, energy_adjustment=adj, purpose="inference")
    preds = model_predictors(state)
    X = df[[c for c in df.columns if c != "y"]]
    spec = design_spec(state, X, preds)
    pipe = build_pipeline(spec, fam, "regression", "inference", n, len(preds))
    pipe.fit(X[spec.inputs], df["y"])
    out = substitution_curve(pipe.predict, X[spec.inputs], donor="carb_g", recipient="protein_g",
                             kcal_per_unit={"carb_g": 4.0, "protein_g": 4.0}, ks=[0, 100])
    return out["delta"][1]


print(f"TRUE direct substitution, 100 kcal carb->protein: {TRUE:.3f}\n")
for exposures in (["protein_g", "carb_g"], ["protein_g", "carb_g", "fat_g", "alcohol_g"]):
    for method in ("none", "standard", "residual", "partition", "density_multivariate"):
        try:
            d = curve(exposures, method)
            print(f"exposures={exposures!s:45} method={method:22} curve(100)={d:+.3f}  "
                  f"bias={d - TRUE:+.3f}")
        except Exception as err:  # noqa: BLE001
            print(f"exposures={exposures!s:45} method={method:22} ERROR {err}")
