"""D-audit experiment 1: what each energy-adjustment option actually puts in the model matrix,
and what the nutrient coefficient is, against a simulated truth with known causal effects.

Truth (linear, kcal units): Y = 0.010*kcal_protein + 0.004*kcal_carb + 0.000*kcal_fat + 2*age_z + noise
Energy E = kcal_protein + kcal_carb + kcal_fat (+ small other); age correlates with E.
"""
import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np
import pandas as pd
import statsmodels.api as sm

from turbotab.core.decisions import EnergyAdjustment, ProjectState
from turbotab.core.models.pipeline import design_spec, shared_steps, transformer, model_predictors

rng = np.random.default_rng(1)
n = 20000
age = rng.normal(50, 15, n)
size = rng.normal(0, 1, n) - 0.03 * (age - 50)          # older people eat less
E_base = 2100 + 450 * size
share_p = np.clip(rng.normal(0.16, 0.03, n), 0.05, 0.4)
share_f = np.clip(rng.normal(0.34, 0.05, n), 0.1, 0.6)
share_c = 1 - share_p - share_f
kp, kf, kc = E_base * share_p, E_base * share_f, E_base * share_c
protein_g, fat_g, carb_g = kp / 4, kf / 9, kc / 4
kcal = kp + kf + kc
y = 0.010 * kp + 0.004 * kc + 0.0 * kf + 0.2 * (age - 50) + rng.normal(0, 5, n)
df = pd.DataFrame({"protein_g": protein_g, "carb_g": carb_g, "fat_g": fat_g, "kcal": kcal,
                   "age": age, "y": y})

print("corr(age, kcal) =", round(np.corrcoef(age, kcal)[0, 1], 3))
roles = {"protein_g": "exposure", "kcal": "energy", "age": "covariate"}
for method in ["none", "standard", "residual", "density_multivariate", "density", "partition"]:
    adj = None if method == "none" else EnergyAdjustment(method=method, energy_column="kcal",
                                                          nutrients=["protein_g"])
    state = ProjectState(target="y", roles=roles, energy_adjustment=adj)
    if method == "none":
        state = ProjectState(target="y", roles=roles,
                             energy_adjustment=EnergyAdjustment(method="none"))
    preds = model_predictors(state)
    spec = design_spec(state, df[[c for c in df.columns if c != "y"]], preds)
    steps = shared_steps(spec)
    M = transformer(steps).fit_transform(df[spec.inputs])
    fit = sm.OLS(df["y"], sm.add_constant(M)).fit()
    coefs = {k: round(v, 5) for k, v in fit.params.items() if k != "const"}
    ses = {k: round(v, 5) for k, v in fit.bse.items() if k != "const"}
    print(f"\n[{method}] matrix columns: {list(M.columns)}")
    print("   coef:", coefs)
    print("   se:  ", ses)

# Truths on the gram scale
print("\nTRUTH per gram protein:")
print("  total causal effect (add 1 g protein = +4 kcal, others fixed): ", 4 * 0.010)
w_c = np.mean(kc / (kc + kf)); w_f = 1 - w_c
print("  average relative causal effect (1 g protein replacing avg of carb+fat at fixed E): ",
      round(4 * (0.010 - (w_c * 0.004 + w_f * 0.0)), 5), f"(weights carb {w_c:.3f}, fat {w_f:.3f})")
print("  replacing carb only: ", 4 * (0.010 - 0.004), "  replacing fat only:", 4 * (0.010 - 0.0))

# All-components model (Tomova 2022): Y ~ kcal_p + kcal_c + kcal_f + age
X = pd.DataFrame({"kp": kp, "kc": kc, "kf": kf, "age": age})
ac = sm.OLS(y, sm.add_constant(X)).fit()
b = ac.params
arce = 4 * (b["kp"] - (w_c * b["kc"] + w_f * b["kf"]))
print("\nall-components model coefs (per kcal):", {k: round(v, 5) for k, v in b.items()})
print("  all-components ARCE per g protein:", round(arce, 5))
