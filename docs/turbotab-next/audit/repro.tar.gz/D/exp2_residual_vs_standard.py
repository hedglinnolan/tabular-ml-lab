"""D-audit experiment 2: the app's residual method (energy dropped from the outcome model) versus
the standard model, when a covariate (sex) drives both total energy and diet composition, and E
itself affects the outcome. Linear and logistic. Uses the app's own EnergyAdjuster."""
import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np
import pandas as pd
import statsmodels.api as sm
from turbotab.core.methods.energy import EnergyAdjuster

rng = np.random.default_rng(7)
n = 50000
male = rng.integers(0, 2, n)
E = 1800 + 500 * male + rng.normal(0, 400, n)                 # men eat more
prot_share = 0.15 + 0.03 * male + rng.normal(0, 0.03, n)      # men eat a higher protein share
protein_g = prot_share * E / 4
lin = 0.02 * protein_g + 0.004 * E + 3.0 * male
y = lin + rng.normal(0, 5, n)
p = 1 / (1 + np.exp(-(-12 + 0.02 * protein_g + 0.004 * E + 1.0 * male)))
yb = (rng.random(n) < p).astype(int)
df = pd.DataFrame({"protein_g": protein_g, "kcal": E, "male": male})

adj = EnergyAdjuster("residual", "kcal", ["protein_g"]).fit(df)
res = adj.transform(df)
print("app residual output columns:", list(res.columns))

std_X = sm.add_constant(df[["protein_g", "kcal", "male"]])
res_X = sm.add_constant(res[["protein_g_adj", "male"]])
res_E_X = sm.add_constant(pd.concat([res[["protein_g_adj", "male"]], df[["kcal"]]], axis=1))
for label, fam, yy in (("linear", sm.OLS, y), ("logistic", sm.Logit, yb)):
    kw = {"disp": 0} if fam is sm.Logit else {}
    s = fam(yy, std_X).fit(**kw)
    r = fam(yy, res_X).fit(**kw)
    re = fam(yy, res_E_X).fit(**kw)
    print(f"\n{label}:")
    print(f"  standard  Y~N+E+C : b_N = {s.params['protein_g']:.5f} (se {s.bse['protein_g']:.5f})")
    print(f"  app residual Y~N_adj+C (E dropped): b_N = {r.params['protein_g_adj']:.5f} "
          f"(se {r.bse['protein_g_adj']:.5f})")
    print(f"  Willett residual + E  Y~N_adj+E+C : b_N = {re.params['protein_g_adj']:.5f} "
          f"(se {re.bse['protein_g_adj']:.5f})")
