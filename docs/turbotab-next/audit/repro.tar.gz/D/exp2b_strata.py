"""exp2b: does the app's within-sex residual (StratifiedEnergyAdjuster) rescue the E-dropped residual?
Covariates: male and age; age lowers E within sex and affects Y."""
import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.models.steps import StratifiedEnergyAdjuster
from turbotab.core.methods.energy import EnergyAdjuster
rng = np.random.default_rng(8); n = 50000
male = rng.integers(0, 2, n); age = rng.normal(50, 15, n)
E = 1800 + 500*male - 10*(age-50) + rng.normal(0, 350, n)
protein_g = (0.15 + 0.03*male + 0.0008*(age-50) + rng.normal(0, 0.03, n)) * E / 4
y = 0.02*protein_g + 0.004*E + 3*male + 0.1*age + rng.normal(0, 5, n)
df = pd.DataFrame({"protein_g": protein_g, "kcal": E, "male": male.astype(str), "age": age})
std = sm.OLS(y, sm.add_constant(pd.DataFrame({"p": protein_g, "E": E, "m": male, "a": age}))).fit()
pooled = EnergyAdjuster("residual", "kcal", ["protein_g"]).fit(df).transform(df)
strat = StratifiedEnergyAdjuster("kcal", ["protein_g"], strata="male").fit(df).transform(df)
for name, adj in (("pooled residual, E dropped", pooled), ("within-sex residual, E dropped", strat)):
    X = sm.add_constant(pd.DataFrame({"p_adj": adj["protein_g_adj"], "m": male, "a": age}))
    f = sm.OLS(y, X).fit()
    print(f"{name:32} b = {f.params['p_adj']:+.5f} (se {f.bse['p_adj']:.5f})")
print(f"{'standard Y~N+E+C':32} b = {std.params['p']:+.5f} (se {std.bse['p']:.5f})   true direct effect 0.02 per g")
