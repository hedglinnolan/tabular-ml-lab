"""D-audit experiment 4: for PREDICTION, what each energy option costs in cross-validated R^2 when
total energy itself predicts the outcome (e.g. energy ~ body size ~ outcome). App's own pipelines,
linear and boosted trees, 5-fold CV."""
import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np
import pandas as pd
from sklearn.model_selection import cross_val_score, KFold

from turbotab.core.decisions import EnergyAdjustment, ProjectState
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import design_spec, build_pipeline, model_predictors

rng = np.random.default_rng(11)
n = 4000
male = rng.integers(0, 2, n)
E = 1800 + 500 * male + rng.normal(0, 400, n)
protein_g = (0.15 + 0.03 * male + rng.normal(0, 0.03, n)) * E / 4
fat_g = (0.33 + rng.normal(0, 0.05, n)) * E / 9
y = 0.02 * protein_g + 0.004 * E + 3.0 * male + rng.normal(0, 3, n)
df = pd.DataFrame({"protein_g": protein_g, "fat_g": fat_g, "kcal": E,
                   "sex": np.where(male == 1, "male", "female"), "y": y})
X = df.drop(columns="y")
cv = KFold(5, shuffle=True, random_state=0)
for key in ("linear", "boosted_trees"):
    fam = get_family(key)
    for method in ("none", "standard", "residual", "density_multivariate", "density", "partition"):
        roles = {"protein_g": "exposure", "fat_g": "exposure", "kcal": "energy", "sex": "covariate"}
        adj = EnergyAdjustment(method=method, energy_column="kcal",
                               nutrients=["protein_g", "fat_g"] if method != "none" else [])
        state = ProjectState(target="y", roles=roles, energy_adjustment=adj, purpose="prediction")
        spec = design_spec(state, X, model_predictors(state))
        pipe = build_pipeline(spec, fam, "regression", "prediction", n, 4)
        r2 = cross_val_score(pipe, X[spec.inputs], df["y"], cv=cv, scoring="r2")
        print(f"{key:14} {method:22} CV R^2 = {r2.mean():.3f}")
