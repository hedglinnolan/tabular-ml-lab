import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
F = Path("/private/tmp/turbotab-audit/C/f")
rng = np.random.default_rng(0)
n = 500
kcal = rng.normal(2000, 400, n).round(); kcal[7] = 0
protein = rng.normal(80, 20, n).round(1)
df = pd.DataFrame({"SEQN": np.arange(n), "kcal": kcal, "protein_g": protein, "ldl": rng.normal(120, 30, n).round(1)})
df["protein_per_1000kcal"] = df["protein_g"] / df["kcal"] * 1000   # one division by zero -> inf
src = F / "ratio.csv"; df.to_csv(src, index=False)   # pandas writes "inf"
print(open(src).read().splitlines()[8])
run = GraphRun(src, F / "proj_ratio")
print([(c["name"], c["physical_type"]) for c in run.info["columns"]])
try:
    out = run.run(ProjectState.model_validate({}), upto=["profile"])
    print("profile ok", "profile" in out)
except Exception as e:
    print("profile stage FAILED:", type(e).__name__, str(e)[:120])
# R-style tokens
p2 = F / "rinf.csv"; p2.write_text("id,x\n1,1.5\n2,Inf\n3,-Inf\n4,2.5\n")
from turbotab.core.datastore import ingest
info = ingest(p2, F / "rinf.parquet"); print("R Inf ->", info.columns[1].physical_type)
run.close()
