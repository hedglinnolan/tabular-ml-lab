import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab.core.consequences import _corr_block, _pair_r
rng = np.random.default_rng(0)
n = 5000
kcal = rng.normal(2000, 500, n)
protein = 0.04 * kcal + rng.normal(0, 14, n)
for miss in (0.0, 0.2, 0.4):
    p = protein.copy(); p[rng.random(n) < miss] = np.nan
    frame = pd.DataFrame({"protein_g": p})
    r_block = _corr_block(frame, kcal[:, None], ["protein_g"])[0, 0]
    print(f"missing {miss:.0%}: _corr_block r = {r_block:.3f}   pairwise-complete r = {_pair_r(p, kcal):.3f}")
