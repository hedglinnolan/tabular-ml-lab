import sys, json
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd
from turbotab.core.datastore import DataStore
from turbotab.core.stages.rows import draw_split, _level_key
F = Path("/private/tmp/turbotab-audit/C/f")
s = DataStore(F / "inf.csv.parquet", 1 << 30)
# _level_key merges distinct identifiers
print("level keys:", [_level_key(v) for v in ["007", "7", "7.0", "1e3", "1000", "0x10"]])
ids = np.arange(6)
frame, info = draw_split(ids, holdout=0.5, seed=0, folds=2, groups=["007", "7", "07", "A", "B", "C"], grouped_by="pid")
print(frame.assign(pid=["007", "7", "07", "A", "B", "C"]).to_string(), "\nn_groups", info["n_groups"])
# big ints through window/json
s2 = DataStore(F / "bigint.csv.parquet", 1 << 30)
print("window:", s2.window(0, 3)["rows"])
