import sys, math
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
from fractions import Fraction
import numpy as np, pandas as pd, pyarrow as pa, pyarrow.parquet as pq
from turbotab.core.datastore import ingest, DataStore
F = Path("/private/tmp/turbotab-audit/C/f")
rng = np.random.default_rng(7)
n = 20000
cols = {
 "offset": 1e9 + rng.normal(0, 1e-3, n),          # std accuracy under large offset
 "cancel": np.tile([1e16, 1.0, -1e16, 3.0], n // 4),  # mean cancellation
 "tiny": rng.normal(0, 1e-300, n),
 "big_int": (2**62 - rng.integers(0, 1000, n)).astype(np.int64),
 "neg_int": rng.integers(-10**12, 10**12, n),
 "f32": rng.normal(100, 10, n).astype(np.float32),
 "heavy": np.exp(rng.normal(0, 5, n)),
}
t = pa.table(cols)
p = F / "extreme.parquet"; pq.write_table(t, p)
info = ingest(p, F / "extreme.ingested.parquet")
store = DataStore(F / "extreme.ingested.parquet", 4 << 30)
names = list(cols)
a = store._summaries_arrow(names)
d = store._summaries_duckdb(names)
def exact(vals):
    fr = [Fraction(float(v)) if not isinstance(v, (int, np.integer)) else Fraction(int(v)) for v in vals]
    m = sum(fr) / len(fr)
    var = sum((x - m) ** 2 for x in fr) / (len(fr) - 1)
    return float(m), math.sqrt(float(var))
for c in names:
    m, s = exact(cols[c].tolist())
    print(c, "| exact mean %.17g std %.17g" % (m, s))
    print("   arrow  mean %r std %r q %r %r %r" % (a[c]["mean"], a[c]["std"], a[c]["q25"], a[c]["median"], a[c]["q75"]))
    print("   duckdb mean %r std %r q %r %r %r" % (d[c]["mean"], d[c]["std"], d[c]["q25"], d[c]["median"], d[c]["q75"]))
    print("   min/max a", a[c]["min"], a[c]["max"], " d", d[c]["min"], d[c]["max"])
