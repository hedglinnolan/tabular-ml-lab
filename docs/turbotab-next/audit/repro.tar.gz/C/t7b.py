import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
F = Path("/private/tmp/turbotab-audit/C/f")
rng = np.random.default_rng(5)
nf, ns = 60, 12
feat = pd.DataFrame({"metabolite": [f"M{i}" for i in range(nf)],
                     
                     "mz": np.round(rng.uniform(80, 900, nf), 4),
                     "rt": np.round(rng.uniform(0.5, 15, nf), 2)})
abund = np.exp(rng.normal(np.linspace(5, 15, nf)[:, None], 0.3, (nf, ns)))
for j in range(ns): feat[f"S{j+1}"] = np.round(abund[:, j], 2)
src = F / "met_T2.csv"; feat.to_csv(src, index=False)
run = GraphRun(src, F / "proj_met2")
out = run.run(ProjectState.model_validate(dict(lens=["metabolomics"], orientation="feature_major")), upto=["oriented"])
o = out["oriented"]
print("reading", o.data["reading"]["reading"], "turn", {k: o.data["turn"][k] for k in ("label_column", "n_samples", "refusal")})
t = pd.read_parquet(o.files["table.parquet"])
print("shape", t.shape)
print(t.iloc[:, :6].to_string())
print("dtypes of feature columns:", t.dtypes.iloc[1:-1].value_counts().to_dict())
run.close()
