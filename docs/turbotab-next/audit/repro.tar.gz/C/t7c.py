import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
F = Path("/private/tmp/turbotab-audit/C/f")
rng = np.random.default_rng(5)
ng, ns = 80, 10
g = pd.DataFrame({"entrez_id": rng.choice(np.arange(1, 100000), ng, replace=False)})
for j in range(ns): g[f"GSM{1000+j}"] = rng.poisson(np.exp(rng.normal(5, 2, ng)))
src = F / "expr_entrez.csv"; g.to_csv(src, index=False)
run = GraphRun(src, F / "proj_entrez")
out = run.run(ProjectState.model_validate(dict(lens=["genomics"], orientation="feature_major")), upto=["oriented"])
o = out["oriented"]
print("turn:", {k: o.data["turn"][k] for k in ("label_column", "n_samples", "refusal")})
t = pd.read_parquet(o.files["table.parquet"])
print("shape", t.shape, "columns", list(t.columns[:4]), "...")
print(t.iloc[:3, :4].to_string())
run.close()
