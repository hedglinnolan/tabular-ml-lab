import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
from turbotab.core.datastore import ingest
F = Path("/private/tmp/turbotab-audit/C/f")
cases = {
 "pad.csv": "id,x\n1, 12.5\n2,13.1 \n3,  9\n",
 "thousands.csv": 'id,kcal\n1,"1,234"\n2,"2,045"\n3,980\n',
 "excelerr.csv": "id,ratio\n1,0.5\n2,#DIV/0!\n3,0.7\n",
 "lod.csv": "id,crp\n1,0.5\n2,<0.2\n3,1.7\n",
}
for name, text in cases.items():
    (F / name).write_text(text)
    info = ingest(F / name, F / (name + ".parquet"))
    c = info.columns[1]
    print(name, c.dtype, c.physical_type, c.sample, info.warnings)
