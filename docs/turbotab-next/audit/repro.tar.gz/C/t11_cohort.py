import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab.core.stages.rows import cohort_flow
from turbotab.core.decisions import ExclusionRule
rng = np.random.default_rng(0)
n = 1000
age = rng.integers(10, 90, n).astype(float); age[rng.random(n) < 0.2] = np.nan
kcal = rng.normal(2000, 600, n); kcal[rng.random(n) < 0.1] = np.nan; kcal[:30] = 9000
f = pd.DataFrame({"y": rng.normal(size=n), "age": age, "kcal": kcal}, index=np.arange(n))
rules = [ExclusionRule.model_validate({"column": "age", "low": 20, "high": 80, "reason": "adults 20-80"}),
         ExclusionRule.model_validate({"column": "kcal", "low": 500, "high": 5000, "reason": "implausible energy"})]
steps, kept = cohort_flow(f, target="y", rules=rules, missing=None, predictor_columns=[])
for s in steps: print(s["key"], "|", s["label"], "| n =", s["n"], "dropped", s["dropped"])
k = f.loc[kept]
print("kept rows with missing age:", int(k["age"].isna().sum()), "missing kcal:", int(k["kcal"].isna().sum()))
