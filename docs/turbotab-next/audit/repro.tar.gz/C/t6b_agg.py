import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import pandas as pd
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
F = Path("/private/tmp/turbotab-audit/C/f")
rows = [
 ("A", "2021-01-05", 90.0, 150.0), ("A", "2021-02-02", 85.0, 145.0), ("A", "",  70.0, 999.0),  # undated record
 ("B", "2021-01-09", 70.0, 120.0), ("B", "2021-03-07", 66.0, 118.0),
]
df = pd.DataFrame(rows, columns=["pid", "visit_date", "weight_kg", "sbp"])
src = F / "visits_iso.csv"; df.to_csv(src, index=False)
run = GraphRun(src, F / "proj_iso")
print([(c["name"], c["physical_type"]) for c in run.info["columns"]])
for method in ("last", "change"):
    st = ProjectState.model_validate(dict(lens=["clinical"], target="sbp",
        grain={"grain": "repeated", "id_column": "pid"}, unit="unit",
        repeat_kind={"repeat_kind": "time_points", "time_column": "visit_date"},
        aggregation={"method": method, "outcome": "last"}))
    out = run.run(st, upto=["working"])
    w = out["working"]; t = pd.read_parquet(w.files["table.parquet"])
    print("== method", method, "ordered_by", w.data["aggregation"]["ordered_by"], "single", w.data["aggregation"]["single_record_units"])
    print(t.to_string())
    print("receipt keys:", sorted(w.data["aggregation"]))
run.close()
