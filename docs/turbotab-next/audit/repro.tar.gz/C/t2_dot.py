import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd
from turbotab.core.datastore import ingest, DataStore
F = Path("/private/tmp/turbotab-audit/C/f")
rng = np.random.default_rng(1)
n = 3000
age = rng.integers(20, 80, n).astype(object)
kcal = np.round(rng.normal(2100, 500, n)).astype(object)
bmi = np.round(rng.normal(27, 5, n), 1).astype(object)
for a in (age, kcal, bmi):
    a[rng.random(n) < 0.03] = "."
df = pd.DataFrame({"SEQN": np.arange(n), "age": age, "kcal": kcal, "bmi": bmi, "glucose": np.round(rng.normal(100, 15, n), 1)})
p = F / "sas_dot.csv"; df.to_csv(p, index=False)
info = ingest(p, F / "sas_dot.parquet")
for c in info.columns: print(c.name, c.dtype, c.physical_type, c.n_unique, c.n_missing)
print("warnings", info.warnings)
from turbotab import engine
store = DataStore(F / "sas_dot.parquet", 4 << 30)
frame = store.materialize().reset_index(drop=True)
fs = [engine.shape_finding_to_dict(f) for f in engine.diagnose(frame, "glucose")]
for f in fs: print("FINDING", f.get("id"), "|", (f.get("title") or "")[:80], "| fix:", f.get("fix") or f.get("auto_fix"))
from turbotab.core import repairs
from turbotab.core.stages.rows import propose_roles
props = propose_roles(store.summaries(), lens=["dietary"], target="glucose", n_rows=n)
for p_ in props: print("ROLE", p_["column"], p_["proposed"], p_["reason"])
