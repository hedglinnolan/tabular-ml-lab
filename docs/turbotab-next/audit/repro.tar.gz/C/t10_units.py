import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np
from turbotab.core.units import outcome_unit
rng = np.random.default_rng(0)
cases = [
 ("gestational_age", rng.normal(39, 1.5, 500), "weeks"),
 ("birth_weight", rng.normal(3300, 450, 500), "g"),
 ("dietary_choline", rng.lognormal(np.log(300), 0.3, 500), "mg/day"),
 ("dietary_cholesterol", rng.lognormal(np.log(250), 0.4, 500), "mg/day"),
 ("glucosinolate_intake", rng.lognormal(np.log(15), 0.5, 500), "mg/day"),
 ("urine_creatinine", rng.lognormal(np.log(120), 0.4, 500), "mg/dL"),
 ("creatine_kinase", rng.lognormal(np.log(110), 0.4, 500), "U/L"),
 ("recreational_activity_min", rng.lognormal(np.log(60), 0.5, 500), "min/week"),
 ("telomere_length_bp", rng.normal(6500, 800, 500), "bp"),
 ("sleep_hr", rng.normal(7, 1, 500), "hours"),
 ("height", rng.normal(88, 4, 500), "cm (toddlers)"),
 ("weight", rng.normal(125, 18, 500), "kg (bariatric cohort)"),
 ("weight", rng.normal(45, 8, 500), "lb (children)"),
 ("hba1c_mmol", rng.normal(40, 6, 500), "mmol/mol"),
 ("hdl_mg", rng.normal(50, 12, 500), "mg/dL"),
]
for name, v, truth in cases:
    print(f"{name:28s} true={truth:24s} app={outcome_unit(name, v)}")
