import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
from types import SimpleNamespace
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
from turbotab.core import structure_previews as SP
from turbotab.core.consequences import PreviewContext
from turbotab.core.datastore import DataStore
F = Path("/private/tmp/turbotab-audit/C/f")
run = GraphRun(F / "expr_entrez.csv", F / "proj_entrez2")
out = run.run(ProjectState.model_validate(dict(lens=["genomics"])), upto=["oriented"])
o = out["oriented"]
ctx = PreviewContext(project_id="x", state=ProjectState.model_validate(dict(lens=["genomics"])),
                     datastore=DataStore(run.raw, 1 << 30), artifact=lambda s: o if s == "oriented" else None,
                     training_row_ids=None, cohort_row_ids=None)
views = SP.orientation_views(SimpleNamespace(orientation="feature_major"), ctx)
v = views[0]
print("preview caption:", v.caption)
print("preview turned columns:", v.story[1].columns[:5])
print("preview turned sample ids:", [r.values["sample_id"] for r in v.story[1].rows][:4])
run.close()
