import sys, time
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd, pyarrow as pa, pyarrow.parquet as pq
from turbotab.core.datastore import ingest, DataStore
F = Path("/private/tmp/turbotab-audit/C/f")
rng = np.random.default_rng(0)
n, p = 250_000, 100
cols = {f"c{i}": rng.normal(size=n) for i in range(p)}
cols["s"] = pa.array(rng.choice(["a", "b", None], n))
cols["i"] = rng.integers(0, 10**12, n)
pq.write_table(pa.table(cols), F / "wide.parquet")
t0 = time.time(); ingest(F / "wide.parquet", F / "wide.ing.parquet"); print("ingest s", round(time.time()-t0, 1))
s = DataStore(F / "wide.ing.parquet", 8 << 30)
md, bounds = s._row_groups(); print("row groups", len(bounds), bounds[:3])
ids = rng.integers(0, n, 5000)          # unsorted with duplicates (a bootstrap draw)
ids[:3] = [n-1, 0, n-1]
want = ["c0", "c57", "s", "i"]
a = s._materialize_arrow(want, ids.astype(np.int64))
d = s._materialize_duckdb(want, ids.astype(np.int64))
print("index equal", np.array_equal(a.index.to_numpy(), ids), np.array_equal(d.index.to_numpy(), ids))
print("frames equal", a.equals(d), a.dtypes.to_dict(), d.dtypes.to_dict())
ref = pd.read_parquet(F / "wide.parquet", columns=want).iloc[ids]
print("values vs source", np.allclose(a["c57"].to_numpy(), ref["c57"].to_numpy()), (a["i"].to_numpy() == ref["i"].to_numpy()).all(),
      (a["s"].fillna("NA").to_numpy() == ref["s"].fillna("NA").to_numpy()).all())
# sample determinism + uniformity
smp = s.sample(5000, ["c0"], seed=0); smp2 = s.sample(5000, ["c0"], seed=0)
print("sample deterministic", smp.index.equals(smp2.index), "groups hit", np.bincount(np.searchsorted([b[0] for b in bounds], smp.index.to_numpy(), side="right")-1))
# window
w = s.window(98300, 10, ["c0", "i"]); print("window first ids ok", w["rows"][0][1] == int(cols["i"][98300]), len(w["rows"]))
