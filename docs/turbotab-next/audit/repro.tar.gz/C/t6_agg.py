import sys, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
F = Path("/private/tmp/turbotab-audit/C/f")

# Three participants with 3 visits each; visit dates written as US text with month names
# (TRY_CAST(... AS TIMESTAMP) cannot read them), rows NOT in chronological order in the file.
rows = [
 # pid, visit_date (text), visit_label, smoking (1=never,2=former,3=current), sex(1/2), weight_kg, sbp
 ("A", "Mar 3, 2021",  "week 12", 3, 1, 80.0, 140.0),
 ("A", "Jan 5, 2021",  "baseline", 3, 1, 90.0, 150.0),
 ("A", "Feb 2, 2021",  "week 4", 2, 1, 85.0, 145.0),
 ("B", "Jan 9, 2021",  "baseline", 1, 2, 70.0, 120.0),
 ("B", "",             "week 12", 1, 2, 66.0, 118.0),   # missing visit date
 ("B", "Feb 7, 2021",  "week 4", 1, 2, 68.0, 119.0),
 ("C", "Jan 1, 2021",  "baseline", 3, 2, 100.0, 160.0),
 ("C", "Feb 1, 2021",  "week 4", 1, 2, 95.0, 155.0),
 ("C", "Mar 1, 2021",  "week 12", 1, 2, 92.0, 150.0),
]
df = pd.DataFrame(rows, columns=["pid", "visit_date", "visit", "smoking", "sex", "weight_kg", "sbp"])
src = F / "visits.csv"; df.to_csv(src, index=False)
run = GraphRun(src, F / "proj_visits")
for c in run.info["columns"]: print(c["name"], c["dtype"], c["physical_type"])
for method in ("first", "last", "change", "mean"):
    st = ProjectState.model_validate(dict(lens=["clinical"], target="sbp",
        grain={"grain": "repeated", "id_column": "pid"}, unit="unit",
        repeat_kind={"repeat_kind": "time_points", "time_column": "visit_date"},
        aggregation={"method": method, "outcome": "last" if method != "mean" else "mean"}))
    out = run.run(st, upto=["working"])
    w = out["working"]
    t = pd.read_parquet(w.files["table.parquet"])
    print("\n== method", method, "receipt ordered_by:", w.data["aggregation"]["ordered_by"],
          "time_column:", w.data["aggregation"]["time_column"], "varying:", w.data["aggregation"]["varying"])
    print(t.to_string())
run.close()
