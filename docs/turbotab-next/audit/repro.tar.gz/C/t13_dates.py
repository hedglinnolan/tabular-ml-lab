import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd
from turbotab.core.datastore import ingest, DataStore
F = Path("/private/tmp/turbotab-audit/C/f")
rng = np.random.default_rng(0)
# US-style dates coarsened to the first of the month (a common de-identification), 3 years
months = pd.date_range("2019-01-01", "2021-12-01", freq="MS")
d = rng.choice(months, 2000)
df = pd.DataFrame({"pid": np.arange(2000), "visit_date": pd.to_datetime(d).strftime("%m/%d/%Y"), "y": rng.normal(size=2000)})
df.to_csv(F / "month_dates.csv", index=False)
info = ingest(F / "month_dates.csv", F / "month_dates.parquet")
c = info.columns[1]; print(c.name, c.physical_type, "warnings:", info.warnings)
s = DataStore(F / "month_dates.parquet", 1 << 30)
got = s.materialize(["visit_date"])["visit_date"]
truth = pd.to_datetime(df["visit_date"], format="%m/%d/%Y")
print("source text:", df["visit_date"].iloc[:4].tolist())
print("read as    :", got.iloc[:4].dt.strftime("%Y-%m-%d").tolist())
print("rows whose date changed:", int((got.to_numpy() != truth.to_numpy()).sum()), "of", len(df))
print("distinct months read:", sorted(got.dt.month.unique().tolist()), " distinct days read:", sorted(got.dt.day.unique().tolist()))
