import sys, time
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd, pyarrow.parquet as pq
from turbotab.core.datastore import ingest
F = Path("/private/tmp/turbotab-audit/C/f")
n = 1_500_000
rng = np.random.default_rng(2)
seq = np.arange(n)
# leading zeros appear only late in the file (beyond the sniff sample)
ids = np.array([str(i) for i in range(1000, 1000 + n)], dtype=object)
ids[-5] = "0012345"
df = pd.DataFrame({"seq": seq, "pid": ids, "x": rng.normal(size=n).round(3)})
df.to_csv(F / "order.csv", index=False)
t0 = time.time(); info = ingest(F / "order.csv", F / "order.parquet"); print("ingest", round(time.time() - t0, 1), "s", info.warnings)
t = pq.read_table(F / "order.parquet", columns=["seq", "pid", "__row_id"]).to_pandas()
print("row_id == file order:", (t["seq"].to_numpy() == t["__row_id"].to_numpy()).all(), "pid dtype", t["pid"].dtype, "late value", t["pid"].iloc[-5])
