import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import pandas as pd
from turbotab.core.datastore import ingest
F = Path("/private/tmp/turbotab-audit/C/f")
df = pd.DataFrame({"supplement": ["None", "Vitamin D", "None", "Iron", "Multivitamin"], "x": [1,2,3,4,5]})
for ext in ("xlsx", "csv"):
    p = F / f"none.{ext}"
    (df.to_excel(p, index=False) if ext == "xlsx" else df.to_csv(p, index=False))
    info = ingest(p, F / f"none.{ext}.parquet")
    c = info.columns[0]; print(ext, c.dtype, "n_missing", c.n_missing, "uniq", c.n_unique, c.sample)
