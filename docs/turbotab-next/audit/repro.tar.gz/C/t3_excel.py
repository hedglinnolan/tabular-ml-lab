import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd
from turbotab.core.datastore import ingest, DataStore
F = Path("/private/tmp/turbotab-audit/C/f")
df = pd.DataFrame({"id": ["001","002","003","004"], "kcal": [2000, "NA", 1800, 2200], "age": [30, 40, None, 50],
                   "flag": [True, False, None, True], "when": pd.to_datetime(["2020-01-01","2020-02-01",None,"2020-03-01"]),
                   "big": [123456789012, 2, 3, 4], "ratio": [0.1, 0.2, 0.30000000000000004, 1/3]})
p = F / "nas.xlsx"; df.to_excel(p, index=False)
info = ingest(p, F / "nas.xlsx.parquet")
for c in info.columns: print(c.name, c.dtype, c.physical_type, c.n_missing, c.sample)
print(info.warnings)
# same data as CSV
p2 = F / "nas.csv"; df.to_csv(p2, index=False)
info2 = ingest(p2, F / "nas.csv.parquet")
for c in info2.columns: print("CSV", c.name, c.dtype, c.physical_type, c.n_missing, c.sample)
