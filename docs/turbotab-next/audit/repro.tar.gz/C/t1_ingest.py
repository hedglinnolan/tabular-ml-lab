import sys, json
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
from turbotab.core.datastore import ingest, DataStore
import pandas as pd, numpy as np
F = Path("/private/tmp/turbotab-audit/C/f")

def run(name, text, show_cols=None):
    p = F / name
    p.write_text(text)
    info = ingest(p, F / (name + ".parquet"))
    print("==", name, "rows", info.n_rows, "warnings:", info.warnings)
    for c in info.columns:
        if show_cols is None or c.name in show_cols:
            print("  ", c.name, c.dtype, c.physical_type, "miss", c.n_missing, "uniq", c.n_unique, "sample", c.sample)
    return info

# 1. SAS-style '.' missing in a numeric column
run("dot.csv", "id,kcal,age\n1,2000,30\n2,.,40\n3,1800,.\n4,2200,50\n")
# 2. NHANES-style sentinel codes 7777/9999 and 7/9
run("sentinel.csv", "id,minutes,smoke\n1,30,1\n2,7777,2\n3,9999,9\n4,45,7\n")
# 3. large ints (> 2^53) e.g. biobank ids / genomic positions
run("bigint.csv", "id,pos\n9007199254740993,1\n9007199254740995,2\n12345678901234567890,3\n")
# 4. leading zeros in small file
run("zeros.csv", "zip,fips,val\n02134,001,1.5\n10001,013,2.5\n00501,101,3\n")
# 5. scientific-notation IDs
run("sci.csv", "sample,val\n1E5,1\n2E5,2\n3E5,3\n")
# 6. ambiguous dates dd/mm vs mm/dd (all days <= 12)
run("dates_amb.csv", "id,visit\n1,03/04/2020\n2,05/06/2020\n3,11/12/2020\n4,01/02/2021\n")
# 7. European date with day > 12 present
run("dates_eu.csv", "id,visit\n1,03/04/2020\n2,25/06/2020\n3,11/12/2020\n")
# 8. decimal comma (European)
run("deccomma.csv", "id;kcal;bmi\n1;2000,5;22,1\n2;1800,2;30,4\n3;2100,0;25,0\n")
# 9. inf tokens
run("inf.csv", "id,x\n1,1.5\n2,inf\n3,-Infinity\n4,2.5\n")
# 10. NA spellings outside list
run("na_spellings.csv", "id,x\n1,1.5\n2,NA\n3,-\n4,2.5\n5, \n6,missing\n")
