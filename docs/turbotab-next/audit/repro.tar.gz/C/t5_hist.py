import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd, pyarrow as pa, pyarrow.parquet as pq
from turbotab.core.datastore import ingest, DataStore
F = Path("/private/tmp/turbotab-audit/C/f")
rng = np.random.default_rng(3)
n = 60000
age = rng.integers(18, 81, n)              # uniform integer ages 18..80
score = rng.integers(0, 41, n)             # uniform 0..40 score (e.g. a 41-point scale)
x = np.round(rng.uniform(0, 3, n), 1)      # values on a 0.1 grid (one decimal place), uniform
pq.write_table(pa.table({"age": age, "score": score, "x1dp": x}), F / "h.parquet")
ingest(F / "h.parquet", F / "h.ing.parquet")
s = DataStore(F / "h.ing.parquet", 4 << 30)
for c in ("age", "score", "x1dp"):
    h = s.histogram(c, 30)
    e = h["edges"]
    print(c, "nbins", len(h["counts"]), "width", round(e[1]-e[0], 4))
    print("  counts", h["counts"])
    # how many distinct values fall in each bin
    v = {"age": age, "score": score, "x1dp": x}[c]
    uniq = np.unique(v)
    start, width = e[0], e[1]-e[0]
    b = np.clip(np.floor((uniq - start)/width).astype(int), 0, len(h["counts"])-1)
    print("  distinct values per bin", np.bincount(b, minlength=len(h["counts"])).tolist())
