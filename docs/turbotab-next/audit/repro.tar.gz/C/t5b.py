import sys
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pyarrow as pa, pyarrow.parquet as pq
from turbotab.core.datastore import ingest, DataStore
from turbotab.core.consequences import _histogram_pair
F = Path("/private/tmp/turbotab-audit/C/f")
rng = np.random.default_rng(11)
n = 8000
hba1c = np.round(np.clip(rng.lognormal(np.log(5.6), 0.12, n), 4.0, 12.0), 1)   # % to 0.1
glu = np.round(np.clip(rng.lognormal(np.log(5.4), 0.15, n), 3.0, 15.0), 1)      # mmol/L to 0.1
pq.write_table(pa.table({"hba1c": hba1c, "glucose_mmol": glu}), F / "h2.parquet")
ingest(F / "h2.parquet", F / "h2.ing.parquet")
s = DataStore(F / "h2.ing.parquet", 4 << 30)
for c, v in (("hba1c", hba1c), ("glucose_mmol", glu)):
    h = s.histogram(c, 30)
    e = np.array(h["edges"]); start, width = e[0], e[1] - e[0]
    print(c, "range", v.min(), v.max(), "width", width)
    print("  store.histogram counts", h["counts"])
    uniq = np.unique(v)
    b = np.clip(np.floor((uniq - start) / width).astype(int), 0, 29)
    print("  grid values per bin    ", np.bincount(b, minlength=30).tolist())
    hb, _ = _histogram_pair(v, v)
    print("  _histogram_pair counts ", hb.counts)
    # what exact bin assignment by edges would be (count values in [e_i, e_{i+1}) using exact decimal)
    from decimal import Decimal
    ed = [Decimal(repr(x)) for x in e]
