"""A: inference on repeated rows of few units. Null exposure effect; strong unit intercepts.
6 participants x 40 visits. The exposure varies mostly between participants."""
import sys, json
import numpy as np, pandas as pd
sys.path.insert(0, "/private/tmp/turbotab-audit/E")
from drive import D, server, open_table, answer_opening

def main():
    rng = np.random.default_rng(11)
    units, per = 6, 40
    pid = np.repeat(np.arange(units) + 1001, per)
    u_x = rng.normal(0, 1, units)          # participant-level exposure level
    u_y = rng.normal(0, 2, units)          # participant-level outcome intercept (ICC high)
    x = np.repeat(u_x, per) + rng.normal(0, 0.3, units * per)
    age = np.repeat(rng.integers(30, 70, units), per).astype(float)
    y = 5 + np.repeat(u_y, per) + rng.normal(0, 1, units * per)   # x has NO effect
    frame = pd.DataFrame({"participant_id": pid, "sodium_mg": x * 500 + 3000, "age": age, "sbp": y * 3 + 110})

    with server() as client:
        d = D(client)
        open_table(d, frame, "scenA")
        grain = {"grain": "repeated", "id_column": "participant_id"}
        roles = {"participant_id": "identifier", "sodium_mg": "exposure", "age": "covariate"}
        answer_opening(d, lens=["clinical"], target="sbp", task="regression", purpose="inference",
                       grain=grain, roles=roles,
                       split={"kind": "set_split", "holdout": 0.0, "seed": 0, "folds": 5})
        split = d.artifact("split")
        print("SPLIT basis:", json.dumps(split.get("basis"), indent=0))
        print("SPLIT grouped_by:", split.get("grouped_by"), "exploratory:", split.get("exploratory"))
        fit = d.artifact("fit")
        m = fit["models"][0]
        for c in m["coefficients"]:
            print("COEF", c)
        print("CONCERNS", m["concerns"])
        print("n_train", fit["n_train"], "n_holdout", fit["n_holdout"])

    # The same regression, cluster-robust and with a random intercept, for contrast
    import statsmodels.api as sm, statsmodels.formula.api as smf
    X = sm.add_constant(frame[["sodium_mg", "age"]])
    naive = sm.OLS(frame["sbp"], X).fit()
    clus = sm.OLS(frame["sbp"], X).fit(cov_type="cluster", cov_kwds={"groups": frame["participant_id"]})
    print("naive  sodium CI", naive.conf_int().loc["sodium_mg"].tolist(), "p", naive.pvalues["sodium_mg"])
    print("cluster sodium CI", clus.conf_int().loc["sodium_mg"].tolist(), "p", clus.pvalues["sodium_mg"])
    mm = smf.mixedlm("sbp ~ sodium_mg + age", frame, groups=frame["participant_id"]).fit()
    print("mixed  sodium CI", mm.conf_int().loc["sodium_mg"].tolist(), "p", mm.pvalues["sodium_mg"])

if __name__ == '__main__':
    main()
