import sys, time
sys.path.insert(0, "/private/tmp/turbotab-audit/E")
import pandas as pd, numpy as np
from drive import D, server
with server() as client:
    d = D(client)
    p = "/private/tmp/turbotab-audit/E/dbg.csv"
    pd.DataFrame({"a": np.arange(50), "b": np.arange(50) * 2.0}).to_csv(p, index=False)
    r = client.post("/api/projects", json={"path": p})
    print(r.status_code, r.text[:300])
    d.pid = r.json()["id"]
    for i in range(40):
        st = d.status()["ingest"]
        print(i, st.status, getattr(st, "error", None))
        if st.status in ("fresh", "error"): break
        time.sleep(0.5)
