"""End-to-end driver through the real TurboTab Next server (TestClient, real job workers).

Usage: venv/bin/python drive.py <scenario>
Every answer goes through POST /decisions, exactly as the browser does.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd

os.environ.setdefault("TURBOTAB_WORKERS", "2")
OUT = Path("/private/tmp/turbotab-audit/E")


class D:
    def __init__(self, client):
        self.c = client
        self.pid = ""

    def get(self, path="", **params):
        r = self.c.get(f"/api/projects/{self.pid}{path}", params=params)
        assert r.status_code == 200, (path, r.status_code, r.text[:500])
        return r.json()

    def post(self, body):
        r = self.c.post(f"/api/projects/{self.pid}/decisions", json=body)
        return r.status_code, r.json()

    def decide(self, body):
        code, js = self.post(body)
        if code != 200:
            raise RuntimeError(f"{body.get('kind')}: {code} {json.dumps(js)[:800]}")
        return js

    def interview(self):
        return {s["key"]: s for s in self.get("")["interview"]}

    def reach(self, key, timeout=300):
        end = time.time() + timeout
        while True:
            steps = self.get("")["interview"]
            step = next(s for s in steps if s["key"] == key)
            first = next((s for s in steps if s["status"] in ("open", "waiting")), None)
            if step["status"] not in ("open", "waiting") or first is None or first["key"] == key:
                if step["status"] == "waiting" and step.get("waiting_on"):
                    if time.time() > end:
                        raise TimeoutError(step)
                    time.sleep(0.1)
                    continue
                return step
            if time.time() > end:
                raise TimeoutError(f"{key} held behind {first}")
            time.sleep(0.1)

    def status(self):
        return self.c.app.state.service.engine.status(self.pid)

    def wait(self, stage, timeout=300):
        end = time.time() + timeout
        while True:
            st = self.status()[stage]
            if st.status == "fresh":
                return
            if st.status == "error":
                raise RuntimeError(f"{stage} failed: {st.error}")
            if time.time() > end:
                raise TimeoutError(stage)
            time.sleep(0.05)

    def artifact(self, stage):
        self.wait(stage)
        return self.get(f"/stages/{stage}")["artifact"]


def server():
    from fastapi.testclient import TestClient

    from turbotab.core.config import Settings
    from turbotab.server.app import create_app

    home = tempfile.mkdtemp(prefix="tt-audit-E-")
    base = Settings.from_env()
    settings = Settings(home=Path(home), mode="local", workers=2,
                        memory_budget_bytes=base.memory_budget_bytes)
    app = create_app(settings, frontend_dist=Path(home) / "no-frontend")
    return TestClient(app, base_url="http://127.0.0.1")


def open_table(d: D, frame: pd.DataFrame, name: str) -> None:
    path = OUT / f"{name}.csv"
    frame.to_csv(path, index=False)
    r = d.c.post("/api/projects", json={"path": str(path)})
    assert r.status_code == 200, r.text
    d.pid = r.json()["id"]
    d.wait("ingest")


def answer_opening(d: D, *, lens, target, task, purpose, grain, roles=None, missing=None,
                   split=None, models=("linear",), energy=None, event=None):
    d.decide({"kind": "set_lens", "lenses": lens})
    d.reach("target")
    d.decide({"kind": "set_target", "column": target})
    iv = d.interview()
    if event is not None and iv["event"]["status"] in ("open", "waiting"):
        d.reach("event")
        d.decide({"kind": "set_event", "column": target, "level": event})
    st = d.reach("task")
    if st["status"] in ("open", "waiting"):
        d.decide({"kind": "set_task", "column": target, "task": task})
    d.reach("purpose")
    d.decide({"kind": "set_purpose", "purpose": purpose})
    st = d.reach("grain")
    if st["status"] in ("open", "waiting") and grain is not None:
        d.decide({"kind": "set_grain", **grain})
    for key in ("repeat_kind", "unit", "aggregation", "temporal"):
        st = d.reach(key)
        if st["status"] in ("open", "waiting"):
            if key == "repeat_kind":
                d.decide({"kind": "set_repeat_kind", "repeat_kind": "repeats"})
            elif key == "unit":
                d.decide({"kind": "set_unit", "unit": "row"})
            elif key == "temporal":
                d.decide({"kind": "set_temporal", "temporal": False})
            else:
                raise RuntimeError(f"unexpected open {key}: {st}")
    d.reach("roles")
    proposed = {c["column"]: c["proposed"] for c in d.artifact("roles")["columns"]}
    d.decide({"kind": "set_roles", "roles": roles or proposed})
    d.reach("exclusions")
    d.decide({"kind": "set_exclusions", "rules": []})
    d.reach("missing")
    d.decide(missing or {"kind": "set_missing", "strategy": "complete_case"})
    d.reach("split")
    d.decide(split or {"kind": "set_split", "holdout": 0.2, "seed": 0, "folds": 5})
    st = d.reach("energy_adjustment")
    if st["status"] in ("open", "waiting"):
        d.decide(energy or {"kind": "set_energy_adjustment", "method": "none"})
    d.reach("models")
    d.decide({"kind": "select_models", "models": list(models)})
    return proposed


if __name__ == "__main__":
    print("import as a module")
