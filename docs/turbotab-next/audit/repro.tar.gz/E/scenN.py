"""N: the real NHANES export through the real server under purpose=inference, proposed roles accepted.
What does the app estimate, label and warn?"""
import sys, json, time
sys.path.insert(0, "/private/tmp/turbotab-audit/E")
import numpy as np, pandas as pd

def main():
    from drive import D, server, answer_opening
    src = "/Users/nhedglin/tabular-ml-lab/_tt_tmp_nhanes.csv"
    with server() as client:
        d = D(client)
        r = client.post("/api/projects", json={"path": src}); assert r.status_code == 200, r.text
        d.pid = r.json()["id"]; d.wait("ingest")
        t = time.time()
        proposed = answer_opening(d, lens=["dietary"], target="glucose", task="regression",
                                  purpose="inference", grain={"grain": "one_row_per_unit", "id_column": "SEQN"},
                                  missing={"kind": "set_missing", "strategy": "complete_case"},
                                  split={"kind": "set_split", "holdout": 0.2, "seed": 0, "folds": 5},
                                  models=("linear",))
        print("PROPOSED ROLES:", json.dumps(proposed))
        plan = d.artifact("seal_plan")
        print("SEAL PLAN options (inference):", [(o["label"], o["below_floor"]) for o in plan["options"]], "cv_first", plan["cv_first"])
        cohort = d.artifact("cohort"); print("COHORT n_final", cohort.get("n_final"))
        fit = d.artifact("fit")
        m = fit["models"][0]
        print("n_train", fit["n_train"], "n_holdout", fit["n_holdout"])
        for c in m["coefficients"]:
            print("COEF %-14s est %+.5f  CI [%+.5f, %+.5f] p %.3g" % (c["feature"], c["estimate"], c["ci_low"], c["ci_high"], c["p"]))
        print("CONCERNS", m["concerns"])
        design = d.artifact("design"); print("DESIGN WARNINGS", design["warnings"])
        print("STEPS", [s["label"] + ": " + s["detail"] for s in design["models"][0]["steps"]])
        print(f"[{time.time()-t:.0f}s]")

if __name__ == "__main__":
    main()
