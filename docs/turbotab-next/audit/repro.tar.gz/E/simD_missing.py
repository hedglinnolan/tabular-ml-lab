"""D: under purpose=inference, what the app's own missing-value options do to the exposure's
coefficient and its 95% CI. Real code: design_spec -> build_pipeline -> Linear.coefficients.
Truth: y = 0.5*x + 1.0*z + e; z (a confounder, corr with x) is missing for ~35%.
Compared with multiple imputation (IterativeImputer incl. y, m=10, Rubin's rules) — not offered by the app."""
import sys, time, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
import numpy as np, pandas as pd
import turbotab.core.models  # registers families
from turbotab.core.decisions import ProjectState, MissingSpec
from turbotab.core.models import get_family
from turbotab.core.models.pipeline import design_spec, build_pipeline

LIN = get_family("linear")
ROLES = {"x": "exposure", "z": "covariate"}
BETA = 0.5

def app_fit(frame, missing):
    st = ProjectState(target="y", task="regression", purpose="inference", roles=ROLES, missing=missing)
    X = frame[["x", "z"]]
    if missing.strategy == "complete_case":
        keep = X.notna().all(axis=1)
        X, y = X[keep], frame["y"][keep].to_numpy()
    else:
        y = frame["y"].to_numpy()
    spec = design_spec(st, X, ["x", "z"])
    pipe = build_pipeline(spec, LIN, "regression", "inference", len(X), 2).fit(X, y)
    rows = {r["feature"]: r for r in LIN.coefficients(pipe, X, y, task="regression", purpose="inference")}
    r = rows["x"]
    return r["estimate"], r["ci_low"], r["ci_high"]

def mi_fit(frame, m=10, seed=0):
    from sklearn.experimental import enable_iterative_imputer  # noqa
    from sklearn.impute import IterativeImputer
    import statsmodels.api as sm
    ests, vars_ = [], []
    for k in range(m):
        imp = IterativeImputer(sample_posterior=True, random_state=seed * 100 + k, max_iter=10)
        full = pd.DataFrame(imp.fit_transform(frame[["x", "z", "y"]]), columns=["x", "z", "y"])
        res = sm.OLS(full["y"], sm.add_constant(full[["x", "z"]])).fit()
        ests.append(res.params["x"]); vars_.append(res.bse["x"] ** 2)
    q = np.mean(ests); w = np.mean(vars_); b = np.var(ests, ddof=1); t = w + (1 + 1 / m) * b
    from scipy import stats
    r = (1 + 1 / m) * b / w; df = (m - 1) * (1 + 1 / r) ** 2
    h = stats.t.ppf(0.975, df) * np.sqrt(t)
    return q, q - h, q + h

def draw(n, mech, rng):
    z = rng.normal(size=n)
    x = 0.7 * z + rng.normal(size=n)
    y = BETA * x + 1.0 * z + rng.normal(size=n)
    driver = x if mech == "x" else y
    p = 1 / (1 + np.exp(-(-1.0 + 1.5 * (driver - driver.mean()) / driver.std())))
    z = np.where(rng.random(n) < p, np.nan, z)
    return pd.DataFrame({"x": x, "z": z, "y": y})

OPTIONS = {
    "complete cases": MissingSpec(strategy="complete_case"),
    "impute (median)": MissingSpec(strategy="impute"),
    "impute + indicator": MissingSpec(strategy="impute", indicators=True),
}
t = time.time()
for mech in ("x", "y"):
    rng = np.random.default_rng(1 if mech == "x" else 2)
    res = {k: [] for k in [*OPTIONS, "MI (not offered)"]}
    for rep in range(150):
        f = draw(1000, mech, rng)
        for k, spec in OPTIONS.items():
            res[k].append(app_fit(f, spec))
        if rep < 60:
            res["MI (not offered)"].append(mi_fit(f, seed=rep))
    share = None
    print(f"\nMissingness of z depends on {mech} (MAR); true beta_x = {BETA}")
    for k, v in res.items():
        a = np.asarray(v)
        cover = np.mean((a[:, 1] <= BETA) & (BETA <= a[:, 2]))
        print(f"  {k:20s} mean est {a[:,0].mean():.3f}  bias {a[:,0].mean()-BETA:+.3f}  95% CI coverage {cover:.2f}  (reps {len(a)})")
print(f"[{time.time()-t:.0f}s]")
