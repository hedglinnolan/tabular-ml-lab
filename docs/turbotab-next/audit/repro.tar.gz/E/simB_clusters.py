"""B: type I error of the app's own inference CIs (turbotab.core.models.linear.statsmodels_fit)
for a null exposure that varies between units, with G units of m rows each (ICC ~0.5).
groups=None is what the app passes when the basis is abandoned/undetermined; groups=ids when grouped."""
import sys, time, warnings
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.simplefilter("ignore")
import numpy as np, pandas as pd
from turbotab.core.models.linear import statsmodels_fit

def sim(G, m, reps, task, clustered, seed=0):
    rng = np.random.default_rng(seed)
    rej = 0
    for r in range(reps):
        ids = np.repeat(np.arange(G), m)
        x = np.repeat(rng.normal(size=G), m) + rng.normal(0, 0.3, G * m)
        u = np.repeat(rng.normal(0, 1.0, G), m)
        X = pd.DataFrame({"x": x})
        if task == "regression":
            y = u + rng.normal(0, 1, G * m)
            classes = None
        else:
            y = (rng.random(G * m) < 1 / (1 + np.exp(-(u * 1.5)))).astype(int)
            classes = [0, 1]
        try:
            res = statsmodels_fit(task, X, y, classes, ids if clustered else None)
            lo, hi = np.asarray(res.conf_int(0.05))[1]
            rej += not (lo <= 0 <= hi)
        except Exception:
            pass
    return rej / reps

t = time.time()
print("task        G   m  naive(iid)  cluster-robust   [nominal 0.05]")
for task in ("regression", "binary"):
    for G, m in ((6, 40), (8, 25), (12, 20), (20, 10), (50, 4)):
        a = sim(G, m, 400, task, False, seed=G)
        b = sim(G, m, 400, task, True, seed=G)
        print(f"{task:10s} {G:3d} {m:3d}   {a:.3f}       {b:.3f}")
print(f"[{time.time()-t:.0f}s]")
