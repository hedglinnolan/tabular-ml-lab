"""Does seal.measure()'s held-out R² precision (±1.96·√(2/n), i.e. (1−R²)√(2/n) at R²=0) match the
actual spread of a held-out R² on n rows? Real function: turbotab.core.seal.measure."""
import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np
from turbotab.core.seal import measure
rng = np.random.default_rng(0)
p = 5
for n in (50, 100, 400):
    print(measure("regression", n)[0])
    for r2 in (0.0, 0.1, 0.3, 0.5):
        b = np.sqrt(r2 / (1 - r2) / p) if r2 > 0 else 0.0
        vals = []
        for _ in range(3000):
            ntr = 2000
            X = rng.normal(size=(ntr + n, p)); y = X @ np.full(p, b) + rng.normal(size=ntr + n)
            Xt = np.c_[np.ones(ntr), X[:ntr]]; coef = np.linalg.lstsq(Xt, y[:ntr], rcond=None)[0]
            pred = np.c_[np.ones(n), X[ntr:]] @ coef; yh = y[ntr:]
            vals.append(1 - ((yh - pred) ** 2).sum() / ((yh - yh.mean()) ** 2).sum())
        vals = np.asarray(vals)
        q = np.quantile(vals, [0.025, 0.975])
        print(f"   n={n:4d} true R²={r2:.1f}: SD {vals.std():.3f} -> ±{1.96*vals.std():.3f};  2.5–97.5% [{q[0]:+.3f}, {q[1]:+.3f}]")
