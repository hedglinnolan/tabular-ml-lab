import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
from turbotab.core.datastore import ingest
F = Path("/private/tmp/turbotab-audit/C-skeptic/f")
run = GraphRun(F / "c5_dot.csv", F / "proj_c5b")
out = run.run(ProjectState.model_validate(dict(lens=["dietary"], target="glucose")), upto=["roles"])
r = out["roles"]; r = getattr(r, "data", r)
for c in r["columns"]:
    if c.get("column", c.get("name")) in ("age", "kcal", "bmi"):
        print({k: (str(v)[:110]) for k, v in c.items() if k in ("column", "name", "proposed", "role", "reason", "kind")})
run.close()
for txt, nm in (("a,b\n" + "\n".join(f"{i},{12.5+i} " for i in range(50)) + "\n", "trail"),
                ("a,b\n" + "\n".join(f'{i}," {12.5+i}"' for i in range(50)) + "\n", "quotedpad")):
    p = F / f"c5_{nm}.csv"; p.write_text(txt)
    info = ingest(p, F / f"c5_{nm}.parquet").to_dict()
    print(nm, [(c["name"], c["physical_type"]) for c in info["columns"]])
