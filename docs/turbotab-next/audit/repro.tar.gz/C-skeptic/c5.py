import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd
from turbotab.core.datastore import ingest
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
from turbotab.core import repairs
F = Path("/private/tmp/turbotab-audit/C-skeptic/f")
rng = np.random.default_rng(7)
n = 2000
age = rng.integers(20, 80, n).astype(object); age[rng.random(n) < 0.03] = "."
kcal = np.round(rng.normal(2100, 500, n)).astype(object); kcal[rng.random(n) < 0.03] = "."
bmi = np.round(rng.normal(27, 5, n), 1).astype(object); bmi[rng.random(n) < 0.03] = "."
df = pd.DataFrame({"SEQN": np.arange(n), "age": age, "kcal": kcal, "bmi": bmi, "glucose": np.round(rng.normal(100, 15, n), 1)})
src = F / "c5_dot.csv"; df.to_csv(src, index=False)
run = GraphRun(src, F / "proj_c5")
print([(c["name"], c["physical_type"], c["dtype"], c["n_unique"]) for c in run.info["columns"]])
out = run.run(ProjectState.model_validate(dict(lens=["dietary"], target="glucose")), upto=["findings", "roles"])
fd = out["findings"]; fd = getattr(fd, "data", fd)
items = fd.get("findings") if isinstance(fd, dict) else fd
for f in items or []:
    fid = f.get("id")
    if any(k in fid for k in ("age", "kcal", "bmi")):
        print("FINDING", fid, "| family:", repairs.family_for(fid), "|", (f.get("summary") or f.get("title") or "")[:140])
r = out.get("roles"); r = getattr(r, "data", r)
for p in (r or {}).get("proposals", []) if isinstance(r, dict) else []:
    if p.get("column") in ("age", "kcal", "bmi"):
        print("ROLE", p.get("column"), p.get("proposed"), "|", (p.get("reason") or "")[:100])
if isinstance(r, dict) and "proposals" not in r: print("roles keys:", list(r)[:10])
run.close()
# other spellings
others = {
 "deccomma": ("a;b\n" + "\n".join(f"{i};{2000+i},5" for i in range(50)) + "\n", ";"),
 "padded": ("a,b\n" + "\n".join(f"{i}, {12.5+i}" for i in range(50)) + "\n", ","),
 "thousands": ("a,b\n" + "\n".join(f'{i},"1,{200+i}"' for i in range(50)) + "\n", ","),
 "divzero": ("a,b\n" + "\n".join(f"{i},{'#DIV/0!' if i%10==0 else 1.5+i}" for i in range(50)) + "\n", ","),
 "lod": ("a,b\n" + "\n".join(f"{i},{'<0.2' if i%10==0 else 1.5+i}" for i in range(50)) + "\n", ","),
}
for k, (txt, d) in others.items():
    p = F / f"c5_{k}.csv"; p.write_text(txt)
    info = ingest(p, F / f"c5_{k}.parquet").to_dict()
    print(k, [(c["name"], c["physical_type"], c["dtype"]) for c in info["columns"]])
