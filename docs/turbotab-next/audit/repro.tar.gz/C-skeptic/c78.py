import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import pandas as pd, numpy as np
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
F = Path("/private/tmp/turbotab-audit/C-skeptic/f")
rng = np.random.default_rng(3)
rows = []
for p in range(40):
    smk = [1, 1, 3] if p % 3 == 0 else ([2, 2, 2] if p % 3 == 1 else [3, 1, 1])
    dow = rng.integers(1, 8, 3)
    for k in range(3):
        date = f"2021-0{k+1}-1{p%9}"
        if p < 4 and k == 1: date = ""     # one undated middle record for P0..P3
        rows.append((f"P{p:02d}", date, smk[k], int(dow[k]), 80 - 3*k + p*0.1, 140 - 4*k))
# put P0's undated record last in the file to make the ordering visible
df = pd.DataFrame(rows, columns=["pid", "visit_date", "smoking_cat", "day_of_week", "weight_kg", "sbp"])
src = F / "visits_iso.csv"; df.to_csv(src, index=False)
run = GraphRun(src, F / "proj_c78")
print([(c["name"], c["physical_type"], c["dtype"]) for c in run.info["columns"]])
print(df[df.pid.isin(["P00", "P02"])].to_string())
for method in ("mean", "last", "change"):
    st = ProjectState.model_validate(dict(lens=["clinical"], target="sbp", grain={"grain": "repeated", "id_column": "pid"},
        unit="unit", repeat_kind={"repeat_kind": "time_points", "time_column": "visit_date"},
        aggregation={"method": method, "outcome": "last"}))
    out = run.run(st, upto=["working"])
    a = out["working"].data["aggregation"]
    t = pd.read_parquet(out["working"].files["table.parquet"])
    print(f"\n== {method}: varying={a['varying']} combined_numeric={a['combined_numeric']} keys={sorted(a)}")
    print(t[t.pid.isin(["P00", "P02", "P05"])].drop(columns=[c for c in t.columns if c.startswith('__')], errors='ignore').to_string())
run.close()
