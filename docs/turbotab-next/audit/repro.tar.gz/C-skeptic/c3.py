import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import pandas as pd, numpy as np, duckdb
from turbotab.core.datastore import ingest
F = Path("/private/tmp/turbotab-audit/C-skeptic/f")
rng = np.random.default_rng(1)
n = 2000
true = pd.to_datetime("2019-01-01") + pd.to_timedelta(rng.integers(0, 3*365, n), unit="D")
cases = {
  "us_full": true.strftime("%m/%d/%Y"),
  "us_month_coarsened": true.to_period("M").to_timestamp().strftime("%m/%d/%Y"),
  "eu_full": true.strftime("%d/%m/%Y"),
}
for name, s in cases.items():
    df = pd.DataFrame({"pid": range(n), "draw_date": s, "vitd": rng.normal(60, 15, n).round(1)})
    src = F / f"c3_{name}.csv"; df.to_csv(src, index=False)
    info = ingest(src, F / f"c3_{name}.parquet").to_dict()
    col = [c for c in info["columns"] if c["name"] == "draw_date"][0]
    got = duckdb.sql(f"select draw_date from read_parquet('{F}/c3_{name}.parquet') order by __row_id__" if False else f"select * from read_parquet('{F}/c3_{name}.parquet')").df()
    expected = pd.to_datetime(s, format="%d/%m/%Y" if name.startswith("eu") else "%m/%d/%Y")
    readd = pd.to_datetime(got["draw_date"])
    print(f"{name}: physical={col['physical_type']} dtype={col['dtype']} warnings={info.get('warnings')}")
    print("   first 3 raw:", list(s[:3]), "-> read:", [str(x.date()) for x in readd[:3]])
    print("   rows whose date differs from truth:", int((readd.values != expected.values).sum()), "of", n,
          "| distinct months read:", sorted(readd.dt.month.unique().tolist())[:12])
