import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
from turbotab.core.datastore import DataStore, ingest
F = Path("/private/tmp/turbotab-audit/C-skeptic/f")
ingest(F / "c10.csv", F / "c10.parquet")
s = DataStore(F / "c10.parquet", 1 << 30)
fn = getattr(s, "_summaries_arrow", None)
print("arrow fn:", fn is not None)
if fn:
    out = fn(["protein_density", "ldl"])
    print({k: {kk: vv for kk, vv in v.items() if kk in ("mean", "std", "min", "max", "n")} if isinstance(v, dict) else v for k, v in out.items()})
