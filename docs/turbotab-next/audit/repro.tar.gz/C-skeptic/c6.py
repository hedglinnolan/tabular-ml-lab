import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import pandas as pd
from turbotab.core.datastore import ingest
F = Path("/private/tmp/turbotab-audit/C-skeptic/f")
df = pd.DataFrame({"pid": range(8),
                   "supplement": ["None", "Vitamin D", "None", "Iron", "Multivitamin", "None", "n/a", "NA"],
                   "note": ["null", "-nan", "NaN", "#N/A", "N/A", "", "1.#IND", "ok"]})
df.to_csv(F / "c6.csv", index=False)
with pd.ExcelWriter(F / "c6.xlsx") as w: df.to_excel(w, index=False)
import openpyxl
wb = openpyxl.load_workbook(F / "c6.xlsx"); print("cells in xlsx:", [c.value for c in wb.active["B"]])
for ext in ("csv", "xlsx"):
    info = ingest(F / f"c6.{ext}", F / f"c6_{ext}.parquet").to_dict()
    t = pd.read_parquet(F / f"c6_{ext}.parquet")
    for c in info["columns"]:
        if c["name"] in ("supplement", "note"):
            print(ext, c["name"], "n_missing", c["n_missing"], "values:", t[c["name"]].tolist())
