import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import pandas as pd, numpy as np, duckdb
from turbotab.core.datastore import ingest
F = Path("/private/tmp/turbotab-audit/C-skeptic/f")
rng = np.random.default_rng(2)
n1, n2 = 30000, 200
d1 = [f"{rng.integers(1,13):02d}/{rng.integers(1,13):02d}/2020" for _ in range(n1)]
d2 = [f"{rng.integers(1,13):02d}/{rng.integers(13,29):02d}/2021" for _ in range(n2)]
df = pd.DataFrame({"pid": range(n1+n2), "d": d1 + d2, "x": rng.normal(size=n1+n2)})
src = F / "c3_late.csv"; df.to_csv(src, index=False)
info = ingest(src, F / "c3_late.parquet").to_dict()
col = [c for c in info["columns"] if c["name"] == "d"][0]
print("late-disambiguation:", col["physical_type"], col["dtype"], "warnings:", info.get("warnings"))
got = duckdb.sql(f"select d from read_parquet('{F}/c3_late.parquet')").df()["d"]
print(got.head(3).tolist(), got.tail(3).tolist())
# small 5-row file
df = pd.DataFrame({"pid": range(5), "d": ["03/04/2020", "05/06/2020", "01/02/2021", "11/12/2020", "07/08/2020"], "x": range(5)})
src = F / "c3_small.csv"; df.to_csv(src, index=False)
info = ingest(src, F / "c3_small.parquet").to_dict()
print("small:", [ (c["name"], c["physical_type"]) for c in info["columns"]], duckdb.sql(f"select d from read_parquet('{F}/c3_small.parquet')").df()["d"].tolist(), info.get("warnings"))
