import sys, warnings; warnings.filterwarnings("ignore")
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np, pandas as pd
from turbotab.core.stages.rows import cohort_flow
from turbotab.core.decisions import ExclusionRule
rng = np.random.default_rng(12)
n = 1000
age = rng.integers(10, 95, n).astype(float); age[rng.random(n) < 0.2] = np.nan
kcal = rng.normal(2200, 900, n); kcal[rng.random(n) < 0.08] = np.nan
y = rng.normal(100, 15, n)
f = pd.DataFrame({"age": age, "kcal": kcal, "glucose": y})
rules = [ExclusionRule(column="age", low=20, high=80, reason="adults 20-80"),
         ExclusionRule(column="kcal", low=500, high=5000, reason="plausible energy")]
for missing in (None, "impute", "complete_case"):
    steps, kept = cohort_flow(f, target="glucose", rules=rules, missing=missing, predictor_columns=["age"])
    print(f"missing={missing}:", [(s["label"], s["n"]) for s in steps])
    k = f.loc[kept]
    print("   in final cohort: age missing", int(k.age.isna().sum()), "| kcal missing", int(k.kcal.isna().sum()), "of", len(k))
