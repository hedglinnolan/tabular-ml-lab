import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import pandas as pd, duckdb
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
F = Path("/private/tmp/turbotab-audit/C-skeptic/f")
print("duckdb TRY_CAST checks:", duckdb.sql("select TRY_CAST('Mar 3, 2021' AS TIMESTAMP), TRY_CAST('03/14/2021' AS TIMESTAMP), TRY_CAST('14-Mar-2021' AS TIMESTAMP), TRY_CAST('2021-03-14' AS TIMESTAMP)").fetchall())
print("pandas parses:", pd.to_datetime(pd.Series(["Mar 3, 2021", "Jan 5, 2021"])).tolist())
rows = []
# 6 people, 3 visits each, file order NOT chronological for persons 0,2,4 (latest first)
import itertools
dates = ["Jan 5, 2021", "Feb 2, 2021", "Mar 3, 2021"]
w = [90.0, 85.0, 80.0]
for p in range(6):
    order = [2, 0, 1] if p % 2 == 0 else [0, 1, 2]
    for k in order:
        rows.append((f"P{p}", dates[k], w[k] + p, 150 - 5*k + p))
df = pd.DataFrame(rows, columns=["pid", "visit_date", "weight_kg", "sbp"])
src = F / "visits_text.csv"; df.to_csv(src, index=False)
run = GraphRun(src, F / "proj_c2")
print([(c["name"], c["physical_type"]) for c in run.info["columns"]])
for explicit in (True, False):
    rk = {"repeat_kind": "time_points", "time_column": "visit_date"} if explicit else {"repeat_kind": "time_points"}
    st = ProjectState.model_validate(dict(lens=["clinical"], target="sbp", grain={"grain": "repeated", "id_column": "pid"}, unit="unit",
        repeat_kind=rk, aggregation={"method": "change", "outcome": "last"}))
    out = run.run(st, upto=["working"])
    s = out["structure"].data if hasattr(out["structure"], "data") else out["structure"]
    print("\nexplicit time column:", explicit, "| structure time_columns:", s.get("time_columns"), "spacing col:", ((s.get("repeats") or {}).get("spacing") or {}).get("column"))
    a = out["working"].data["aggregation"]
    print("receipt: ordered_by =", a["ordered_by"], "time_column =", a["time_column"])
    t = pd.read_parquet(out["working"].files["table.parquet"])
    print(t[["pid", "visit_date", "weight_kg", "sbp"]].to_string())
    print("true chronological weight change for every person: 80-90 = -10")
run.close()
