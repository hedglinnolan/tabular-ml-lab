import sys; sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
import numpy as np
from turbotab.core.units import outcome_unit
rng = np.random.default_rng(0)
cases = [
 ("gestational_age", "weeks", rng.normal(39, 1.5, 500)),
 ("birth_weight", "g", rng.normal(3300, 450, 500)),
 ("dietary_choline", "mg/day", rng.normal(330, 90, 500)),
 ("dietary_cholesterol", "mg/day", rng.normal(290, 110, 500)),
 ("cholesterol_intake", "mg/day", rng.normal(290, 110, 500)),
 ("glucosinolate_intake", "mg/day", rng.lognormal(2.5, 0.6, 500)),
 ("urine_creatinine", "mg/dL", rng.normal(120, 50, 500).clip(10)),
 ("creatine_kinase", "U/L", rng.lognormal(4.7, 0.5, 500)),
 ("recreational_activity_min", "min", rng.lognormal(4, 0.8, 500)),
 ("telomere_length_bp", "bp", rng.normal(6500, 900, 500)),
 ("sleep_hr", "hours", rng.normal(7, 1, 500)),
 ("height", "cm (toddlers)", rng.normal(88, 5, 500)),
 ("weight", "kg (bariatric)", rng.normal(130, 20, 500)),
 ("weight", "lb (children)", rng.normal(60, 15, 500)),
 ("hba1c_mmol", "mmol/mol", rng.normal(40, 6, 500)),
 ("hdl", "mg/dL", rng.normal(52, 14, 500)),
 ("glucose", "mg/dL", rng.normal(100, 15, 500)),
 ("glucose", "mmol/L", rng.normal(5.5, 0.8, 500)),
 ("serum_25ohd", "nmol/L", rng.normal(60, 20, 500)),
 ("plasma_folate", "nmol/L", rng.normal(30, 10, 500)),
 ("energy_kcal", "kcal", rng.normal(2000, 500, 500)),
 ("total_cholesterol", "mg/dL", rng.normal(195, 35, 500)),
 ("ldl", "mmol/L", rng.normal(3.1, 0.8, 500)),
 ("sbp", "mmHg", rng.normal(125, 15, 500)),
 ("age", "years", rng.normal(50, 12, 500)),
]
for name, truth, v in cases:
    print(f"{name:28s} truth={truth:16s} app={outcome_unit(name, v)}")
