import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import pandas as pd, numpy as np
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
F = Path("/private/tmp/turbotab-audit/C-skeptic/f")
rng = np.random.default_rng(4)
rows = []
for p in range(150):
    start = int(rng.integers(1, 4))  # Jan..Mar 2021 enrolment
    for k in range(3):                # quarterly visits
        m = start + 3*k
        for fmt, tag in (("%m/01/2021", "us"), ("2021-%m-01", "iso")):
            pass
        rows.append((f"P{p}", f"{m:02d}/01/2021", f"2021-{m:02d}-01", 80 - k + rng.normal(), 140 - 2*k + rng.normal()))
df = pd.DataFrame(rows, columns=["pid", "visit_us", "visit_iso", "weight", "sbp"])
for col in ("visit_us", "visit_iso"):
    d = df[["pid", col, "weight", "sbp"]].rename(columns={col: "visit_date"})
    src = F / f"c3c_{col}.csv"; d.to_csv(src, index=False)
    run = GraphRun(src, F / f"proj_c3c_{col}")
    out = run.run(ProjectState.model_validate(dict(lens=["clinical"], target="sbp", grain={"grain": "repeated", "id_column": "pid"})), upto=["structure"])
    s = out["structure"]; s = getattr(s, "data", s)
    r = s.get("repeats") or {}
    print(col, "| reading:", r.get("reading"), "| spacing:", {k: (r.get("spacing") or {}).get(k) for k in ("column", "median_days", "min_days", "max_days")})
    print("   sentence:", (r.get("sentence") or "")[:200])
    run.close()
