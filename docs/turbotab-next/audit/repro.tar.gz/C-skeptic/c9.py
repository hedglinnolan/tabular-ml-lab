import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd
from turbotab.core.datastore import ingest, DataStore
from turbotab.core.consequences import _histogram_pair
F = Path("/private/tmp/turbotab-audit/C-skeptic/f")
rng = np.random.default_rng(9)
n = 40000
df = pd.DataFrame({
  "score": rng.integers(0, 41, n),                         # 41 integer levels, uniform
  "age": rng.integers(18, 81, n),                          # 63 integer levels, uniform
  "grid": np.round(rng.integers(0, 31, n) * 0.1, 1),       # 0.0..3.0 on 0.1 grid -> width exactly 0.1
  "hba1c": np.round(np.exp(rng.normal(np.log(5.6), 0.12, n)), 1),
})
df.to_csv(F / "c9.csv", index=False)
ingest(F / "c9.csv", F / "c9.parquet")
store = DataStore(F / "c9.parquet", 1 << 30)
for c in df.columns:
    h = store.histogram(c, bins=30)
    hp, _ = _histogram_pair(df[c].to_numpy(), df[c].to_numpy())
    zeros = [i for i, k in enumerate(h["counts"]) if k == 0]
    print(f"{c}: duckdb counts {h['counts'][:14]} ... zeros at {zeros}")
    diff = [(i, a, b) for i, (a, b) in enumerate(zip(h["counts"], hp.counts)) if a != b]
    print(f"   numpy  counts {hp.counts[:14]} ... ; bins differing duckdb vs numpy: {len(diff)} e.g. {diff[:3]}")
    # per-bin number of distinct values (sawtooth explanation)
    e = np.asarray(h["edges"]); vals = np.unique(df[c])
    per = np.histogram(vals, e)[0]
    print(f"   distinct values per bin (numpy edges): {per[:14].tolist()}")
