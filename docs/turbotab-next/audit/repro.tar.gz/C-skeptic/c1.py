import sys, warnings, logging
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
from types import SimpleNamespace
import numpy as np, pandas as pd
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
from turbotab.core import structure_previews as SP
from turbotab.core.consequences import PreviewContext
from turbotab.core.datastore import DataStore
F = Path("/private/tmp/turbotab-audit/C-skeptic/f"); F.mkdir(exist_ok=True, parents=True)
rng = np.random.default_rng(11)
def make(nf=50, ns=10, extra=()):
    d = {"compound": [f"cmp_{i}" for i in range(nf)]}
    if "hmdb" in extra: d["hmdb"] = [f"HMDB{i:07d}" for i in range(nf)]
    if "mzrt" in extra:
        d["mz"] = np.round(rng.uniform(80, 900, nf), 4); d["rt"] = np.round(rng.uniform(0.5, 15, nf), 2)
    df = pd.DataFrame(d)
    ab = np.exp(rng.normal(np.linspace(4, 16, nf)[:, None], 0.25, (nf, ns)))
    for j in range(ns): df[f"QC{j}" if False else f"P{j+1:02d}"] = np.round(ab[:, j], 3)
    return df
def go(df, name, preview=False):
    src = F / f"{name}.csv"; df.to_csv(src, index=False)
    run = GraphRun(src, F / f"proj_{name}")
    st = ProjectState.model_validate(dict(lens=["metabolomics"], orientation="feature_major"))
    out = run.run(st, upto=["oriented"])
    o = out["oriented"]
    print(f"--- {name}: reading={o.data['reading']['reading']} turn={ {k:o.data['turn'][k] for k in ('label_column','n_samples','refusal')} }")
    t = pd.read_parquet(o.files["table.parquet"])
    print("shape", t.shape, "sample_ids:", list(t['sample_id']))
    print("feature dtypes:", t.dtypes.iloc[1:-1].astype(str).value_counts().to_dict())
    print("first 3 feature cols:", list(t.columns[1:4]))
    print(t.iloc[:4, :4].to_string())
    if preview:
        run2 = GraphRun(src, F / f"proj_{name}_p")
        st2 = ProjectState.model_validate(dict(lens=["metabolomics"]))
        o2 = run2.run(st2, upto=["oriented"])["oriented"]
        ctx = PreviewContext(project_id="x", state=st2, datastore=DataStore(run2.raw, 1 << 30),
                             artifact=lambda s: o2 if s == "oriented" else None,
                             training_row_ids=None, cohort_row_ids=None)
        v = SP.orientation_views(SimpleNamespace(orientation="feature_major"), ctx)[0]
        print("PREVIEW caption:", v.caption)
        print("PREVIEW turned cols:", v.story[1].columns[:5])
        print("PREVIEW sample ids:", [r.values["sample_id"] for r in v.story[1].rows])
        run2.close()
    run.close()
go(make(), "plain")
go(make(extra=("mzrt",)), "mzrt", preview=True)
go(make(extra=("hmdb","mzrt")), "hmdb_mzrt")
# numeric ids
g = pd.DataFrame({"entrez_id": rng.choice(np.arange(1, 100000), 60, replace=False)})
for j in range(8): g[f"GSM{2000+j}"] = rng.poisson(np.exp(rng.normal(5, 2, 60)))
go(g, "entrez", preview=True)
