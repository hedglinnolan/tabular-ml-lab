import sys, warnings, logging, traceback
warnings.filterwarnings("ignore"); logging.disable(logging.WARNING)
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from pathlib import Path
import numpy as np, pandas as pd, duckdb
from turbotab.core.decisions import ProjectState
from turbotab.core.tests.graph_runner import GraphRun
from turbotab.core.datastore import DataStore
F = Path("/private/tmp/turbotab-audit/C-skeptic/f")
print("duckdb", duckdb.__version__)
try: print(duckdb.sql("select stddev_samp(x) from (values (1.0::double),(2.0),('inf'::double)) t(x)").fetchall())
except Exception as e: print("raw duckdb stddev over inf:", type(e).__name__, e)
rng = np.random.default_rng(1)
n = 300
df = pd.DataFrame({"pid": range(n), "kcal": rng.normal(2000, 400, n).round(), "protein_g": rng.normal(80, 20, n).round(1),
                   "ldl": rng.normal(120, 30, n).round(1)})
df.loc[5, "kcal"] = 0
df["protein_density"] = df.protein_g / df.kcal * 1000
src = F / "c10.csv"; df.to_csv(src, index=False)
print("line with inf:", open(src).read().splitlines()[6])
run = GraphRun(src, F / "proj_c10")
print("ingest ok:", [(c["name"], c["physical_type"]) for c in run.info["columns"]])
for stage in ("profile", "findings", "target_info"):
    try:
        st = ProjectState.model_validate(dict(lens=["dietary"], target="ldl"))
        out = run.run(st, upto=[stage])
        print(stage, "ok:", stage in out)
    except Exception as e:
        print(stage, "FAILED:", type(e).__name__, str(e)[:150])
store = DataStore(run.raw, 1 << 30)
try:
    s = store.summaries(["ldl", "protein_density"]); print("summaries ok", {k: (v.get('std') if isinstance(v, dict) else v) for k, v in s.items()} if isinstance(s, dict) else type(s))
except Exception as e:
    print("store.summaries FAILED:", type(e).__name__, str(e)[:120])
run.close()
