from turbotab.core.decisions import ProjectState, EnergyAdjustment
from turbotab.core.models.pipeline import model_predictors, design_spec, shared_steps
import pandas as pd, numpy as np
st = ProjectState(target="y", task="regression", purpose="inference",
                  roles={"protein_g": "exposure", "energy_kcal": "energy", "age": "covariate"},
                  energy_adjustment=EnergyAdjustment(method="none", energy_column=None, nutrients=[], log_transform=False, strata=None),
                  missing="impute")
preds = model_predictors(st); print("predictors under the UI's 'No adjustment' decision:", preds)
df = pd.DataFrame(np.random.default_rng(0).normal(size=(50, 3)) + 5, columns=["protein_g", "energy_kcal", "age"])
print("shared steps:", [n for n, _ in shared_steps(design_spec(st, df, preds))])
