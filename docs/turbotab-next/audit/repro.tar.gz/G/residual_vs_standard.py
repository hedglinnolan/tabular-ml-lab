"""App's residual method (energy dropped) vs the standard model, with a sex covariate."""
import numpy as np, pandas as pd
from turbotab.core.methods.energy import EnergyAdjuster, METHOD_TABLE
rng = np.random.default_rng(1)
n = 20000
sex = rng.integers(0, 2, n).astype(float)                # 1 = men
E = 1800 + 600*sex + 450*rng.normal(size=n)              # men eat more
prot = 0.035*E + 8*sex + 12*rng.normal(size=n)           # men: higher protein density too
Y = 0.30*prot + 0.006*E + 1.5*sex + 4*rng.normal(size=n) # energy itself matters (body size)
X = pd.DataFrame({"protein_g": prot, "energy_kcal": E, "sex": sex})
def ols(cols, y):
    A = np.column_stack([np.ones(len(y))] + [np.asarray(c) for c in cols]); return np.linalg.lstsq(A, y, rcond=None)[0]
b_std = ols([prot, E, sex], Y)[1]
adj = EnergyAdjuster("residual", "energy_kcal", ["protein_g"]).fit(X)
Z = adj.transform(X); print("residual output columns:", list(Z.columns))
b_res = ols([Z["protein_g_adj"], Z["sex"]], Y)[1]
b_res_E = ols([Z["protein_g_adj"], E, sex], Y)[1]
print(f"standard  Y~N+E+sex           beta_N = {b_std:.4f}")
print(f"app residual Y~N_adj+sex (E out) beta_N = {b_res:.4f}   ({100*(b_res/b_std-1):+.1f}% vs standard)")
print(f"Willett/Stampfer residual + E Y~N_adj+E+sex beta_N = {b_res_E:.4f}")
print("app estimand:", METHOD_TABLE['residual']['estimand'][:80])
