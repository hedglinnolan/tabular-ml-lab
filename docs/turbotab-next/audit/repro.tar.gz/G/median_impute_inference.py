"""Inference after the app's only imputation (SimpleImputer median, outcome not used): bias and CI coverage."""
import numpy as np, statsmodels.api as sm
from sklearn.impute import SimpleImputer
rng = np.random.default_rng(3)
B1, reps, n = 1.0, 400, 600
est, cover, est_cc, cover_cc = [], [], [], []
for _ in range(reps):
    x1 = rng.normal(size=n); x2 = 0.6*x1 + 0.8*rng.normal(size=n)   # exposure x1, covariate x2
    y = B1*x1 + 1.0*x2 + rng.normal(size=n)
    miss = rng.random(n) < 1/(1+np.exp(-(x1 - 0.3)))                 # x2 missing (MAR on x1), ~43%
    X = np.column_stack([x1, np.where(miss, np.nan, x2)])
    Xi = SimpleImputer(strategy="median").fit_transform(X)            # the app's numeric imputer
    r = sm.OLS(y, sm.add_constant(Xi)).fit(); lo, hi = r.conf_int()[1]
    est.append(r.params[1]); cover.append(lo <= B1 <= hi)
    keep = ~miss; rc = sm.OLS(y[keep], sm.add_constant(X[keep])).fit(); lo, hi = rc.conf_int()[1]
    est_cc.append(rc.params[1]); cover_cc.append(lo <= B1 <= hi)
print(f"true beta_x1 = {B1}; share of x2 missing ~ {miss.mean():.0%}")
print(f"median single imputation: mean beta = {np.mean(est):.3f}, 95% CI coverage = {np.mean(cover):.1%}")
print(f"complete cases          : mean beta = {np.mean(est_cc):.3f}, 95% CI coverage = {np.mean(cover_cc):.1%}")
