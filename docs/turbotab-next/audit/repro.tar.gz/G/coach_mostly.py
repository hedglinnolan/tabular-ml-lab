from types import SimpleNamespace as NS
from turbotab.core.coach import energy_coach
for r0 in (0.31, 0.45, 0.6):
    view = NS(kind="relationship", r_before=r0, r_after=0.0, y_label_before="sodium_mg", x_label="energy_kcal", coach=[])
    energy_coach(NS(method="residual"), [view], None)
    print(f"r={r0:.2f} (energy explains r^2={r0*r0:.0%} of variance) ->", [n.text for n in view.coach][0])
