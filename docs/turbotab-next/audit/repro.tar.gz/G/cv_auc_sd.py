"""Spread of a single 5-fold CV AUC estimate across fresh samples, by n (true AUC ~0.75)."""
import numpy as np, warnings
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold, cross_val_score
warnings.filterwarnings("ignore")
rng = np.random.default_rng(0)
def draw(n):
    X = rng.normal(size=(n, 5)); lin = X @ np.array([0.6, 0.4, 0.2, 0, 0]) - 1.0
    y = (rng.random(n) < 1/(1+np.exp(-lin))).astype(int); return X, y
for n in (50, 100, 200, 500, 1000):
    est = []
    for rep in range(150):
        X, y = draw(n)
        if y.sum() < 10 or (n - y.sum()) < 10: continue
        cv = StratifiedKFold(5, shuffle=True, random_state=rep)
        est.append(cross_val_score(LogisticRegression(), X, y, cv=cv, scoring="roc_auc").mean())
    est = np.array(est)
    print(f"n={n:5d}  mean CV AUC={est.mean():.3f}  SD across samples={est.std():.3f}  95% range ±{1.96*est.std():.3f}")
