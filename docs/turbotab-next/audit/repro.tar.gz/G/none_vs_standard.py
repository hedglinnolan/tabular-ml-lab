"""Does energy_adjustment 'none' leave the energy column in the model? Compare to Y~N+C and Y~N+E+C."""
import numpy as np, pandas as pd
from turbotab.core.decisions import ProjectState, EnergyAdjustment
from turbotab.core.models.pipeline import model_predictors, design_spec, shared_steps, transformer
from turbotab.core.methods.energy import METHOD_TABLE
from turbotab.core.voice import sentence_for
rng = np.random.default_rng(0)
n = 4000
C = rng.normal(size=n)                      # covariate, e.g. age (standardized)
E = 2000 + 400*rng.normal(size=n) + 150*C   # energy correlates with C
N = 0.04*E + 15*rng.normal(size=n)          # nutrient tracks energy
Y = 0.5*N + 0.01*E + 1.0*C + rng.normal(size=n)
df = pd.DataFrame({"protein_g": N, "energy_kcal": E, "age": C, "y": Y})
roles = {"protein_g": "exposure", "energy_kcal": "energy", "age": "covariate", "y": "exposure"}
roles.pop("y")
for method in ["none", "standard", "residual"]:
    st = ProjectState(target="y", task="regression", purpose="inference", roles=roles,
                      energy_adjustment=EnergyAdjustment(method=method, energy_column="energy_kcal",
                                                         nutrients=["protein_g"]),
                      missing="impute")
    preds = model_predictors(st)
    spec = design_spec(st, df[preds], preds)
    t = transformer(shared_steps(spec))
    M = t.fit_transform(df[spec.inputs])
    M = pd.DataFrame(M, columns=list(t.get_feature_names_out())) if not isinstance(M, pd.DataFrame) else M
    from sklearn.linear_model import LinearRegression
    lr = LinearRegression().fit(M, df["y"])
    print(f"\n[{method}] model matrix columns: {list(M.columns)}")
    print("  coefs:", dict(zip(M.columns, np.round(lr.coef_, 4))))
    print("  estimand shown:", METHOD_TABLE[method]["estimand"][:110])
    print("  sentence:", sentence_for({"kind": "set_energy_adjustment", "method": method,
                                       "energy_column": "energy_kcal", "nutrients": ["protein_g"]}, st))
X1 = np.column_stack([np.ones(n), N, C]); b_abs = np.linalg.lstsq(X1, Y, rcond=None)[0]
X2 = np.column_stack([np.ones(n), N, E, C]); b_std = np.linalg.lstsq(X2, Y, rcond=None)[0]
print("\nOLS absolute Y~N+C   : beta_N =", round(b_abs[1], 4))
print("OLS standard Y~N+E+C : beta_N =", round(b_std[1], 4))
