"""No covariates: the app's residual model (E out) vs the standard model — coefficient and CI."""
import numpy as np, pandas as pd, statsmodels.api as sm
from turbotab.core.methods.energy import EnergyAdjuster
rng = np.random.default_rng(7); n = 3000
E = 2000 + 500*rng.normal(size=n); N = 0.035*E + 12*rng.normal(size=n)
Y = 0.30*N + 0.010*E + 4*rng.normal(size=n)
X = pd.DataFrame({"protein_g": N, "energy_kcal": E})
Z = EnergyAdjuster("residual", "energy_kcal", ["protein_g"]).fit(X).transform(X)
std = sm.OLS(Y, sm.add_constant(np.column_stack([N, E]))).fit()
res = sm.OLS(Y, sm.add_constant(Z[["protein_g_adj"]].to_numpy())).fit()
print("standard Y~N+E : beta=%.4f  95%% CI %s" % (std.params[1], np.round(std.conf_int()[1], 4)))
print("app residual   : beta=%.4f  95%% CI %s" % (res.params[1], np.round(res.conf_int()[1], 4)))
