import numpy as np, statsmodels.api as sm
from sklearn.linear_model import Ridge, LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
rng=np.random.default_rng(1)
n=300
g=rng.integers(0,2,n); z=rng.normal(size=n)
y=1.5*g+0.8*z+rng.normal(size=n)
for lab,(a,b) in {"indicator 0/1":(0,1),"values 1/2":(1,2),"values 3/7":(3,7),"values -1/1":(-1,1)}.items():
    x=np.where(g==1,b,a)
    X=sm.add_constant(np.c_[x,z]); m=sm.OLS(y,X).fit()
    ci=m.conf_int()[1]
    print(f"{lab:14s} OLS slope={m.params[1]:.3f} CI=({ci[0]:.3f},{ci[1]:.3f}) t={m.tvalues[1]:.2f} pred(row0)={m.fittedvalues[0]:.4f}")
print("ridge alpha=50 without / with standardizing, predictions for row 0 and slope:")
for lab,(a,b) in {"indicator 0/1":(0,1),"values 3/7":(3,7),"values 0/100":(0,100)}.items():
    x=np.where(g==1,b,a); Xm=np.c_[x,z]
    r=Ridge(alpha=50).fit(Xm,y); p=make_pipeline(StandardScaler(),Ridge(alpha=50)).fit(Xm,y)
    print(f"{lab:14s} raw ridge pred0={r.predict(Xm[:1])[0]:.4f} coef={r.coef_[0]:.4f} | standardized ridge pred0={p.predict(Xm[:1])[0]:.4f}")
