import numpy as np
rng=np.random.default_rng(5)
n=2000; R=1000
def slope(x,y): 
    xc=x-x.mean(); return (xc*(y-y.mean())).sum()/(xc**2).sum()
res={}
for name in ["MCAR 30% dropped","MAR on x only 30% dropped","Missing depends on y (MNAR) ~25% dropped","Missing depends on y (MNAR) ~8% dropped","MAR on z (z prognostic, adjusting for z not possible since z missing) ~12%"]:
    res[name]=[];
fr={k:[] for k in res}
for r in range(R):
    x=rng.normal(size=n); z=rng.normal(size=n); y=1.0*x+0.5*z+rng.normal(size=n)
    for name in res:
        if name.startswith("MCAR"): m=rng.random(n)<0.30
        elif name.startswith("MAR on x only"): m=rng.random(n)< 1/(1+np.exp(-(1.2*x-1.3)))   # depends on x only
        elif "~25%" in name: m=rng.random(n)< 1/(1+np.exp(-(1.5*y-2.0)))
        elif "~8%" in name: m=rng.random(n)< 1/(1+np.exp(-(1.5*y-3.5)))
        else: m=rng.random(n)< 1/(1+np.exp(-(1.5*z-2.7)))
        # y missing if m (outcome observed only when not m) -- complete case slope of y on x
        keep=~m
        res[name].append(slope(x[keep],y[keep])); fr[name].append(m.mean())
for name in res:
    print(f"{name:75s} dropped={np.mean(fr[name]):.3f}  slope mean={np.mean(res[name]):.3f} (truth 1.000)")
