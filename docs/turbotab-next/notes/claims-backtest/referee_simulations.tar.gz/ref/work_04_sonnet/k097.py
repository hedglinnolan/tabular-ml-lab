import numpy as np
from scipy import stats
from scipy.linalg import sqrtm
rng=np.random.default_rng(7)
def sym_inv_sqrt(A):
    w,V=np.linalg.eigh(A); w=np.clip(w,1e-10,None); return V@np.diag(w**-0.5)@V.T
def fit(X,y,cl,c):   # c: contrast vector for coefficient of interest
    n,p=X.shape; ids=np.unique(cl); XtXi=np.linalg.inv(X.T@X); b=XtXi@X.T@y; e=y-X@b
    # iid
    s2=e@e/(n-p); se_iid=np.sqrt(s2*(c@XtXi@c)); df_iid=n-p
    # CR2 + Bell-McCaffrey (Satterthwaite under working model I)
    H=X@XtXi@X.T
    meat=np.zeros((p,p)); A=[]; 
    for g in ids:
        i=np.where(cl==g)[0]; Ag=sym_inv_sqrt(np.eye(len(i))-H[np.ix_(i,i)]); A.append((i,Ag))
        u=X[i].T@Ag@e[i]; meat+=np.outer(u,u)
    V=XtXi@meat@XtXi; se_cr2=np.sqrt(c@V@c)
    # BM dof: d = (sum eig G)^2 / sum eig^2 G, G_{gh} = g_g' g_h with g_g = (I-H)_g' A_g X_g (XtXi c)
    IH=np.eye(n)-H; a=X@XtXi@c  # (n,)
    gs=[]
    for i,Ag in A:
        # vector of length n: (I-H)[:, i] @ Ag @ X_i @ XtXi c
        gs.append(IH[:,i]@Ag@(X[i]@(XtXi@c)))
    Gm=np.array(gs)@np.array(gs).T
    ev=np.linalg.eigvalsh(Gm); ev=ev[ev>1e-12]
    dof=ev.sum()**2/(ev**2).sum()
    return b@c, se_iid, df_iid, se_cr2, dof
def sim(G,m,exposure,R=1500):
    cov_iid=cov_cr2=0; w_iid=[];w_cr2=[]
    for r in range(R):
        cl=np.repeat(np.arange(G),m)
        u=rng.normal(size=G)[cl]*np.sqrt(0.5); e=rng.normal(size=G*m)*np.sqrt(0.5)
        if exposure=="person-level": x=np.repeat(rng.normal(size=G),m)
        else:
            x=rng.normal(size=G*m); x=x-np.array([x[cl==g].mean() for g in range(G)])[cl]   # within-cluster only
        y=0.0*x+u+e
        X=np.c_[np.ones(G*m),x]; c=np.array([0,1.0])
        bh,sei,dfi,sec,dof=fit(X,y,cl,c)
        ti=stats.t.ppf(.975,dfi); tc=stats.t.ppf(.975,dof)
        cov_iid+=abs(bh)<=ti*sei; cov_cr2+=abs(bh)<=tc*sec
        w_iid.append(sei);w_cr2.append(sec)
    print(f"G={G:3d} m={m} exposure={exposure:12s}: coverage iid={cov_iid/R:.3f}  CR2+BM={cov_cr2/R:.3f}")
sim(20,5,"person-level"); sim(50,5,"person-level"); sim(20,5,"within-only")
