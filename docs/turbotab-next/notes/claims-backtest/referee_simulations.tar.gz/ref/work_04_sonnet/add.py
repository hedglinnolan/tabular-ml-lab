import sys, json
OUT="/private/tmp/claude-501/-Users-nhedglin-tabular-ml-lab/a12607bd-3f0c-4a23-8d52-bda4a2c1292e/scratchpad/ref/out/merits_04_sonnet.jsonl"
obj=json.load(sys.stdin)
req=["id","truth","failing_part","narrowest_regime","reason","basis_used","citations","bite","bite_note","confidence"]
for k in req: assert k in obj, k
assert obj["truth"] in ("true","overstated","false","not_established")
with open(OUT,"a") as f: f.write(json.dumps(obj, ensure_ascii=False)+"\n")
print("ok", obj["id"])
