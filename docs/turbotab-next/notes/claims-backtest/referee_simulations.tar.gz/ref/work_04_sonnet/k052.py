import numpy as np, sys, time
from scipy import stats
from sklearn.model_selection import RepeatedKFold
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
seed=int(sys.argv[1]); R=int(sys.argv[2]); n=int(sys.argv[3])
rng=np.random.default_rng(seed)
t0=time.process_time()
rej=0; rej_corr=0; tot=0; widths=[]
for rep in range(R):
    X=rng.normal(size=(n,5)); y=rng.integers(0,2,size=n)  # labels independent of X: true accuracy difference = 0 exactly
    rkf=RepeatedKFold(n_splits=5,n_repeats=10,random_state=int(rng.integers(1e9)))
    d=[]
    for tr,te in rkf.split(X):
        a=KNeighborsClassifier(5).fit(X[tr],y[tr]).predict(X[te])
        b=LinearDiscriminantAnalysis().fit(X[tr],y[tr]).predict(X[te])
        d.append(np.mean(a==y[te])-np.mean(b==y[te]))
    d=np.array(d); m=d.mean(); s2=d.var(ddof=1); k=len(d)
    t=m/np.sqrt(s2/k)
    p=2*stats.t.sf(abs(t),k-1)
    rej+=p<0.05
    # Nadeau-Bengio corrected: var*(1/k + n_te/n_tr)
    ntr=n*4/5; nte=n/5
    tc=m/np.sqrt(s2*(1/k+nte/ntr))
    pc=2*stats.t.sf(abs(tc),k-1); rej_corr+=pc<0.05
    tot+=1
print(f"n={n} reps={tot} naive_reject={rej/tot:.3f} NB_reject={rej_corr/tot:.3f} cpu={time.process_time()-t0:.1f}s")
