import numpy as np, shap, warnings
warnings.filterwarnings("ignore")
from scipy.stats import spearmanr
from sklearn.ensemble import HistGradientBoostingRegressor as HG, RandomForestRegressor as RF
rng=np.random.default_rng(2)
n=600
for rho in [0.0,0.5,0.9,0.99]:
    z=rng.normal(size=(n,3)); 
    x1=z[:,0]; x2=rho*z[:,0]+np.sqrt(1-rho**2)*z[:,1]; x3=z[:,2]
    X=np.c_[x1,x2,x3]
    y=1.0*x1+1.0*x2+0.5*x3+rng.normal(0,1,n)   # both truly matter equally
    outs={}
    for name,mk in {"RF(max_features=2/3)":lambda s:RF(100,max_features=2/3,min_samples_leaf=5,random_state=s,n_jobs=1),
                    "GBM(subsample .7)":lambda s:HG(max_iter=100,learning_rate=0.05,random_state=s)}.items():
        sv=[]
        for s in range(5):
            m=mk(s).fit(X,y)
            sv.append(shap.TreeExplainer(m).shap_values(X))
        # mean pairwise Spearman across seeds of per-row SHAP for x1, x2, and the group sum x1+x2; and the |SHAP| share of x1
        def pw(f): 
            return np.mean([spearmanr(f(sv[i]),f(sv[j]))[0] for i in range(5) for j in range(i+1,5)])
        share=[np.abs(v[:,0]).mean()/(np.abs(v[:,0]).mean()+np.abs(v[:,1]).mean()) for v in sv]
        print(f"rho={rho:4.2f} {name:22s} rowwise Spearman x1={pw(lambda v:v[:,0]):.2f} x2={pw(lambda v:v[:,1]):.2f} group(x1+x2)={pw(lambda v:v[:,0]+v[:,1]):.2f} | x1 share of group mean|SHAP| across seeds: {np.round(share,2)}")
