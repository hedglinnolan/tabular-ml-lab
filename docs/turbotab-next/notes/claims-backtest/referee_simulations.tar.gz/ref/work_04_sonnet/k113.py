import numpy as np
rng=np.random.default_rng(3)
N=500; x0=rng.normal(size=N)            # fixed observed baseline cohort
def final_risk(x, binary):
    # simple 3-step discrete-time g-formula: covariate evolves, hazard depends on covariate
    L=x.copy(); surv=np.ones_like(x); ev=np.zeros_like(x,bool)
    for t in range(3):
        L=0.6*L+0.5*rng.normal(size=L.shape)
        h=1/(1+np.exp(-(-2.5+0.9*L)))
        surv*= (1-h)
    risk=1-surv   # per-unit final cumulative risk given simulated covariate path
    return (rng.random(risk.shape)<risk).astype(float) if binary else risk
for design in ["resample baseline (iid draws)","each cohort member simulated once (fixed baseline)"]:
  for binary in [False,True]:
    ests=[];ses=[]
    for rep in range(3000):
        x = rng.choice(x0,size=N,replace=True) if design.startswith("resample") else x0
        r=final_risk(x,binary); ests.append(r.mean()); ses.append(r.std(ddof=1)/np.sqrt(N))
    ests=np.array(ests); ses=np.array(ses)
    # true MC sd: for resample design, target = mean over resampling; for fixed design, MC sd conditional on fixed cohort
    print(f"{design:52s} outcome={'0/1 event' if binary else 'risk prob'}: actual MC sd={ests.std(ddof=1):.5f}  mean reported sd/sqrt(n)={ses.mean():.5f}  share of runs reported>=actual={np.mean(ses>=ests.std(ddof=1)):.2f}")
