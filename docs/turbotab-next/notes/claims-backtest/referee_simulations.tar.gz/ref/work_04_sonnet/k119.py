import numpy as np, sys, time, warnings
warnings.filterwarnings("ignore")
from sklearn.ensemble import HistGradientBoostingClassifier as HGB
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import log_loss, brier_score_loss
from sklearn.linear_model import LogisticRegression
import xgboost as xgb

def dgp(rng, n, p, signal, prev_shift):
    X = rng.normal(size=(n,p))
    f = (X[:,0] + 0.8*X[:,1]*X[:,2] + 0.7*np.sin(2*X[:,3]) + 0.6*(X[:,4]>0.5) - 0.5*X[:,5]**2 + 0.4*X[:,6]*(X[:,7]>0))
    f = (f - 0.0)
    eta = signal*f/ 1.0 + prev_shift
    pr = 1/(1+np.exp(-eta))
    y = (rng.random(n) < pr).astype(int)
    return X, y

def calib_slope(y, p):
    p = np.clip(p, 1e-6, 1-1e-6)
    z = np.log(p/(1-p)).reshape(-1,1)
    m = LogisticRegression(C=1e6, max_iter=500).fit(z, y)
    return m.coef_[0,0]

def make(model, par):
    if model=='hgb':
        return HGB(learning_rate=par['lr'], max_leaf_nodes=par['leaves'], min_samples_leaf=par['msl'],
                   l2_regularization=par['l2'], max_iter=par['iters'], early_stopping=False, random_state=0)
    else:
        return xgb.XGBClassifier(learning_rate=par['lr'], max_depth=par['depth'], min_child_weight=par['mcw'],
                   reg_lambda=par['l2'], n_estimators=par['iters'], n_jobs=1, random_state=0, verbosity=0, tree_method='hist')

def sample_cands(rng, model, S):
    out=[]
    for _ in range(S):
        if model=='hgb':
            out.append(dict(lr=float(np.exp(rng.uniform(np.log(0.01),np.log(0.3)))), leaves=int(rng.integers(3,32)),
                            msl=int(rng.integers(5,60)), l2=float(np.exp(rng.uniform(np.log(0.01),np.log(10)))), iters=int(rng.integers(50,301))))
        else:
            out.append(dict(lr=float(np.exp(rng.uniform(np.log(0.01),np.log(0.3)))), depth=int(rng.integers(1,7)),
                            mcw=float(np.exp(rng.uniform(np.log(1),np.log(20)))), l2=float(np.exp(rng.uniform(np.log(0.1),np.log(20)))), iters=int(rng.integers(50,301))))
    return out

DEF = {'hgb':dict(lr=0.1, leaves=31, msl=20, l2=0.0, iters=100), 'xgb':dict(lr=0.3, depth=6, mcw=1, l2=1.0, iters=100)}

def run(model, ntr, p, signal, shift, R, S, seed, nte=20000, folds=3):
    rng = np.random.default_rng(seed)
    Xte, yte = dgp(np.random.default_rng(999), nte, p, signal, shift)
    rows=[]
    t0=time.process_time()
    for r in range(R):
        X,y = dgp(rng, ntr, p, signal, shift)
        if y.sum()<10 or (1-y).sum()<10: continue
        cands = sample_cands(rng, model, S)
        skf = StratifiedKFold(folds, shuffle=True, random_state=int(rng.integers(1e9)))
        scores = np.zeros(S)
        for tr,va in skf.split(X,y):
            for j,c in enumerate(cands):
                m = make(model,c).fit(X[tr],y[tr])
                scores[j]+=log_loss(y[va], np.clip(m.predict_proba(X[va])[:,1],1e-6,1-1e-6), labels=[0,1])
        best = cands[int(np.argmin(scores))]
        out={}
        for name,par in (('def',DEF[model]),('tuned',best)):
            m = make(model,par).fit(X,y); pt = np.clip(m.predict_proba(Xte)[:,1],1e-6,1-1e-6)
            out[name]=(log_loss(yte,pt), brier_score_loss(yte,pt), calib_slope(yte,pt))
        rows.append(out['def']+out['tuned'])
    a=np.array(rows)
    d=a[:,3:]-a[:,:3]   # tuned - default
    print(f"{model} ntr={ntr} p={p} sig={signal} shift={shift} S={S} reps={len(a)} prev~{yte.mean():.3f} cpu={time.process_time()-t0:.0f}s")
    names=['logloss','brier','calib_slope']
    for k,nm in enumerate(names):
        print(f"  {nm}: default={a[:,k].mean():.4f} tuned={a[:,3+k].mean():.4f} diff(tuned-def)={d[:,k].mean():+.4f} se={d[:,k].std(ddof=1)/np.sqrt(len(a)):.4f}  frac tuned better={(d[:,k]<0).mean() if k<2 else (abs(a[:,3+k]-1)<abs(a[:,k]-1)).mean():.2f}")
    return a

if __name__=='__main__':
    model=sys.argv[1]; ntr=int(sys.argv[2]); p=int(sys.argv[3]); signal=float(sys.argv[4]); shift=float(sys.argv[5]); R=int(sys.argv[6]); S=int(sys.argv[7]); seed=int(sys.argv[8])
    run(model,ntr,p,signal,shift,R,S,seed)
