import numpy as np
from scipy import stats
rng=np.random.default_rng(11)
N=2000; sb2=1.0; sw2=2.0; mu=0.0
zq=stats.norm.ppf([0.05,0.95])
truth_q=mu+np.sqrt(sb2)*zq; cut=mu-1.0; truth_share=stats.norm.cdf((cut-mu)/np.sqrt(sb2))
print("truth: P5,P95 =",truth_q.round(3)," share below cut =",round(truth_share,3))
for m in [2,5,20,100,500,2000]:
    R=1500; err={'single day':[], 'mean of available days':[], 'variance-adjusted':[]}; sh={k:[] for k in err}
    for r in range(R):
        b=rng.normal(0,np.sqrt(sb2),N); d1=mu+b+rng.normal(0,np.sqrt(sw2),N)
        idx=rng.choice(N,m,replace=False); d2=np.full(N,np.nan); d2[idx]=mu+b[idx]+rng.normal(0,np.sqrt(sw2),m)
        # within var from the m repeaters
        wv = np.var(d1[idx]-d2[idx],ddof=1)/2 if m>=2 else np.nan
        mean_av=np.where(np.isnan(d2),d1,(d1+np.nan_to_num(d2))/2)
        tot=d1.var(ddof=1); sb2_hat=max(tot-wv,0.05*tot)
        adj_sd=np.sqrt(sb2_hat)
        qs={'single day':np.quantile(d1,[.05,.95]),'mean of available days':np.quantile(mean_av,[.05,.95]),
            'variance-adjusted':d1.mean()+adj_sd*zq}
        shs={'single day':np.mean(d1<cut),'mean of available days':np.mean(mean_av<cut),'variance-adjusted':stats.norm.cdf((cut-d1.mean())/adj_sd)}
        for k in err:
            err[k].append(np.abs(qs[k]-truth_q).mean()); sh[k].append(shs[k]-truth_share)
    print(f"repeaters m={m:5d}: " + " | ".join(f"{k}: mean|Perr|={np.mean(err[k]):.2f} share bias={np.mean(sh[k]):+.3f} sd={np.std(sh[k]):.3f}" for k in err))
