import os
os.environ["OMP_NUM_THREADS"]="1"
import numpy as np
rng=np.random.default_rng(0)
n=5000
g_c=rng.gamma(9,25,n); g_f=rng.gamma(6,12,n); g_p=rng.gamma(8,9,n)    # grams carb, fat, protein
E=4*g_c+9*g_f+4*g_p                                                   # total kcal (exact Atwater)
# true outcome: each kcal of carb/protein/fat has effect per kcal: carb 0, fat +0.002, protein -0.001
y=0.002*9*g_f -0.001*4*g_p + 0.0005*4*g_c + rng.normal(0,1,n)
# leave-one-out (omit carb): y ~ E + fat + protein, in GRAMS vs in KCAL
Xg=np.c_[np.ones(n),E,g_f,g_p]; Xk=np.c_[np.ones(n),E,9*g_f,4*g_p]
bg=np.linalg.lstsq(Xg,y,rcond=None)[0]; bk=np.linalg.lstsq(Xk,y,rcond=None)[0]
print("fitted values identical:",np.allclose(Xg@bg,Xk@bk))
print("grams model: coef fat per g = %.5f, protein per g=%.5f"%(bg[2],bg[3]))
print("kcal model : coef fat per kcal=%.6f, protein per kcal=%.6f"%(bk[2],bk[3]))
print("recovering kcal-for-kcal from grams model: fat %.6f protein %.6f"%(bg[2]/9,bg[3]/4))
# implied exchange in grams model: +1 g fat at fixed E means carb falls by 9/4 g
print("1 g fat at fixed E: carb change =",-9/4,"g ; energy change = 0")
