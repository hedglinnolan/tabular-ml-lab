import numpy as np
rng=np.random.default_rng(2)
def sim(n,prev,rec,spec,R=20000):
    npos=rng.binomial(n,prev,size=R)
    tp=rng.binomial(npos,rec); fn=npos-tp
    nneg=n-npos
    tn=rng.binomial(nneg,spec); fp=nneg-tn
    f1p=2*tp/np.maximum(2*tp+fp+fn,1)
    f1n=2*tn/np.maximum(2*tn+fn+fp,1)
    macro=(f1p+f1n)/2
    k=n*prev
    claim=0.5/np.sqrt(k)        # half-width/1.96 : sd under worst case
    return f1p.std(), macro.std(), claim
print("n prev rec spec | sd(F1_rare) sd(macroF1) claim_sd(0.5/sqrt k)")
for n,prev,rec,spec in [(200,.1,.5,.9),(200,.1,.7,.9),(500,.05,.5,.95),(500,.05,.6,.8),(1000,.02,.5,.98),(1000,.02,.5,.9),(100,.2,.8,.8),(300,.3,.7,.7),(2000,.01,.5,.97)]:
    a,b,c=sim(n,prev,rec,spec)
    print(n,prev,rec,spec,"| %.4f %.4f %.4f  ratio_rareF1/claim=%.2f macro/claim=%.2f"%(a,b,c,a/c,b/c))
