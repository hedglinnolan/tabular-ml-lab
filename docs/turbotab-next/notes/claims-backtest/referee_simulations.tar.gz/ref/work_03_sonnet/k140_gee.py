import os, sys, time
os.environ["OMP_NUM_THREADS"]="1"; os.environ["OPENBLAS_NUM_THREADS"]="1"; os.environ["VECLIB_MAXIMUM_THREADS"]="1"
import numpy as np, warnings
import statsmodels.api as sm
from scipy import stats
from scipy.linalg import block_diag, sqrtm
warnings.filterwarnings("ignore")

def cr2_test(Xt, resid, Vlist, idx_list, c):
    """CR2 + Bell-McCaffrey Satterthwaite df for scalar contrast c. Xt: design in mean-derivative scale (N x p)."""
    N,p=Xt.shape
    Vinv=[np.linalg.inv(V) for V in Vlist]
    Vfull=block_diag(*Vlist); Wfull=block_diag(*Vinv)
    M=np.linalg.inv(Xt.T@Wfull@Xt)
    H=Xt@M@Xt.T@Wfull
    IH=np.eye(N)-H
    Omega=IH@Vfull@IH.T
    gs=[]
    for j,ix in enumerate(idx_list):
        Vj=Vlist[j]
        # D_j: Vj = D_j' D_j (upper chol)
        Dj=np.linalg.cholesky(Vj).T
        Bj=Dj@ (IH[ix,:]@Vfull@IH[ix,:].T) @Dj.T
        w,U=np.linalg.eigh(Bj)
        Bm12=U@np.diag(1/np.sqrt(np.maximum(w,1e-12)))@U.T
        Aj=Dj.T@Bm12@Dj
        gj=Aj.T@Vinv[j]@Xt[ix,:]@M@c
        gs.append(gj)
    # variance estimate
    Vhat=sum((g@resid[ix])**2 for g,ix in zip(gs,idx_list))
    # Satterthwaite df: z_j = a_j'(IH) eps, Cov = a_j' Omega a_k
    Mmat=np.zeros((len(gs),len(gs)))
    avecs=[]
    for g,ix in zip(gs,idx_list):
        a=np.zeros(N); a[ix]=g; avecs.append(a)
    Amat=np.array(avecs)
    Cm=Amat@Omega@Amat.T
    df=np.trace(Cm)**2/ (Cm**2).sum()
    return Vhat, df

def make_data(rng, kind, design, J=12, icc=0.2):
    sizes=rng.integers(4,40,size=J) if design.endswith("unbal") else np.full(J,15)
    cl=np.repeat(np.arange(J),sizes)
    N=len(cl)
    if design.startswith("clus6"):
        trt=np.zeros(J); trt[rng.permutation(J)[:6]]=1; x=trt[cl]
    elif design.startswith("clus3"):
        trt=np.zeros(J); trt[rng.permutation(J)[:3]]=1; x=trt[cl]
    elif design.startswith("within"):
        x=rng.binomial(1,0.5,size=N).astype(float)
    b=rng.normal(size=J)
    if kind=="gauss":
        sd_b=np.sqrt(icc/(1-icc))
        y=sd_b*b[cl]+rng.normal(size=N)
    elif kind=="brare":
        eta=-3.2+(1.3*b[cl])
        y=rng.binomial(1,1/(1+np.exp(-eta))).astype(float)
    else:
        eta=-1.4+ (0.9*b[cl])      # ~20% prevalence, random intercept sd 0.9
        y=rng.binomial(1,1/(1+np.exp(-eta))).astype(float)
    return y,x,cl

def one(rng,kind,design):
    y,x,cl=make_data(rng,kind,design)
    X=sm.add_constant(x)
    fam=sm.families.Gaussian() if kind=="gauss" else sm.families.Binomial()
    mod=sm.GEE(y,X,groups=cl,family=fam,cov_struct=sm.cov_struct.Exchangeable())
    res=mod.fit(maxiter=50)
    beta=res.params
    eta=X@beta
    if kind=="gauss":
        mu=eta; dmu=np.ones_like(eta); var=np.ones_like(eta)*res.scale
    else:
        mu=1/(1+np.exp(-eta)); dmu=mu*(1-mu); var=mu*(1-mu)
    rho=res.cov_struct.dep_params
    rho=float(np.atleast_1d(rho)[0])
    Xt=X*dmu[:,None]
    resid=y-mu
    idx=[np.where(cl==j)[0] for j in np.unique(cl)]
    Vl=[]
    for ix in idx:
        n=len(ix); R=np.full((n,n),rho); np.fill_diagonal(R,1.0)
        s=np.sqrt(var[ix]); Vl.append(s[:,None]*R*s[None,:])
    c=np.array([0.0,1.0])
    Vh,df=cr2_test(Xt,resid,Vl,idx,c)
    se=np.sqrt(Vh)
    t=beta[1]/se
    p_bm=2*stats.t.sf(abs(t),df)
    p_z=2*stats.norm.sf(abs(t))
    # also naive robust (CR0) with z
    return p_bm,p_z,df

if __name__=="__main__":
    kind,design,R=sys.argv[1],sys.argv[2],int(sys.argv[3])
    seed=int(sys.argv[4]) if len(sys.argv)>4 else 0
    rng=np.random.default_rng(seed)
    t0=time.process_time()
    out=[]
    for r in range(R):
        try: out.append(one(rng,kind,design))
        except Exception as e: pass
        if time.process_time()-t0>50: break
    out=np.array(out)
    print(kind,design,"reps",len(out),"reject@.05 BM-t: %.3f   z-with-CR2se: %.3f   median df %.1f  min df %.1f  cpu %.1fs"%((out[:,0]<.05).mean(),(out[:,1]<.05).mean(),np.median(out[:,2]),out[:,2].min(),time.process_time()-t0))
