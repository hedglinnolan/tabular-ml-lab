import numpy as np
rng = np.random.default_rng(1)
H, J, m = 6, 2, 30   # strata, PSUs/stratum, persons per PSU
R = 4000
def one(rng):
    est=[];se_dom=[];se_del=[]
    pass
res=[]
for r in range(R):
    ys=[];ws=[];ds=[];hs=[];ps=[]
    for h in range(H):
        wh = 100*(1+0.5*h)
        for j in range(J):
            pj = rng.beta(0.6,1.8)          # PSU-level subgroup prevalence (clustered membership)
            d = rng.random(m)<pj
            u = rng.normal(0,1.0)           # PSU effect
            y = 2.0 + u + rng.normal(0,1.0,m) + 0.5*d
            ys.append(y); ws.append(np.full(m,wh)); ds.append(d)
            hs.append(np.full(m,h)); ps.append(np.full(m,h*J+j))
    y=np.concatenate(ys); w=np.concatenate(ws); d=np.concatenate(ds); h=np.concatenate(hs); p=np.concatenate(ps)
    if d.sum()<5: continue
    mu = (w*d*y).sum()/(w*d).sum()
    def var_lin(keep, y,w,d,h,p):
        # Taylor-linearized variance of domain mean using ultimate cluster, lonely PSU contributes 0
        y=y[keep];w=w[keep];d=d[keep];h=h[keep];p=p[keep]
        den=(w*d).sum()
        u=w*d*(y-mu)/den
        v=0.0
        for hh in np.unique(h):
            pj=np.unique(p[h==hh])
            z=np.array([u[p==q].sum() for q in pj])
            n=len(z)
            if n>1: v+= n/(n-1)*((z-z.mean())**2).sum()
        return v
    v_dom = var_lin(np.ones_like(d,bool), y,w,d,h,p)
    v_del = var_lin(d, y,w,d,h,p)   # delete rows outside the subgroup
    res.append((mu,v_dom,v_del))
res=np.array(res)
true_sd=res[:,0].std()
print("n reps",len(res))
print("true SD of subgroup mean   %.4f"%true_sd)
print("mean SE, domain (keep all) %.4f  (RMS %.4f)"%(np.sqrt(res[:,1]).mean(), np.sqrt(res[:,1].mean())))
print("mean SE, delete rows       %.4f  (RMS %.4f)"%(np.sqrt(res[:,2]).mean(), np.sqrt(res[:,2].mean())))
# coverage of 95% CI with z=1.96 around true mean 2.5ish: use mean of mu as center target
tgt=res[:,0].mean()
for name,k in (("domain",1),("delete",2)):
    cov=(np.abs(res[:,0]-tgt)<=1.96*np.sqrt(res[:,k])).mean()
    print(name,"coverage of mean (z=1.96): %.3f"%cov)
