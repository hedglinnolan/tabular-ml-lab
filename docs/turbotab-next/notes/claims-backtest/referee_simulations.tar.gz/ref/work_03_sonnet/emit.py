import json,sys
OUT="/private/tmp/claude-501/-Users-nhedglin-tabular-ml-lab/a12607bd-3f0c-4a23-8d52-bda4a2c1292e/scratchpad/ref/out/merits_03_sonnet.jsonl"
def emit(d):
    with open(OUT,"a") as f: f.write(json.dumps(d,ensure_ascii=False)+"\n")
