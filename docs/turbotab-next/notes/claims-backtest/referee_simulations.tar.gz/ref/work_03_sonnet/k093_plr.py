import numpy as np, time
rng=np.random.default_rng(5)
t0=time.time()
def fit_cf(X,D,Y,K=5):
    n=len(D); idx=rng.permutation(n); folds=np.array_split(idx,K)
    rD=np.zeros(n); rY=np.zeros(n); Dh=np.zeros(n)
    for f in folds:
        tr=np.setdiff1d(idx,f)
        Xt=np.c_[np.ones(len(tr)),X[tr]]; Xf=np.c_[np.ones(len(f)),X[f]]
        bD=np.linalg.lstsq(Xt,D[tr],rcond=None)[0]; bY=np.linalg.lstsq(Xt,Y[tr],rcond=None)[0]
        Dh[f]=Xf@bD; rD[f]=D[f]-Dh[f]; rY[f]=Y[f]-Xf@bY
    theta=(rD*rY).sum()/(rD*rD).sum()
    psi=rD*(rY-theta*rD)
    se=np.sqrt((psi**2).sum()/ (rD*rD).sum()**2)
    r2=1-((D-Dh)**2).sum()/((D-D.mean())**2).sum()
    return theta,se,r2
theta0=1.0
for n in (300,2000):
  for R2 in (0.5,0.9,0.95,0.99):
    cov=[];bias=[];ses=[];r2s=[]
    for r in range(600):
        p=5
        X=rng.normal(size=(n,p)); b=np.ones(p)
        s=X@b; s=s/s.std()
        D=np.sqrt(R2)*s+np.sqrt(1-R2)*rng.normal(size=n)
        Y=theta0*D+ 1.5*s + rng.normal(size=n)     # confounded by s
        th,se,r2=fit_cf(X,D,Y)
        cov.append(abs(th-theta0)<=1.96*se); bias.append(th-theta0); ses.append(se); r2s.append(r2)
    print("n=%d R2=%.2f cf-R2=%.3f bias=%+.4f meanSE=%.4f emp SD=%.4f coverage=%.3f"%(n,R2,np.mean(r2s),np.mean(bias),np.mean(ses),np.std(bias),np.mean(cov)))
print("time",time.time()-t0)
