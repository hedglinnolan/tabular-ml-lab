import numpy as np
from scipy.stats import norm
rng=np.random.default_rng(3)
def hm_se(A,na,nn):
    Q1=A/(2-A);Q2=2*A*A/(1+A)
    return np.sqrt((A*(1-A)+(na-1)*(Q1-A*A)+(nn-1)*(Q2-A*A))/(na*nn))
def auc(x,y):
    from scipy.stats import rankdata
    r=rankdata(np.concatenate([x,y])); na=len(x);nn=len(y)
    return (r[:na].sum()-na*(na+1)/2)/(na*nn)
# binormal true AUC 0.75, 0.9, 0.6; compare empirical SD to H&M at 0.75 assumed
for A_true in (0.6,0.75,0.9,0.97):
    d=np.sqrt(2)*norm.ppf(A_true)
    for na,nn in ((30,270),(100,900),(20,80)):
        a=[auc(rng.normal(d,1,na),rng.normal(0,1,nn)) for _ in range(3000)]
        print("A_true",A_true,"na,nn",na,nn,"emp SD %.4f  HM@0.75 %.4f  HM@true %.4f"%(np.std(a),hm_se(0.75,na,nn),hm_se(A_true,na,nn)))
