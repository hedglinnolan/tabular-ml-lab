import os
os.environ["OMP_NUM_THREADS"]="1"
import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(7)
expit=lambda z:1/(1+np.exp(-z))
def run(cal, bx_age, by_age, N=300000, ncase=3000, beta=0.5):
    age=rng.uniform(30,70,N)
    X=rng.binomial(1,expit(-0.5+bx_age*(age-50)))
    Y=rng.binomial(1,expit(-5+beta*X+by_age*(age-50)))
    cases=np.where(Y==1)[0]; ctrl=np.where(Y==0)[0]
    cases=rng.choice(cases,min(ncase,len(cases)),replace=False)
    ca=age[ctrl]; order=np.argsort(ca); ca_s=ca[order]; ctrl_s=ctrl[order]
    dx=[];da=[]
    for i in cases:
        lo=np.searchsorted(ca_s,age[i]-cal); hi=np.searchsorted(ca_s,age[i]+cal)
        j=ctrl_s[rng.integers(lo,hi)]
        dx.append(X[i]-X[j]); da.append(age[i]-age[j])
    dx=np.array(dx);da=np.array(da)
    # conditional logit 1:1 == logistic (no intercept) of 1 on differences (case-control)
    # use symmetrization trick: random flip so outcome has both labels
    flip=rng.random(len(dx))<0.5
    yy=np.where(flip,0,1); s=np.where(flip,-1,1)
    D1=np.c_[s*dx]; D2=np.c_[s*dx,s*da]
    b1=sm.Logit(yy,D1).fit(disp=0).params[0]
    b2=sm.Logit(yy,D2).fit(disp=0).params[0]
    return b1,b2
for cal,bx,by in [(5,0.04,0.07),(5,0.08,0.10),(10,0.08,0.10),(2,0.08,0.10)]:
    r=np.array([run(cal,bx,by) for _ in range(6)])
    print("caliper +-%d, age->X slope %.2f, age->Y slope %.2f: log-OR true 0.5; CLR matched only mean %.3f ; plus age-diff covariate %.3f"%(cal,bx,by,r[:,0].mean(),r[:,1].mean()))
