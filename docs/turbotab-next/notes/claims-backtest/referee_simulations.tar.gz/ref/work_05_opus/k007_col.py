import numpy as np
rng = np.random.default_rng(2)
p=10; n=100; alphas=np.logspace(-3,3,25)
def fit_ridge_loo(X, y):
    Xm=X.mean(0); ym=y.mean(); Xc=X-Xm; yc=y-ym
    U,s,Vt=np.linalg.svd(Xc, full_matrices=False)
    best=None
    for a in alphas:
        d=s**2/(s**2+a); H=(U*d)@U.T
        r=(yc-H@yc)/(1-np.diag(H)-1/n)
        e=np.mean(r**2)
        if best is None or e<best[0]: best=(e,a)
    a=best[1]; b=Vt.T@((s/(s**2+a))*(U.T@yc)); return b, ym-Xm@b
def sim(r, R=400):
    S=np.eye(p); S[0,1]=S[1,0]=r; L=np.linalg.cholesky(S); beta=np.r_[1.0,1.0,0.5*np.ones(p-2)]
    o=[]; rr=[]
    for _ in range(R):
        X=rng.normal(size=(n,p))@L.T; y=X@beta+2*rng.normal(size=n)
        Xt=rng.normal(size=(2000,p))@L.T; yt=Xt@beta+2*rng.normal(size=2000)
        A=np.c_[np.ones(n),X]; bo=np.linalg.lstsq(A,y,rcond=None)[0]
        o.append(np.mean((np.c_[np.ones(2000),Xt]@bo-yt)**2))
        b,c=fit_ridge_loo(X,y); rr.append(np.mean((Xt@b+c-yt)**2))
    return round(np.mean(o),3), round(np.mean(rr),3)
for r in [0.0,0.9,0.95,0.99]:
    print(r, sim(r), "OLS theory approx", round(4*(1+(p+1)/n * n/(n-p-2)),3))
