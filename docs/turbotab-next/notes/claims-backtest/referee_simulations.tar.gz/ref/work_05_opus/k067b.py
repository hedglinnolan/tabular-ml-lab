import numpy as np
from scipy import stats
exec(open('k067_qrilc.py').read().split('def one')[0])
rng = np.random.default_rng(11)
def mean_cov(n, cens, R=1000):
    c_full=c_si=0; w_full=w_si=0
    for r in range(R):
        y = rng.normal(size=n); lod=np.quantile(y,cens); obs=y>lod
        mu, sd = qrilc_fit(y[obs], n, 1-obs.mean())
        a=(lod-mu)/sd; u=rng.uniform(0, stats.norm.cdf(a), (~obs).sum())
        yc=y.copy(); yc[~obs]=mu+sd*stats.norm.ppf(u)
        se=yc.std(ddof=1)/np.sqrt(n); c_si += abs(yc.mean())<1.96*se
        sef=y.std(ddof=1)/np.sqrt(n); c_full += abs(y.mean())<1.96*sef
    return c_full/R, c_si/R
for n,c in [(50,0.3),(200,0.3),(200,0.5),(500,0.5)]:
    print("mean", n, c, mean_cov(n,c))
