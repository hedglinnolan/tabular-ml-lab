import numpy as np, warnings, time
import statsmodels.api as sm
from statsmodels.genmod.cov_struct import Exchangeable
warnings.filterwarnings("ignore")
rng = np.random.default_rng(1)
G, m, R = 12, 10, 600
def run(level):
    rej = 0; n=0
    for r in range(R):
        u = rng.normal(0, 1, G)
        if level == "cluster":
            x = np.repeat(rng.normal(size=G), m)
        else:
            x = rng.normal(size=G*m) + np.repeat(rng.normal(size=G), m)  # within-varying, correlated within cluster
        y = np.repeat(u, m) + rng.normal(size=G*m)  # beta=0
        X = sm.add_constant(x)
        groups = np.repeat(np.arange(G), m)
        try:
            res = sm.GEE(y, X, groups=groups, cov_struct=Exchangeable(), family=sm.families.Gaussian()).fit(cov_type="robust")
            z = res.params[1]/res.bse[1]
            rej += abs(z) > 1.959964; n += 1
        except Exception as e:
            pass
    return rej/n, n
t=time.time()
for lev in ["cluster","within"]:
    print(lev, run(lev))
print("time", time.time()-t)
