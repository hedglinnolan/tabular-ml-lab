import numpy as np
from sklearn.linear_model import LogisticRegression
rng = np.random.default_rng(3)
n = 300
x = rng.normal(size=n)
g = np.zeros(n, int); g[:22] = 1
eta = -1.0 + 0.6*x + 0.0*g
y = (rng.uniform(size=n) < 1/(1+np.exp(-eta))).astype(int)
# force exactly 2 events in rare level
idx1 = np.where(g==1)[0]; y[idx1] = 0; y[idx1[:2]] = 1
print("events in rare level:", y[g==1].sum(), "of", (g==1).sum())
def stats_of(xx, gg, yy):
    m = LogisticRegression(C=1e2, max_iter=2000).fit(np.c_[xx, gg], yy)
    X1 = np.c_[xx, np.ones_like(gg)]; X0 = np.c_[xx, np.zeros_like(gg)]
    A = (m.predict_proba(X1)[:,1] - m.predict_proba(X0)[:,1]).mean()   # swap into rare category
    Xp = np.c_[xx+1, gg]; Xc = np.c_[xx, gg]
    Bst = (m.predict_proba(Xp)[:,1] - m.predict_proba(Xc)[:,1]).mean()  # shift continuous x by 1
    return A, Bst
B = 1000
res = []; fail = []
for b in range(B):
    i = rng.integers(0, n, n)
    a, bb = stats_of(x[i], g[i], y[i])
    res.append((a, bb)); fail.append(y[i][g[i]==1].sum()==0 or (g[i]==1).sum()==0)
res = np.array(res); fail = np.array(fail)
print("failure rate", fail.mean())
for k, name in [(0, "swap into rare category"), (1, "shift x by 1")]:
    allq = np.quantile(res[:,k], [0.025, 0.975]); okq = np.quantile(res[~fail,k], [0.025, 0.975])
    w = allq[1]-allq[0]
    print(name, "all:", allq.round(4), "dropped:", okq.round(4), "shift/width lo,hi:", ((okq-allq)/w).round(3))
