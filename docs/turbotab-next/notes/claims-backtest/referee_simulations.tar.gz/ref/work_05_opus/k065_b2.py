import numpy as np
from sklearn.linear_model import LogisticRegression
def run(ng, k, seed, B=800, n=300):
    rng = np.random.default_rng(seed)
    x = rng.normal(size=n); g = np.zeros(n, int); g[:ng] = 1
    y = (rng.uniform(size=n) < 1/(1+np.exp(-(-1.0+0.6*x)))).astype(int)
    idx1 = np.where(g==1)[0]; y[idx1]=0; y[idx1[:k]]=1
    res=[]; fail=[]
    for b in range(B):
        i = rng.integers(0,n,n); xx,gg,yy=x[i],g[i],y[i]
        m = LogisticRegression(C=1e2, max_iter=2000).fit(np.c_[xx,gg], yy)
        p1 = m.predict_proba(np.c_[xx,np.ones_like(gg)])[:,1].mean()
        res.append(p1); fail.append(yy[gg==1].sum()==0)
    res=np.array(res); fail=np.array(fail)
    a=np.quantile(res,[.025,.975]); d=np.quantile(res[~fail],[.025,.975]); w=a[1]-a[0]
    # Firth-like reference is unavailable; also compare vs empirical rare-group rate (no model) band
    return fail.mean(), a.round(4), d.round(4), ((d-a)/w).round(3)
for ng,k in [(10,2),(25,3),(40,3)]:
    print(ng,k, run(ng,k,5))
