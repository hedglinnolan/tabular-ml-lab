import numpy as np
from scipy import stats
rng = np.random.default_rng(7)
def qrilc_fit(yobs, n, frac):
    # QRILC-style: regress observed empirical quantiles on normal quantiles (median regression ~ use LS here on sorted values)
    k = len(yobs); ys = np.sort(yobs)
    p = frac + (np.arange(1, k+1) - 0.5)/n  # plotting positions in full sample
    z = stats.norm.ppf(p)
    # LAD via simple iteratively reweighted LS
    A = np.c_[np.ones(k), z]; b = np.linalg.lstsq(A, ys, rcond=None)[0]
    for _ in range(30):
        w = 1/np.maximum(np.abs(ys - A@b), 1e-6)
        b = np.linalg.lstsq(A*np.sqrt(w)[:,None], ys*np.sqrt(w), rcond=None)[0]
    return b[0], b[1]
def one(n, beta, cens, R=2000):
    cov_si = cov_mi = 0; cov_full=0
    for r in range(R):
        x = rng.integers(0, 2, n)
        y = beta*x + rng.normal(size=n)
        lod = np.quantile(y, cens)
        obs = y > lod
        def fit(yc):
            X = np.c_[np.ones(n), x]
            b, res, *_ = np.linalg.lstsq(X, yc, rcond=None)
            s2 = np.sum((yc - X@b)**2)/(n-2)
            V = s2*np.linalg.inv(X.T@X)
            return b[1], V[1,1]
        # single QRILC
        mu, sd = qrilc_fit(y[obs], n, 1-obs.mean())
        def draw():
            m = (~obs).sum()
            a = (lod - mu)/sd
            u = rng.uniform(0, stats.norm.cdf(a), m)
            yc = y.copy(); yc[~obs] = mu + sd*stats.norm.ppf(u); return yc
        b, v = fit(draw())
        cov_si += abs(b - beta) < 1.96*np.sqrt(v)
        # repeat QRILC 20 times + Rubin's rules (still improper, but carries between-imputation var)
        M=20; bs=[]; vs=[]
        for m_ in range(M):
            bb, vv = fit(draw()); bs.append(bb); vs.append(vv)
        bs=np.array(bs); W=np.mean(vs); B=np.var(bs, ddof=1); T=W+(1+1/M)*B
        cov_mi += abs(bs.mean()-beta) < 1.96*np.sqrt(T)
        bf, vf = fit(y); cov_full += abs(bf-beta) < 1.96*np.sqrt(vf)
    return cov_full/R, cov_si/R, cov_mi/R
for n, beta, cens in [(100, 0.0, 0.3), (100, 0.5, 0.3), (100, 0.5, 0.5)]:
    print(n, beta, cens, one(n, beta, cens, R=1000))
