import sys, json, urllib.request, urllib.parse
q = sys.argv[1]
n = int(sys.argv[2]) if len(sys.argv) > 2 else 3
alen = int(sys.argv[3]) if len(sys.argv) > 3 else 1200
url = "https://www.ebi.ac.uk/europepmc/webservices/rest/search?" + urllib.parse.urlencode({"query": q, "resultType": "core", "format": "json", "pageSize": n})
d = json.load(urllib.request.urlopen(url, timeout=30))
for r in d["resultList"]["result"][:n]:
    ji = r.get("journalInfo", {})
    print("TITLE:", r.get("title"))
    print("  ", r.get("authorString", "")[:150], "|", ji.get("journal", {}).get("title"), ji.get("volume"), r.get("pageInfo"), r.get("pubYear"), "| PMID", r.get("pmid"), "DOI", r.get("doi"))
    print("  ABS:", (r.get("abstractText") or "")[:alen])
    print()
