import numpy as np
def es(n,p,r2): return 1 + (p-2)/(n*np.log(1-((r2*(n-p-1))+p)/(n-1)))
def n_cont(p,r2,S=0.9):
    n=p+2
    while True:
        v=es(n,p,r2)
        if not np.isnan(v) and v>=S: return n
        n+=1
def n_bin(p,r2cs,S=0.9): return int(np.ceil(p/((S-1)*np.log(1-r2cs/S))))
print("check pmsampsize example p=25 r2=0.2 ->", n_cont(25,0.2), "crit2", int(np.ceil(1+25*0.8/0.05)))
for r2 in [0.1,0.12,0.15,0.153,0.16,0.18,0.2,0.25,0.3]:
    print(r2, "cont crit1:", n_cont(73,r2), " crit2:", int(np.ceil(1+73*(1-r2)/0.05)), " bin-formula:", n_bin(73,r2))
# solve r2 for 3916
from scipy.optimize import brentq
print("cont r2 for n=3916:", brentq(lambda r: es(3916,73,r)-0.9, 0.01, 0.8))
print("bin r2cs for n=3916:", brentq(lambda r: 73/((0.9-1)*np.log(1-r/0.9))-3916, 0.01, 0.8))
for p in range(70,77):
    print(p, n_cont(p,0.15), n_bin(p,0.15))
