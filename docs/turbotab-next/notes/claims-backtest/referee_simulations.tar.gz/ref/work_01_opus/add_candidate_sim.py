import numpy as np, time
from sklearn.model_selection import KFold
rng=np.random.default_rng(11)
def fit_search(X, y, cand):
    # declared search: intercept-only or best single candidate by training-fold |corr|; pick by inner 5-fold CV
    best=None
    opts=[None]+list(cand)
    kf=KFold(5, shuffle=True, random_state=0)
    scores=[]
    for o in opts:
        e=0
        for tr,te in kf.split(X):
            if o is None: pred=np.full(len(te), y[tr].mean())
            else:
                b=np.polyfit(X[tr,o], y[tr], 1); pred=np.polyval(b, X[te,o])
            e+=((y[te]-pred)**2).sum()
        scores.append(e/len(y))
    o=opts[int(np.argmin(scores))]
    if o is None: return (None, y.mean())
    return (o, np.polyfit(X[:,o], y, 1))
def predict(model, X):
    o,b=model
    return np.full(len(X), b) if o is None else np.polyval(b, X[:,o])
def run(n=60, p=2000, ndecl=5, nadd=1, reps=150):
    out={"declared":[], "declared+added":[]}
    truth={"declared":[], "declared+added":[]}
    for r in range(reps):
        X=rng.normal(size=(n,p)); y=rng.normal(size=n)
        decl=list(range(ndecl))
        c=np.abs([np.corrcoef(X[:,j],y)[0,1] for j in range(ndecl,p)])
        added=list(ndecl+np.argsort(c)[::-1][:nadd])   # outcome view on ALL rows picks these
        for name,cand in [("declared",decl),("declared+added",decl+added)]:
            kf=KFold(10, shuffle=True, random_state=r); e=0
            for tr,te in kf.split(X):
                m=fit_search(X[tr],y[tr],cand); e+=((y[te]-predict(m,X[te]))**2).sum()
            out[name].append(e/n)
            m=fit_search(X,y,cand)
            Xt=rng.normal(size=(4000,p)) if False else None
            # true MSE of a pure-noise problem: 1 + E[(pred - 0)^2] over fresh x
            o,b=m
            tm = 1 + (b**2 if o is None else (b[1]**2 + b[0]**2))   # var(y)=1, x~N(0,1) indep
            truth[name].append(tm)
    for k in out:
        print(f"n={n} p={p} add={nadd} {k:16s}: CV MSE={np.mean(out[k]):.3f}  true MSE={np.mean(truth[k]):.3f}  (null var(y)=1)")
t=time.time()
run(nadd=1); run(nadd=3)
print("secs", round(time.time()-t,1))
