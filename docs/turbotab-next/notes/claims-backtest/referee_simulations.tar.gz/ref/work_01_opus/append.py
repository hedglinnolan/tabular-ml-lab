import json, sys
OUT = "/private/tmp/claude-501/-Users-nhedglin-tabular-ml-lab/a12607bd-3f0c-4a23-8d52-bda4a2c1292e/scratchpad/ref/out/merits_01_opus.jsonl"
rec = json.loads(sys.stdin.read())
keys = ["id","truth","failing_part","narrowest_regime","reason","basis_used","citations","bite","bite_note","confidence"]
assert set(rec) == set(keys), set(keys) ^ set(rec)
with open(OUT, "a") as f:
    f.write(json.dumps({k: rec[k] for k in keys}) + "\n")
print("appended", rec["id"])
