import numpy as np
def pl_parts(beta, t, d, x):
    o = np.argsort(t); t, d, x = t[o], d[o], x[o]
    eta = beta*x; m = eta.max(); w = np.exp(eta-m)
    S0 = np.cumsum(w[::-1])[::-1]; S1 = np.cumsum((w*x)[::-1])[::-1]; S2 = np.cumsum((w*x*x)[::-1])[::-1]
    ll = np.sum(d*(eta - (np.log(S0)+m)))
    g = np.sum(d*(x - S1/S0)); h = -np.sum(d*(S2/S0 - (S1/S0)**2))
    return ll, g, h
def newton(t,d,x,maxit=20,eps=1e-9):
    b=0.0; ll,g,h=pl_parts(b,t,d,x)
    for it in range(1,maxit+1):
        bn = b - g/h
        lln,gn,hn = pl_parts(bn,t,d,x)
        while lln < ll:  # step halving
            bn = (b+bn)/2; lln,gn,hn = pl_parts(bn,t,d,x)
        conv = abs(1-ll/lln) < eps
        b,ll,g,h = bn,lln,gn,hn
        if conv: return b, it, True
    return b, maxit, False
rng=np.random.default_rng(1)
# (b) monotone: group 0 has no events
n1=n0=15
t=np.r_[rng.exponential(1,n1), rng.exponential(1.5,n0)]; d=np.r_[np.ones(n1),np.zeros(n0)]; x=np.r_[np.ones(n1),np.zeros(n0)]
b,it,conv=newton(t,d,x); print(f"(b) monotone binary: beta={b:.3g}, beta*SD={b*x.std(ddof=1):.3g}, iters={it}, 'converged'={conv}")
# continuous monotone
n=40; x=rng.normal(size=n); t=np.argsort(np.argsort(-x)).astype(float)+1; d=np.ones(n)
b,it,conv=newton(t,d,x); print(f"(b2) monotone continuous: beta={b:.3g}, beta*SD={b*x.std(ddof=1):.3g}, iters={it}, 'converged'={conv}")
# (c) finite MLE with beta*SD>20: near-monotone, one swap of a near-tied pair
n=20; x=np.sort(rng.normal(size=n))[::-1].copy(); x[5]=x[4]-0.01*x.std(ddof=1)
t=np.arange(1,n+1,dtype=float); d=np.ones(n); x[[4,5]]=x[[5,4]]
b,it,conv=newton(t,d,x,maxit=200); ll,g,h=pl_parts(b,t,d,x)
print(f"(c) near-monotone w/ swap of pair 0.01 SD apart: beta={b:.4g}, beta*SD={b*x.std(ddof=1):.3g}, iters={it}, converged={conv}, score={g:.2e}, ll={ll:.4f}")
for bb in [b*0.5, b, b*2, b*5]:
    print("   ll at", round(bb,1), "=", round(pl_parts(bb,t,d,x)[0],5))
