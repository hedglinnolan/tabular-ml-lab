import numpy as np
from scipy import stats
rng=np.random.default_rng(7)
def one(k, m, sb, sw):
    n=m.sum(); b=rng.normal(0,sb,k)
    d=[b[i]+rng.normal(0,sw,m[i]) for i in range(k)]
    means=np.array([x.mean() for x in d]); allv=np.concatenate(d); gm=allv.mean()
    ssw=sum(((x-x.mean())**2).sum() for x in d); msw=ssw/(n-k)
    ssb=(m*(means-gm)**2).sum(); msb=ssb/(k-1)
    lam=(n**2-(m**2).sum())/((k-1)*n)
    s2b=(msb-msw)/lam; trunc = s2b<=0
    if trunc:
        v=means.var(ddof=1)/k
    else:
        v=(s2b*(m**2).sum()+msw*n)/n**2
    q=stats.t.ppf(0.975,k-1)
    return abs(gm)<=q*np.sqrt(v), trunc
for k in [8, 20]:
  for sb in [0.0, 0.2, 0.5, 1.0]:
    m=rng.integers(2,8,k)
    res=[one(k,m,sb,1.0) for _ in range(4000)]
    cov=np.mean([r[0] for r in res]); tr=np.mean([r[1] for r in res])
    print(f"k={k} sb={sb}: bias-CI coverage={cov:.3f} (truncated in {tr:.2f})")
