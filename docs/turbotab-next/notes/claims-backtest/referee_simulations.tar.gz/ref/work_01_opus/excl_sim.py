import numpy as np
rng=np.random.default_rng(3)
def slope(x,y): return np.polyfit(x,y,1)[0]
R=400; n=2000; res={"all":[], "trim |y|<2sd":[], "errors kept":[], "errors excluded by range":[]}
for r in range(R):
    x=rng.normal(size=n); y=0.5*x+rng.normal(size=n)
    res["all"].append(slope(x,y))
    k=np.abs(y-y.mean())<2*y.std(); res["trim |y|<2sd"].append(slope(x[k],y[k]))
    # 2% gross recording errors (e.g. 999 codes) independent of true y
    yr=y.copy(); e=rng.random(n)<0.02; yr[e]=999.0
    res["errors kept"].append(slope(x,yr))
    k=yr<100; res["errors excluded by range"].append(slope(x[k],yr[k]))
for k,v in res.items(): print(f"{k:28s} mean slope={np.mean(v):.3f} (true 0.5)")
