import numpy as np, warnings
from scipy.optimize import minimize_scalar
warnings.filterwarnings("ignore")
def negpl(beta, t, d, x):
    # Breslow partial log-likelihood, single covariate, no ties
    o = np.argsort(t); t, d, x = t[o], d[o], x[o]
    eta = beta * x
    # risk set at time i = indices j >= i
    lse = np.log(np.cumsum(np.exp(eta - eta.max())[::-1])[::-1]) + eta.max()
    return -np.sum(d * (eta - lse))
def profile(t,d,x,label):
    sd = x.std(ddof=1)
    bs = np.linspace(-60/sd, 60/sd, 2001)
    ll = np.array([-negpl(b,t,d,x) for b in bs])
    i = ll.argmax()
    r = minimize_scalar(lambda b: negpl(b,t,d,x), bounds=(bs[max(i-1,0)], bs[min(i+1,len(bs)-1)]), method="bounded")
    interior = 0 < i < len(bs)-1
    print(f"{label}: beta_hat={r.x:.4g}, beta*SD={r.x*sd:.3g}, interior max={interior}, ll(max)={-r.fun:.4f}, ll(+-edge)={ll[0]:.4f},{ll[-1]:.4f}")
rng = np.random.default_rng(1)
# (a) group 1: every row has the event; group 0: some events, interleaved
n1, n0 = 15, 15
t1 = rng.exponential(1.0, n1); d1 = np.ones(n1)
t0 = rng.exponential(1.5, n0); d0 = (rng.random(n0) < 0.5).astype(float)
t = np.r_[t1, t0]; d = np.r_[d1, d0]; x = np.r_[np.ones(n1), np.zeros(n0)]
print("(a) events in group1:", int(d1.sum()), "/", n1, " events in group0:", int(d0.sum()), "/", n0)
profile(t,d,x,"(a) all-events group")
# (b) one group has no events
d0b = np.zeros(n0)
profile(t,np.r_[d1,d0b],x,"(b) no-events group")
# (c) continuous x perfectly ordering failures except one tiny swap
n = 20
x = np.sort(rng.normal(size=n))[::-1].copy()   # largest x fails first
t = np.arange(1, n+1, dtype=float); d = np.ones(n)
x[[4,5]] = x[[5,4]]  # swap two adjacent ranks
gap = abs(x[4]-x[5]); print("(c) swapped pair x-gap in SDs:", gap/x.std(ddof=1))
profile(t,d,x,"(c) near-monotone, one adjacent swap")
