import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
rng=np.random.default_rng(1)
def gen(n,p=5,b0=-3.0):
    X=rng.normal(size=(n,p)); lp=b0+X@np.array([.8,.6,.4,.3,.2]); y=rng.random(n)<1/(1+np.exp(-lp)); return X,y.astype(int)
res=[]
for rep in range(150):
    X,y=gen(2000); Xt,yt=gen(20000)
    if y.sum()<10: continue
    m0=LogisticRegression(C=1e6,max_iter=500).fit(X,y)
    idx=np.where(y==1)[0]; extra=rng.choice(idx,(y==0).sum()-len(idx))
    Xo=np.vstack([X,X[extra]]); yo=np.concatenate([y,y[extra]])
    m1=LogisticRegression(C=1e6,max_iter=500).fit(Xo,yo)
    p0=m0.predict_proba(Xt)[:,1]; p1=m1.predict_proba(Xt)[:,1]
    res.append((y.mean(),yt.mean(),roc_auc_score(yt,p0),roc_auc_score(yt,p1),p0.mean(),p1.mean(),(p0>.5).mean(),(p1>.5).mean(),
      ((p0>.5)&(yt==1)).sum()/yt.sum(),((p1>.5)&(yt==1)).sum()/yt.sum(), ((p1>.5)&(yt==0)).sum()/(yt==0).sum()))
r=np.array(res).mean(0)
print("prevalence train %.3f test %.3f"%tuple(r[:2]))
print("AUC plain %.4f oversampled %.4f"%(r[2],r[3]))
print("mean predicted risk plain %.3f oversampled %.3f (true %.3f)"%(r[4],r[5],r[1]))
print("frac flagged at 0.5: plain %.3f oversamp %.3f"%(r[6],r[7]))
print("sens at 0.5 plain %.3f oversamp %.3f; FPR oversamp %.3f"%(r[8],r[9],r[10]))
