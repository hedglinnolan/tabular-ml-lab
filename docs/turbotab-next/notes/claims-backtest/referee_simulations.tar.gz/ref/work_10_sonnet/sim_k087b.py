import numpy as np
exec(open('sim_k087.py').read().split("for (n,k,sb2,sw2)")[0])
rng=np.random.default_rng(11)
for (n,k,sb2,sw2) in [(80,2,1.0,5.0),(60,2,1.0,5.0),(60,2,1.0,4.0)]:
    lam=sb2/(sb2+sw2/k)
    rows=[]
    for rep in range(250):
        est,bs,fail=one(n,k,sb2,sw2,1.0,200,rng)
        if est is None or len(bs)<180: continue
        lo,hi=np.percentile(bs,[2.5,97.5]); rows.append((fail/200,lo<=1<=hi,1>hi,1<lo,hi-lo))
    r=np.array(rows)
    print("n=%d lambda=%.2f shown %d/250 ; mean dropped %.3f ; cover %.3f (miss above %.3f below %.3f) width %.2f"%(n,lam,len(r),r[:,0].mean(),r[:,1].mean(),r[:,2].mean(),r[:,3].mean(),np.median(r[:,4])),flush=True)
    for lo_,hi_ in [(0,0.02),(0.02,0.10)]:
        m=(r[:,0]>=lo_)&(r[:,0]<hi_)
        if m.sum()>5: print("   dropped in [%.2f,%.2f): n=%d cover %.3f miss above %.3f"%(lo_,hi_,m.sum(),r[m,1].mean(),r[m,2].mean()))
