import numpy as np, pandas as pd, statsmodels.api as sm
rng=np.random.default_rng(7)
n=500
x=rng.normal(size=n); c=(rng.random(n)<0.4).astype(float); e=0.5*c+0.3*x+rng.normal(size=n)*0.5
y=1+0.7*e+0.4*c+0.2*x+rng.normal(size=n)
def fit(cc):
    X=sm.add_constant(np.c_[e,cc,x]); return sm.OLS(y,X).fit()
a=fit(c); b=fit(1-c)
print("OLS coef orig  ",np.round(a.params,6)); print("OLS coef recode",np.round(b.params,6))
print("exposure CI equal:",np.allclose(a.conf_int()[1],b.conf_int()[1]), " fitted equal:",np.allclose(a.fittedvalues,b.fittedvalues))
print("intercept CI orig",np.round(a.conf_int()[0],4),"recode",np.round(b.conf_int()[0],4), "se int",a.bse[0],b.bse[0])
yb=(y>np.median(y)).astype(float)
la=sm.Logit(yb,sm.add_constant(np.c_[e,c,x])).fit(disp=0); lb=sm.Logit(yb,sm.add_constant(np.c_[e,1-c,x])).fit(disp=0)
print("logit",np.round(la.params,5),np.round(lb.params,5))
from sklearn.linear_model import Lasso
la=Lasso(alpha=0.05).fit(np.c_[e,c,x],y); lb=Lasso(alpha=0.05).fit(np.c_[e,1-c,x],y)
print("lasso",la.intercept_,la.coef_,lb.intercept_,lb.coef_)
