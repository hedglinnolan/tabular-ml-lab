import numpy as np, time
rng=np.random.default_rng(5)
t0=time.time()
def rc_beta(Y,Zbar,s_w2,k):
    n=len(Y)
    vm=Zbar.var(ddof=1)
    sb2=vm-s_w2/k
    if sb2<=0: return None
    lam=sb2/vm
    bn=np.cov(Zbar,Y)[0,1]/vm
    return bn/lam
def one(n,k,sb2,sw2,beta,B,rng):
    x=rng.normal(0,np.sqrt(sb2),n)
    Y=beta*x+rng.normal(0,1,n)
    Z=x[:,None]+rng.normal(0,np.sqrt(sw2),(n,k))
    Zbar=Z.mean(1); sw2hat=Z.var(axis=1,ddof=1).mean()
    est=rc_beta(Y,Zbar,sw2hat,k)
    bs=[];fail=0
    for b in range(B):
        i=rng.integers(0,n,n)
        Zi=Z[i]; Zb=Zi.mean(1); s=Zi.var(axis=1,ddof=1).mean()
        r=rc_beta(Y[i],Zb,s,k)
        if r is None: fail+=1
        else: bs.append(r)
    return est,np.array(bs),fail
for (n,k,sb2,sw2) in [(150,2,1.0,3.0),(100,2,1.0,8.0),(100,2,1.0,15.0)]:
    lam=sb2/(sb2+sw2/k); beta=1.0
    cov=0;shown=0;ntr=0;fails=[];wid=[];cov_all=0
    for rep in range(60):
        est,bs,fail=one(n,k,sb2,sw2,beta,200,rng)
        fails.append(fail/200)
        if est is None: continue
        ntr+=1
        if len(bs)>=0.9*200:
            shown+=1
            lo,hi=np.percentile(bs,[2.5,97.5])
            cov+=(lo<=beta<=hi); wid.append(hi-lo)
    print("n=%d k=%d lambda=%.2f: mean frac resamples dropped %.3f; interval shown %d/%d ; coverage among shown %.2f ; median width %.2f"%(n,k,lam,np.mean(fails),shown,ntr,cov/max(shown,1),np.median(wid) if wid else np.nan),flush=True)
print(time.time()-t0)
