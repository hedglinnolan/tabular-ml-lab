import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import KFold
rng=np.random.default_rng(3)
# population: stratum A 80% (sd noise 1), stratum B 20% (noise sd 3); sample 300 from each (B oversampled 4x)
def draw(nA,nB):
    xA=rng.normal(size=(nA,1)); yA=1+xA[:,0]+rng.normal(0,1,nA)
    xB=rng.normal(size=(nB,1)); yB=1+xB[:,0]+rng.normal(0,3,nB)
    X=np.vstack([xA,xB]); y=np.concatenate([yA,yB]); s=np.r_[np.zeros(nA),np.ones(nB)]
    return X,y,s
popMSE=0.8*1+0.2*9
est_u=[];est_w=[]
for r in range(400):
    X,y,s=draw(300,300); w=np.where(s==0,0.8/300,0.2/300)  # design weights proportional
    kf=KFold(5,shuffle=True,random_state=int(rng.integers(1e9)))
    e=np.zeros(len(y))
    for tr,te in kf.split(X):
        m=LinearRegression().fit(X[tr],y[tr]); e[te]=(y[te]-m.predict(X[te]))**2
    est_u.append(e.mean()); est_w.append((w*e).sum()/w.sum())
print("population MSE (irreducible 2.6): %.3f"%popMSE)
print("unweighted random-row 5-fold CV MSE: mean %.3f"%np.mean(est_u))
print("design-weighted CV MSE: mean %.3f"%np.mean(est_w))
