import numpy as np
rng=np.random.default_rng(2)
k=8
def dl(y,v):
    w=1/v; mw=(w*y).sum()/w.sum(); Q=(w*(y-mw)**2).sum(); c=w.sum()-(w**2).sum()/w.sum(); t2=max(0,(Q-(len(y)-1))/c)
    w2=1/(v+t2); return (w2*y).sum()/w2.sum(), t2
for n in [100,400]:
  for tau in [0.0,0.3,0.6]:
    out=[]
    for r in range(3000):
        t=np.exp(rng.normal(0,tau,size=k)); m=t*rng.chisquare(n,size=k)/n
        idm,_=dl(m,(m*np.sqrt(2/n))**2)
        ml,t2l=dl(np.log(m),np.full(k,2/n))
        out.append((t.mean(),m.mean(),idm,np.exp(ml),np.exp(ml+t2l/2)))
    o=np.array(out).mean(0)
    print("n=%d tau=%.1f  mean true cycle MSE %.4f | sample arith mean %.4f | RE identity pooled %.4f | exp(RE log mu) %.4f | exp(mu+tau2/2) %.4f"%(n,tau,*o))
