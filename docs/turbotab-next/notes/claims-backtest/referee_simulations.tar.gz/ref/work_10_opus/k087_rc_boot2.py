import numpy as np, time
t0=time.process_time()
rng = np.random.default_rng(11)
def rc(W1, W2, Y):
    Wb = (W1+W2)/2
    su2 = np.mean((W1-W2)**2, axis=-1)/2
    vW = np.var(Wb, axis=-1, ddof=1)
    sx2 = vW - su2/2
    Yc = Y-Y.mean(-1,keepdims=True); Wc = Wb-Wb.mean(-1,keepdims=True)
    bn = np.sum(Wc*Yc,-1)/np.sum(Wc*Wc,-1)
    ok = sx2 > 0
    return np.where(ok, bn*vW/np.where(ok,sx2,1), np.nan), ok
def run(n, sx2, su2, beta, nsim, B):
    rec=[]
    for s in range(nsim):
        X = rng.normal(0, np.sqrt(sx2), n)
        W1 = X + rng.normal(0,np.sqrt(su2),n); W2 = X + rng.normal(0,np.sqrt(su2),n)
        Y = beta*X + rng.normal(0,1,n)
        idx = rng.integers(0,n,(B,n))
        bb, ok = rc(W1[idx], W2[idx], Y[idx])
        frac = ok.mean()
        lo, hi = np.quantile(bb[ok],[0.025,0.975]) if ok.sum()>10 else (np.nan,np.nan)
        rec.append((frac, lo, hi))
    r=np.array(rec)
    for gate in [0.9, 0.97, 1.0]:
        m = r[:,0]>=gate
        if m.sum()==0: continue
        lo, hi = r[m,1], r[m,2]
        print(f"  gate {gate}: shown {m.mean():.3f} cov {np.mean((lo<=beta)&(beta<=hi)):.3f} miss_above(hi<beta) {np.mean(hi<beta):.3f} miss_below(lo>beta) {np.mean(lo>beta):.3f}")
    m = (r[:,0]>=0.9)&(r[:,0]<0.97)
    if m.sum(): print(f"  frac in [0.90,0.97): n={m.sum()} cov {np.mean((r[m,1]<=beta)&(beta<=r[m,2])):.3f} miss_above {np.mean(r[m,2]<beta):.3f}")
    m = r[:,0]>=0
    print(f"  always shown (drop fails): cov {np.nanmean((r[m,1]<=beta)&(beta<=r[m,2])):.3f} miss_above {np.nanmean(r[m,2]<beta):.3f}")
for (n,sx2,su2,B) in [(60,1,4,200),(100,1,4,200),(150,1,6,200),(250,1,8,200),(40,1,3,200)]:
    print(f"n={n} sx2={sx2} su2={su2} B={B} lambda={sx2/(sx2+su2/2):.2f}")
    run(n,sx2,su2,1.0, 2000, B)
print("cpu", time.process_time()-t0)
