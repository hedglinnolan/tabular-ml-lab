import numpy as np, time
t0=time.process_time()
rng = np.random.default_rng(7)
def rc(W1, W2, Y):
    # W1,W2,Y shape (..., n)
    Wb = (W1+W2)/2
    su2 = np.mean((W1-W2)**2, axis=-1)/2
    vW = np.var(Wb, axis=-1, ddof=1)
    sx2 = vW - su2/2
    cov = np.mean((Wb-Wb.mean(-1,keepdims=True))*(Y-Y.mean(-1,keepdims=True)),axis=-1)*Wb.shape[-1]/(Wb.shape[-1]-1)
    bn = cov/vW
    lam = sx2/vW
    ok = sx2 > 0
    return np.where(ok, bn/np.where(ok,lam,1), np.nan), ok
def run(n, sx2, su2, beta, nsim, B):
    cover=shown=0; widths=[]; fails=[]; cover_all=0; cover_inf=0; n_inf_shown=0
    for s in range(nsim):
        X = rng.normal(0, np.sqrt(sx2), n)
        W1 = X + rng.normal(0,np.sqrt(su2),n); W2 = X + rng.normal(0,np.sqrt(su2),n)
        Y = beta*X + rng.normal(0,1,n)
        idx = rng.integers(0,n,(B,n))
        bb, ok = rc(W1[idx], W2[idx], Y[idx])
        frac = ok.mean(); fails.append(1-frac)
        # interval keeping failures as +inf (they correspond to lambda<=0: unbounded correction in the direction of naive sign)
        bb_inf = np.where(ok, bb, np.inf*np.sign(np.nan_to_num(np.cov(W1[idx].mean(-1),Y[idx].mean(-1))[0,1]) or 1))
        lo_i, hi_i = np.quantile(np.where(ok,bb,np.inf), [0.025,0.975])
        cover_inf += (lo_i<=beta<=hi_i)
        if frac >= 0.9:
            shown += 1
            lo, hi = np.quantile(bb[ok],[0.025,0.975])
            cover += (lo<=beta<=hi); widths.append(hi-lo)
    return shown/nsim, cover/max(shown,1), np.mean(fails), cover_inf/nsim
for (n,sx2,su2,B) in [(60,1,4,200),(60,1,4,1000),(100,1,4,200),(40,1,4,200),(300,1,2,200)]:
    sh, cov, fl, ci = run(n,sx2,su2,1.0, 1000, B)
    print(f"n={n} sx2={sx2} su2={su2} B={B}: shown {sh:.3f}, coverage|shown {cov:.3f}, mean fail frac {fl:.3f}, coverage keeping fails as +inf (all sims) {ci:.3f}")
print("cpu", time.process_time()-t0)
