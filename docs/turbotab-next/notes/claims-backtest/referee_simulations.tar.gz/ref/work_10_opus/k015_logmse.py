import numpy as np
from scipy import stats
rng=np.random.default_rng(2)
def dl(y,v):
    w=1/v; mu=np.sum(w*y)/w.sum(); Q=np.sum(w*(y-mu)**2); k=len(y)
    tau2=max(0,(Q-(k-1))/(w.sum()-np.sum(w**2)/w.sum()))
    ws=1/(v+tau2); mu=np.sum(ws*y)/ws.sum()
    q=np.sum(ws*(y-mu)**2)/(k-1); se_hk=np.sqrt(q/ws.sum()); se_dl=np.sqrt(1/ws.sum())
    return mu,tau2,se_dl,se_hk
for n in [100, 500, 3000]:
    for tau in [0.0, 0.15]:
        k=8; res_id=[]; res_log=[]; truth_mean=[]; truth_med=[]; cov_hk=0; cov_dl=0; cov_pi=0
        for s in range(3000):
            true_log = rng.normal(0,tau,k); true = np.exp(true_log)
            e = rng.normal(0,1,(k,n))*np.sqrt(true)[:,None]
            m = (e**2).mean(1); v = (e**2).var(1,ddof=1)/n
            mu,t2,_,_ = dl(m,v); res_id.append(mu)
            ly=np.log(m); lv=v/m**2
            mu2,t22,sdl,shk = dl(ly,lv); res_log.append(np.exp(mu2))
            cov_hk += abs(mu2-0)<=stats.t.ppf(.975,k-1)*shk
            cov_dl += abs(mu2-0)<=1.96*sdl
            newc = rng.normal(0,tau); cov_pi += abs(newc-mu2)<=stats.t.ppf(.975,k-2)*np.sqrt(t22+shk**2)
            truth_mean.append(true.mean())
        print(f"n/cycle={n} tau_log={tau}: identity pooled {np.mean(res_id):.4f}, log pooled(back) {np.mean(res_log):.4f}, true population median 1.0000, mean of true MSE_i {np.mean(truth_mean):.4f}; log-scale mean coverage HKSJ {cov_hk/3000:.3f} DL {cov_dl/3000:.3f}; PI t(k-2) cov new cycle {cov_pi/3000:.3f}")
