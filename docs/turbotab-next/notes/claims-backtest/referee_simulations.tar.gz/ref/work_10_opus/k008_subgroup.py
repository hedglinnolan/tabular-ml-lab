import numpy as np, time
from scipy.stats import norm
import statsmodels.api as sm
import warnings; warnings.filterwarnings("ignore")
t0=time.process_time()
rng=np.random.default_rng(5)
def auc(s1,s0):
    # s1: (...,n1), s0: (...,n0)
    d = s1[...,:,None]-s0[...,None,:]
    return ((d>0)+0.5*(d==0)).mean(axis=(-1,-2))
def delong_ci(s1,s0):
    n1,n0=len(s1),len(s0)
    psi = (s1[:,None]>s0[None,:]) + 0.5*(s1[:,None]==s0[None,:])
    A = psi.mean(); v10=psi.mean(1); v01=psi.mean(0)
    se = np.sqrt(v10.var(ddof=1)/n1 + v01.var(ddof=1)/n0)
    return A-1.96*se, A+1.96*se
true_auc = 0.75; d = np.sqrt(2)*norm.ppf(true_auc)
for n1,n0 in [(5,5),(5,15),(10,10),(25,25)]:
    cb=cd=0; nsim=2000; B=500
    for s in range(nsim):
        s1 = rng.normal(d,1,n1); s0 = rng.normal(0,1,n0)
        b1 = s1[rng.integers(0,n1,(B,n1))]; b0 = s0[rng.integers(0,n0,(B,n0))]
        lo,hi = np.quantile(auc(b1,b0),[.025,.975]); cb += lo<=true_auc<=hi
        lo,hi = delong_ci(s1,s0); cd += lo<=true_auc<=hi
    print(f"AUC n1={n1} n0={n0}: stratified bootstrap percentile cov {cb/nsim:.3f}, DeLong cov {cd/nsim:.3f}")
# calibration slope with 10 rows (5/5) on a correctly calibrated model
fails=0; cov=0; nsim=1000; slopes=[]
for s in range(nsim):
    lp = rng.normal(0,1.5,200)
    y = rng.random(200)<1/(1+np.exp(-lp))
    i1 = rng.choice(np.where(y)[0],5,replace=False); i0=rng.choice(np.where(~y)[0],5,replace=False)
    idx=np.r_[i1,i0]
    try:
        r = sm.GLM(y[idx].astype(float), sm.add_constant(lp[idx]), family=sm.families.Binomial()).fit()
        b=r.params[1]; se=r.bse[1]
        if not np.isfinite(se) or abs(b)>20: fails+=1; continue
        slopes.append(b); cov += (b-1.96*se<=1<=b+1.96*se)
    except Exception:
        fails+=1
print(f"cal slope 5/5: fail/separation {fails/nsim:.3f}, Wald cov among fitted {cov/max(1,nsim-fails):.3f}, slope IQR {np.percentile(slopes,[25,75])}")
print("cpu", time.process_time()-t0)
