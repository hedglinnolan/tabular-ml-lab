import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import KFold
rng = np.random.default_rng(1)
# Population: 2 strata. Stratum B (90% of pop) has noisier outcome and different slope.
N = 200000
strat = rng.random(N) < 0.10  # True = stratum A (10% of pop)
x = rng.normal(size=N)
y = np.where(strat, 1.0*x + rng.normal(0,0.5,N), 0.3*x + rng.normal(0,2.0,N))
res_cv, res_wcv, res_pop = [], [], []
for rep in range(200):
    # Stratified sample: 500 from A, 500 from B (A heavily oversampled)
    ia = rng.choice(np.where(strat)[0], 500, replace=False)
    ib = rng.choice(np.where(~strat)[0], 500, replace=False)
    idx = np.r_[ia, ib]
    w = np.r_[np.full(500, strat.sum()/500), np.full(500, (~strat).sum()/500)]
    X = x[idx, None]; Y = y[idx]
    kf = KFold(5, shuffle=True, random_state=rep)
    se = np.empty(1000)
    for tr, te in kf.split(X):
        m = LinearRegression().fit(X[tr], Y[tr], sample_weight=w[tr])
        se[te] = (Y[te] - m.predict(X[te]))**2
    res_cv.append(se.mean()); res_wcv.append(np.sum(w*se)/np.sum(w))
    m = LinearRegression().fit(X, Y, sample_weight=w)
    res_pop.append(np.mean((y - m.predict(x[:,None]))**2))
print("unweighted CV MSE mean %.3f" % np.mean(res_cv))
print("weighted CV MSE mean   %.3f" % np.mean(res_wcv))
print("true population MSE    %.3f" % np.mean(res_pop))
