import numpy as np, time
t0=time.process_time()
rng=np.random.default_rng(9)
# Conditional on fitted models: per-row losses for interpretable (L0) and F flexible families.
# Losses: L_f = base + noise; flexible family 0 truly better than interpretable by delta in mean loss.
def sim(n, F, delta, nsim=1000, B=500, rho=0.7):
    span=0; cover=0; est=[]
    for s in range(nsim):
        base = rng.normal(0.5, 0.4, n)
        L0 = base + rng.normal(0, 0.3, n)
        Lf = base[None,:] + rng.normal(0,0.3,(F,n))*1.0
        Lf[0] -= delta  # family 0 better (lower loss) by delta
        # BBC over the flexible set: pick best flexible in-bag, evaluate paired diff (L0 - Lpick) on OOB
        idx = rng.integers(0,n,(B,n))
        inbag_mean = np.stack([Lf[f][idx].mean(1) for f in range(F)])  # F x B
        pick = inbag_mean.argmin(0)
        diffs = np.empty(B)
        for b in range(B):
            oob = np.ones(n,bool); oob[idx[b]] = False
            diffs[b] = (L0[oob]-Lf[pick[b]][oob]).mean()
        lo,hi = np.quantile(diffs,[.025,.975]); est.append(diffs.mean())
        span += (lo<=0<=hi); cover += (lo<=delta<=hi)
    # correct reference: SD of full-sample paired mean diff for family 0
    return span/nsim, cover/nsim, np.mean(est)
for n in [10, 30, 100, 400]:
    for F,delta in [(1,0.0),(1,0.1),(3,0.0),(3,0.1)]:
        sp, cv, m = sim(n,F,delta, nsim=400 if n<=100 else 200, B=300)
        print(f"n={n} F={F} true cost={delta}: P(interval spans 0)={sp:.3f}  coverage of true cost={cv:.3f}  mean BBC est={m:.3f}")
print("cpu", time.process_time()-t0)
