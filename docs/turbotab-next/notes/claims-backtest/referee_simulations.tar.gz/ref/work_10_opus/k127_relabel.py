import numpy as np, statsmodels.api as sm, pandas as pd
from statsmodels.duration.hazard_regression import PHReg
from sklearn.linear_model import LogisticRegression
rng = np.random.default_rng(3)
n=800
a = rng.normal(size=n); s = rng.integers(0,2,n); age = rng.normal(size=n)
eta = -0.5 + 0.7*a + 0.8*s + 0.3*age
yb = rng.random(n) < 1/(1+np.exp(-eta))
def fit_logit(scol, inter=False):
    cols = [np.ones(n), a, scol, age] + ([scol*age] if inter else [])
    X = np.column_stack(cols); r = sm.GLM(yb, X, family=sm.families.Binomial()).fit()
    return r.params, r.bse, r.fittedvalues
for inter in [False, True]:
    p1,b1,f1 = fit_logit(s, inter); p2,b2,f2 = fit_logit(1-s, inter)
    print("logit inter=%s params"%inter, np.round(p1,4), np.round(p2,4), "max fitted diff %.2e"%np.max(np.abs(f1-f2)), "exposure se diff %.2e"%abs(b1[1]-b2[1]))
# Cox
t = rng.exponential(1/np.exp(0.7*a+0.8*s)); c = rng.exponential(2,n); time=np.minimum(t,c); ev=(t<=c).astype(int)
r1 = PHReg(time, np.column_stack([a,s]), status=ev).fit(); r2 = PHReg(time, np.column_stack([a,1-s]), status=ev).fit()
print("cox", np.round(r1.params,5), np.round(r2.params,5), np.round(r1.bse,5), np.round(r2.bse,5))
# liblinear penalizes intercept
for solver in ["liblinear","lbfgs"]:
    m1 = LogisticRegression(C=0.05, solver=solver).fit(np.column_stack([a,s,age]), yb)
    m2 = LogisticRegression(C=0.05, solver=solver).fit(np.column_stack([a,1-s,age]), yb)
    print(solver, "exposure coef", round(m1.coef_[0,0],5), round(m2.coef_[0,0],5))
