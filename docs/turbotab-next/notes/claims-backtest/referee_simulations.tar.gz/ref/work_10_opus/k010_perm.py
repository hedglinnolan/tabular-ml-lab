import numpy as np, statsmodels.api as sm
rng = np.random.default_rng(0)
n=500; X = sm.add_constant(rng.normal(size=(n,4))); y = X@np.array([1,2,-1,.5,0]) + rng.normal(size=n)
p = rng.permutation(n)
for cov in ["nonrobust","HC3"]:
    a = sm.OLS(y,X).fit(cov_type=cov); b = sm.OLS(y[p],X[p]).fit(cov_type=cov)
    print(cov, np.max(np.abs(a.params-b.params)), np.max(np.abs(a.bse-b.bse)), np.max(np.abs(a.fittedvalues[p]-b.fittedvalues)))
a = sm.OLS(y,X).fit(cov_type="HAC",cov_kwds={"maxlags":5}); b = sm.OLS(y[p],X[p]).fit(cov_type="HAC",cov_kwds={"maxlags":5})
print("HAC se diff", np.max(np.abs(a.bse-b.bse)), "rel", np.max(np.abs(a.bse-b.bse)/a.bse))
