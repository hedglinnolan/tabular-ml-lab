import numpy as np, warnings
warnings.filterwarnings("ignore")
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, log_loss, accuracy_score
rng = np.random.default_rng(7)
Cs = np.logspace(-4, 2, 13)
def gen(n,p,beta):
    X = rng.normal(size=(n,p)); eta = X@beta
    return X, (rng.random(n) < 1/(1+np.exp(-eta))).astype(int)
p=30; beta = np.zeros(p); beta[:6]=0.6
res = {"logloss":[], "auc":[], "acc":[]}
chosenC = {"logloss":[], "auc":[], "acc":[]}
for rep in range(40):
    X,y = gen(150,p,beta); Xt,yt = gen(5000,p,beta)
    skf = StratifiedKFold(5, shuffle=True, random_state=rep)
    oof = np.zeros((len(Cs), len(y))); aucs=np.zeros(len(Cs)); accs=np.zeros(len(Cs))
    for j,C in enumerate(Cs):
        a=[];ac=[]
        for tr,te in skf.split(X,y):
            m = LogisticRegression(C=C, max_iter=2000).fit(X[tr],y[tr])
            pr = m.predict_proba(X[te])[:,1]; oof[j,te]=pr
            a.append(roc_auc_score(y[te],pr)); ac.append(accuracy_score(y[te],pr>0.5))
        aucs[j]=np.mean(a); accs[j]=np.mean(ac)
    ll = np.array([log_loss(y, np.clip(o,1e-12,1-1e-12)) for o in oof])
    picks = {"logloss": ll.argmin(), "auc": aucs.argmax(), "acc": accs.argmax()}
    for k,j in picks.items():
        m = LogisticRegression(C=Cs[j], max_iter=2000).fit(X,y)
        res[k].append(log_loss(yt, m.predict_proba(Xt)[:,1])); chosenC[k].append(np.log10(Cs[j]))
for k in res: print(k, "test logloss mean %.4f  sd-of-mean %.4f  median log10C %.1f" % (np.mean(res[k]), np.std(res[k])/np.sqrt(len(res[k])), np.median(chosenC[k])))
d = np.array(res["auc"])-np.array(res["logloss"]); print("auc-logloss tuned diff mean %.4f se %.4f"%(d.mean(), d.std()/np.sqrt(len(d))))
d = np.array(res["acc"])-np.array(res["logloss"]); print("acc-logloss tuned diff mean %.4f se %.4f"%(d.mean(), d.std()/np.sqrt(len(d))))
