import numpy as np, warnings
warnings.filterwarnings("ignore")
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import KFold
import statsmodels.api as sm
rng = np.random.default_rng(3)
n=600
X = np.column_stack([rng.normal(size=n), rng.normal(size=n), rng.integers(0,2,size=n)])
eta = -0.3+0.8*X[:,0]-0.5*X[:,1]+0.7*X[:,2]
y = (rng.random(n) < 1/(1+np.exp(-eta))).astype(int)
def oof(Xm, fitter):
    p = np.zeros(n)
    for tr,te in KFold(5, shuffle=True, random_state=0).split(Xm):
        p[te] = fitter(Xm[tr], y[tr], Xm[te])
    return p
def skl(Xtr,ytr,Xte, **kw):
    m = LogisticRegression(penalty=None, solver="lbfgs", max_iter=100).fit(Xtr,ytr)
    return m.predict_proba(Xte)[:,1]
def sm_fit(Xtr,ytr,Xte):
    r = sm.Logit(ytr, sm.add_constant(Xtr, has_constant="add")).fit(disp=0, maxiter=100)
    return r.predict(sm.add_constant(Xte, has_constant="add"))
for c in (1, 1e3, 1e6):
    Xs = X.copy(); Xs[:,0] = X[:,0]*c
    p0s = oof(X, skl); p1s = oof(Xs, skl)
    try:
        p0m = oof(X, sm_fit); p1m = oof(Xs, sm_fit); dm = np.abs(p0m-p1m).max()
    except Exception as e:
        dm = str(e)[:50]
    print(f"scale {c:g}: sklearn lbfgs max|dp| = {np.abs(p0s-p1s).max():.2e}; statsmodels Newton max|dp| = {dm}")
