import numpy as np
rng = np.random.default_rng(1)
def impute_draw(X_obs, x_obs, X_mis, rng):
    # Bayesian linear regression draw (flat prior)
    n,k = X_obs.shape
    XtX_inv = np.linalg.inv(X_obs.T@X_obs)
    b_hat = XtX_inv@X_obs.T@x_obs
    res = x_obs - X_obs@b_hat
    s2 = res@res / rng.chisquare(n-k)
    b = rng.multivariate_normal(b_hat, s2*XtX_inv)
    return X_mis@b + rng.normal(0, np.sqrt(s2), len(X_mis))
def one(n=400, m=10, use_y=True, beta=(0.5,0.5), pmiss=0.4):
    x1 = rng.normal(size=n)
    x2 = 0.6*x1 + 0.8*rng.normal(size=n)
    y = beta[0]*x1 + beta[1]*x2 + rng.normal(size=n)
    miss = rng.random(n) < pmiss
    ests=[]
    for _ in range(m):
        cols = [np.ones(n), x1] + ([y] if use_y else [])
        Z = np.column_stack(cols)
        x2i = x2.copy()
        x2i[miss] = impute_draw(Z[~miss], x2[~miss], Z[miss], rng)
        D = np.column_stack([np.ones(n), x1, x2i])
        b = np.linalg.lstsq(D, y, rcond=None)[0]
        ests.append(b[1:])
    return np.mean(ests, axis=0)
for use_y in (False, True):
    R = np.array([one(use_y=use_y) for _ in range(300)])
    print("use_y", use_y, "mean beta1,beta2 =", R.mean(0).round(3), " (truth 0.5, 0.5)")
# Null coefficient check: true beta2=0 -> is bias away from zero when y included?
for use_y in (False, True):
    R = np.array([one(use_y=use_y, beta=(0.5,0.0)) for _ in range(300)])
    print("NULL beta2: use_y", use_y, "mean beta1,beta2 =", R.mean(0).round(3), "sd beta2", R[:,1].std().round(3), "rej-ish |mean/sd|", abs(R[:,1].mean()/R[:,1].std()*1).round(2))
