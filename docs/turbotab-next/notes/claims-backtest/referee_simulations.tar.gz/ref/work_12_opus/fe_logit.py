# Incidental-parameter bias: logistic with one intercept per small group (households of size 2 or 4)
import numpy as np, scipy.sparse as sp, warnings
from sklearn.linear_model import LogisticRegression
warnings.filterwarnings('ignore')
rng=np.random.default_rng(3)
def sim(G=400, m=2, beta=1.0):
    a=rng.normal(size=G); g=np.repeat(np.arange(G),m)
    x=0.7*a[g]+rng.normal(size=G*m)          # exposure differs by group (confounding)
    p=1/(1+np.exp(-(a[g]*1.0+beta*x-0.0))); y=(rng.random(G*m)<p).astype(int)
    # keep only groups with variation in y (others' intercepts diverge; same as conditional logit discards them)
    ys=np.bincount(g,weights=y,minlength=G); keep=(ys>0)&(ys<m)
    k=keep[g]; gg=np.unique(g[k],return_inverse=True)[1]
    D=sp.csr_matrix((np.ones(k.sum()),(np.arange(k.sum()),gg)))
    X=sp.hstack([sp.csr_matrix(x[k][:,None]),D]).tocsr()
    fe=LogisticRegression(penalty=None,fit_intercept=False,max_iter=5000).fit(X,y[k]).coef_[0][0]
    pooled=LogisticRegression(penalty=None,max_iter=2000).fit(x[:,None],y).coef_[0][0]
    return fe,pooled
for m in [2,4,10]:
    r=np.array([sim(m=m,G=max(60,800//m)) for _ in range(30)])
    print(f'group size {m}: true beta 1.0  FE-dummies logit mean {r[:,0].mean():.2f}   pooled (no FE) {r[:,1].mean():.2f}')
