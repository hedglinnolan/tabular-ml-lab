import numpy as np
rng=np.random.default_rng(2)
def one(n=2000, beta=0.5, M=10, p0=0.5, p1=0.05):
    Z=rng.normal(size=n)
    nonuser = rng.random(n) < 1/(1+np.exp(-(-0.8-0.5*Z)))
    X=np.where(nonuser,0.0,np.exp(0.3*Z+rng.normal(scale=0.6,size=n)))
    Y=beta*X+0.5*Z+rng.normal(size=n)
    R=rng.random(n)<np.where(X==0,p0,p1)
    def ols(Xc,Yc,Zc):
        A=np.column_stack([np.ones(len(Yc)),Xc,Zc]); return np.linalg.lstsq(A,Yc,rcond=None)[0][1]
    obs=~R
    out={}
    out['cc_beta']=ols(X[obs],Y[obs],Z[obs]); out['cc_mean']=X[obs].mean()
    Xz=np.where(R,0.0,X); out['zf_beta']=ols(Xz,Y,Z); out['zf_mean']=Xz.mean()
    # MI: predictive mean matching on X ~ Y + Z (closer to standard MICE default)
    A=np.column_stack([np.ones(obs.sum()),Y[obs],Z[obs]]); coef=np.linalg.lstsq(A,X[obs],rcond=None)[0]
    resid=X[obs]-A@coef; df=obs.sum()-3; s2=resid@resid/df; cov=np.linalg.inv(A.T@A)
    Am=np.column_stack([np.ones(R.sum()),Y[R],Z[R]])
    b=[];mu=[]
    for m in range(M):
        cd=rng.multivariate_normal(coef,cov*s2*df/rng.chisquare(df))
        yhat_obs=A@coef; yhat_mis=Am@cd
        idx=np.searchsorted(np.sort(yhat_obs),yhat_mis).clip(0,obs.sum()-1)
        order=np.argsort(yhat_obs); donors=X[obs][order]
        # pick random among 5 nearest
        k=(idx[:,None]+np.arange(-2,3)[None,:]).clip(0,obs.sum()-1)
        pick=k[np.arange(len(idx)),rng.integers(0,5,len(idx))]
        Xi=X.copy(); Xi[R]=donors[pick]
        b.append(ols(Xi,Y,Z)); mu.append(Xi.mean())
    out['mi_beta']=np.mean(b); out['mi_mean']=np.mean(mu)
    out['true_mean']=X.mean(); out['frac_blank']=R.mean()
    return out
for p0,p1 in [(0.5,0.05),(0.8,0.02)]:
    rs=[one(p0=p0,p1=p1) for _ in range(150)]
    keys=rs[0].keys()
    print('P(blank|never)=',p0,'P(blank|user)=',p1)
    for k in keys: print(f'  {k:10s} {np.mean([r[k] for r in rs]):.3f}')
