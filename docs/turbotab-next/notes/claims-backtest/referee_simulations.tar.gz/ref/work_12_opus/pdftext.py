import re, zlib, sys
data = open(sys.argv[1],'rb').read()
out=[]
for m in re.finditer(rb'stream\r?\n(.*?)\r?\nendstream', data, re.S):
    s=m.group(1)
    try:
        d=zlib.decompress(s)
    except Exception:
        continue
    # extract text in TJ/Tj
    txt=[]
    for t in re.finditer(rb'\[(.*?)\]\s*TJ|\((.*?)\)\s*Tj', d, re.S):
        if t.group(1) is not None:
            parts=re.findall(rb'\(((?:\\.|[^\\)])*)\)|(-?\d+\.?\d*)', t.group(1))
            line=b''
            for p,num in parts:
                if p: line+=p
                elif num and float(num)<-200: line+=b' '
            txt.append(line)
        else:
            txt.append(t.group(2))
    if txt:
        out.append(b' '.join(txt))
sys.stdout.buffer.write(b'\n'.join(out))
