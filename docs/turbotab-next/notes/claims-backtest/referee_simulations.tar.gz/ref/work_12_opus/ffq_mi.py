# FFQ blank = mostly 'never'. Compare complete-case, zero-fill, and MI under MAR (with outcome) for beta in Y ~ X + Z
import numpy as np
rng=np.random.default_rng(1)
def one(n=2000, beta=0.5, M=10):
    Z=rng.normal(size=n)
    nonuser = rng.random(n) < 1/(1+np.exp(-(-0.8-0.5*Z)))  # ~30% never
    X=np.where(nonuser,0.0,np.exp(0.3*Z+rng.normal(scale=0.6,size=n)))
    Y=beta*X+0.5*Z+rng.normal(size=n)
    pblank=np.where(X==0,0.5,0.05)
    R=rng.random(n)<pblank  # True = blank
    def ols(Xc,Yc,Zc):
        A=np.column_stack([np.ones(len(Yc)),Xc,Zc]); return np.linalg.lstsq(A,Yc,rcond=None)[0][1]
    cc=ols(X[~R],Y[~R],Z[~R])
    zf=ols(np.where(R,0.0,X),Y,Z)
    # MI under MAR: normal linear regression of X on Y,Z among observed, proper draws
    obs=~R; A=np.column_stack([np.ones(obs.sum()),Y[obs],Z[obs]])
    coef,res,_,_=np.linalg.lstsq(A,X[obs],rcond=None)
    resid=X[obs]-A@coef; df=obs.sum()-3; s2=resid@resid/df
    cov=np.linalg.inv(A.T@A)
    ests=[]
    for m in range(M):
        s2d=s2*df/rng.chisquare(df)
        cd=rng.multivariate_normal(coef,cov*s2d)
        Am=np.column_stack([np.ones(R.sum()),Y[R],Z[R]])
        Xi=X.copy(); Xi[R]=Am@cd+rng.normal(scale=np.sqrt(s2d),size=R.sum())
        ests.append(ols(Xi,Y,Z))
    mi=np.mean(ests)
    # PMM-like: also mean intake bias
    return cc,zf,mi, X.mean(), np.where(R,np.nan,X)
res=np.array([one()[:4] for _ in range(200)])
print('true beta 0.5')
for name,i in [('complete case',0),('zero fill',1),('MI MAR w/ Y',2)]:
    print(f'{name:14s} mean={res[:,i].mean():.3f} sd={res[:,i].std():.3f}')
