import numpy as np, pandas as pd, statsmodels.formula.api as smf
rng = np.random.default_rng(4)
def one(n, eff):
    x = rng.lognormal(0, 0.6, n); f = eff*np.log(x); f = f - f.mean()
    y = f + rng.normal(size=n); d = pd.DataFrame(dict(x=x, y=y))
    d["q"] = pd.qcut(d.x, 5, labels=False)
    k = np.quantile(x, [0.05, 0.35, 0.65, 0.95])
    mq = smf.ols("y ~ C(q)", d).fit()
    ms = smf.ols(f"y ~ cr(x, knots=({k[1]},{k[2]}), lower_bound={x.min()}, upper_bound={x.max()})", d).fit()
    out=[]
    for m in (mq, ms):
        fh = m.fittedvalues - m.fittedvalues.mean()
        out += [np.mean((fh-f)**2), m.f_pvalue < 0.05]
    return out
for n, eff in ((500, 0.0), (500, 0.15), (2000, 0.15), (2000, 0.4)):
    r = np.array([one(n, eff) for _ in range(400)])
    print(f"n={n} eff={eff}: curve MSE quintile={r[:,0].mean():.4f} spline={r[:,2].mean():.4f} | reject rate quintile={r[:,1].mean():.3f} spline={r[:,3].mean():.3f}")
