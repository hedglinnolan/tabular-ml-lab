import re, zlib, sys
data = open(sys.argv[1],'rb').read()
streams = re.findall(rb'stream\r?\n(.*?)\r?\nendstream', data, re.S)
out=[]
for s in streams:
    try:
        d = zlib.decompress(s)
    except Exception:
        continue
    # extract text from TJ/Tj operators
    parts = re.findall(rb'\[(.*?)\]\s*TJ|\((.*?)\)\s*Tj', d, re.S)
    txt=[]
    for a,b in parts:
        if a:
            txt.append(b''.join(re.findall(rb'\(((?:\\.|[^\\)])*)\)', a)))
        else:
            txt.append(b)
    if txt:
        out.append(b' '.join(txt))
    elif b'BT' not in d and len(d)<200000:
        pass
print(len(streams), 'streams')
t = b'\n'.join(out).decode('latin-1')
open(sys.argv[2],'w').write(t)
print(len(t))
