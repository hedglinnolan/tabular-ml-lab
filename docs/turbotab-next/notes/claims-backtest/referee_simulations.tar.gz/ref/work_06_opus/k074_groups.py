import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold, GroupKFold, cross_val_score
from sklearn.metrics import r2_score
rng = np.random.default_rng(3)
def make(nsub, m, clustered):
    ids = np.repeat(np.arange(nsub), m)
    if clustered:
        z = rng.normal(size=(nsub,3))[ids]        # subject-level traits (constant within subject)
        u = rng.normal(scale=1.0, size=nsub)[ids] # subject random effect not explained by features
        w = rng.normal(size=(len(ids),2))
        X = np.column_stack([z, w]); y = z[:,0] + 0.5*w[:,0] + u + rng.normal(scale=0.7,size=len(ids))
    else:
        X = rng.normal(size=(nsub*m,5)); y = X[:,0] + 0.5*X[:,3] + rng.normal(scale=1.2,size=nsub*m)
    return X, y, ids
for clustered in (True, False):
    rows=[]
    for rep in range(6):
        X,y,ids = make(80,5,clustered)
        rf = RandomForestRegressor(n_estimators=100, min_samples_leaf=2, n_jobs=1, random_state=rep)
        r_rand = cross_val_score(rf, X, y, cv=KFold(5, shuffle=True, random_state=rep), scoring="r2").mean()
        r_grp = cross_val_score(rf, X, y, cv=GroupKFold(5), groups=ids, scoring="r2").mean()
        Xn,yn,_ = make(400,5,clustered)
        r_true = r2_score(yn, rf.fit(X,y).predict(Xn))
        rows.append((r_rand,r_grp,r_true))
    a=np.mean(rows,0)
    print(f"clustered={clustered}: random-fold CV R2={a[0]:.3f}  grouped CV R2={a[1]:.3f}  true R2 on new units={a[2]:.3f}")
