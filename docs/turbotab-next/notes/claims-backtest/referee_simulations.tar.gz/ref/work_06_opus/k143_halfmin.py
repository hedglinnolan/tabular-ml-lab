import numpy as np, statsmodels.api as sm
rng = np.random.default_rng(1)
def run(n=300, cens_q=0.35, reps=2000, role="outcome"):
    cover=0; bias=[]
    for _ in range(reps):
        g = rng.integers(0,2,n)
        if role=="outcome":
            logm = 0.4*g + rng.normal(size=n); true=0.4
        else:
            logm = rng.normal(size=n); y = 0.5*logm + rng.normal(size=n); true=0.5
        lod = np.quantile(logm, cens_q) if False else np.log(np.exp(np.quantile(rng.normal(size=100000)+ (0.2 if role=="outcome" else 0), cens_q)))
        obs = logm.copy(); below = logm < lod
        fill = np.log(0.5*np.exp(obs[~below].min()))
        obs[below] = fill
        if role=="outcome":
            X = sm.add_constant(g); fit = sm.OLS(obs, X).fit()
        else:
            X = sm.add_constant(obs); fit = sm.OLS(y, X).fit()
        b = fit.params[1]; lo, hi = fit.conf_int()[1]
        cover += (lo <= true <= hi); bias.append(b-true)
    return cover/reps, np.mean(bias)
for role in ("outcome","exposure"):
    for q in (0.1, 0.35, 0.5):
        c, b = run(cens_q=q, role=role)
        print(f"metabolite as {role:8s} censored~{q:.0%}: 95% CI coverage={c:.3f}, mean bias={b:+.3f}")
