import numpy as np
from sklearn.linear_model import LinearRegression, RidgeCV
rng = np.random.default_rng(0)
alphas = np.logspace(-3, 4, 40)
def sim(n, p, r2, rho, reps=100):
    S = rho*np.ones((p,p)) + (1-rho)*np.eye(p); L = np.linalg.cholesky(S)
    res = []
    for _ in range(reps):
        beta = rng.normal(size=p)
        sig2 = beta@S@beta*(1-r2)/r2
        X = rng.normal(size=(n,p))@L.T; y = X@beta + rng.normal(scale=np.sqrt(sig2), size=n)
        Xt = rng.normal(size=(5000,p))@L.T; yt = Xt@beta + rng.normal(scale=np.sqrt(sig2), size=5000)
        e_ols = np.mean((LinearRegression().fit(X,y).predict(Xt)-yt)**2)
        e_r = np.mean((RidgeCV(alphas=alphas).fit(X,y).predict(Xt)-yt)**2)
        res.append((e_ols/sig2, e_r/sig2))
    a = np.array(res)
    return a.mean(0), np.mean(a[:,1] < a[:,0])
for p in (10, 30):
    for n in (40, 100, 300, 1000, 2000, 4000):
        if n <= p+2: continue
        (o, r), frac = sim(n, p, 0.3, 0.5)
        print(f"p={p:3d} n={n:5d}  OLS testMSE/sig2={o:.3f}  RidgeCV={r:.3f}  ridge better in {frac:.0%} of reps")
