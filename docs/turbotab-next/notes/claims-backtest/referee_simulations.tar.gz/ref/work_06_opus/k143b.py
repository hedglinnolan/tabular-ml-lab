import numpy as np
from scipy.stats import norm
rng = np.random.default_rng(2)
def ols(x, y):
    X = np.column_stack([np.ones_like(x), x]); b, *_ = np.linalg.lstsq(X, y, rcond=None)
    r = y - X@b; s2 = r@r/(len(y)-2); V = s2*np.linalg.inv(X.T@X); return b[1], np.sqrt(V[1,1])
for n in (300, 1000):
  for role in ("outcome","exposure"):
    for q in (0.35, 0.5):
        cov=0; bs=[]
        for _ in range(1500):
            g = rng.integers(0,2,n).astype(float)
            if role=="outcome":
                m = 0.4*g + rng.normal(size=n); true=0.4; lod = norm.ppf(q)+0.2
            else:
                m = rng.normal(size=n)+0.6*rng.normal(size=n)*0; true=0.5; lod=norm.ppf(q)
                y = 0.5*m + 0.7*m**0 * rng.normal(size=n)
            o = m.copy(); bel = m<lod; o[bel] = np.log(0.5)+o[~bel].min()
            b, se = (ols(g,o) if role=="outcome" else ols(o,y))
            cov += abs(b-true) <= 1.96*se; bs.append(b-true)
        print(f"n={n} {role:8s} cens={q:.0%} coverage={cov/1500:.3f} bias={np.mean(bs):+.3f}")
