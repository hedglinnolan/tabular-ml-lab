import numpy as np, pandas as pd, statsmodels.formula.api as smf
rng = np.random.default_rng(5)
n = 20000
E = rng.normal(2000, 500, n)
N = 20 + 0.02*E + rng.normal(0, 13, n)          # nutrient g/d, corr(N,E) ~ 0.6
print("corr(N,E)=%.2f" % np.corrcoef(N,E)[0,1])
fitb = np.polyfit(E, N, 1); b = fitb[0]; Ebar = E.mean(); Nbar = N.mean()
radj = N - np.polyval(fitb, E) + Nbar            # energy-adjusted intake (residual + mean)
h = lambda x: np.where(x < 55, 0.0, 0.08*(x-55))  # threshold-shaped curve, in outcome units
grid = np.linspace(np.quantile(N,.05), np.quantile(N,.95), 25)
def fit_curves(Y):
    d = pd.DataFrame(dict(Y=Y, N=N, E=E, R=radj))
    ks = lambda v: tuple(np.quantile(v, [.25,.5,.75]))
    ms = smf.ols(f"Y ~ cr(N, knots={ks(N)}, lower_bound={N.min()}, upper_bound={N.max()}) + E", d).fit()
    mr = smf.ols(f"Y ~ cr(R, knots={ks(radj)}, lower_bound={radj.min()}, upper_bound={radj.max()}) + E", d).fit()
    out = {}
    for E0 in (Ebar-500, Ebar, Ebar+500):
        R0 = grid - b*(E0-Ebar)   # energy-adjusted intake of someone with intake=grid at energy E0
        cs = ms.predict(pd.DataFrame(dict(N=grid, E=E0)))
        cr_ = mr.predict(pd.DataFrame(dict(R=np.clip(R0, radj.min(), radj.max()), E=E0)))
        out[E0] = (cs.values, cr_.values)
    return out
for truth in ("additive h(N)+dE", "residual-type h(N-b(E-Ebar))+dE"):
    if truth.startswith("additive"):
        Y = h(N) + 0.001*E + rng.normal(0,1,n); tc = lambda E0: h(grid)
    else:
        Y = h(N - b*(E-Ebar)) + 0.001*E + rng.normal(0,1,n); tc = lambda E0: h(grid - b*(E0-Ebar))
    out = fit_curves(Y)
    for E0,(cs,cr_) in out.items():
        t = tc(E0)
        # compare curve shapes (centered at grid midpoint contrast): RMSE of contrasts vs truth
        rs = np.sqrt(np.mean(((cs-cs[0])-(t-t[0]))**2)); rr = np.sqrt(np.mean(((cr_-cr_[0])-(t-t[0]))**2))
        print(f"truth={truth:34s} E0={E0:6.0f}: RMSE of fixed-energy curve vs truth  standard={rs:.3f}  residual={rr:.3f}  (true range {t.max()-t.min():.2f})")
