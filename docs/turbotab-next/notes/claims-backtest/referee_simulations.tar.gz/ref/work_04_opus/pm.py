import sys, json, time, urllib.request, urllib.parse
term = sys.argv[1]
u = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi?" + urllib.parse.urlencode({"db":"pubmed","term":term,"retmode":"json","retmax":2})
ids = json.load(urllib.request.urlopen(u, timeout=25))["esearchresult"]["idlist"]
print("ids", ids)
time.sleep(0.5)
if ids:
    u = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi?" + urllib.parse.urlencode({"db":"pubmed","id":ids[0],"rettype":"abstract","retmode":"text"})
    print(urllib.request.urlopen(u, timeout=25).read().decode()[:3500])
