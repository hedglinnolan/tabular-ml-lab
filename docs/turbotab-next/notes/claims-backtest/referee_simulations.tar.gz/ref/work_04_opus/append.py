import json, sys
OUT = "/private/tmp/claude-501/-Users-nhedglin-tabular-ml-lab/a12607bd-3f0c-4a23-8d52-bda4a2c1292e/scratchpad/ref/out/merits_04_opus.jsonl"
obj = json.load(open(sys.argv[1]))
req = ["id","truth","failing_part","narrowest_regime","reason","basis_used","citations","bite","bite_note","confidence"]
assert all(k in obj for k in req), [k for k in req if k not in obj]
with open(OUT, "a") as f:
    f.write(json.dumps(obj, ensure_ascii=False) + "\n")
print("appended", obj["id"])
