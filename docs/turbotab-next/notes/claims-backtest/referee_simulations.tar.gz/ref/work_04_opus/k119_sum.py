import json, numpy as np
R = [json.loads(l) for l in open("k119_res.jsonl")]
print("reps", len(R), "events median", np.median([r["events"] for r in R]))
for lib in ("hgb", "xgb"):
    for m in ("auc", "ll", "brier", "slope"):
        d = np.array([r[f"{lib}_default"][m] for r in R]); t = np.array([r[f"{lib}_tuned"][m] for r in R])
        better = (t > d).mean() if m == "auc" else ((t < d).mean() if m in ("ll","brier") else (np.abs(t-1) < np.abs(d-1)).mean())
        print(f"{lib} {m:6s} default {d.mean():.4f}  tuned {t.mean():.4f}  diff(t-d) {np.mean(t-d):+.4f} se {np.std(t-d,ddof=1)/np.sqrt(len(d)):.4f}  tuned better in {better:.2f}")
