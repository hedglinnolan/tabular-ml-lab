import numpy as np, statsmodels.api as sm
from sklearn.linear_model import Ridge
rng = np.random.default_rng(104); n=300
x = rng.choice([0., 2.], n)            # two-valued amount with gap 2
I = (x == 2).astype(float)             # indicator coding
z = rng.standard_normal(n)
y = 1 + 0.8*I + 0.5*z + rng.standard_normal(n)
for name, v in (("amount", x), ("indicator", I)):
    f = sm.OLS(y, sm.add_constant(np.c_[v, z])).fit()
    print(name, "slope", f.params[1].round(4), "CI", f.conf_int()[1].round(4), "t", f.tvalues[1].round(3))
fa = sm.OLS(y, sm.add_constant(np.c_[x, z])).fit().fittedvalues
fi = sm.OLS(y, sm.add_constant(np.c_[I, z])).fit().fittedvalues
print("max |pred diff| OLS:", np.abs(fa-fi).max())
ra = Ridge(alpha=50).fit(np.c_[x, z], y).predict(np.c_[x, z]); ri = Ridge(alpha=50).fit(np.c_[I, z], y).predict(np.c_[I, z])
print("max |pred diff| unstandardized ridge:", np.abs(ra-ri).max().round(4))
