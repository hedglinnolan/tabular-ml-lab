# Fixed "fitted" models; MC step of a parametric g-formula. Compare true MC SD of the estimate with sd(r_i)/sqrt(n_sim).
import numpy as np
rng0 = np.random.default_rng(113)
n_obs = 500; L0_obs = rng0.normal(0, 1, n_obs)
def final_risk(L0, rng):
    # two intervals; L1 depends on L0 and (intervened) A0=1; hazards depend on L0, L1
    L1 = 0.6*L0 + 0.5 + rng.normal(0, 1, L0.size)
    h1 = 1/(1+np.exp(-(-2.5 + 0.8*L0))); h2 = 1/(1+np.exp(-(-2.0 + 0.7*L1 + 0.3*L0)))
    return 1 - (1-h1)*(1-h2)
for design, n_sim in (("resample baseline iid", 5000), ("cycle observed baseline", 500), ("cycle x10", 5000)):
    ests, sds = [], []
    for rep in range(2000):
        rng = np.random.default_rng(rep)
        if design.startswith("resample"): L0 = rng.choice(L0_obs, n_sim, replace=True)
        else: L0 = np.tile(L0_obs, n_sim//n_obs)
        r = final_risk(L0, rng); ests.append(r.mean()); sds.append(r.std(ddof=1)/np.sqrt(n_sim))
    print(f"{design:26s} n_sim={n_sim}: true MC SD {np.std(ests):.5f}   mean sd(r)/sqrt(n) {np.mean(sds):.5f}   ratio bound/true {np.mean(sds)/np.std(ests):.2f}")
