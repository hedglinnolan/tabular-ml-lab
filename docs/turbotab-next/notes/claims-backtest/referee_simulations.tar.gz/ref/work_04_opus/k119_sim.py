# Defaults vs nested-tuned boosting at small effective size (binary outcome, ~120 events in training).
import sys, json, numpy as np, time
from sklearn.ensemble import HistGradientBoostingClassifier as HGB
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, log_loss, brier_score_loss
import statsmodels.api as sm
import xgboost as xgb
seed0, nrep = int(sys.argv[1]), int(sys.argv[2])
n, prev_shift, p, ntest, S = 400, -1.0, 10, 20000, 12
def gen(rng, m):
    X = rng.standard_normal((m, p))
    lin = prev_shift + 0.8*X[:,0] - 0.6*X[:,1] + 0.5*X[:,2]*X[:,3] + 0.7*np.sin(2*X[:,4]) + 0.4*(X[:,5]>0)
    y = (rng.random(m) < 1/(1+np.exp(-lin))).astype(int)
    return X, y
def calslope(y, pr):
    pr = np.clip(pr, 1e-6, 1-1e-6); lg = np.log(pr/(1-pr))
    return sm.GLM(y, sm.add_constant(lg), family=sm.families.Binomial()).fit().params[1]
def hgb(cfg): return HGB(**cfg, early_stopping=False, random_state=0)
def xg(cfg): return xgb.XGBClassifier(**cfg, n_jobs=1, tree_method="hist", verbosity=0)
HGB_DEF = dict(learning_rate=0.1, max_leaf_nodes=31, min_samples_leaf=20, l2_regularization=0.0, max_iter=100)
XGB_DEF = dict(learning_rate=0.3, max_depth=6, min_child_weight=1, reg_lambda=1.0, n_estimators=100)
def cands(rng):
    h, x = [], []
    for _ in range(S):
        lr = float(np.exp(rng.uniform(np.log(0.01), np.log(0.3)))); it = int(rng.integers(50, 501))
        h.append(dict(learning_rate=lr, max_leaf_nodes=int(rng.integers(3, 32)), min_samples_leaf=int(rng.integers(5, 51)),
                      l2_regularization=float(rng.uniform(0, 10)), max_iter=it))
        x.append(dict(learning_rate=lr, max_depth=int(rng.integers(1, 7)), min_child_weight=float(rng.uniform(1, 10)),
                      reg_lambda=float(np.exp(rng.uniform(np.log(0.1), np.log(10)))), n_estimators=it))
    return [HGB_DEF]+h, [XGB_DEF]+x   # defaults are included among the candidates
def tune(make, cfgs, X, y, rng):
    skf = StratifiedKFold(3, shuffle=True, random_state=int(rng.integers(1e9)))
    best, bl = None, np.inf
    for c in cfgs:
        ll = 0
        for tr, va in skf.split(X, y):
            m = make(c).fit(X[tr], y[tr]); ll += log_loss(y[va], m.predict_proba(X[va])[:,1], labels=[0,1])
        if ll < bl: bl, best = ll, c
    return best
res = []
for rep in range(seed0, seed0+nrep):
    rng = np.random.default_rng(1000+rep)
    X, y = gen(rng, n); Xt, yt = gen(rng, ntest)
    hc, xc = cands(rng)
    row = {"rep": rep, "events": int(min(y.sum(), n-y.sum()))}
    for lib, make, dflt, cs in (("hgb", hgb, HGB_DEF, hc), ("xgb", xg, XGB_DEF, xc)):
        for arm, cfg in (("default", dflt), ("tuned", tune(make, cs, X, y, rng))):
            pr = make(cfg).fit(X, y).predict_proba(Xt)[:,1]
            row[f"{lib}_{arm}"] = dict(auc=roc_auc_score(yt, pr), ll=log_loss(yt, pr), brier=brier_score_loss(yt, pr), slope=calslope(yt, pr))
    res.append(row)
for r in res: print(json.dumps(r))
