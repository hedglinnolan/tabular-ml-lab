# Normal (transformed-scale) usual-intake model: x_ij = mu + b_i + e_ij. N persons, m with a 2nd recall.
# Compare error in the prevalence below the true usual-intake 20th percentile:
#  (A) distribution of each person's mean of available days, (B) variance-components (NCI-style, no covariates) estimate.
import numpy as np
from scipy.stats import norm
rng = np.random.default_rng(53)
N, nsim = 500, 2000
for ratio in (1.0, 3.0):           # sigma_w^2 / sigma_b^2
    sb, sw = 1.0, np.sqrt(ratio)
    c = norm.ppf(0.20)*sb           # cut-off at true 20th percentile => true prevalence 0.20
    for m in (2, 5, 10, 30, 100, 500):
        eA, eB, degen = [], [], 0
        for _ in range(nsim):
            b = rng.normal(0, sb, N); d1 = b + rng.normal(0, sw, N)
            d2 = b[:m] + rng.normal(0, sw, m)
            means = d1.copy(); means[:m] = (d1[:m]+d2)/2
            eA.append((means < c).mean() - 0.20)
            sw2 = np.mean((d1[:m]-d2)**2)/2          # within-person variance from m pairs (m df)
            sb2 = np.var(d1, ddof=1) - sw2
            if sb2 <= 1e-6: degen += 1; sb2 = 1e-6
            mu = np.r_[d1, d2].mean()
            eB.append(norm.cdf((c-mu)/np.sqrt(sb2)) - 0.20)
        eA, eB = np.array(eA), np.array(eB)
        print(f"ratio={ratio} m={m:3d}  mean-of-days bias {eA.mean():+.3f} rmse {np.sqrt((eA**2).mean()):.3f} | ME-model bias {eB.mean():+.3f} rmse {np.sqrt((eB**2).mean()):.3f}  sb2<=0 in {degen/nsim:.3f}  |eB|>|eA| in {(np.abs(eB)>np.abs(eA)).mean():.2f}")
