# Two symmetric models (OLS on X1-block vs OLS on X2-block, equal true signal) => E[score diff]=0.
# Rejection rate of naive paired t over 10x5 CV fold differences (df=49) vs Nadeau-Bengio corrected t.
import numpy as np
from scipy import stats
rng = np.random.default_rng(52)
n, p, r, K, nsim = 200, 3, 10, 5, 400
rej_naive = rej_nb = 0
tcrit = stats.t.ppf(0.975, r*K-1)
for s in range(nsim):
    X1 = rng.standard_normal((n,p)); X2 = rng.standard_normal((n,p))
    y = X1.sum(1)*0.5 + X2.sum(1)*0.5 + rng.standard_normal(n)
    d = []
    for rep in range(r):
        perm = rng.permutation(n); folds = np.array_split(perm, K)
        for k in range(K):
            te = folds[k]; tr = np.setdiff1d(perm, te)
            sc = []
            for X in (X1, X2):
                A = np.c_[np.ones(len(tr)), X[tr]]
                b = np.linalg.lstsq(A, y[tr], rcond=None)[0]
                pred = np.c_[np.ones(len(te)), X[te]] @ b
                sc.append(np.mean((y[te]-pred)**2))
            d.append(sc[0]-sc[1])
    d = np.array(d); m = d.mean(); s2 = d.var(ddof=1)
    t_naive = m/np.sqrt(s2/(r*K))
    t_nb = m/np.sqrt((1/(r*K) + (1/K)/(1-1/K))*s2)
    rej_naive += abs(t_naive) > tcrit
    rej_nb += abs(t_nb) > tcrit
print(f"nsim={nsim}  naive rejection={rej_naive/nsim:.3f}  (nominal 0.05)  NB-corrected rejection={rej_nb/nsim:.3f}")
