import json, sys, urllib.request, urllib.parse
q = sys.argv[1]; rows = int(sys.argv[2]) if len(sys.argv)>2 else 2
u = "https://api.crossref.org/works?rows=%d&query.bibliographic=%s" % (rows, urllib.parse.quote(q))
d = json.load(urllib.request.urlopen(u, timeout=25))
for i in d['message']['items']:
    au = ", ".join((a.get('family') or '') for a in i.get('author', [])[:5])
    print(i.get('title'), '|', au, '|', i.get('container-title'), i.get('volume'), i.get('page'), i.get('DOI'), i.get('issued',{}).get('date-parts'))
