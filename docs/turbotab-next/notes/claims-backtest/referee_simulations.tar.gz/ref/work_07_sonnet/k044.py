import numpy as np, statsmodels.api as sm, warnings
warnings.filterwarnings("ignore")
rng=np.random.default_rng(1)
n=100
a=np.r_[np.zeros(50),np.ones(50)]
x=rng.normal(size=n)
y=np.r_[np.zeros(50),(rng.random(50)<0.4).astype(int)]; y[:]=y
y[a==0]=0  # control arm: no events -> complete/quasi separation on arm
print("events control/treated:",y[a==0].sum(),y[a==1].sum())
X=sm.add_constant(np.column_stack([a,x]))
for it in (5,10,25,50,100):
    try:
        m=sm.Logit(y,X).fit(method="newton",maxiter=it,disp=0,warn_convergence=False)
    except Exception as e:
        print(it,"err",e); continue
    X1=X.copy();X1[:,1]=1;X0=X.copy();X0[:,1]=0
    r1=m.predict(X1).mean();r0=m.predict(X0).mean()
    print(f"iter={it:3d} coef_arm={m.params[1]:8.2f} std risk treated={r1:.4f} control={r0:.6f} RD={r1-r0:.4f} RR={r1/max(r0,1e-300):.3g}")
print("raw arm risks",y[a==1].mean(),y[a==0].mean())
