import numpy as np, sys, time
from scipy.optimize import minimize
from scipy import stats
rng=np.random.default_rng(int(sys.argv[2]) if len(sys.argv)>2 else 5)
K=4
def F(z): return 1/(1+np.exp(-z))
def f(z): e=F(z); return e*(1-e)
def parts(par,X,y):
    th=par[:K-1]; be=par[K-1:]
    eta=X@be
    up=np.where(y<K-1,th[np.minimum(y,K-2)],np.inf)      # y in 0..K-1 ; upper cutoff th[y]
    lo=np.where(y>0,th[np.maximum(y-1,0)],-np.inf)
    Fu=np.where(np.isinf(up),1.0,F(up-eta)); Fl=np.where(np.isinf(lo),0.0,F(lo-eta))
    fu=np.where(np.isinf(up),0.0,f(up-eta)); fl=np.where(np.isinf(lo),0.0,f(lo-eta))
    p=np.clip(Fu-Fl,1e-12,None)
    return eta,p,fu,fl
def nll(par,X,y):
    _,p,_,_=parts(par,X,y); return -np.log(p).sum()
def scores(par,X,y):
    eta,p,fu,fl=parts(par,X,y)
    n=len(y); S=np.zeros((n,len(par)))
    for k in range(K-1):
        S[:,k]=np.where(y==k,fu/p,0)+np.where(y==k+1,-fl/p,0)
    S[:,K-1:]=(-(fu-fl)/p)[:,None]*X
    return S
def fit(X,y):
    p0=np.r_[np.linspace(-1,1,K-1),np.zeros(X.shape[1])]
    r=minimize(lambda q:nll(q,X,y),p0,jac=lambda q:-scores(q,X,y).sum(0),method="BFGS")
    return r.x
def hess(par,X,y,h=1e-5):
    d=len(par);H=np.zeros((d,d))
    for j in range(d):
        e=np.zeros(d);e[j]=h
        H[:,j]=(-scores(par+e,X,y).sum(0)+scores(par-e,X,y).sum(0))/(2*h)
    return (H+H.T)/2
def gen(G,m,design,beta=0.7,sd_u=1.0):
    g=np.repeat(np.arange(G),m)
    u=rng.normal(0,sd_u,G)[g]
    if design=="row": x=rng.normal(size=G*m)
    else: x=(rng.random(G)<0.5).astype(float)[g]
    ystar=beta*x+u+rng.logistic(size=G*m)
    cuts=np.array([-1.0,0.5,2.0])
    y=np.searchsorted(cuts,ystar)
    return x[:,None],y,g
# pseudo-true beta from large sample
for design in ("row","cluster"):
    X,y,g=gen(4000,10,design); pt=fit(X,y)[K-1]
    print(design,"pseudo-true beta (marginal PO fit)",round(pt,3))
    for G in (8,15,30,60):
        m=10; reps=int(sys.argv[1]); cov={"model":0,"CR1_norm":0,"CR1_t":0}; ok=0; wr=[]
        for _ in range(reps):
            X,y,g=gen(G,m,design)
            if len(np.unique(y[X[:,0]==X[:,0].max()]))<2 and design=="cluster": pass
            try:
                par=fit(X,y)
                H=hess(par,X,y); Ai=np.linalg.inv(H)
                S=scores(par,X,y); Sg=np.add.reduceat(S[np.argsort(g,kind="stable")],np.r_[0,np.flatnonzero(np.diff(np.sort(g)))+1],axis=0)
                B=Sg.T@Sg; V=G/(G-1)*Ai@B@Ai
                b=par[K-1]; se_m=np.sqrt(Ai[K-1,K-1]); se_c=np.sqrt(V[K-1,K-1])
            except Exception as e:
                continue
            ok+=1
            cov["model"]+=abs(b-pt)<=1.96*se_m
            cov["CR1_norm"]+=abs(b-pt)<=1.96*se_c
            cov["CR1_t"]+=abs(b-pt)<=stats.t.ppf(.975,G-1)*se_c
            wr.append(se_c/se_m)
        print(f"  G={G:3d} reps={ok} coverage model={cov['model']/ok:.3f} CR1+normal={cov['CR1_norm']/ok:.3f} CR1+t(G-1)={cov['CR1_t']/ok:.3f} median se ratio CR/model={np.median(wr):.2f}")
