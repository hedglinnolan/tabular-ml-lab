import re,zlib,sys
d=open(sys.argv[1],'rb').read()
out=[]
for m in re.finditer(rb'stream\r?\n(.*?)\r?\nendstream',d,re.S):
    s=m.group(1)
    try: t=zlib.decompress(s)
    except Exception: continue
    if b'TJ' not in t and b'Tj' not in t: continue
    txt=[]
    for line in t.split(b'\n'):
        if line.endswith(b'TJ') or line.endswith(b'Tj'):
            parts=re.findall(rb'\((.*?)(?<!\\)\)|(-?\d+\.?\d*)',line)
            s2=''
            for a,b in parts:
                if a: s2+=a.decode('latin1').replace('\\(','(').replace('\\)',')')
                elif b and float(b)<-200: s2+=' '
            txt.append(s2)
        elif line.endswith(b'ET') or b'Td' in line or b'TD' in line:
            txt.append('\n') if False else None
    out.append(' '.join(txt))
open(sys.argv[2],'w').write('\n=====PAGE=====\n'.join(out))
print(len(out))
