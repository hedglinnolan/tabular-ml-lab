import numpy as np, sys
exec(open("k045.py").read().split("# pseudo-true beta")[0].replace("rng=np.random.default_rng(int(sys.argv[2]) if len(sys.argv)>2 else 5)","rng=np.random.default_rng(11)"))
def gen2(G,m,ntreat,beta=0.7,sd_u=1.0,unbal=False):
    sizes=np.full(G,m) if not unbal else np.maximum(2,rng.poisson(m,G)) if False else np.maximum(2,(rng.lognormal(np.log(m),0.8,G)).astype(int))
    g=np.repeat(np.arange(G),sizes)
    tr=np.zeros(G); tr[rng.choice(G,ntreat,replace=False)]=1
    x=tr[g]; u=rng.normal(0,sd_u,G)[g]
    ystar=beta*x+u+rng.logistic(size=len(g))
    y=np.searchsorted(np.array([-1.0,0.5,2.0]),ystar)
    return x[:,None],y,g
def pt_for(G,ntreat):
    # large-G analogue: same treated fraction
    GG=G*200; nt=ntreat*200
    X,y,g=gen2(GG,10,nt); return fit(X,y)[K-1]
for (G,nt,unbal) in ((20,2,False),(40,4,False),(20,2,True),(12,6,True),(30,15,True)):
    pt=pt_for(G,nt)
    reps=int(sys.argv[1]); cov={"CR1_norm":0,"CR1_t":0,"model":0}; ok=0
    for _ in range(reps):
        X,y,g=gen2(G,10,nt,unbal=unbal)
        try:
            par=fit(X,y); H=hess(par,X,y); Ai=np.linalg.inv(H)
            S=scores(par,X,y); o=np.argsort(g,kind="stable"); Sg=np.add.reduceat(S[o],np.r_[0,np.flatnonzero(np.diff(g[o]))+1],axis=0)
            V=G/(G-1)*Ai@(Sg.T@Sg)@Ai; b=par[K-1]; se_c=np.sqrt(V[K-1,K-1]); se_m=np.sqrt(Ai[K-1,K-1])
        except Exception: continue
        ok+=1
        cov["model"]+=abs(b-pt)<=1.96*se_m
        cov["CR1_norm"]+=abs(b-pt)<=1.96*se_c
        cov["CR1_t"]+=abs(b-pt)<=stats.t.ppf(.975,G-1)*se_c
    print(f"G={G} treated clusters={nt} unbalanced sizes={unbal} reps={ok}: model={cov['model']/ok:.3f} CR1+normal={cov['CR1_norm']/ok:.3f} CR1+t(G-1)={cov['CR1_t']/ok:.3f}")
