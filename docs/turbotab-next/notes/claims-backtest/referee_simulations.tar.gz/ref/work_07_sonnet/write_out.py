import json
out="/private/tmp/claude-501/-Users-nhedglin-tabular-ml-lab/a12607bd-3f0c-4a23-8d52-bda4a2c1292e/scratchpad/ref/out/merits_07_sonnet.jsonl"
R=[]
R.append(dict(id="K-055",truth="overstated",
 failing_part="a grouping ... decides how the rows are validated ..., not the model's intercepts, so fixed-effects or cluster-only adjustment is refused",
 narrowest_regime="Prediction for groups (sites, participants, clusters) not present in the training data: whole-group folds / internal-external validation are then the honest check, and group fixed effects cannot be applied to an unseen level.",
 reason="Grouped validation answers 'how well does the model transport to a new group' only. When the model will score new rows from groups already in the training data (repeat visits, known participants or sites), group-level intercepts (fixed, or random with BLUPs) are often the strongest predictor, and row-level or forward-in-time validation is the matching check; refusing them discards signal and grouped folds under-state performance. Even for new groups, the between-group intercept spread is something to report and recalibrate, not ignore. Refusing cluster-robust SEs is harmless because they do not affect predictions.",
 basis_used="derivation",
 citations=[{"cite":"Steyerberg & Harrell 2016, J Clin Epidemiol 69:245-247 (internal-external validation)","verified":True},{"cite":"Royston, Parmar & Sylvester 2004, Stat Med 23:907-926 (leave-one-study-out validation)","verified":True},{"cite":"Roberts et al. 2017, Ecography 40:913-929 (blocked CV)","verified":False}],
 bite="yes",bite_note="Decides the validation scheme (grouped vs random folds), which can change the reported performance a lot when between-group variation is strong, and whether a group-intercept model is allowed at all.",
 confidence=0.7))
R.append(dict(id="K-145",truth="false",
 failing_part="give the same nutrient effect for any functional form ... a restricted cubic spline of the energy residual estimates the nutrient's substitution curve at fixed total energy exactly as a spline of the nutrient with energy beside it does",
 narrowest_regime="Terms linear in the nutrient on the model's linear-predictor scale (linear, logistic, Cox with a linear nutrient term), where the residual and standard models give the same nutrient coefficient (Frisch-Waugh-Lovell).",
 reason="With r = N - a - bE, a spline f(r) is a function of N - bE, so the dose-response curve at fixed energy is f(N - bE - a), which shifts with E; it is equivalent to the standard g(N)+hE model only when g is linear. In a simulation with true Y = g(N) + cE, g quadratic, corr(N,E)=0.55, the residual-spline model's curve matched the truth only near mean energy and was badly off at E=1600 and E=2400 (e.g. predicted +4.3 vs truth +1.8 at the high-N end), and its residual variance was 7.96 against a true noise variance of 1; the standard spline(N)+E model recovered the curve at every E. Willett 1997's equivalence is stated for the linear case.",
 basis_used="mixed",
 citations=[{"cite":"Willett, Howe & Kushi 1997, Am J Clin Nutr 65(4 Suppl):1220S-1228S (abstract checked; the equivalence is for linear terms, full text not retrievable)","verified":False}],
 bite="yes",bite_note="Recommending the residual model for a curved exposure gives a misspecified, energy-shifted curve; the standard nutrient-spline-plus-energy model (or an explicit N x E interaction) is the correct substitution model.",
 confidence=0.9))
R.append(dict(id="K-045",truth="overstated",
 failing_part="the CR1 sandwich ... with a G/(G-1) correction and a t(G-1) reference gives valid 95% intervals",
 narrowest_regime="Many (roughly 40+), reasonably balanced clusters with the exposure not concentrated in a few clusters. The independent-rows Wald claim holds under a correctly specified proportional-odds model.",
 reason="Cameron & Miller say t(G-1) is 'at a minimum' and that with few clusters (anywhere from under 20 to under 50 when balanced, more when unbalanced) the CRVE is still biased downward and tests over-reject. In a proportional-odds simulation (4 categories, cluster random intercept SD 1, cluster size 10), CR1 with t(G-1) covered 92.7-96.7% with 8-60 clusters and a balanced half-treated design, but only 80% with 2 of 20 treated clusters, 86% with 4 of 40, 66% with 2 of 20 under unbalanced cluster sizes, and 83% with 6 of 12 unbalanced. The parenthetical 'no interval below the unit floor' is unclear and is not a validity condition (the CR standard error can fall below the model-based one for a within-cluster covariate).",
 basis_used="mixed",
 citations=[{"cite":"Cameron & Miller 2015, J Human Resources 50:317-372, few-cluster section: 'at a minimum one should use the T(G-1) distribution'; for nonlinear models 'even then tests may over-reject when there are few clusters' (checked in the paper text)","verified":True},{"cite":"MASS::polr / statsmodels OrderedModel Wald intervals","verified":False}],
 bite="yes",bite_note="Whether the app presents the clustered ordinal interval as valid or flags it (or switches to a CR2/CR3 with Satterthwaite df or a wild cluster bootstrap) when clusters are few or exposure sits in few clusters.",
 confidence=0.8))
R.append(dict(id="K-044",truth="overstated",
 failing_part="the model's risks run to 0% or 100% and no finite estimate exists",
 narrowest_regime="The logistic coefficient and odds ratio (no finite MLE under separation), the Wald/delta-method variance, and a risk ratio whose denominator risk goes to 0.",
 reason="Separation removes the finite MLE of the coefficients, but the fitted risks converge, so the standardized risk difference has a finite limit: with 0/50 events in control and 20/50 treated, the g-computed RD stabilized at 0.397 (the observed difference) across IRLS iterations while the coefficient kept growing and the RR diverged. What fails is the inference (infinite Wald SE) and RR, not the point RD. Refusing is defensible, but Firth penalized likelihood, an exact or Newcombe interval for the arm risks, or dropping the separating covariate gives an answer, and the stated reason is wrong for the RD.",
 basis_used="mixed",
 citations=[{"cite":"Heinze & Schemper 2002, Stat Med 21:2409-2419 (Firth penalization for separation)","verified":True}],
 bite="yes",bite_note="Refusing returns no trial effect, whereas a penalized fit or the arm-wise estimate returns a usable one when only one subgroup or arm is separated.",
 confidence=0.7))
R.append(dict(id="K-021",truth="false",
 failing_part="intervals that treat the PSUs as unstratified, which are too narrow",
 narrowest_regime="Intervals are too narrow when the clustering (PSU) itself is dropped; ignoring strata is conservative (too wide). A genuine problem arises only if PSU labels repeat across strata (1/2 coding) and are mistaken for unique clusters.",
 reason="Stratification removes between-stratum variation from the variance, so a PSU-only (unstratified, with-replacement) variance estimator overestimates variance when strata means differ. In a simulation (8 strata, 4 PSUs each, 20 persons per PSU), the stratum-aware variance was 0.0094 (actual 0.0094, coverage 94%) and the PSU-only variance was 0.235 (25 times too large, coverage 100%). Collapsing reused PSU labels (1..4 across strata) gave unbiased variance but only m-1 degrees of freedom. A block may be defensible for data completeness, but the stated direction of error is wrong.",
 basis_used="mixed",
 citations=[{"cite":"Lumley 2010, Complex Surveys (ignoring strata is conservative)","verified":False},{"cite":"Lohr, Sampling: Design and Analysis (stratified vs unstratified variance)","verified":False}],
 bite="yes",bite_note="Blocks the analysis until an attestation is given although the unstratified interval is conservative rather than anti-conservative; a warning, plus a check that PSU labels are unique, would suffice.",
 confidence=0.8))
R.append(dict(id="K-118",truth="true",
 failing_part="",narrowest_regime="Pooled CV RMSE defined as the square root of the pooled out-of-fold MSE (same predictions, same weights). It does not hold if RMSE is the mean of per-fold RMSEs, or if tie-breaking/one-SE rules use the standard error of the score.",
 reason="sqrt is strictly increasing on [0,inf), so the ordering of any two pooled MSEs equals the ordering of the square roots; the table can display either without changing which family is lowest.",
 basis_used="derivation",citations=[],
 bite="no",bite_note="Ranking is unchanged; the choice only affects display units (RMSE is in outcome units, which is easier to read).",
 confidence=0.95))
R.append(dict(id="K-060",truth="overstated",
 failing_part="marks a near dependency among the exposure and adjustment set ... graded 'act on it'",
 narrowest_regime="Dependencies that involve at least two non-intercept columns (or diagnostics after centering), especially structural sum-type partners, where which partners are held fixed defines a substitution; the 30 and 0.5 cutoffs are heuristics.",
 reason="With the intercept in the uncentered, unit-length-scaled matrix, an exposure whose mean is large relative to its SD forms a near dependency with the intercept alone. Height 170 +/- 10 cm gave CI 33.5 with proportions 1.0 and 1.0 on the exposure and the intercept; calendar year gave CI 993; with height, age and SBP the CI was 51 with proportions 0.92 (height) and 0.97 (intercept). Centering drops the CI to about 1, and the slope variance is identical either way, so nothing about the exposure's meaning or precision is at stake. The exposure-proportion sum of 0.5 is not BKW's. Also, collinearity itself does not change what the coefficient means; the chosen adjustment set does, and the substitution reading applies mainly to compositional or sum-constrained partners. Whether the app excludes the intercept from the count could not be checked.",
 basis_used="mixed",
 citations=[{"cite":"Belsley, Kuh & Welsch 1980, Regression Diagnostics, ch. 3 (CI about 30 and two or more proportions above 0.5)","verified":False},{"cite":"Belsley 1984, Am Statistician 38:73-77 (demeaning/centering dispute)","verified":False}],
 bite="yes",bite_note="A Decide card at the adjustment question interrupts the analysis; for uncentered intercept artifacts it would fire spuriously.",
 confidence=0.6))
R.append(dict(id="K-017",truth="overstated",
 failing_part="below 0.3 no such noticing is raised",
 narrowest_regime="|r| >= 0.3 is a reasonable flag that the two energy models will differ materially; the interpretive difference between substitution and addition exists at any r.",
 reason="The substitution versus addition choice always changes what the coefficient means. The size of the numerical change is gamma*rho*sd(E)/sd(N), where gamma is the energy effect on the outcome, so it depends on the outcome's dependence on energy and the SD ratio, not on the correlation alone: at rho=0.25 with a strong energy effect the coefficient can shift by tens of percent. The 0.3 cutoff on a raw Pearson r (nutrients are skewed) has no methods derivation, so 'no noticing below 0.3' invents a regime where the choice does not matter.",
 basis_used="derivation",
 citations=[{"cite":"Willett, Howe & Kushi 1997, Am J Clin Nutr 65:1220S (abstract: adjustment for energy is usually appropriate; no 0.3 threshold)","verified":False}],
 bite="yes",bite_note="Gates whether the researcher is asked about the energy model at all; with r below 0.3 and a strong energy-outcome link the answer would still change.",
 confidence=0.7))
R.append(dict(id="K-038",truth="overstated",
 failing_part="chooses the number of trees well once the plan's effective size is at least 1,500, so that the stopping set ... holds about 100 or more units of the rarest class; below 1,500, searching ... is better",
 narrowest_regime="Direction only: a 10% stopping set is noisier than CV-searched tree counts at small n, with the gap shrinking as n grows.",
 reason="With a stopping set of 10% of the fit's units, n_plan = 1,500 gives about 120-135 stopping rows in total, so about 30-60 of the rarest class even at 25-50% prevalence, so the '100 rarest-class units' arithmetic does not close unless 'effective size' means something else. In a boosted-tree simulation (sklearn HistGradientBoosting, 10 features, 25% prevalence, test log loss on 20,000 rows, 30 reps), CV-searched tree counts beat ES at every n, with a smooth gap (ES minus CV: +0.0143, +0.0078, +0.0039, +0.0030, +0.0039 at n = 300, 600, 1000, 1500, 3000) and no change of regime at 1,500. The 1,500 cutoff and the 100-unit mechanism are not supported.",
 basis_used="mixed",citations=[{"cite":"Rule of about 100 events for validation-set stability (Vergouwe et al. 2005) is a different problem from picking a tree count","verified":False}],
 bite="yes",bite_note="Switches ES on or off for the Sobol candidates (compute versus a small gain in accuracy; the difference in log loss is about 0.003 at n >= 1,500 and 0.008-0.014 below 1,000 in this setup).",
 confidence=0.55))
R.append(dict(id="K-009",truth="true",
 failing_part="",narrowest_regime="Holds as a definition of out-of-sample R2 (Campbell-Thompson style): baseline is the training mean for each fold, SSE and baseline SSE are summed over all out-of-fold predictions. The code that computes it could not be checked.",
 reason="This is a sound convention: the baseline is the predictor a user would have without the model, so a mean-only model scores exactly 0 (confirmed in simulation), whereas sklearn's r2_score on pooled predictions (baseline = mean of all y) gives -0.078, -0.023 and -0.002 at n = 30, 100, 1000, and on a mean-shifted holdout it gives -1.04 instead of 0. Pooling over all out-of-fold predictions is standard and avoids averaging unstable per-fold R2.",
 basis_used="mixed",
 citations=[{"cite":"Campbell & Thompson 2008, Rev Financial Studies 21:1509-1531 (out-of-sample R2 against historical mean)","verified":False}],
 bite="no",bite_note="In random CV at realistic n the two baselines differ by about 1/n; it matters mainly for mean-shifted holdouts (temporal or grouped), where the training-mean baseline is the honest one.",
 confidence=0.7))
R.append(dict(id="K-064",truth="true",
 failing_part="",narrowest_regime="Holds for constant-factor kcal substitution. A %-energy column can still be moved through energy via a person-level conversion (pct/100 x that person's total energy), which is not a constant factor; 'lb' could in principle be a food mass.",
 reason="One percentage point of energy equals E/100 kcal, which differs between people, so no constant kcal-per-unit exists and a fixed factor mis-states the substitution; modelling on the share scale (shares summing to 100% at fixed total energy) is the coherent alternative. A body-weight, height or age column carries no food energy, so refusing a kcal factor on it is correct.",
 basis_used="derivation",citations=[{"cite":"Tomova, Arnold, Gilthorpe & Tennant 2022, Am J Clin Nutr 115:189-198 (energy adjustment and substitution)","verified":True}],
 bite="yes",bite_note="Prevents a numerically meaningless substitution (a constant factor applied to a %-energy or non-food column) that would otherwise be computed silently.",
 confidence=0.65))
R.append(dict(id="K-147",truth="overstated",
 failing_part="must come from a bootstrap over the whole chain",
 narrowest_regime="Model-based intervals that ignore calibration-model uncertainty, and Rubin's rules over per-copy model-based variances that omit it, are too narrow (true). A bootstrap over the whole chain is one valid option, not the only one: a sandwich from stacked calibration and outcome estimating equations is equally accepted.",
 reason="Keogh et al. section 6.1.2 says the usual model SEs are too small and that SEs may be obtained 'either from a bootstrap variance estimator or a sandwich estimator obtained by stacking the calibration and outcome model estimating equations'; so 'must' be a bootstrap overstates their guidance. Schomaker & Heumann show that 3 of 4 bootstrap-plus-MI orderings give valid inference but performance varies with the number of imputations and the amount of missingness, so '5 re-imputations per resample' is a convention. The refusal of model_based and rubin_only is sound.",
 basis_used="literature",
 citations=[{"cite":"Keogh, Shaw et al. 2020, Stat Med 39:2197-2231, section 6.1.2 (text read)","verified":True},{"cite":"Schomaker & Heumann 2018, Stat Med 37:2252-2266 (abstract read)","verified":True},{"cite":"Rao & Wu 1988, JASA 83:231-241","verified":False},{"cite":"Carroll et al. 2006, Measurement Error in Nonlinear Models, App. B.3 (stacked estimating equations)","verified":False}],
 bite="yes",bite_note="Refusing the model-based interval changes the reported interval (wider, honest), whereas bootstrap vs stacked sandwich changes little but affects compute.",
 confidence=0.7))
with open(out,"a") as f:
    for r in R: f.write(json.dumps(r)+"\n")
from collections import Counter
print(Counter(r["truth"] for r in R)); print([ (r["id"],r["truth"],r["confidence"]) for r in R if r["truth"] in("false","overstated")])
