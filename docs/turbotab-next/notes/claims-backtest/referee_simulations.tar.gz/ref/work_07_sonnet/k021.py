import numpy as np
rng=np.random.default_rng(3)
# Stratified two-stage-ish design: H strata, m PSUs per stratum selected, each PSU has n persons; WR PSU sampling.
H=8; m=4; n=20; reps=4000
# population: stratum mean differs, PSU effect, person noise
mu_h=rng.normal(0,2,H)*1.0
def one(strat_var=True):
    ybar_psu=np.empty((H,m))
    for h in range(H):
        u=rng.normal(0,0.5,m)   # PSU effects
        y=mu_h[h]+u[:,None]+rng.normal(0,1,(m,n))
        ybar_psu[h]=y.mean(1)
    est=ybar_psu.mean()          # equal weights: equal allocation
    # strat-aware variance (WR linearization)
    zh=ybar_psu/H                # contribution per PSU: PSU totals scaled
    # estimator = sum_h (1/H) * mean_i ybar_hi ; var = sum_h (1/H^2) s_h^2/m
    v_strat=np.sum(ybar_psu.var(1,ddof=1)/m)/H**2
    # ignoring strata: PSUs treated as one-stage sample of Hm clusters, weights equal
    allp=ybar_psu.ravel()
    v_unstrat=allp.var(ddof=1)/(H*m)
    return est,v_strat,v_unstrat
out=np.array([one() for _ in range(reps)])
true_var=out[:,0].var()
print("actual var of estimate %.5f"%true_var)
print("mean strat-aware var %.5f"%out[:,1].mean(),"mean unstratified var %.5f"%out[:,2].mean())
# coverage with t(df)
from scipy import stats
mu=mu_h.mean()
for nm,col,df in (("strat-aware",1,H*(m-1)),("unstratified",2,H*m-1)):
    se=np.sqrt(out[:,col]); t=stats.t.ppf(.975,df)
    cov=np.mean(np.abs(out[:,0]-mu)<=t*se)
    print(nm,"coverage",cov,"mean width",2*t*se.mean())
# NHANES-style: PSU labels 1..m reused across strata, strata column dropped -> collapse
def one_collapsed():
    ybar=np.empty((H,m))
    for h in range(H):
        u=rng.normal(0,0.5,m); y=mu_h[h]+u[:,None]+rng.normal(0,1,(m,n)); ybar[h]=y.mean(1)
    est=ybar.mean()
    # cluster totals by label j across strata: label j has H PSUs
    tot=ybar.mean(0)   # m collapsed clusters
    v=tot.var(ddof=1)/m
    return est,v
o2=np.array([one_collapsed() for _ in range(reps)])
t=stats.t.ppf(.975,m-1)
print("collapsed labels: mean var %.5f vs actual %.5f; coverage %.3f; median width %.3f"%(o2[:,1].mean(),o2[:,0].var(),np.mean(np.abs(o2[:,0]-mu)<=t*np.sqrt(o2[:,1])),np.median(2*t*np.sqrt(o2[:,1]))))
