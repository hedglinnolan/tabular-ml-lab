import numpy as np
rng=np.random.default_rng(2)
def bkw(X):
    Xs=X/np.sqrt((X**2).sum(0))
    U,s,Vt=np.linalg.svd(Xs,full_matrices=False)
    ci=s.max()/s
    phi=(Vt.T**2)/s**2   # p x p : variable j, component k
    pi=phi/phi.sum(1,keepdims=True)
    return ci,pi
n=500
cases={
 "height_cm 170+-10 alone (+ intercept)":[rng.normal(170,10,n)],
 "calendar year 2010+-4":[rng.normal(2010,4,n)],
 "age 50+-15":[rng.normal(50,15,n)],
 "SBP 120+-15":[rng.normal(120,15,n)],
 "height + age(50+-15) + SBP":[rng.normal(170,10,n),rng.normal(50,15,n),rng.normal(120,15,n)],
}
for name,cols in cases.items():
    X=np.column_stack([np.ones(n)]+cols)
    ci,pi=bkw(X)
    k=np.argmax(ci)
    print(name,"max CI %.1f"%ci.max(),"props at max comp:",np.round(pi[:,k],2))
    # centered
    Xc=np.column_stack([np.ones(n)]+[c-c.mean() for c in cols]); ci2,pi2=bkw(Xc); print("   centered max CI %.2f"%ci2.max())
    # slope variance doesn't depend on centering: show vif
    c=cols[0]; print("   var(slope) uncentered fit==centered fit:", np.linalg.inv(X.T@X)[1,1], np.linalg.inv(Xc.T@Xc)[1,1])
