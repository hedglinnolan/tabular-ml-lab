import os,sys,time
os.environ["OMP_NUM_THREADS"]="1"; os.environ["OPENBLAS_NUM_THREADS"]="1"
import numpy as np
from sklearn.ensemble import HistGradientBoostingClassifier as H
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import log_loss
n=int(sys.argv[1]); reps=int(sys.argv[2]); seed=int(sys.argv[3])
rng=np.random.default_rng(seed)
p=10
def make(m,rng):
    X=rng.normal(size=(m,p))
    eta=-1.6+1.0*X[:,0]+0.8*X[:,1]*X[:,2]+0.7*np.sin(2*X[:,3])+0.6*(X[:,4]>0.5)-0.5*X[:,5]**2+0.4
    y=(rng.random(m)<1/(1+np.exp(-eta))).astype(int); return X,y
Xt,yt=make(20000,np.random.default_rng(999))
print("prevalence",yt.mean())
t0=time.time()
res=[]
for r in range(reps):
    X,y=make(n,rng)
    kw=dict(learning_rate=0.1,max_depth=3,max_leaf_nodes=8,min_samples_leaf=10,l2_regularization=1.0)
    # ES: 10% stopping set, patience 20, up to 1000 rounds
    m=H(max_iter=1000,early_stopping=True,validation_fraction=0.1,n_iter_no_change=20,random_state=r,**kw).fit(X,y)
    ll_es=log_loss(yt,m.predict_proba(Xt)[:,1]); k_es=m.n_iter_
    # CV-searched number of trees
    grid=np.arange(10,401,10)
    cvloss=np.zeros(len(grid))
    for tr,va in StratifiedKFold(5,shuffle=True,random_state=r).split(X,y):
        mm=H(max_iter=400,early_stopping=False,random_state=r,**kw).fit(X[tr],y[tr])
        st=list(mm.staged_predict_proba(X[va]))
        for gi,k in enumerate(grid): cvloss[gi]+=log_loss(y[va],st[k-1][:,1])*len(va)
    kbest=grid[np.argmin(cvloss)]
    m2=H(max_iter=int(kbest),early_stopping=False,random_state=r,**kw).fit(X,y)
    ll_cv=log_loss(yt,m2.predict_proba(Xt)[:,1])
    res.append((ll_es,ll_cv,k_es,kbest))
res=np.array(res)
d=res[:,0]-res[:,1]
print(f"n={n} reps={reps} ES logloss={res[:,0].mean():.4f} CV-trees logloss={res[:,1].mean():.4f} diff(ES-CV)={d.mean():+.4f} se={d.std(ddof=1)/np.sqrt(reps):.4f} trees ES median={np.median(res[:,2])} CV median={np.median(res[:,3])}  time {time.time()-t0:.0f}s")
