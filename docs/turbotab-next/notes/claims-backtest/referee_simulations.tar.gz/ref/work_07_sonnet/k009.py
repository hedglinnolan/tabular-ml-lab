import numpy as np
from sklearn.model_selection import KFold, GroupKFold
from sklearn.metrics import r2_score
rng=np.random.default_rng(4)
# 1. null model (predicts the training mean), random 5-fold CV, various n: which baselines give R2=0?
for n in (30,100,1000):
    r_tr=[];r_te=[];r_pool_global=[]
    for _ in range(300):
        y=rng.normal(size=n); pred=np.empty(n); base=np.empty(n); folds=[]
        for tr,te in KFold(5,shuffle=True,random_state=int(rng.integers(1e9))).split(y):
            pred[te]=y[tr].mean(); base[te]=y[tr].mean()
        sse=((y-pred)**2).sum()
        r_tr.append(1-sse/((y-base)**2).sum())            # pooled, training-mean baseline
        r_te.append(r2_score(y,pred))                     # pooled sklearn: global mean of y as baseline
    print(f"null model n={n}: pooled R2 vs train mean = {np.mean(r_tr):.4f}; sklearn pooled r2_score (mean of all y) = {np.mean(r_te):.4f}")
# 2. shifted holdout (e.g. temporal/grouped): training mean 0, test mean shifted 1, model = null
y_tr=rng.normal(0,1,500); y_te=rng.normal(1.0,1,500)
pred=np.full(500,y_tr.mean())
print("shifted holdout, null model: R2 vs train mean = %.3f ; R2 vs test mean (sklearn) = %.3f"%(1-((y_te-pred)**2).sum()/((y_te-y_tr.mean())**2).sum(), r2_score(y_te,pred)))
