import numpy as np
from patsy import dmatrix
rng=np.random.default_rng(1)
n=200000
E=rng.normal(2000,400,n)
N=0.05*E+rng.normal(0,30,n)   # nutrient, corr with E
b=np.polyfit(E,N,1); r=N-np.polyval(b,E)
print("corr(N,E)",np.corrcoef(N,E)[0,1], "slope",b)
# truth: Y = g(N) + c*E, g quadratic (curved dose response)
g=lambda x: 0.002*(x-100)**2
c=0.001
Y=g(N)+c*E+rng.normal(0,1,n)
def spl(x,df=5): return np.asarray(dmatrix(f"cr(x,df={df})-1",{"x":x}))
# standard model: spline(N)+E
X1=np.column_stack([np.ones(n),spl(N),E]); be1=np.linalg.lstsq(X1,Y,rcond=None)[0]
# residual model: spline(r) + E
X2=np.column_stack([np.ones(n),spl(r),E]); be2=np.linalg.lstsq(X2,Y,rcond=None)[0]
res1=Y-X1@be1; res2=Y-X2@be2
print("resid var standard",res1.var(),"residual-model",res2.var(),"(noise var 1)")
# substitution curve at fixed E=2000: effect of N from 80 to 120 relative to N=100
def curve_standard(Ngrid):
    Xg=np.column_stack([np.ones(len(Ngrid)),spl_fit(Ngrid, N),np.full(len(Ngrid),2000.)])
    return Xg@be1
from patsy import build_design_matrices
d1=dmatrix("cr(x,df=5)-1",{"x":N}); d2=dmatrix("cr(x,df=5)-1",{"x":r})
def pred1(Ng,Efix):
    D=np.asarray(build_design_matrices([d1.design_info],{"x":Ng})[0]); return np.column_stack([np.ones(len(Ng)),D,np.full(len(Ng),Efix)])@be1
def pred2(Ng,Efix):
    rg=Ng-np.polyval(b,Efix)
    D=np.asarray(build_design_matrices([d2.design_info],{"x":rg})[0]); return np.column_stack([np.ones(len(Ng)),D,np.full(len(Ng),Efix)])@be2
Ng=np.array([70.,85,100,115,130])
for Efix in (1600.,2000.,2400.):
    # N at E: mean N = 0.05E ~ 80,100,120 
    truth=g(Ng)-g(Ng[2])
    p1=pred1(Ng,Efix); p1-=p1[2]
    p2=pred2(Ng,Efix); p2-=p2[2]
    print("E=",Efix,"truth",np.round(truth,3),"std",np.round(p1,3),"resid",np.round(p2,3))
