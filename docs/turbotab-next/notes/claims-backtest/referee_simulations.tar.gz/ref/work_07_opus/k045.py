import numpy as np, statsmodels.api as sm, time, warnings
from scipy import stats
warnings.filterwarnings("ignore")
rng=np.random.default_rng(5)
def gen(G, m_sizes, xlevel="cluster"):
    xs=[];ys=[];gs=[]
    for g in range(G):
        m=m_sizes[g]; u=rng.normal(0,1.0)
        if xlevel=="cluster": x=np.full(m, float(g%2==0)) if True else None
        else: x=rng.normal(0,1,m)+rng.normal(0,1)
        p=1/(1+np.exp(-(-0.5+0.5*x+u))); ys.append(rng.binomial(1,p)); xs.append(x); gs.append(np.full(m,g))
    return np.concatenate(xs),np.concatenate(ys),np.concatenate(gs)
def fit(x,y,g):
    X=sm.add_constant(x); r=sm.Logit(y,X).fit(disp=0)
    p=r.predict(X); S=(y-p)[:,None]*X
    Hinv=r.normed_cov_params if hasattr(r,'normed_cov_params') else r.cov_params()
    Hinv=np.asarray(r.cov_params())
    G=len(np.unique(g)); Sg=np.array([S[g==k].sum(0) for k in np.unique(g)])
    V=G/(G-1)*Hinv@(Sg.T@Sg)@Hinv
    return r.params[1], np.sqrt(V[1,1]), G
# truth: plim of independence-logit coefficient
def truth(xlevel, sizes_fn):
    x,y,g=gen(20000, sizes_fn(20000), xlevel); X=sm.add_constant(x); return sm.Logit(y,X).fit(disp=0).params[1]
t0=time.time()
for xlevel in ["cluster"]:
  for label,sizes_fn in [("balanced m=30",lambda G: np.full(G,30)),("unbalanced lognormal",lambda G: np.maximum(5,(rng.lognormal(3,1.0,G))).astype(int))]:
    b0=truth(xlevel,lambda G: np.full(G,30)) if label.startswith("bal") else truth(xlevel,sizes_fn)
    for G in [10,20,50]:
        R=1500; cov=0
        for r in range(R):
            sizes=sizes_fn(G); x,y,g=gen(G,sizes,xlevel)
            try: b,se,GG=fit(x,y,g)
            except Exception: continue
            q=stats.t.ppf(.975,GG-1); cov+= abs(b-b0)<=q*se
        print("%s x at %s level G=%d truth %.3f  CR1+t(G-1) coverage %.3f  (%.0fs)"%(label,xlevel,G,b0,cov/R,time.time()-t0))
