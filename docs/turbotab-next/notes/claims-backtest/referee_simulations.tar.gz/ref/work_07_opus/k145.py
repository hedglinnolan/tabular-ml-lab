import numpy as np, statsmodels.api as sm
from patsy import dmatrix, build_design_matrices
rng=np.random.default_rng(1)
n=20000
E=rng.normal(2000,400,n)
N=0.03*E+rng.normal(0,15,n)   # nutrient g, corr with E
print("corr(N,E)",round(np.corrcoef(N,E)[0,1],3))
y=-0.002*(N-60)**2+0.001*E+rng.normal(0,1,n)  # true curve in N at fixed E
ols=sm.OLS(N,sm.add_constant(E)).fit(); a,b=ols.params
res=N-(a+b*E)
def fit(x):
    D=dmatrix("cr(x,df=5)",{"x":x}); X=np.column_stack([np.asarray(D),E])
    return D.design_info, sm.OLS(y,X).fit()
diN,fN=fit(N); diR,fR=fit(res)
print("R2 nutrient-spline+E %.4f  residual-spline+E %.4f"%(fN.rsquared,fR.rsquared))
def pred(di,f,x,e):
    D=np.asarray(build_design_matrices([di],{"x":x})[0]); return np.column_stack([D,np.full(len(x),e)])@f.params
for e0 in [1600,2000,2400]:
    grid=np.array([45.,60,75])
    pN=pred(diN,fN,grid,e0); pR=pred(diR,fR,grid-(a+b*e0),e0)
    true=-0.002*(grid-60)**2
    print("E=%d  dy(N 45->60, 60->75): true %s | nutrient-spline %s | residual-spline %s"%(e0, np.round(np.diff(true),3), np.round(np.diff(pN),3), np.round(np.diff(pR),3)))
