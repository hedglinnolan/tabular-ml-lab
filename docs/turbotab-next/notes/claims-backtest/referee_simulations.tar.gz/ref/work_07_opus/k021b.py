import numpy as np
from scipy import stats
rng=np.random.default_rng(11)
H,nh,m=15,2,20
def sim(mu_h, psu_sd, nested):
    y=[];w=[];s=[];p=[]
    for h in range(H):
        for j in range(nh):
            u=rng.normal(0,psu_sd); y.append(mu_h[h]+u+rng.normal(0,1,m)); w.append(np.ones(m)); s.append(np.full(m,h)); p.append(np.full(m, j if nested else h*nh+j))
    return [np.concatenate(a) for a in (y,w,s,p)]
def var_lin(e,W,clus,strat):
    v=0;df=0
    for h in np.unique(strat):
        cl=np.unique(clus[strat==h]); z=np.array([e[(clus==c)&(strat==h)].sum() for c in cl]); n=len(z)
        v+=n/(n-1)*((z-z.mean())**2).sum(); df+=n-1
    return v/W**2, df
for strata_sd in [1.0,0.3,0.0]:
  mu_h=rng.normal(0,strata_sd,H); target=mu_h.mean()
  for nested in [False,True]:
    cov={'S_t':0,'U_t':0,'U_z':0}; wid={'S_t':[],'U_t':[],'U_z':[]}
    R=3000
    for r in range(R):
        y,w,s,p=sim(mu_h,0.5,nested); W=w.sum(); est=(w*y).sum()/W; e=w*(y-est)
        vS,dfS=var_lin(e,W,p,s); vU,dfU=var_lin(e,W,p,np.zeros_like(s))
        for k,(v,q) in {'S_t':(vS,stats.t.ppf(.975,dfS)),'U_t':(vU,stats.t.ppf(.975,dfU)),'U_z':(vU,1.96)}.items():
            hw=q*np.sqrt(v); cov[k]+= abs(est-target)<=hw; wid[k].append(2*hw)
    print("strata_sd %.1f nested=%s  "%(strata_sd,nested)+"  ".join("%s cov %.3f medwidth %.3f"%(k,cov[k]/R,np.median(wid[k])) for k in cov))
