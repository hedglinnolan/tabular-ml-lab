import json, sys
out = "/private/tmp/claude-501/-Users-nhedglin-tabular-ml-lab/a12607bd-3f0c-4a23-8d52-bda4a2c1292e/scratchpad/ref/out/merits_07_opus.jsonl"
obj = json.loads(sys.stdin.read())
req = ["id","truth","failing_part","narrowest_regime","reason","basis_used","citations","bite","bite_note","confidence"]
for k in req: assert k in obj, k
with open(out, "a") as f: f.write(json.dumps(obj) + "\n")
print("appended", obj["id"])
