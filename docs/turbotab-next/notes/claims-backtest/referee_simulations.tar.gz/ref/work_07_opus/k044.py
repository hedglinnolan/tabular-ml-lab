import numpy as np
from sklearn.linear_model import LogisticRegression
rng=np.random.default_rng(3)
n=400
A=rng.integers(0,2,n)
S=rng.choice(3,n,p=[0.47,0.47,0.06])   # stratum 2 small
p=np.where(S==0,0.2,np.where(S==1,0.4,0.9))*np.where(A==1,0.7,1.0)
y=rng.binomial(1,p)
y[S==2]=1   # quasi-complete separation: every participant in stratum 2 had the event
X=np.column_stack([A,S==1,S==2]).astype(float)
def stdrisk(C):
    m=LogisticRegression(C=C,max_iter=10000,tol=1e-12,solver="lbfgs").fit(X,y)
    X1=X.copy();X1[:,0]=1;X0=X.copy();X0[:,0]=0
    r1=m.predict_proba(X1)[:,1].mean(); r0=m.predict_proba(X0)[:,1].mean()
    return m.coef_[0], r1, r0
for C in [1e2,1e4,1e6,1e8]:
    b,r1,r0=stdrisk(C)
    print("C=%g coef(A,S1,S2)=%s  r1=%.5f r0=%.5f RD=%.5f RR=%.5f"%(C,np.round(b,3),r1,r0,r1-r0,r1/r0))
# Firth-free alternative: stratified (exact-ish) standardization: per-stratum arm risks weighted by stratum share
w=np.array([(S==s).mean() for s in range(3)])
r1=sum(w[s]*y[(S==s)&(A==1)].mean() for s in range(3)); r0=sum(w[s]*y[(S==s)&(A==0)].mean() for s in range(3))
print("saturated stratum standardization r1=%.5f r0=%.5f RD=%.5f"%(r1,r0,r1-r0))
