import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(4)
n=5000
N=rng.normal(300,80,n)          # nutrient kcal
O=rng.normal(1700,500,n)        # other energy, independent of N
E=N+O
print("corr(N,E) = %.3f"%np.corrcoef(N,E)[0,1])
y=0.002*N+0.004*O+rng.normal(0,1,n)   # per kcal effects
sub=sm.OLS(y,sm.add_constant(np.column_stack([N,E]))).fit().params[1]
add=sm.OLS(y,sm.add_constant(np.column_stack([N,O]))).fit().params[1]
crude=sm.OLS(y,sm.add_constant(N)).fit().params[1]
print("per 100 kcal: substitution (N|E) %.3f   addition (N|other) %.3f   crude %.3f"%(100*sub,100*add,100*crude))
