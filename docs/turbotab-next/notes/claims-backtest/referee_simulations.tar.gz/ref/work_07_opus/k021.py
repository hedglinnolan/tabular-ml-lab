import numpy as np
from scipy import stats
rng=np.random.default_rng(7)
def lin_var(yw_tot_by_psu, strata, W):
    # with-replacement linearization variance of ratio mean: z_hi = PSU totals of w*(y-ybar)
    v=0.0; df=0
    for h in np.unique(strata):
        z=yw_tot_by_psu[strata==h]; nh=len(z)
        v+= nh/(nh-1)*np.sum((z-z.mean())**2); df+=nh-1
    return v/W**2, df
def one(H=15, nh=2, m=20, strata_sd=1.0, psu_sd=0.5, nested_labels=False):
    mu_h=rng.normal(0,strata_sd,H)
    ys=[];ws=[];st=[];psu=[]
    for h in range(H):
        for j in range(nh):
            u=rng.normal(0,psu_sd)
            y=mu_h[h]+u+rng.normal(0,1,m); w=rng.uniform(0.5,1.5,m)
            ys.append(y);ws.append(w);st.append(np.full(m,h));psu.append(np.full(m, j if nested_labels else h*nh+j))
    y=np.concatenate(ys);w=np.concatenate(ws);s=np.concatenate(st);p=np.concatenate(psu)
    W=w.sum(); est=(w*y).sum()/W; e=w*(y-est)
    # stratified
    keys=np.unique(s*1000+p) if nested_labels else np.unique(p)
    if nested_labels:
        k=s*1000+p
    else:
        k=p
    ids=np.unique(k); z=np.array([e[k==i].sum() for i in ids]); zs=np.array([s[k==i][0] for i in ids])
    vS,dfS=lin_var(z,zs,W)
    # unstratified: treat the PSU column alone as clusters
    ids2=np.unique(p); z2=np.array([e[p==i].sum() for i in ids2])
    vU,dfU=lin_var(z2,np.zeros(len(ids2)),W)
    return est, vS, dfS, vU, dfU, mu_h.mean()
for strata_sd in [1.0, 0.0]:
  for nested in [False, True]:
    R=2000; out=np.array([one(strata_sd=strata_sd,nested_labels=nested) for _ in range(R)])
    est,vS,dfS,vU,dfU,true=out.T
    # coverage of design-based truth: here estimate conditional on strata means; target = mean of stratum means (equal-size strata)
    # Use conditional-on-strata repeated sampling SD: strata effects fixed within design; recompute with fixed mu_h
    print("strata_sd",strata_sd,"nested_labels",nested,"median SE strat %.4f  unstrat %.4f  ratio %.2f  df %d vs %d"%(np.median(np.sqrt(vS)),np.median(np.sqrt(vU)),np.median(np.sqrt(vU/vS)),dfS[0],dfU[0]))
