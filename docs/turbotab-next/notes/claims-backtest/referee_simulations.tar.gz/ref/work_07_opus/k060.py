import numpy as np
rng=np.random.default_rng(2)
def bkw(X,names):
    Xs=X/np.linalg.norm(X,axis=0)
    U,s,Vt=np.linalg.svd(Xs,full_matrices=False); V=Vt.T
    ci=s.max()/s
    phi=(V**2)/(s**2); pi=(phi/phi.sum(1,keepdims=True)).T  # rows: singular values, cols: variables
    order=np.argsort(ci)
    for k in order[::-1][:2]:
        print("  CI %.1f  VDP %s"%(ci[k], dict(zip(names,np.round(pi[k],2)))))
n=2000
# exposure height in cm, adjustment: sex (0/1), age (years, 40-70), smoking 0/1 independent
h=rng.normal(170,10,n); sex=rng.integers(0,2,n); smk=rng.integers(0,2,n)
print("height cm + sex + smoking (independent covariates):")
bkw(np.column_stack([np.ones(n),h,sex,smk]),["const","height","sex","smk"])
age=rng.uniform(55,65,n)
print("age 55-65 years + sex:")
bkw(np.column_stack([np.ones(n),age,sex]),["const","age","sex"])
print("corr(height, sex) =",np.corrcoef(h,sex)[0,1].round(3))
