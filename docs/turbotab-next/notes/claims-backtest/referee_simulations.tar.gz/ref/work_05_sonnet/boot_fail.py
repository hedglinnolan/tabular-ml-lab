import numpy as np, warnings
from sklearn.linear_model import LogisticRegression
warnings.filterwarnings("ignore")
rng=np.random.default_rng(3)
n=60; prev=0.10
x=rng.normal(size=n)
y=(rng.random(n)< 1/(1+np.exp(-(np.log(prev/(1-prev))+0.8*x)))).astype(int)
print("positives in sample", y.sum())
B=3000
pred=np.empty(B); npos=np.empty(B,int)
for b in range(B):
    idx=rng.integers(0,n,n)
    yb=y[idx]; npos[b]=yb.sum()
    if yb.sum()==0 or yb.sum()==n:
        pred[b]=np.nan; continue
    m=LogisticRegression(C=1.0,max_iter=200).fit(x[idx,None],yb)
    pred[b]=m.predict_proba([[0.0]])[0,1]
ok=~np.isnan(pred)
full=pred[ok]
print("lower/upper 95% pct band, all fittable resamples:", np.percentile(full,[2.5,97.5]).round(4), "mean", full.mean().round(4))
for k in (2,3,4,5,6):
    keep=ok&(npos>=k)
    fail=1-keep.mean()
    print(f"fail if npos<{k}: failure rate {fail:.3f}; band {np.percentile(pred[keep],[2.5,97.5]).round(4)}; width ratio {np.subtract(*np.percentile(pred[keep],[97.5,2.5][::-1]))/np.subtract(*np.percentile(full,[97.5,2.5][::-1])):.2f}")
# random (non-informative) failures
for f in (0.1,0.3):
    keep=ok&(rng.random(B)>f)
    print(f"random failures {f}: band {np.percentile(pred[keep],[2.5,97.5]).round(4)}")
