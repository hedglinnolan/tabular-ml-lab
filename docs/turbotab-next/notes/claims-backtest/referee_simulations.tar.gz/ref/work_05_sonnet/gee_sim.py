import numpy as np, time, warnings
import statsmodels.api as sm
warnings.filterwarnings("ignore")
rng = np.random.default_rng(1)
def one(G, binary, clusterlevel, unbal):
    sizes = rng.integers(2, 25, G) if unbal else np.full(G, 8)
    g = np.repeat(np.arange(G), sizes)
    n = len(g)
    if clusterlevel:
        xc = rng.binomial(1, 0.5, G) if not binary else rng.normal(size=G)
        x = xc[g]
        if unbal: pass
    else:
        x = rng.normal(size=n)
    u = rng.normal(size=G)[g]
    if binary:
        eta = -0.5 + 1.0*u
        y = rng.binomial(1, 1/(1+np.exp(-eta)))
        fam = sm.families.Binomial()
    else:
        y = u + rng.normal(size=n)
        fam = sm.families.Gaussian()
    X = sm.add_constant(x)
    m = sm.GEE(y, X, groups=g, family=fam, cov_struct=sm.cov_struct.Exchangeable())
    r = m.fit(cov_type="robust")  # CR0 sandwich
    z = r.params[1]/r.bse[1]
    from scipy import stats
    p_norm = 2*stats.norm.sf(abs(z))
    p_t = 2*stats.t.sf(abs(z), G-1)
    return p_norm<0.05, p_t<0.05
t0=time.time()
for binary in (False, True):
  for clusterlevel in (True, False):
    for unbal in (False, True):
        R=600
        res=[one(12,binary,clusterlevel,unbal) for _ in range(R)]
        res=np.array(res).mean(0)
        print(f"binary={binary} clusterlevel={clusterlevel} unbal={unbal}: type I normal-CR0={res[0]:.3f}  t(G-1)-CR0={res[1]:.3f}  (se~{np.sqrt(.05*.95/R):.3f})  elapsed={time.time()-t0:.1f}s", flush=True)
