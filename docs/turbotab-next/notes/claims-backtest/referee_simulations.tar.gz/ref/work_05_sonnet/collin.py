import numpy as np, warnings
from sklearn.linear_model import LinearRegression, RidgeCV
from sklearn.ensemble import RandomForestRegressor
warnings.filterwarnings("ignore")
rng=np.random.default_rng(5)
def gen(n, r, p_extra=0, shift=False):
    cov=np.array([[1,r],[r,1]])
    X=rng.multivariate_normal([0,0],cov,size=n)
    if shift: pass
    E=rng.normal(size=(n,p_extra))
    Xf=np.hstack([X,E])
    beta=np.r_[0.7,0.7,np.zeros(p_extra)]
    y=Xf@beta+rng.normal(size=n)
    return Xf,y
def trial(n,r,p_extra,reps=200):
    out={"ols":[], "ridge":[], "drop":[], "rf":[]}
    for _ in range(reps):
        X,y=gen(n,r,p_extra); Xt,yt=gen(5000,r,p_extra)
        out["ols"].append(np.mean((LinearRegression().fit(X,y).predict(Xt)-yt)**2))
        out["ridge"].append(np.mean((RidgeCV(alphas=np.logspace(-2,3,20)).fit(X,y).predict(Xt)-yt)**2))
        keep=[i for i in range(X.shape[1]) if i!=1]
        out["drop"].append(np.mean((LinearRegression().fit(X[:,keep],y).predict(Xt[:,keep])-yt)**2))
    return {k:round(float(np.mean(v)),3) for k,v in out.items() if v}
for n,r,pe in [(500,0.95,0),(200,0.95,0),(60,0.95,0),(30,0.95,0),(500,0.99,0)]:
    print(n,r,pe,trial(n,r,pe))
# distribution shift: collinearity broken in deployment
X,y=gen(200,0.95,0)
Xt=np.random.default_rng(9).normal(size=(5000,2)); yt=Xt@np.array([0.7,0.7])+np.random.default_rng(10).normal(size=5000)
print("shift: ols", np.mean((LinearRegression().fit(X,y).predict(Xt)-yt)**2).round(3),
      "ridge", np.mean((RidgeCV(alphas=np.logspace(-2,3,20)).fit(X,y).predict(Xt)-yt)**2).round(3),
      "drop", np.mean((LinearRegression().fit(X[:,[0]],y).predict(Xt[:,[0]])-yt)**2).round(3))
