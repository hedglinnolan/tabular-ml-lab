import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(5)
n=200000
x=rng.normal(size=n); y=1.0*x+rng.normal(size=n)
def slope(x,y): return sm.OLS(y,sm.add_constant(x)).fit().params[1]
print("full slope",slope(x,y))
keep=np.abs(y)<2.0     # outcome-range exclusion
print("exclude |y|>=2 slope",slope(x[keep],y[keep]))
print("exclude |y| outlier at 3SD of y",slope(x[np.abs(y-y.mean())<3*y.std()],y[np.abs(y-y.mean())<3*y.std()]))
# logistic: exclude 80% of y=0 rows (outcome-dependent), OR unbiased
p=1/(1+np.exp(-(-1+0.7*x))); yb=(rng.uniform(size=n)<p).astype(int)
def lslope(x,y): return sm.Logit(y,sm.add_constant(x)).fit(disp=0).params
print("logit full",lslope(x,yb))
k=(yb==1)|(rng.uniform(size=n)<0.2)
print("logit drop 80% of controls",lslope(x[k],yb[k]))
