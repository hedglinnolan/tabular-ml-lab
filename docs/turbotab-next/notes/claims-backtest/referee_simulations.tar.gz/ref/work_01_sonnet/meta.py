import numpy as np
from scipy import stats
rng=np.random.default_rng(2)
def sim(k,tau,reps=20000):
    cov_fe=0;cov_pi=0;cov_ci_fe_for_mu=0
    for _ in range(reps):
        mu=1.0
        v=rng.uniform(0.01,0.05,size=k)   # within-cycle variance of MSE
        theta=rng.normal(mu,tau,size=k)
        y=rng.normal(theta,np.sqrt(v))
        w=1/v; fe=np.sum(w*y)/w.sum(); se=1/np.sqrt(w.sum())
        new=rng.normal(mu,tau)   # true MSE of a new cycle
        lo,hi=fe-1.96*se,fe+1.96*se
        cov_fe+= lo<=new<=hi
        cov_ci_fe_for_mu+= lo<=mu<=hi
        # DL random effects PI
        Q=np.sum(w*(y-fe)**2); C=w.sum()-np.sum(w**2)/w.sum()
        t2=max((Q-(k-1))/C,0); ws=1/(v+t2); re=np.sum(ws*y)/ws.sum(); sere=1/np.sqrt(ws.sum())
        h=stats.t.ppf(0.975,k-2)*np.sqrt(t2+sere**2)
        cov_pi+= re-h<=new<=re+h
    return cov_fe/reps,cov_ci_fe_for_mu/reps,cov_pi/reps
for k,tau in [(6,0.0),(6,0.1),(6,0.2),(10,0.2),(10,0.4)]:
    print(k,tau,sim(k,tau))
