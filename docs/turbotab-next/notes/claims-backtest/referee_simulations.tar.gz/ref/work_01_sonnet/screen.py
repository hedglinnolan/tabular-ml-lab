import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
rng=np.random.default_rng(3)
n,p,keep=50,5000,50
errs_wrong=[];errs_right=[]
def screen(X,y,keep):
    c=np.abs((X-X.mean(0)).T@(y-y.mean()))/ (X.std(0)*len(y)+1e-12)
    return np.argsort(-c)[:keep]
for rep in range(10):
    X=rng.normal(size=(n,p)); y=np.repeat([0,1],n//2)
    sel=screen(X,y,keep)
    skf=StratifiedKFold(5,shuffle=True,random_state=rep)
    e1=e2=0
    for tr,te in skf.split(X,y):
        clf=LogisticRegression(C=1.0,max_iter=200).fit(X[tr][:,sel],y[tr])
        e1+=(clf.predict(X[te][:,sel])!=y[te]).sum()
        s2=screen(X[tr],y[tr],keep)
        clf=LogisticRegression(C=1.0,max_iter=200).fit(X[tr][:,s2],y[tr])
        e2+=(clf.predict(X[te][:,s2])!=y[te]).sum()
    errs_wrong.append(e1/n);errs_right.append(e2/n)
print("screen-before-CV error (true=0.5):",np.mean(errs_wrong),"screen-inside-CV:",np.mean(errs_right))
