import numpy as np, warnings
from statsmodels.duration.hazard_regression import PHReg
warnings.filterwarnings("ignore")
rng=np.random.default_rng(4)
def fitcox(t,e,x):
    m=PHReg(t,x.reshape(-1,1),status=e,ties="breslow")
    r=m.fit(disp=False)
    return r.params[0], r.bse[0]
# Case A: group x=1 has EVERY row an event (no censoring); group x=0 has 50% censoring. Interleaved times.
n=200
x=np.r_[np.ones(100),np.zeros(100)]
t1=rng.exponential(1.0,100); e1=np.ones(100)
t0=rng.exponential(1.0,100); e0=(rng.uniform(size=100)<0.5).astype(float)
t=np.r_[t1,t0]; e=np.r_[e1,e0]
b,se=fitcox(t,e,x); print("A: group1 all events, group0 half censored:  beta=%.3f se=%.3f (SD of x=%.2f -> beta per SD=%.2f)"%(b,se,x.std(),b*x.std()))
# Case B: group x=1 has NO events (all censored)
t1=rng.exponential(1.0,100); e1=np.zeros(100)
t0=rng.exponential(1.0,100); e0=np.ones(100)
t=np.r_[t1,t0]; e=np.r_[e1,e0]
b,se=fitcox(t,e,x); print("B: group1 no events:  beta=%.3f se=%.3f per SD=%.2f"%(b,se,b*x.std()))
# Case C: both groups all events
t=np.r_[rng.exponential(1.0,100),rng.exponential(1.0,100)]; e=np.ones(200)
b,se=fitcox(t,e,x); print("C: both all events: beta=%.3f se=%.3f"%(b,se))
# Case D: group x=1 all events AND all of its events occur before any x=0 event -> monotone? (beta -> +inf)
t1=rng.uniform(0,1,100); t0=rng.uniform(1.5,3,100)
t=np.r_[t1,t0]; e=np.r_[np.ones(100),(rng.uniform(size=100)<0.5).astype(float)]
b,se=fitcox(t,e,x); print("D: group1 all events and all earlier than group0: beta=%.3f se=%.3f per SD=%.2f"%(b,se,b*x.std()))
# Case E: collinear / no divergence but plain nonconvergence? skip
