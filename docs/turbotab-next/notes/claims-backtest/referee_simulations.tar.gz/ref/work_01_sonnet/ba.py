import numpy as np
from scipy import stats
rng=np.random.default_rng(1)
def fit(d_list):
    k=len(d_list); m=np.array([len(x) for x in d_list]); n=m.sum()
    means=np.array([x.mean() for x in d_list])
    dbar=np.sum(m*means)/n
    SSb=np.sum(m*(means-dbar)**2); SSw=sum(((x-x.mean())**2).sum() for x in d_list)
    MSb=SSb/(k-1); MSw=SSw/(n-k)
    lam=(n**2-np.sum(m**2))/((k-1)*n)
    sb=max((MSb-MSw)/lam,0.0)
    var_bias=(sb*np.sum(m**2)+MSw*n)/n**2
    return dbar,sb,MSw,var_bias,k,means
def run(sb_true,sw_true,k,reps=4000,mu=0.5):
    cov=0;cov2=0;cnt_trunc=0
    for _ in range(reps):
        m=rng.integers(1,8,size=k)
        d_list=[]
        for mi in m:
            b=rng.normal(0,np.sqrt(sb_true))
            d_list.append(mu+b+rng.normal(0,np.sqrt(sw_true),size=mi))
        dbar,sb,sw,vb,kk,means=fit(d_list)
        if sb==0.0:
            cnt_trunc+=1
            vb2=np.var(means,ddof=1)/kk
        else: vb2=vb
        t=stats.t.ppf(0.975,kk-1)
        cov+= abs(dbar-mu)<=t*np.sqrt(vb)
        cov2+= abs(dbar-mu)<=t*np.sqrt(vb2)
    return cov/reps,cov2/reps,cnt_trunc/reps
for sb,sw,k in [(1,1,20),(0.1,1,20),(0.0,1,20),(0.1,1,10),(0.3,1,15),(1,1,50)]:
    print(sb,sw,k,run(sb,sw,k))
