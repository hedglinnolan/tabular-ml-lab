import numpy as np, time, warnings
warnings.filterwarnings("ignore")
from sklearn.ensemble import RandomForestClassifier as RF, GradientBoostingClassifier as GB
from sklearn.linear_model import LogisticRegression as LR
from sklearn.metrics import roc_auc_score
rng=np.random.default_rng(7); t0=time.process_time()
def dgp(n,r,b0=-4.0):
    X=r.normal(size=(n,10)); lp=b0+0.9*X[:,0]+0.6*np.abs(X[:,1])+0.5*X[:,2]*X[:,3]+0.4*X[:,4]
    return X,(r.random(n)<1/(1+np.exp(-lp))).astype(int)
Xt,yt=dgp(30000,np.random.default_rng(99))
print("test prevalence",yt.mean())
models={"LR":lambda w:LR(C=1e6,max_iter=500,class_weight=w),
        "RF":lambda w:RF(n_estimators=100,min_samples_leaf=3,class_weight=w,random_state=0),
        "GB":lambda w:GB(n_estimators=100,max_depth=3,random_state=0)}
res={k:[] for k in models}
nrep=0
while time.process_time()-t0<45:
    X,y=dgp(2500,rng); nrep+=1
    for k,f in models.items():
        row=[]
        for w in (None,"balanced"):
            if k=="GB":
                sw=None if w is None else np.where(y==1,(y==0).sum()/(y==1).sum(),1.0)
                m=f(None).fit(X,y,sample_weight=sw)
            else: m=f(w).fit(X,y)
            p=m.predict_proba(Xt)[:,1]; row+= [roc_auc_score(yt,p),p.mean()]
        res[k].append(row)
print("reps",nrep)
for k,v in res.items():
    v=np.array(v).mean(0)
    print(f"{k}: AUC plain {v[0]:.4f} weighted {v[2]:.4f} | mean predicted risk plain {v[1]:.4f} weighted {v[3]:.4f} (true {yt.mean():.4f})")
