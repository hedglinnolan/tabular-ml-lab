import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(1)
# K-050: squared Pearson vs 1-SSE/SST for out-of-fold predictions that are biased/miscalibrated
n=2000
x=rng.normal(size=n); y=x+rng.normal(size=n)
for name,p in [("good",x),("shifted +2",x+2),("scaled x3",3*x),("inverted-scale 0.2x",0.2*x),("noise-only mix",x+3*rng.normal(size=n))]:
    r2p=np.corrcoef(p,y)[0,1]**2
    r2s=1-np.sum((y-p)**2)/np.sum((y-y.mean())**2)
    print(f"{name:22s} r^2={r2p:.3f}  1-SSE/SST={r2s:.3f}")
# K-019: within-strata residual
n=4000
s=rng.integers(0,2,n)
E=rng.normal(2000+500*s,300,n)
N=np.where(s==0, 10+0.02*E, 30+0.005*E)+rng.normal(0,3,n)
Y=0.1*N+0.001*E+0.5*s+rng.normal(0,1,n)
r=np.empty(n)
for k in (0,1):
    m=s==k; X=sm.add_constant(E[m]); r[m]=sm.OLS(N[m],X).fit().resid
def coef(cols,names):
    X=sm.add_constant(np.column_stack(cols)); f=sm.OLS(Y,X).fit(); return f.params[1]
print("std Y~N+E:",coef([N,E],0))
print("resid Y~r+E:",coef([r,E],0))
print("std Y~N+E+s:",coef([N,E,s],0))
print("resid Y~r+E+s:",coef([r,E,s],0))
print("std Y~N+E+s+sE:",coef([N,E,s,s*E],0))
print("resid Y~r+E+s+sE:",coef([r,E,s,s*E],0))
# equal slopes
N2=10+0.02*E+3*s+rng.normal(0,3,n)
Y2=0.1*N2+0.001*E+0.5*s+rng.normal(0,1,n)
r2=np.empty(n)
for k in (0,1):
    m=s==k; X=sm.add_constant(E[m]); r2[m]=sm.OLS(N2[m],X).fit().resid
Y=Y2
print("equal slopes: std Y~N+E+s:",coef([N2,E,s],0)," resid Y~r+E+s:",coef([r2,E,s],0))
