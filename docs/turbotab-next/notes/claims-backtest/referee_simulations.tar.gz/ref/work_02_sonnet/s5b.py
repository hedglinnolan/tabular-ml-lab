import numpy as np, time, sys, warnings
warnings.filterwarnings("ignore")
from scipy.stats import qmc
from sklearn.ensemble import GradientBoostingClassifier as GB
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, log_loss
seed=int(sys.argv[1]); n=int(sys.argv[2]); S=int(sys.argv[3]); budget=float(sys.argv[4])
rng=np.random.default_rng(seed); t0=time.process_time()
def dgp(n,r):
    X=r.normal(size=(n,10)); lp=-0.3+0.8*X[:,0]+0.5*np.abs(X[:,1])-0.4+0.4*X[:,2]*X[:,3]+0.3*X[:,4]
    return X,(r.random(n)<1/(1+np.exp(-lp))).astype(int)
Xt,yt=dgp(6000,np.random.default_rng(12345))
default=dict(n_estimators=120,learning_rate=0.05,max_depth=2,subsample=0.7,min_samples_leaf=8,max_features=0.5)
def cand(u):
    return dict(n_estimators=int(40+u[0]*160),learning_rate=float(10**(-2+1.2*u[1])),max_depth=int(1+np.floor(u[2]*5)),
                subsample=float(0.5+0.5*u[3]),min_samples_leaf=int(1+np.floor(u[4]*20)),max_features=float(0.3+0.7*u[5]))
out=[]
while time.process_time()-t0<budget:
    X,y=dgp(n,rng)
    sob=qmc.Sobol(6,scramble=True,seed=int(rng.integers(1e9))).random(S)
    cfgs=[default]+[cand(u) for u in sob]
    skf=StratifiedKFold(5,shuffle=True,random_state=int(rng.integers(1e9)))
    sc=[]
    for c in cfgs:
        a=[]
        for tr,te in skf.split(X,y):
            m=GB(random_state=0,**c).fit(X[tr],y[tr]); a.append(roc_auc_score(y[te],m.predict_proba(X[te])[:,1]))
        sc.append(np.mean(a))
    best=int(np.argmax(sc))
    md=GB(random_state=0,**default).fit(X,y); mb=GB(random_state=0,**cfgs[best]).fit(X,y)
    pd_=md.predict_proba(Xt)[:,1]; pb=mb.predict_proba(Xt)[:,1]
    out.append((roc_auc_score(yt,pb)-roc_auc_score(yt,pd_), log_loss(yt,pd_)-log_loss(yt,pb), best==0))
o=np.array(out,float)
print(f"n={n} S={S} reps={len(o)} mean dAUC(tuned-default)={o[:,0].mean():+.4f} se={o[:,0].std()/np.sqrt(len(o)):.4f}  frac worse={np.mean(o[:,0]<0):.2f}  mean dlogloss gain={o[:,1].mean():+.4f} frac default kept={o[:,2].mean():.2f}")
np.save(f"s5b_{seed}_{n}_{S}.npy",o)
