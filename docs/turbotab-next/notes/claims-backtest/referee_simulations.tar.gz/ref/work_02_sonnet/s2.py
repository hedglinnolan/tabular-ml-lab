import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(2)
# K-079: pure location shift of outcome by exposure; cut at various quantiles
n=3000
x=rng.normal(size=n)
y=50+10*rng.normal(size=n)+2*x   # pure shift: effect same everywhere
X=sm.add_constant(x)
tot=sm.OLS(y,X).fit()
for q in (0.2,0.5,0.8):
    c=np.quantile(y,q)
    lo=np.minimum(y,c); hi=np.maximum(y-c,0)
    fl=sm.OLS(lo,X).fit(); fh=sm.OLS(hi,X).fit()
    print(f"cut at q{q}: total={tot.params[1]:.3f} below={fl.params[1]:.3f} above={fh.params[1]:.3f} share_above={fh.params[1]/tot.params[1]:.2f} P(y>c)={np.mean(y>c):.2f}  above 95%CI=({fh.conf_int()[1][0]:.3f},{fh.conf_int()[1][1]:.3f}) sum_check={fl.params[1]+fh.params[1]-tot.params[1]:.1e}")
# K-041: precision at 10 events
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression
aucs=[];slopes=[]
b=1.2
for rep in range(2000):
    # validation set with 10 events; prevalence 10% -> n=100 ; true model lp ~ N, calibrated
    n=100
    lp=rng.normal(-2.4,1.2,n)
    p=1/(1+np.exp(-lp)); yv=(rng.random(n)<p).astype(int)
    if yv.sum()<3 or yv.sum()==n: continue
    aucs.append(roc_auc_score(yv,lp))
    try:
        m=LogisticRegression(C=1e6,max_iter=500).fit(lp.reshape(-1,1),yv); slopes.append(m.coef_[0,0])
    except Exception: pass
aucs=np.array(aucs); slopes=np.array(slopes)
print("events~10 (n=100): AUC mean {:.3f} SD {:.3f} ; slope mean {:.2f} SD {:.2f} 5-95 range {}".format(aucs.mean(),aucs.std(),slopes.mean(),slopes.std(),np.quantile(slopes,[.05,.95]).round(2)))
aucs=[];slopes=[]
for rep in range(1000):
    n=1000
    lp=rng.normal(-2.4,1.2,n); p=1/(1+np.exp(-lp)); yv=(rng.random(n)<p).astype(int)
    aucs.append(roc_auc_score(yv,lp))
    m=LogisticRegression(C=1e6,max_iter=500).fit(lp.reshape(-1,1),yv); slopes.append(m.coef_[0,0])
aucs=np.array(aucs); slopes=np.array(slopes)
print("events~100 (n=1000): AUC SD {:.3f} ; slope SD {:.2f} 5-95 range {}".format(aucs.std(),slopes.std(),np.quantile(slopes,[.05,.95]).round(2)))
