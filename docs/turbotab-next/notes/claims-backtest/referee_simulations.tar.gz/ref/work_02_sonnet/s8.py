import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(4)
n=200000
z=rng.normal(size=n); t=rng.integers(0,2,n)   # randomized
lp=-1+1.0*t+2.0*z                               # conditional log-OR = 1.0
y=(rng.random(n)<1/(1+np.exp(-lp))).astype(int)
un=sm.Logit(y,sm.add_constant(t)).fit(disp=0); ad=sm.Logit(y,sm.add_constant(np.column_stack([t,z]))).fit(disp=0)
print("randomized, prognostic covariate: unadjusted logOR %.3f (OR %.2f)  adjusted logOR %.3f (OR %.2f)  [conditional truth 1.0]"%(un.params[1],np.exp(un.params[1]),ad.params[1],np.exp(ad.params[1])))
print("SEs: unadj %.4f adj %.4f"%(un.bse[1],ad.bse[1]))
# CC with outcome-dependent missingness in logistic regression: slopes unbiased
n=200000
x=rng.normal(size=n); y=(rng.random(n)<1/(1+np.exp(-(-1+0.7*x)))).astype(int)
keep=rng.random(n)<np.where(y==1,0.9,0.3)   # missingness depends on outcome only
f=sm.Logit(y[keep],sm.add_constant(x[keep])).fit(disp=0)
print("logistic, missingness depends on Y (not X): CC slope %.3f (true 0.7), intercept %.3f (true -1)"%(f.params[1],f.params[0]))
# linear: same mechanism biased
yl=0.7*x+rng.normal(size=n)
keep=rng.random(n)<1/(1+np.exp(-(1.5*yl-1)))
f=sm.OLS(yl[keep],sm.add_constant(x[keep])).fit()
print("linear, missingness depends on Y: CC slope %.3f (true 0.7)"%f.params[1])
