import numpy as np, statsmodels.api as sm, time
rng=np.random.default_rng(5)
t0=time.process_time()
def smd(a,b):
    return abs(a.mean()-b.mean())/np.sqrt((a.var(ddof=1)+b.var(ddof=1))/2)
def scenario(n, mis_frac, bmi_link, diff_err, sd_err_keep=0.3, beta=0.05, low_cut=0.5):
    bmi=rng.normal(0,1,n); age=rng.normal(0,1,n)
    mis=(rng.random(n)<1/(1+np.exp(-(np.log(mis_frac/(1-mis_frac))+bmi_link*bmi))))
    Etrue=2200+300*rng.normal(size=n)+50*bmi
    factor=np.where(mis,rng.uniform(0.4,0.7,n),rng.normal(1,0.1,n))
    E=Etrue*factor
    dens=rng.normal(1,0.2,n)
    Xtrue=dens*Etrue/100
    err=np.where(mis,diff_err,sd_err_keep)*rng.normal(size=n)*Xtrue.std()
    X=Xtrue*factor+err
    Y=beta*Xtrue+0.3*bmi+0.2*age+rng.normal(0,1,n)
    keep=E>np.quantile(E,0.0)+low_cut*0  # placeholder
    # energy screen: remove implausible = E < 1200 or E>4500 (range rule)
    rem=(E<1200)|(E>4500)
    # also report Goldberg-like: ratio E/BMR low
    if rem.sum()<5 or (~rem).sum()<50: return None
    Z=np.column_stack([E,bmi,age])
    ex=sm.OLS(Y,sm.add_constant(np.column_stack([X,Z]))).fit()
    kp=~rem
    ek=sm.OLS(Y[kp],sm.add_constant(np.column_stack([X[kp],Z[kp]]))).fit()
    shift=abs(ex.params[1]-ek.params[1])/(1.96*ek.bse[1])
    share=rem.mean()
    smds_all=[smd(Z[rem,j],Z[kp,j]) for j in range(3)]
    smds_noE=[smds_all[1],smds_all[2]]
    return share, max(smds_all), max(smds_noE), shift
rows=[]
while time.process_time()-t0<40:
    n=int(rng.choice([500,2000,8000]))
    r=scenario(n,rng.choice([0.05,0.15,0.3]),rng.choice([0,0.5,1.0]),rng.choice([0.3,0.8,1.5]))
    if r: rows.append((n,)+r)
R=np.array(rows)
from scipy.stats import spearmanr
prod=R[:,1]*R[:,2]; prod2=R[:,1]*R[:,3]
print("scenarios",len(R))
print("spearman(share*maxSMD incl energy, shift in HW)",spearmanr(prod,R[:,4])[0])
print("spearman(share*maxSMD excl energy, shift in HW)",spearmanr(prod2,R[:,4])[0])
# show examples where product similar but shift differs
for lo,hi in [(0.02,0.06),(0.06,0.15),(0.15,0.4)]:
    m=(prod>=lo)&(prod<hi)
    if m.sum()>3: print(f"product in [{lo},{hi}): n={m.sum()}, shift quantiles (HW units) 10/50/90:",np.quantile(R[m,4],[.1,.5,.9]).round(2))
for nn in (500,2000,8000):
    m=(R[:,0]==nn)
    print("n",nn,"median product",np.median(prod[m]).round(3),"median shift",np.median(R[m,4]).round(2))
