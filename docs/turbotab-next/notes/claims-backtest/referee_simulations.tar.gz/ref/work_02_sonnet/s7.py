import numpy as np, statsmodels.api as sm, time, warnings
warnings.filterwarnings("ignore")
from scipy import stats
rng=np.random.default_rng(3); t0=time.process_time()
for G in (2,3,5,11,30):
    cover_z=cover_t=0; N=0
    while N<1500:
        m=20
        g=np.repeat(np.arange(G),m)
        x=rng.normal(size=G*m)+rng.normal(size=G)[g]*0.8   # cluster-level x variation
        u=rng.normal(size=G)[g]*0.7
        y=0.0*x+u+rng.normal(size=G*m)
        f=sm.OLS(y,sm.add_constant(x)).fit(cov_type="cluster",cov_kwds={"groups":g})
        b,se=f.params[1],f.bse[1]
        if not np.isfinite(se): continue
        N+=1
        cover_z+= abs(b)<1.96*se
        cover_t+= abs(b)<stats.t.ppf(0.975,max(G-1,1))*se
    print(f"G={G}: coverage normal {cover_z/N:.3f}, t(G-1) {cover_t/N:.3f}  (nominal 0.95)")
print("cpu",time.process_time()-t0)
