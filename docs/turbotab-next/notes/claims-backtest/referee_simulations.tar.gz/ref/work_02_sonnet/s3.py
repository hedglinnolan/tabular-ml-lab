import numpy as np, time, sys
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import RepeatedStratifiedKFold
from sklearn.metrics import roc_auc_score
seed=int(sys.argv[1]); learner=sys.argv[2]; nrep=int(sys.argv[3])
rng=np.random.default_rng(seed); t0=time.process_time()
def dgp(n,r):
    X=r.normal(size=(n,8)); lp=-0.8+0.7*X[:,0]+0.5*X[:,1]+0.4*X[:,2]*X[:,3]
    y=(r.random(n)<1/(1+np.exp(-lp))).astype(int); return X,y
def mk():
    if learner=="rf": return RandomForestClassifier(n_estimators=60,min_samples_leaf=1,n_jobs=1,random_state=0)
    return LogisticRegression(C=1e6,max_iter=300)
def auc(m,X,y): return roc_auc_score(y,m.predict_proba(X)[:,1])
Xt,yt=dgp(8000,np.random.default_rng(999))
res=[]
for rep in range(nrep):
    if time.process_time()-t0>50: break
    X,y=dgp(150,rng)
    m=mk().fit(X,y); app=auc(m,X,y); truth=auc(m,Xt,yt)
    opt=[]
    for b in range(20):
        idx=rng.integers(0,len(y),len(y))
        if len(np.unique(y[idx]))<2: continue
        mb=mk().fit(X[idx],y[idx]); opt.append(auc(mb,X[idx],y[idx])-auc(mb,X,y))
    boot=app-np.mean(opt)
    cv=[]
    for tr,te in RepeatedStratifiedKFold(n_splits=5,n_repeats=2,random_state=rep).split(X,y):
        cv.append(auc(mk().fit(X[tr],y[tr]),X[te],y[te]))
    res.append((app,boot,np.mean(cv),truth))
r=np.array(res)
print(learner,"reps",len(r),"mean apparent %.3f | harrell-boot %.3f | repeated-CV %.3f | truth(of this fitted model) %.3f"%tuple(r.mean(0)))
print("  mean error vs truth: boot %.3f  repCV %.3f ; RMSE boot %.3f repCV %.3f"%((r[:,1]-r[:,3]).mean(),(r[:,2]-r[:,3]).mean(),np.sqrt(((r[:,1]-r[:,3])**2).mean()),np.sqrt(((r[:,2]-r[:,3])**2).mean())))
print("  cpu",time.process_time()-t0)
