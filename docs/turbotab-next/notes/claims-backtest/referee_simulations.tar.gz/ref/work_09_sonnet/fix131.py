import json
from emit import OUT, emit
rows=[json.loads(l) for l in open(OUT)]
for r in rows:
    if r["id"]=="K-131":
        r["reason"]=("The tests detect integer raw counts or an unlogged raw scale, not normalization status, so 'failing = already normalized or log-scale' does not follow. Under the genomics lens any non-integer matrix (unlogged TPM/FPKM, RSEM/tximport expected counts, raw microarray intensities, all heavy right-skewed) fails the whole-number test and is read as already normalized, so the refusal of linear families is never armed; conversely, data already scaled to [0,1] (min-max or sum-to-one) is flagged as unnormalized in the metabolomics lens (simulated: 100-fold span and median skew 1.24, flagged True), while plain log2 intensities are correctly not flagged (span 2.3, skew 0.02). The author's lognormal reasoning is right (a feature with 30% CV has skewness (e^{s2}+2)sqrt(e^{s2}-1) = 0.93), but nothing supports the 100, 1,000, 0.5 and 20-column cutoffs as the boundary of 'needs normalization'.")
open(OUT,"w").write("".join(json.dumps(r,ensure_ascii=False)+"\n" for r in rows))
