import numpy as np, time, sys
from scipy import stats
rng=np.random.default_rng(int(sys.argv[2]) if len(sys.argv)>2 else 0)
n=int(sys.argv[1]); K=10; R=10; nd=int(sys.argv[3]) if len(sys.argv)>3 else 600
def ols_pred(xtr,ytr,xte):
    A=np.column_stack([np.ones(len(xtr)),xtr]); b=np.linalg.lstsq(A,ytr,rcond=None)[0]
    return np.column_stack([np.ones(len(xte)),xte])@b
rej=0; ratios=[]; naive_se=[]; cvmeans=[]; t0=time.time()
for d in range(nd):
    x=rng.normal(size=(n,2)); y=x[:,0]+x[:,1]+2*rng.normal(size=n)
    diffs=[]; fold_scoreA=[]
    for r in range(R):
        perm=rng.permutation(n); folds=np.array_split(perm,K)
        for k in range(K):
            te=folds[k]; tr=np.concatenate([folds[j] for j in range(K) if j!=k])
            eA=np.mean((y[te]-ols_pred(x[tr][:,[0]],y[tr],x[te][:,[0]]))**2)
            eB=np.mean((y[te]-ols_pred(x[tr][:,[1]],y[tr],x[te][:,[1]]))**2)
            diffs.append(eA-eB); 
            if r==0: fold_scoreA.append(eA)
    diffs=np.array(diffs); J=len(diffs); s2=diffs.var(ddof=1)
    corr=(1/J+(1/(K-1)))*s2
    t=diffs.mean()/np.sqrt(corr); p=2*stats.t.sf(abs(t),J-1)
    rej+= p<0.05
    naive=(1/J)*s2; tn=diffs.mean()/np.sqrt(naive); rn=2*stats.t.sf(abs(tn),J-1)<0.05
    ratios.append(rn)
    fs=np.array(fold_scoreA); naive_se.append(fs.std(ddof=1)/np.sqrt(K)); cvmeans.append(fs.mean())
print(f"n={n} datasets={nd} corrected-t rejection={rej/nd:.3f} naive-t rejection={np.mean(ratios):.3f}")
print(f"mean naive SE of CV score={np.mean(naive_se):.4f}  true SD of CV mean across datasets={np.std(cvmeans,ddof=1):.4f}  ratio={np.mean(naive_se)/np.std(cvmeans,ddof=1):.2f}  time={time.time()-t0:.1f}s")
