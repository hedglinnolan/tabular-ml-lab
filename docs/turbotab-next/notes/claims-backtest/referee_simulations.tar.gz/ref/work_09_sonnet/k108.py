import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(1)
n=500
X=rng.normal(size=n); M=rng.integers(0,2,n)
y=1+0.5*X+0.8*M+0.7*X*M+rng.normal(size=n)
def fit(M):
    D=np.column_stack([np.ones(n),X,M,X*M]); r=sm.OLS(y,D).fit()
    return r.params.round(4), r.conf_int()[1].round(4)
print("orig  ",fit(M))
print("recode",fit(1-M))
# no interaction
def fit0(M):
    D=np.column_stack([np.ones(n),X,M]); r=sm.OLS(y,D).fit()
    return r.params.round(4), r.conf_int()[1].round(4)
print("noint orig",fit0(M)); print("noint recode",fit0(1-M))
