import numpy as np, time, sys, xgboost as xgb
dg=sys.argv[1]; seed=int(sys.argv[2]); N=int(sys.argv[3]); rng=np.random.default_rng(seed)
n=300; nt=4000
def make(n,rng):
    if dg=="additive":
        X=rng.normal(size=(n,10)); f=np.sin(X[:,0])+X[:,1]**2/2+0.7*X[:,2]-0.5*X[:,3]
    elif dg=="interact":
        X=rng.normal(size=(n,10)); f=2*X[:,0]*X[:,1]+1.5*(X[:,2]>0)*X[:,3]+np.sin(X[:,4])
    elif dg=="highdim":
        X=rng.normal(size=(n,100)); f=X[:,0]+X[:,1]+0.8*X[:,2]*X[:,3]+0.6*X[:,4]
    return X,f+rng.normal(size=n)
X,y=make(n,rng); Xt,yt=make(nt,rng)
def run(c):
    m=xgb.XGBRegressor(n_estimators=c['nr'],learning_rate=c['eta'],max_depth=c['d'],min_child_weight=c['mcw'],subsample=c['sub'],
        colsample_bytree=c['col'],reg_lambda=c['lam'],reg_alpha=c['alp'],tree_method='hist',n_jobs=1,random_state=0)
    m.fit(X,y); return float(np.mean((m.predict(Xt)-yt)**2))
def wide():
    return dict(eta=np.exp(rng.uniform(np.log(0.003),0)),d=int(rng.integers(1,16)),mcw=2**rng.uniform(0,7),sub=rng.uniform(0.1,1),
        col=rng.uniform(0.05,1),lam=2**rng.uniform(-10,10),alp=2**rng.uniform(-10,10),nr=int(rng.integers(25,401)))
def box():
    return dict(eta=np.exp(rng.uniform(np.log(0.01),np.log(0.3))),d=int(rng.integers(2,11)),mcw=np.exp(rng.uniform(0,np.log(64))),sub=rng.uniform(0.5,1),
        col=rng.uniform(0.3,1),lam=np.exp(rng.uniform(np.log(1e-3),np.log(100))),alp=0.0,nr=int(rng.integers(25,401)))
t0=time.time(); W=[];B=[]
for i in range(N):
    W.append(run(wide())); B.append(run(box()))
    if time.time()-t0>50: break
W=np.array(W);B=np.array(B)
print(f"{dg} seed{seed} k={len(W)} each: best wide {W.min():.3f} best box {B.min():.3f}; median wide {np.median(W):.3f} median box {np.median(B):.3f}; mean top-5 wide {np.sort(W)[:5].mean():.3f} box {np.sort(B)[:5].mean():.3f}; frac within 3% of overall best: wide {np.mean(W<=1.03*min(W.min(),B.min())):.2f} box {np.mean(B<=1.03*min(W.min(),B.min())):.2f}")
