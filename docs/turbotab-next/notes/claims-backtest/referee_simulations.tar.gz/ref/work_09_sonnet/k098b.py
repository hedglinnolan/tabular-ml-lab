import numpy as np, time, sys
from scipy import stats
from sklearn.tree import DecisionTreeRegressor
rng=np.random.default_rng(int(sys.argv[2]))
n=int(sys.argv[1]); K=10; R=10; nd=int(sys.argv[3]); depth=int(sys.argv[4])
rej=0; t0=time.time(); sc=[]; se=[]
for d in range(nd):
    x=rng.normal(size=(n,2)); y=np.sin(2*x[:,0])+np.sin(2*x[:,1])+rng.normal(size=n)
    diffs=[]; A0=[]
    for r in range(R):
        perm=rng.permutation(n); folds=np.array_split(perm,K)
        for k in range(K):
            te=folds[k]; tr=np.concatenate([folds[j] for j in range(K) if j!=k])
            eA=np.mean((y[te]-DecisionTreeRegressor(max_depth=depth,random_state=0).fit(x[tr][:,[0]],y[tr]).predict(x[te][:,[0]]))**2)
            eB=np.mean((y[te]-DecisionTreeRegressor(max_depth=depth,random_state=0).fit(x[tr][:,[1]],y[tr]).predict(x[te][:,[1]]))**2)
            diffs.append(eA-eB)
            if r==0: A0.append(eA)
    diffs=np.array(diffs); J=len(diffs); s2=diffs.var(ddof=1)
    t=diffs.mean()/np.sqrt((1/J+1/(K-1))*s2); rej+=2*stats.t.sf(abs(t),J-1)<0.05
    se.append(np.std(A0,ddof=1)/np.sqrt(K)); sc.append(np.mean(A0))
print(f"trees depth{depth} n={n} nd={nd} corrected-t rejection={rej/nd:.3f}; naive SE {np.mean(se):.3f} vs true SD {np.std(sc,ddof=1):.3f}; {time.time()-t0:.0f}s")
