import numpy as np, time, sys, xgboost as xgb
dg=sys.argv[1]; seed=int(sys.argv[2]); rng=np.random.default_rng(seed)
n=300; nt=4000
def make(n,rng):
    if dg=="additive":
        X=rng.normal(size=(n,10)); f=np.sin(X[:,0])+X[:,1]**2/2+0.7*X[:,2]-0.5*X[:,3]; sd=1.0
    elif dg=="interact":
        X=rng.normal(size=(n,10)); f=2*X[:,0]*X[:,1]+1.5*(X[:,2]>0)*X[:,3]+np.sin(X[:,4]); sd=1.0
    elif dg=="highdim":
        X=rng.normal(size=(n,300)); f=X[:,0]+X[:,1]+0.8*X[:,2]*X[:,3]+0.6*X[:,4]; sd=1.0
    return X,f+sd*rng.normal(size=n)
X,y=make(n,rng); Xt,yt=make(nt,rng)
t0=time.time(); rows=[]
for i in range(int(sys.argv[3])):
    c=dict(eta=np.exp(rng.uniform(np.log(0.01),np.log(1.0))), max_depth=int(rng.integers(1,16)),
           mcw=2**rng.uniform(0,7), sub=rng.uniform(0.2,1), col=rng.uniform(0.1,1),
           lam=2**rng.uniform(-10,10), alp=2**rng.uniform(-10,10), nr=int(rng.integers(25,601)))
    m=xgb.XGBRegressor(n_estimators=c['nr'],learning_rate=c['eta'],max_depth=c['max_depth'],min_child_weight=c['mcw'],
        subsample=c['sub'],colsample_bytree=c['col'],reg_lambda=c['lam'],reg_alpha=c['alp'],tree_method='hist',n_jobs=1,random_state=0)
    m.fit(X,y); mse=float(np.mean((m.predict(Xt)-yt)**2))
    rows.append((mse,c))
    if time.time()-t0>50: break
rows.sort(key=lambda r:r[0]); best=rows[0][0]
good=[r for r in rows if r[0]<=best*1.03]
def inbox(c):
    return dict(eta=0.01<=c['eta']<=0.3, depth=2<=c['max_depth']<=10, mcw=1<=c['mcw']<=64, sub=0.5<=c['sub']<=1,
                col=0.3<=c['col']<=1, lam=1e-3<=c['lam']<=100, alpha0=c['alp']<=0.01)
allin=[all(inbox(r[1]).values()) for r in rows]
print(dg,"fits",len(rows),"best mse",round(best,3),"n good (<=3% of best)",len(good))
print(" good configs wholly inside box:",sum(all(inbox(r[1]).values()) for r in good))
for k in inbox(rows[0][1]).keys():
    print("  ",k,"good outside:",sum(not inbox(r[1])[k] for r in good),"of",len(good))
bi=[r[0] for r,a in zip(rows,allin) if a]
print(" best in-box mse",round(min(bi),3) if bi else None,"(n in-box configs",len(bi),")  ratio to overall best",round(min(bi)/best,3) if bi else None)
print(" top5 configs:",[(round(r[0],3),{k:(round(v,3) if isinstance(v,float) else v) for k,v in r[1].items()}) for r in rows[:3]])
