import re,zlib,sys
d=open(sys.argv[1],'rb').read()
out=[]
for m in re.finditer(rb'stream\r?\n',d):
    s=m.end(); e=d.find(b'endstream',s)
    try: t=zlib.decompress(d[s:e])
    except Exception: continue
    if b'TJ' in t or b'Tj' in t:
        txt=[]
        for blk in re.findall(rb'\[(.*?)\]\s*TJ|\((.*?)\)\s*Tj',t,flags=re.S):
            b=blk[0] or blk[1]
            parts=re.findall(rb'\(((?:\\.|[^\\)])*)\)|(-?\d+\.?\d*)',b)
            line=''
            for p,n in parts:
                if p: line+=p.decode('latin1')
                elif n and float(n)<-200: line+=' '
            txt.append(line)
        out.append('\n'.join(txt))
open(sys.argv[2],'w').write('\n=====\n'.join(out))
