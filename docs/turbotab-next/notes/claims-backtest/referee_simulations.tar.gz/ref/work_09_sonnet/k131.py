import numpy as np
from scipy.stats import skew
rng=np.random.default_rng(0)
def metab_flag(M):
    if (M<0).any(): return False
    pos=M[M>0]; span=pos.max()/pos.min()
    sk=np.median([skew(M[:,j]) for j in range(M.shape[1])])
    return span>=100 and (M.max()>=1000 or sk>=0.5), round(span,1), round(sk,2), round(M.max(),1)
n,p=80,40
mu=rng.normal(2,1.5,p)  # log-scale feature means (natural log)
raw=np.exp(mu+0.5*rng.normal(size=(n,p)))      # lognormal conc, CV~0.5, small units (mM)
print("raw conc small units",metab_flag(raw))
print("log2 of raw intensities (x1e4)",metab_flag(np.log2(raw*1e4)))
print("log1p of small-unit conc w/ 30% zeros",metab_flag(np.log1p(raw*(rng.random((n,p))>0.3))))
mm=(raw-raw.min(0))/(raw.max(0)-raw.min(0))
print("min-max scaled raw",metab_flag(mm))
tpm=raw*1e3; print("unlogged TPM-like (genomics lens: non-integer -> count test fails)",float((tpm==np.round(tpm)).mean()))
# lognormal skewness at CV .3
s2=np.log(1.09); print("lognormal CV .3 skew",(np.exp(s2)+2)*np.sqrt(np.exp(s2)-1))
