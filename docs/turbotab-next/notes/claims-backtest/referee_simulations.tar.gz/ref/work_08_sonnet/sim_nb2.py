import numpy as np
from scipy import stats
rng = np.random.default_rng(7)
def fit_pred(Xtr, ytr, Xte, lam=0.0):
    A = np.c_[np.ones(len(Xtr)), Xtr]
    P = np.eye(A.shape[1])*lam; P[0,0]=0
    b = np.linalg.solve(A.T@A+P, A.T@ytr)
    return np.c_[np.ones(len(Xte)), Xte] @ b
p=10
beta = np.r_[np.full(5,0.5), np.full(5,0.1)]
def gen(n):
    X = rng.standard_normal((n,p)); y = X@beta + rng.standard_normal(n); return X,y
# learner A: OLS on all 10; learner B: ridge lam=20 on all
def diff(Xtr,ytr,Xte,yte):
    return np.mean((yte-fit_pred(Xtr,ytr,Xte,0))**2)-np.mean((yte-fit_pred(Xtr,ytr,Xte,20))**2)
def truemu(ntr, nrep=800):
    Xt,yt = gen(20000)
    v=[]
    for i in range(nrep):
        X,y = gen(ntr); v.append(diff(X,y,Xt,yt))
    return np.mean(v), np.std(v)/np.sqrt(nrep)
def cover(n, K, r, reps=300):
    ntr = n - n//K
    mu,se = truemu(ntr)
    cov=0; covu=0; w=[]
    for it in range(reps):
        X,y = gen(n); ds=[]
        for rr in range(r):
            perm = rng.permutation(n)
            for f in np.array_split(perm,K):
                tr=np.setdiff1d(perm,f); ds.append(diff(X[tr],y[tr],X[f],y[f]))
        ds=np.array(ds); m=ds.mean(); s2=ds.var(ddof=1); N=len(ds)
        tq=stats.t.ppf(.975,N-1)
        hw=tq*np.sqrt((1/N+1/(K-1))*s2); hwu=tq*np.sqrt(s2/N)
        cov += abs(m-mu)<=hw; covu += abs(m-mu)<=hwu
    return mu,se,cov/reps,covu/reps
for n,K,r in [(60,5,10),(100,5,10)]:
    print(n,K,r,cover(n,K,r),flush=True)
