exec(open('sim_shrink.py').read().split("t0=time.time()")[0])
def run2(n,reps=60,K=5):
    rows=[]
    for r in range(reps):
        X,y=gen(n)
        if y.sum()<5: continue
        res=fit(X,y)
        cb=boot_slope(X,y,B=40); cc=cv_slope(X,y,K=K)
        true=slope(lp(res,Xt),yt)   # oracle needed shrinkage of this fitted model
        rows.append((cb,cc,true))
    a=np.array(rows)
    print("n",n,"K",K,"boot mean %.3f med %.3f sd %.3f | cv mean %.3f med %.3f sd %.3f | oracle(test) mean %.3f sd %.3f"%(a[:,0].mean(),np.median(a[:,0]),a[:,0].std(),a[:,1].mean(),np.median(a[:,1]),a[:,1].std(),a[:,2].mean(),a[:,2].std()),
          "corr(cv,oracle) %.2f corr(boot,oracle) %.2f"%(np.corrcoef(a[:,1],a[:,2])[0,1],np.corrcoef(a[:,0],a[:,2])[0,1]),flush=True)
run2(150,K=5); run2(150,K=10); run2(400,K=5)
