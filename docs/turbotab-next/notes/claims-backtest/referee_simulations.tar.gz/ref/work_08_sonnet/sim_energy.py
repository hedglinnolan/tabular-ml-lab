import os
for v in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","VECLIB_MAXIMUM_THREADS","MKL_NUM_THREADS"]: os.environ[v]="1"
import numpy as np
from sklearn.linear_model import LinearRegression, RidgeCV, LassoCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score
rng=np.random.default_rng(2)
def make(n,p=20):
    # nutrients proportional to energy with density variation
    E=np.exp(rng.normal(7.5,0.3,n))              # kcal
    dens=np.exp(rng.normal(0,0.3,(n,p))) * rng.uniform(0.5,1.5,p)  # per kcal densities
    N=dens*E[:,None]/1000
    return E,N,dens
def sim(n=400,p=20):
    E,N,dens=make(n+5000,p)
    # truth: outcome depends on nutrient density of first 3 nutrients (diet quality), plus noise
    y=3*(dens[:,:3]/dens[:,:3].mean(0)).sum(1)+rng.standard_normal(n+5000)*1.5
    tr=slice(0,n); te=slice(n,None)
    # parameterisations
    Xstd=np.c_[N,E]
    # residual: nutrient regressed on energy (fit on train), + E
    Xres=np.zeros_like(N)
    for j in range(p):
        b=np.polyfit(E[tr],N[tr,j],1); Xres[:,j]=N[:,j]-np.polyval(b,E)
    Xres=np.c_[Xres,E]
    Xpart=np.c_[N,E-N.sum(1)]   # energy-partition-like (energy from other sources approx = E - kcal_from_nutrients)
    Xden=np.c_[dens,E]
    out={}
    for name,X in [("standard",Xstd),("residual",Xres),("partition",Xpart),("density+E",Xden)]:
        r={}
        for mname,m in [("OLS",LinearRegression()),("ridge",RidgeCV(alphas=np.logspace(-3,3,20))),
                        ("lasso",LassoCV(cv=5,n_alphas=30,max_iter=5000)),
                        ("RF",RandomForestRegressor(100,min_samples_leaf=5,random_state=0,n_jobs=1))]:
            from sklearn.preprocessing import StandardScaler
            from sklearn.pipeline import make_pipeline
            mm=make_pipeline(StandardScaler(),m) if mname in("ridge","lasso") else m
            mm.fit(X[tr],y[tr]); r[mname]=r2_score(y[te],mm.predict(X[te]))
        out[name]=r
    return out
res=[sim() for _ in range(5)]
import pandas as pd
df=pd.concat([pd.DataFrame(r).T for r in res]).groupby(level=0).mean()
print(df.round(3))
