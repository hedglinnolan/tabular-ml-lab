import numpy as np
from scipy import stats
rng = np.random.default_rng(1)
def corrected_t(d, K, r):
    n = len(d)
    n2n1 = 1.0/(K-1)
    m = d.mean(); s2 = d.var(ddof=1)
    t = m/np.sqrt((1.0/n + n2n1)*s2) if s2>0 else 0
    p = 2*stats.t.sf(abs(t), n-1)
    tu = m/np.sqrt(s2/n); pu = 2*stats.t.sf(abs(tu), n-1)
    return p, pu
def ols_fit_pred(Xtr, ytr, Xte):
    A = np.c_[np.ones(len(Xtr)), Xtr]
    b = np.linalg.lstsq(A, ytr, rcond=None)[0]
    return np.c_[np.ones(len(Xte)), Xte] @ b
def run(n=100, pA=5, pB=5, beta=0.3, r=10, K=5, reps=1000, noise=1.0):
    rej=0; rej_u=0
    for it in range(reps):
        X = rng.standard_normal((n, pA+pB))
        # signal only through shared latent: both feature sets exchangeable
        y = beta*X.sum(axis=1) + noise*rng.standard_normal(n)
        ds=[]
        for rr in range(r):
            perm = rng.permutation(n)
            folds = np.array_split(perm, K)
            for f in folds:
                tr = np.setdiff1d(perm, f)
                # learner A: features 0..pA-1, learner B: features pA..
                eA = np.mean((y[f]-ols_fit_pred(X[tr][:, :pA], y[tr], X[f][:, :pA]))**2)
                eB = np.mean((y[f]-ols_fit_pred(X[tr][:, pA:], y[tr], X[f][:, pA:]))**2)
                ds.append(eA-eB)
        p,pu = corrected_t(np.array(ds), K, r)
        rej += p<0.05; rej_u += pu<0.05
    return rej/reps, rej_u/reps
import sys
for (n,pA,beta,K,r) in [(100,5,0.3,5,10),(50,5,0.3,5,10),(200,5,0.3,5,10),(100,5,0.3,10,10),(100,5,0.3,5,1)]:
    print(n,pA,beta,K,r, run(n=n,pA=pA,beta=beta,K=K,r=r,reps=600), flush=True)
