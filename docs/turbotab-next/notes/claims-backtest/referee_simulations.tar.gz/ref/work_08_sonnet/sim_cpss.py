import os
for v in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","VECLIB_MAXIMUM_THREADS","MKL_NUM_THREADS"]: os.environ[v]="1"
import numpy as np, time
from sklearn.linear_model import lars_path
rng=np.random.default_rng(3)
def first_q(X,y,q):
    _,active,_ = lars_path(X,y,method='lasso',max_iter=q,verbose=0)
    return set(active[:q]) if len(active)>=q else set(active)
def cpss(X,y,q,B=50,tau=0.6):
    n,p=X.shape; cnt=np.zeros(p)
    for b in range(B):
        perm=rng.permutation(n); A=perm[:n//2]; Ac=perm[n//2:]
        for idx in (A,Ac):
            for k in first_q(X[idx],y[idx],q): cnt[k]+=1
    return np.where(cnt/(2*B)>=tau)[0]
def design(n,p,kind):
    if kind=="indep": return rng.standard_normal((n,p))
    if kind.startswith("ar"):
        rho=float(kind[2:]); Z=rng.standard_normal((n,p)); X=np.zeros((n,p)); X[:,0]=Z[:,0]
        for j in range(1,p): X[:,j]=rho*X[:,j-1]+np.sqrt(1-rho**2)*Z[:,j]
        return X
    if kind.startswith("eq"):
        rho=float(kind[2:]); z=rng.standard_normal((n,1)); return np.sqrt(rho)*z+np.sqrt(1-rho)*rng.standard_normal((n,p))
def run(kind,n=200,p=100,s=5,beta=1.0,reps=60,tau=0.6):
    q=int(np.floor(np.sqrt((2*tau-1)*p))); Vs=[]; Ts=[]
    sig=np.arange(0,p,p//s)[:s]  # spread signals (for ar designs, noise neighbours exist)
    for r in range(reps):
        X=design(n,p,kind); b=np.zeros(p); b[sig]=beta
        y=X@b+rng.standard_normal(n)
        S=cpss(X,y,q,tau=tau); V=len([k for k in S if k not in sig]); Vs.append(V); Ts.append(len(S)-V)
    return q,np.mean(Vs),np.max(Vs),np.mean(Ts)
t0=time.time()
for kind in ["indep","ar0.8","ar0.95","eq0.5"]:
    print(kind,run(kind),round(time.time()-t0,1),flush=True)
# weak signals, n small
print("indep n=60 beta=.5",run("indep",n=60,beta=0.5),flush=True)
print("ar0.95 n=60 beta=.5",run("ar0.95",n=60,beta=0.5),flush=True)
