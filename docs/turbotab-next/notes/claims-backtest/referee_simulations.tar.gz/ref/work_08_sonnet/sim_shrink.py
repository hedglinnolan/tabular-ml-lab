import os
for v in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","VECLIB_MAXIMUM_THREADS","MKL_NUM_THREADS"]: os.environ[v]="1"
import numpy as np, time, warnings
warnings.filterwarnings("ignore")
import statsmodels.api as sm
rng=np.random.default_rng(11)
p=10
beta=np.r_[np.full(4,0.5),np.zeros(6)]
b0=-1.5
def gen(n):
    X=rng.standard_normal((n,p)); eta=b0+X@beta; y=(rng.random(n)<1/(1+np.exp(-eta))).astype(float); return X,y
def fit(X,y):
    return sm.GLM(y,sm.add_constant(X),family=sm.families.Binomial()).fit(maxiter=50)
def lp(res,X): return sm.add_constant(X,has_constant='add')@res.params
def slope(eta,y):
    r=sm.GLM(y,sm.add_constant(eta),family=sm.families.Binomial()).fit(maxiter=50); return r.params[1]
def boot_slope(X,y,B=60):
    s=[]; n=len(y)
    for b in range(B):
        i=rng.integers(0,n,n)
        if y[i].sum()<3: continue
        try:
            rb=fit(X[i],y[i]); s.append(slope(lp(rb,X),y))
        except Exception: pass
    return np.mean(s)
def cv_slope(X,y,K=5):
    n=len(y); perm=rng.permutation(n); eta=np.zeros(n)
    for f in np.array_split(perm,K):
        tr=np.setdiff1d(perm,f); rb=fit(X[tr],y[tr]); eta[f]=lp(rb,X[f])
    return slope(eta,y)
def shrink_update(res,X,y,c):
    # coefficients x c ; intercept re-estimated with shrunk LP (slopes only) as offset
    bs=res.params[1:]*c
    r=sm.GLM(y,np.ones((len(y),1)),family=sm.families.Binomial(),offset=X@bs).fit()
    return np.r_[r.params[0],bs]
def evalm(par,Xt,yt):
    eta=sm.add_constant(Xt)@par; pr=1/(1+np.exp(-eta)); 
    ll=-np.mean(yt*np.log(pr+1e-12)+(1-yt)*np.log(1-pr+1e-12)); br=np.mean((pr-yt)**2)
    return ll,br,slope(eta,yt),(yt.mean()-pr.mean())
Xt,yt=gen(40000)
def run(n,reps=120):
    out={k:[] for k in ["raw","boot","cv"]}; cs={"boot":[],"cv":[]}
    for r in range(reps):
        X,y=gen(n)
        if y.sum()<5: continue
        res=fit(X,y); 
        cb=min(1,boot_slope(X,y)); cc=min(1,cv_slope(X,y)); cs["boot"].append(cb); cs["cv"].append(cc)
        out["raw"].append(evalm(res.params,Xt,yt))
        out["boot"].append(evalm(shrink_update(res,X,y,cb),Xt,yt))
        out["cv"].append(evalm(shrink_update(res,X,y,cc),Xt,yt))
    for k in out:
        a=np.array(out[k]); print(n,k,"logloss %.4f brier %.4f calslope %.3f CITL %.3f"%tuple(a.mean(0)), "SDslope %.3f"%a[:,2].std())
    print(" mean shrink factors",{k:round(np.mean(v),3) for k,v in cs.items()},flush=True)
t0=time.time()
run(150,reps=80); print(time.time()-t0)
