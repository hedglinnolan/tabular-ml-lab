import os
for v in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","VECLIB_MAXIMUM_THREADS","MKL_NUM_THREADS"]: os.environ[v]="1"
import numpy as np, warnings, time
warnings.filterwarnings("ignore")
import statsmodels.api as sm
from scipy import stats
rng=np.random.default_rng(5)
def one(K=20,m=50,icc=0.05):
    g=np.repeat(np.arange(K),m); arm=np.repeat(rng.permutation(np.r_[np.zeros(K//2),np.ones(K//2)]),m)
    u=np.repeat(rng.standard_normal(K)*np.sqrt(icc),m); y=u+rng.standard_normal(K*m)*np.sqrt(1-icc)
    X=sm.add_constant(arm)
    r=sm.GEE(y,X,groups=g,cov_struct=sm.cov_struct.Exchangeable()).fit()
    b=r.params[1]; se=r.bse[1]; return abs(b/se)
t0=time.time(); z=np.array([one() for _ in range(600)])
K=20; N=K*50
for name,df in [("t(N-2)=%d"%(N-2),N-2),("t(K-2)=%d"%(K-2),K-2),("normal",1e9)]:
    print(name,"type I at nominal .05:",np.mean(z>stats.t.ppf(.975,df)))
print(time.time()-t0)
for K in (10,):
    z=np.array([one(K=K,m=50) for _ in range(3000)]); N=K*50
    for name,df in [("t(N-2)",N-2),("t(K-2)",K-2)]:
        print("K",K,name,np.mean(z>stats.t.ppf(.975,df)))
