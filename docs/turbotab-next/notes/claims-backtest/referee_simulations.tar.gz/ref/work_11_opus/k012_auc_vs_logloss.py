import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, log_loss
rng=np.random.default_rng(1)
Cs=np.logspace(-3,2,11)
res=[]
for rep in range(40):
    n,p=150,20
    beta=np.zeros(p); beta[:5]=0.5
    X=rng.normal(size=(n,p)); pr=1/(1+np.exp(-(X@beta-0.5))); y=rng.binomial(1,pr)
    Xt=rng.normal(size=(5000,p)); yt=rng.binomial(1,1/(1+np.exp(-(Xt@beta-0.5))))
    skf=StratifiedKFold(5,shuffle=True,random_state=rep)
    oof=np.zeros((len(Cs),n))
    for tr,va in skf.split(X,y):
        for i,C in enumerate(Cs):
            m=LogisticRegression(C=C,max_iter=2000).fit(X[tr],y[tr]); oof[i,va]=m.predict_proba(X[va])[:,1]
    ll=[log_loss(y,o) for o in oof]; auc=[roc_auc_score(y,o) for o in oof]
    cl=Cs[np.argmin(ll)]; ca=Cs[np.argmax(auc)]
    def test(C):
        m=LogisticRegression(C=C,max_iter=2000).fit(X,y); q=m.predict_proba(Xt)[:,1]; return log_loss(yt,q),roc_auc_score(yt,q)
    res.append((cl,ca,*test(cl),*test(ca)))
r=np.array(res)
print("median C by logloss, by AUC:",np.median(r[:,0]),np.median(r[:,1]))
print("frac different choice:",np.mean(r[:,0]!=r[:,1]))
print("test logloss (LL-tuned, AUC-tuned):",r[:,2].mean(),r[:,4].mean())
print("test AUC (LL-tuned, AUC-tuned):",r[:,3].mean(),r[:,5].mean())
