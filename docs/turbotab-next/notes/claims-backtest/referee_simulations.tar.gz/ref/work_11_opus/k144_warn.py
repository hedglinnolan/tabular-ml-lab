import numpy as np, warnings, sklearn
from sklearn.linear_model import LogisticRegression
print(sklearn.__version__)
rng=np.random.default_rng(0)
n,p=400,5
X=rng.normal(size=(n,p)); y=rng.binomial(1,1/(1+np.exp(-(X@np.array([.8,-.5,.3,0,.2])))))
for c in (1,1e3,1e5):
    Xs=X.copy(); Xs[:,0]*=c
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        m=LogisticRegression(penalty=None,max_iter=1000).fit(Xs,y)
    print(c, m.n_iter_, set(str(x.category.__name__)+": "+str(x.message)[:90] for x in w))
    for solver in ("newton-cg","newton-cholesky"):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            m2=LogisticRegression(penalty=None,solver=solver,max_iter=1000).fit(Xs,y)
            m0=LogisticRegression(penalty=None,solver=solver,max_iter=1000).fit(X,y)
        print("  ",solver, np.max(np.abs(m2.predict_proba(Xs)[:,1]-m0.predict_proba(X)[:,1])), len(w))
