import numpy as np, warnings
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss
warnings.simplefilter("ignore", DeprecationWarning)
rng=np.random.default_rng(3)
worst=[]
for rep in range(20):
    n=500
    inc=rng.normal(50000,20000,n); age=rng.normal(45,12,n); z=rng.normal(size=n)
    eta=-0.5+0.8*(inc-50000)/20000-0.03*(age-45)+0.5*z
    y=rng.binomial(1,1/(1+np.exp(-eta)))
    X=np.c_[inc,age,z]; Xs=(X-X.mean(0))/X.std(0)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        a=LogisticRegression(penalty=None,max_iter=1000).fit(X,y)
        conv=[str(x.category.__name__) for x in w if "Convergence" in x.category.__name__]
    b=LogisticRegression(penalty=None,max_iter=1000).fit(Xs,y)
    pa=a.predict_proba(X)[:,1]; pb=b.predict_proba(Xs)[:,1]
    worst.append((np.max(np.abs(pa-pb)), log_loss(y,pa)-log_loss(y,pb), len(conv), a.n_iter_[0]))
w=np.array(worst)
print("max|dp| per rep:",np.round(w[:,0],3))
print("logloss excess raw-vs-std:",np.round(w[:,1],4))
print("convergence warnings:",w[:,2].astype(int), "iters:",w[:,3].astype(int))
