import numpy as np, warnings
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_predict, StratifiedKFold
import statsmodels.api as sm
rng=np.random.default_rng(0)
n,p=400,5
X=rng.normal(size=(n,p)); y=rng.binomial(1,1/(1+np.exp(-(X@np.array([.8,-.5,.3,0,.2])))))
cv=StratifiedKFold(5,shuffle=True,random_state=0)
for c in (1e-3,1,1e3,1e5):
    Xs=X.copy(); Xs[:,0]*=c
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        a=cross_val_predict(LogisticRegression(penalty=None,max_iter=1000),X,y,cv=cv,method="predict_proba")[:,1]
        b=cross_val_predict(LogisticRegression(penalty=None,max_iter=1000),Xs,y,cv=cv,method="predict_proba")[:,1]
    # statsmodels Newton per fold
    d=[]
    for tr,va in cv.split(X,y):
        m1=sm.Logit(y[tr],sm.add_constant(X[tr])).fit(disp=0); m2=sm.Logit(y[tr],sm.add_constant(Xs[tr])).fit(disp=0)
        d.append(np.max(np.abs(m1.predict(sm.add_constant(X[va]))-m2.predict(sm.add_constant(Xs[va])))))
    print(f"scale {c:g}: sklearn lbfgs max|dp|={np.max(np.abs(a-b)):.2e} warnings={len(w)}; statsmodels Newton max|dp|={max(d):.2e}")
