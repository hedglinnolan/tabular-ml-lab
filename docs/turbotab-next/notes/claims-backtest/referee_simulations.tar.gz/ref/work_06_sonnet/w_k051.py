from emit import emit
emit({
 "id":"K-051","truth":"true",
 "failing_part":"",
 "narrowest_regime":"Residual-method adjustment where the energy-adjusted residual r = N - (a + bE) is entered with total energy E in the model and the nutrient is correlated with energy (b != 0). If b = 0, or the effect is linear, the two models coincide.",
 "reason":"Since r = N - a - bE, a spline f(r) is a function of N - bE, so f(N - bE) + g(E) equals h(N) + k(E) for all N, E only if f is linear (the mixed derivative -b f'' must vanish); for a straight line the coefficient on r equals the coefficient on N (I confirmed 0.4996 vs 0.4996). When the truth is additive in N and E, the residual spline blurs the substitution curve across the spread of energy: a step at N=0 (true -1.48 to +1.52) came out as -0.71 to +0.68 at N=+-0.5, and a hinge at 1 was smeared; the standard spline recovered the truth. Plotting f against r + (a + b*mean E) gives the energy-adjusted scale at mean energy, so the label is apt, and the standard model (spline of N with E beside it) is the route to the substitution curve. One imprecision: the residual model must include E for the equivalence statement; the claim does not say so.",
 "basis_used":"mixed",
 "citations":[{"cite":"Willett WC, Stampfer MJ (1986) Total energy intake: implications for epidemiologic analyses. Am J Epidemiol 124:17-27 (existence confirmed through a 2023 AJE commentary abstract; contents not opened)","verified":False},
              {"cite":"Tomova GD et al. (2022) Theory and performance of substitution models for estimating relative causal effects of nutrients. Int J Epidemiol (search returned nothing)","verified":False}],
 "bite":"yes",
 "bite_note":"It changes how a nonlinear nutrient curve from the residual method is labelled (energy-adjusted, not isocaloric substitution) and steers a researcher who wants the substitution curve to the standard model; with a nonlinear truth the two curves visibly differ.",
 "confidence":0.7})
