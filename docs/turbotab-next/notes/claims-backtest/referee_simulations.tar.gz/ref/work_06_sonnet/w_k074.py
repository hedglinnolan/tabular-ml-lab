from emit import emit
emit({
 "id":"K-074","truth":"false",
 "failing_part":"\"not grouping by it ... is the conservative path: the held-out draw and the folds group only by a settled cluster reading\"",
 "narrowest_regime":"Not grouping is the safe default only when the model will be applied to the same units it was trained on (within-unit prediction), or when the repeating column is not a unit at all (a code or category whose rows are exchangeable). For prediction to new units it is the optimistic path.",
 "reason":"With a repeating unit identifier, a random row split puts the same unit's rows on both sides, so the held-out score partly measures recognition of seen units and overstates accuracy for new units; grouping is the conservative choice for performance claims. In a simulation (100 subjects x 10 rows, subject-level covariates plus an unobserved subject effect, random forest), ungrouped 5-fold CV gave R2 = 0.62 while grouped CV gave -0.004 and the true R2 on brand-new subjects was 0.031 (8 replicates). Leaving it ungrouped until confirmed is conservative only in the sense of imposing no structure, which is the wrong sense for a held-out estimate the researcher will rely on.",
 "basis_used":"simulation",
 "citations":[{"cite":"Saeb S, Lonini L, Jayaraman A, Mohr DC, Kording KP (2017) The need to approximate the use-case in clinical machine learning. GigaScience 6:1-9 (Europe PMC summary: record-wise CV often massively overestimates accuracy; subject-wise reflects the clinical use case)","verified":True}],
 "bite":"yes",
 "bite_note":"Whether the sealed held-out set and resampling folds keep a unit's rows together decides whether the reported predictive accuracy is honest for new units or inflated (here 0.62 vs about 0.03), and which model or tuning wins in selection.",
 "confidence":0.85})
