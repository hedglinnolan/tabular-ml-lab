import numpy as np, time
from sklearn.linear_model import LinearRegression, RidgeCV
rng=np.random.default_rng(5)
def run(n,p,rho=0.5,reps=12):
    out=[]
    C=rho*np.ones((p,p))+(1-rho)*np.eye(p); L=np.linalg.cholesky(C)
    for _ in range(reps):
        beta=rng.normal(0,1,p)*np.sqrt(0.5/p)
        X=rng.normal(size=(n,p))@L.T; Xt=rng.normal(size=(2000,p))@L.T
        sd=np.sqrt((beta@C@beta)/0.5)
        y=X@beta+rng.normal(0,sd,n); yt=Xt@beta+rng.normal(0,sd,2000)
        o=LinearRegression().fit(X,y); r=RidgeCV(alphas=np.logspace(-3,3,25)).fit(X,y)
        out.append([np.mean((yt-o.predict(Xt))**2),np.mean((yt-r.predict(Xt))**2)])
    return np.mean(out,0)
t0=time.time()
print("n p | test MSE OLS, RidgeCV (dense signal, rho=.5, true R2 = 1/3)")
for n,p in [(100,10),(100,50),(500,10),(500,100),(500,250),(1500,50),(1500,300)]:
    m=run(n,p); print(n,p,m.round(3),f"ridge/OLS={m[1]/m[0]:.3f}")
print(time.time()-t0)
