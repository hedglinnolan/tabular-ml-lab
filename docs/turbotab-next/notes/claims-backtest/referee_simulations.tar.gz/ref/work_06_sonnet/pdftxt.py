import re, zlib, sys
data = open("bam3.pdf","rb").read()
streams = re.findall(rb"stream\r?\n(.*?)\r?\nendstream", data, re.S)
print(len(streams), "streams")
out=[]
cmaps=[]
for s in streams:
    try:
        d = zlib.decompress(s)
    except Exception:
        continue
    if b"beginbfchar" in d or b"beginbfrange" in d:
        cmaps.append(d)
    elif b"BT" in d and (b"Tj" in d or b"TJ" in d):
        out.append(d)
print(len(out), "content streams;", len(cmaps), "cmaps")
open("content_streams.bin","wb").write(b"\n=====\n".join(out))
open("cmaps.bin","wb").write(b"\n=====\n".join(cmaps))
print(out[0][:600] if out else None)
print(cmaps[0][:400] if cmaps else None)
