import numpy as np, statsmodels.api as sm
from scipy import stats
rng=np.random.default_rng(7)
# A: censored variable is the OUTCOME on log scale; two groups, true log-mean diff delta=0.5; common LOD at 40th pctl of pooled
def outcome_case(n=150, sd=1.0, delta=0.5, lodq=0.4, reps=1500, sub_rule="halfmin"):
    cov=0; bias=[]
    for _ in range(reps):
        g=rng.integers(0,2,n)
        zl=rng.normal(0,sd,n)+delta*g          # log outcome
        z=np.exp(zl)
        lod=np.quantile(np.exp(rng.normal(0,sd,20000)+delta*0.5), lodq)
        det=z>=lod
        sub=np.min(z[det])/2
        zs=np.where(det,z,sub)
        y=np.log(zs)
        f=sm.OLS(y,sm.add_constant(g.astype(float))).fit()
        lo,hi=f.conf_int()[1]
        cov+=(lo<=delta<=hi); bias.append(f.params[1]-delta)
    return round(cov/reps,3), round(float(np.mean(bias)),3)
# B: censored variable is the EXPOSURE (log scale), outcome continuous
def exposure_case(n=300, sd=1.0, beta=0.5, lodq=0.4, reps=1500):
    cov=0; bias=[]
    for _ in range(reps):
        xl=rng.normal(0,sd,n); x=np.exp(xl)
        lod=np.exp(sd*stats.norm.ppf(lodq))
        det=x>=lod
        xs=np.where(det,x,np.min(x[det])/2)
        y=beta*xl+rng.normal(0,1,n)
        f=sm.OLS(y,sm.add_constant(np.log(xs))).fit()
        lo,hi=f.conf_int()[1]
        cov+=(lo<=beta<=hi); bias.append(f.params[1]-beta)
    return round(cov/reps,3), round(float(np.mean(bias)),3)
print("outcome-censored, group diff (coverage, bias):")
for sd in [0.5,1.0,2.0]:
    for q in [0.2,0.4,0.6]:
        print(" sd",sd,"lodq",q, outcome_case(sd=sd,lodq=q))
print("exposure-censored slope (coverage, bias):")
for sd in [0.5,1.0,2.0]:
    for q in [0.2,0.4,0.6]:
        print(" sd",sd,"lodq",q, exposure_case(sd=sd,lodq=q))
