from emit import emit
emit({
 "id":"K-143","truth":"false",
 "failing_part":"\"because a deterministic fill adds no imputation uncertainty, so the intervals computed afterwards remain valid\"",
 "narrowest_regime":"Only by coincidence, when the fixed fill happens to sit near the conditional mean of the censored values (Berkson-like error) and the censoring fraction is small; nothing in a half-minimum rule guarantees that.",
 "reason":"A single deterministic fill is treated by the downstream model as an observed value, so it ignores the uncertainty about the censored values; absence of imputation uncertainty is the source of too-narrow intervals, not a guarantee of validity. Helsel 2006 (verified abstract) says substitution gives poor estimates, obscures or fabricates patterns, and 'should generally be considered unacceptable in scientific research', the opposite of the cited use. In my simulations (log-normal, half of the minimum detect substituted) 95% CIs for a regression slope or a group difference had coverage from 0.05 to 0.95 depending on spread and censoring fraction (e.g. exposure censored, log-sd 2, 60% below LOD: coverage 0.05, slope bias +0.18; outcome censored, log-sd 1, 60% below LOD: coverage 0.72).",
 "basis_used":"mixed",
 "citations":[{"cite":"Helsel DR (2006) Fabricating data: how substituting values for nondetects can ruin results, and what can be done about it. Chemosphere 65:2434-2439 (abstract read via Europe PMC; it argues against substitution)","verified":True},
              {"cite":"Wei R et al. (2018) Sci Rep 8:663, missing value imputation for MS metabolomics (abstract: QRILC favoured for left-censored MNAR; half-minimum is one of the compared simple fills)","verified":True}],
 "bite":"yes",
 "bite_note":"Allowing half-minimum under inference while refusing a censoring-aware route sends researchers to a fill whose intervals can badly undercover; the alternative (censored-data likelihood/Tobit, multiple imputation from a censored model, or reporting a detect/non-detect sensitivity) changes the reported CI and p-value.",
 "confidence":0.9})
