from emit import emit
emit({
 "id":"K-103","truth":"true",
 "failing_part":"",
 "narrowest_regime":"Plate counts from pour-plate/spiral APC methods read against a stated countable range; TNTC means the true count exceeds the range, so it is a lower bound (right-censored). QNS/hemolyzed specimens have no valid measured value for the analyte.",
 "reason":"I read the January 2026 BAM Ch. 3 PDF: it states the suitable colony counting range was updated in March 2025 from 25-250 to 15-300 per plate, and it estimates the APC by maximum likelihood 'using the plates for which exact counts are available and the too numerous to count (TNTC) plates', i.e. TNTC enters as a censored observation (a lower bound), not a dropped value. That matches the claim's censored-not-missing reading and its 15-300 figure. Treating QNS/hemolysis as a measurement failure with no value (missing) is the standard classification; the claim does not assert the missingness is ignorable.",
 "basis_used":"literature",
 "citations":[{"cite":"FDA BAM Chapter 3: Aerobic Plate Count, January 2026 edition (PDF fetched and text extracted: range 15-300 per plate; TNTC plates enter the Poisson ML estimate as censored)","verified":True},
              {"cite":"Haas CN, Heller B (1988) Averaging of TNTC counts. Appl Environ Microbiol 54:2069-2072 (cited in the BAM chapter's reference list; not opened)","verified":False}],
 "bite":"yes",
 "bite_note":"Routing TNTC to missing drops the highest-concentration samples and biases means and regressions downward; keeping them as right-censored (Tobit/survival-style or ML) changes the estimates and intervals.",
 "confidence":0.85})
