import numpy as np, time
from scipy import stats
rng=np.random.default_rng(3)
def rcs_basis(x,k):
    K=len(k); p3=lambda u: np.maximum(u,0)**3
    cols=[x]
    for j in range(K-2):
        cols.append((p3(x-k[j]) - p3(x-k[K-2])*(k[K-1]-k[j])/(k[K-1]-k[K-2]) + p3(x-k[K-1])*(k[K-2]-k[j])/(k[K-1]-k[K-2]))/(k[K-1]-k[0])**2)
    return np.column_stack(cols)
curves={"plateau":lambda x: np.tanh(1.2*x),"quadratic":lambda x: 0.35*x**2,"linear":lambda x: 0.5*x,"threshold":lambda x: 0.8*np.maximum(x-0.5,0)}
def fit(Xd,y):
    b,res,rk,_=np.linalg.lstsq(Xd,y,rcond=None); r=y-Xd@b
    rss=r@r; tss=((y-y.mean())**2).sum(); p=Xd.shape[1]-1; n=len(y)
    F=((tss-rss)/p)/(rss/(n-p-1)); return b, stats.f.sf(F,p,n-p-1)
def one(n,f,sd=2.0):
    x=rng.normal(0,1,n); y=f(x)+rng.normal(0,sd,n)
    q=np.quantile(x,[.2,.4,.6,.8]); c=np.digitize(x,q); D=np.eye(5)[c]
    bq,pq_=fit(D[:,1:]*1.0 if False else np.column_stack([np.ones(n),D[:,1:]]),y)
    kn=np.quantile(x,[.05,.35,.65,.95]); B=np.column_stack([np.ones(n),rcs_basis(x,kn)]); br,pr_=fit(B,y)
    g=np.linspace(np.quantile(x,.05),np.quantile(x,.95),150); cg=np.digitize(g,q)
    Dg=np.column_stack([np.ones(len(g)),np.eye(5)[cg][:,1:]]); pq=Dg@bq
    pr=np.column_stack([np.ones(len(g)),rcs_basis(g,kn)])@br; t=f(g)
    return np.mean((pq-t)**2),np.mean((pr-t)**2),pq_<.05,pr_<.05
t0=time.time()
for name,f in curves.items():
    for n in [500,2000]:
        r=np.array([one(n,f) for _ in range(400)],float)
        print(f"{name:10s} n={n:5d} IMSE quintile={r[:,0].mean():.5f} rcs={r[:,1].mean():.5f} ratio={r[:,0].mean()/r[:,1].mean():.2f}  power(overall F) quint={r[:,2].mean():.2f} rcs={r[:,3].mean():.2f}")
print(time.time()-t0)
