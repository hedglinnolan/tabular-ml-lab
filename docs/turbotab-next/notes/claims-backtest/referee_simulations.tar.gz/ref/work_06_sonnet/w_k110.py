from emit import emit
emit({
 "id":"K-110","truth":"true",
 "failing_part":"",
 "narrowest_regime":"MS-based metabolomics (LC/GC-MS) where missingness concentrates in low-intensity features; the hedge 'likely' matters because some missingness in low features is still random (peak-picking/alignment failures), so the pattern is evidence of a left-censored component, not proof that all of it is.",
 "reason":"A detection limit makes a value missing because of its own magnitude, which is missing-not-at-random by definition, and a missing-rate that rises as feature abundance falls is the expected signature. Wei et al. 2018 (abstract verified) treat left-censored MNAR as a distinct type and report QRILC favoured for it versus random forest for MCAR/MAR, supporting the censoring reading and its different handling. The claim is hedged ('likely') and only routes to a non-detection fill, which the user can override.",
 "basis_used":"mixed",
 "citations":[{"cite":"Wei R et al. (2018) Missing value imputation approach for mass spectrometry-based metabolomics data. Sci Rep 8:663, doi:10.1038/s41598-017-19120-0 (abstract read via Europe PMC)","verified":True},
              {"cite":"Yang J et al. (2015) metabolomics missing-value/pre-processing paper cited as 'Yang 2015' (could not locate or open)","verified":False}],
 "bite":"yes",
 "bite_note":"Chooses a censoring-aware fill (half-min/QRILC family or censored model) over generic MAR imputation such as kNN/RF for the low-abundance clusters, which changes downstream means, fold-changes and tests.",
 "confidence":0.8})
