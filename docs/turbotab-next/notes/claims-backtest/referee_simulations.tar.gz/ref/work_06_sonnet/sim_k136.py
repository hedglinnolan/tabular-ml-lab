import numpy as np, warnings, time
import statsmodels.api as sm
from scipy import stats
warnings.filterwarnings("ignore")
rng=np.random.default_rng(9)
def run(K,m=20,icc=0.05,reps=400,cl_cov=False):
    res={k:0 for k in ["rob_z","rob_tK2","bc_z","bc_tK2","bc_tKdf"]}
    for _ in range(reps):
        g=np.repeat(np.arange(K),m); arm=(np.arange(K)%2).astype(float)
        a=rng.normal(0,np.sqrt(icc),K); z=rng.normal(0,1,K)  # cluster-level covariate (null)
        y=a[g]+rng.normal(0,np.sqrt(1-icc),K*m)               # null treatment effect = 0 (true beta=0)
        cols=[np.ones(K*m),arm[g]]+([z[g]] if cl_cov else [])
        X=np.column_stack(cols)
        for ct,name in [("robust","rob"),("bias_reduced","bc")]:
            f=sm.GEE(y,X,groups=g,cov_struct=sm.cov_struct.Exchangeable()).fit(cov_type=ct)
            b,se=f.params[1],f.bse[1]
            res[name+"_z"]+= abs(b/se)<1.96
            res[name+"_tK2"]+= abs(b/se)<stats.t.ppf(.975,K-2)
            if name=="bc": res["bc_tKdf"]+= abs(b/se)<stats.t.ppf(.975,K-(3 if cl_cov else 2))
    return {k:round(v/reps,3) for k,v in res.items()}
t0=time.time()
for K in [8,12,20]:
    print("K",K,"no cluster covariate:",run(K))
print("K 12 with a cluster-level covariate (df K-3 vs K-2):",run(12,cl_cov=True))
print(time.time()-t0)
