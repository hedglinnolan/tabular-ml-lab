from emit import emit
emit({
 "id":"K-096","truth":"overstated",
 "failing_part":"\"It is refused under prediction because the model is applied to everyone\" (stated as a fact about the deployment), and, more loosely, that restriction on the exposure changes the estimand to 'the effect among consumers'",
 "narrowest_regime":"Under inference, restricting to consumers narrows the target to positive intakes and must be reported; under prediction the restriction is wrong only when the model will also score non-consumers. If the intended use is among consumers (the deployment population has exposure > 0), a consumers-only training set matches the use case and refusing it is not warranted.",
 "reason":"Selecting on the exposure value is selection on a predictor, so it does not by itself bias the dose-response over x > 0 if the model is right; what is lost is the zero point and the consumer vs non-consumer contrast, so 'estimand change' is correct as a statement about the target population and extrapolation, and recording it matches STROBE-nut nut-14 (verified in PMC4896435: 'Specify if food consumption of total population or consumers only were used'), which is a reporting item, not a refusal rule. The prediction refusal is justified only by an assumption that the model will be applied to non-consumers, which the app cannot know without asking the deployment population.",
 "basis_used":"mixed",
 "citations":[{"cite":"Lachat C et al. (2016) STROBE-nut, PLoS Med 13:e1002036 (PMC4896435): nut-14 'Specify if food consumption of total population or consumers only were used to obtain results'; nut-11 on handling nonconsumers","verified":True}],
 "bite":"yes",
 "bite_note":"A researcher building a consumers-only predictor for use among consumers would be blocked by the refusal, and an inference user is told to record the change in target population rather than silently dropping zeros.",
 "confidence":0.55})
