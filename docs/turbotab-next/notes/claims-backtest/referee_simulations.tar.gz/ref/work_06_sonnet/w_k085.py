from emit import emit
emit({
 "id":"K-085","truth":"overstated",
 "failing_part":"\"In a randomized trial the primary analysis is intention to treat\" as a universal, and \"which randomization protects\" without the requirement of complete outcome data",
 "narrowest_regime":"Superiority trials (and the treatment-policy estimand) with outcomes observed on all randomized participants or missing-data assumptions stated; for non-inferiority/equivalence trials ITT alone is not conservative and per-protocol or both are expected, and under ICH E9(R1) the primary estimand may be a different strategy if the question is about effect under adherence.",
 "reason":"The definition itself is right: White et al. (read in PMC) state that ITT 'requires all participants ... to be included in the analysis in the groups to which they were randomised, regardless of any departures from randomised treatment', and it estimates the effect of assignment. But the paper's own point is that with incomplete outcomes ITT analysis rests on untestable assumptions, so randomization protects the comparison only for the part of the outcome data that is observed or missing at random; and 'the primary analysis is ITT' is a default for superiority trials, not a rule for every randomized trial. CONSORT item 16 only asks that the report say whether the analysis was by original assigned groups, so it does not by itself establish ITT as primary.",
 "basis_used":"literature",
 "citations":[{"cite":"White IR, Horton NJ, Carpenter J, Pocock SJ (2011) Strategy for intention to treat analysis in randomised trials with missing outcome data. BMJ 342:d40 (PMC3230114 read)","verified":True},
              {"cite":"Moher D et al. (2010) CONSORT 2010 statement, item 16 (numbers analysed, 'whether the analysis was by original assigned groups'); article not opened, wording from memory","verified":False},
              {"cite":"ICH E9 and E9(R1) (non-inferiority and estimand framework) from memory","verified":False}],
 "bite":"yes",
 "bite_note":"Recommending 'itt' as the trial analysis set decides whether non-adherers are analysed as assigned; in a non-inferiority trial or one with substantial post-randomization dropout the unqualified recommendation could understate the need for a per-protocol or missing-data sensitivity analysis.",
 "confidence":0.5})
