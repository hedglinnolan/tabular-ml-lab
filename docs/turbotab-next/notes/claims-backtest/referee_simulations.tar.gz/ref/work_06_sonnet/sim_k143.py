import numpy as np, statsmodels.api as sm
from scipy import stats
rng=np.random.default_rng(1)
def run(n=200,cens=0.3,beta=0.5,reps=1500, scale="orig"):
    cover=0; bias=[]; cover_mean=0; bm=[]
    for _ in range(reps):
        xl=rng.normal(0,1,n); x=np.exp(xl)
        lod=np.exp(stats.norm.ppf(cens))
        det=x>=lod
        xo=np.where(det,x,np.nan)
        sub=np.nanmin(xo)/2
        xs=np.where(det,x,sub)
        xa=np.log(xs) if scale=="log" else xs
        xt=np.log(x) if scale=="log" else x
        # truth slope on analysis scale
        y=beta*xt+rng.normal(0,1,n)
        X=sm.add_constant(xa); f=sm.OLS(y,X).fit()
        lo,hi=f.conf_int()[1]
        cover+= (lo<=beta<=hi); bias.append(f.params[1]-beta)
        # mean of x on analysis scale
        m=xa.mean(); se=xa.std(ddof=1)/np.sqrt(n); t=stats.t.ppf(.975,n-1)
        mt=xt.mean()  # (near) truth: population mean
        truth = np.exp(0.5) if scale=="orig" else 0.0
        cover_mean += (m-t*se<=truth<=m+t*se); bm.append(m-truth)
    return dict(n=n,cens=cens,scale=scale,slope_cov=cover/reps,slope_bias=np.mean(bias),mean_cov=cover_mean/reps,mean_bias=np.mean(bm))
for scale in ["orig","log"]:
    for cens in [0.1,0.3,0.5]:
        print(run(cens=cens,scale=scale))
print(run(n=1000,cens=0.3,scale="log"))
print(run(n=1000,cens=0.3,scale="orig"))
