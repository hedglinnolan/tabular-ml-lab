from emit import emit
emit({
 "id":"K-039","truth":"not_established",
 "failing_part":"\"1.0 below 2,000 (under least squares' and the screened elastic net's 1.5)\" and, more generally, the numeric ladder 2.0/1.0/3.0/2.0 whose stated basis is that it keeps \"the two families the reference journeys pick today ... first\"",
 "narrowest_regime":"The qualitative parts hold: ridge is a poor primary choice for inference (biased, no standard intervals), p >= n favours a shrinkage method over least squares, and tuning a penalty by inner CV from fewer than ~50 rows is noisy. The specific scores and the n=2,000 switch have no methods derivation.",
 "reason":"The only basis offered for the below-2,000 value is outcome-fitting to existing journeys, not a methods argument. The direction also looks backwards: ridge's gain over least squares comes from shrinking variance, which is largest when n is small relative to p, and shrinks as n grows. In my simulation (dense signal, correlated predictors, true R2 about 1/3, RidgeCV by efficient LOO) ridge test MSE was 0.54x OLS at n=100,p=50, 0.89x at n=500,p=100, 0.58x at n=500,p=250 and about equal (0.99x) when p/n is small, never worse; so ranking ridge below least squares for n<2,000 is unsupported wherever p/n is not tiny. Elastic net vs ridge at p >= n depends on sparsity of the truth and was not tested.",
 "basis_used":"mixed",
 "citations":[],
 "bite":"yes",
 "bite_note":"The shelf score decides which family is recommended first at moderate n with a moderate predictor-to-row ratio, where ridge can beat least squares by a large margin in held-out error; at small p/n the families tie and the ordering is immaterial.",
 "confidence":0.65})
