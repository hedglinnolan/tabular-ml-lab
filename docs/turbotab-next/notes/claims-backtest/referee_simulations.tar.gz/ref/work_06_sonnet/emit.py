import json, sys
OUT="/private/tmp/claude-501/-Users-nhedglin-tabular-ml-lab/a12607bd-3f0c-4a23-8d52-bda4a2c1292e/scratchpad/ref/out/merits_06_sonnet.jsonl"
def emit(obj):
    with open(OUT,"a") as f:
        f.write(json.dumps(obj, ensure_ascii=False)+"\n")
