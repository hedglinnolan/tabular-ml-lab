import numpy as np
rng=np.random.default_rng(4)
n=300000
E=rng.normal(0,1,n); b_true=0.8
N=b_true*E+np.sqrt(1-b_true**2)*rng.normal(0,1,n)
bb,aa=np.polyfit(E,N,1); r=N-(aa+bb*E)
knots=np.linspace(-2.5,2.5,26)
def hinge(x): return np.column_stack([x]+[np.maximum(x-k,0) for k in knots])
def curve(nut,E,y,grid,E0=0.0):
    D=np.column_stack([np.ones(len(y)),hinge(nut),E]); coef=np.linalg.lstsq(D,y,rcond=None)[0]
    G=np.column_stack([np.ones(len(grid)),hinge(grid),np.full(len(grid),E0)]); return G@coef
grid_r=np.linspace(-1.5,1.5,7)
for name,h in [("threshold at 0 (step-ish)",lambda x: 1.5*np.tanh(6*x)),("hinge at 1",lambda x: np.maximum(x-1,0)*1.0)]:
    y=h(N)+0.3*E+rng.normal(0,0.5,n)
    cS=curve(N,E,y,grid_r+aa); cR=curve(r,E,y,grid_r)
    t=h(grid_r+aa)
    print(name,"- truth additive in N and E (standard model correct)")
    print("  grid        ",np.round(grid_r+aa,2))
    print("  true h      ",np.round(t-t[3],3))
    print("  standard    ",np.round(cS-cS[3],3))
    print("  residual    ",np.round(cR-cR[3],3))
