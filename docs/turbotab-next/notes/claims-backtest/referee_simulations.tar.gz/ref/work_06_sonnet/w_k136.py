from emit import emit
emit({
 "id":"K-136","truth":"true",
 "failing_part":"",
 "narrowest_regime":"Two-arm (or multi-arm) cluster-randomized trial with few clusters; the t reference is only adequate when paired with a bias-corrected sandwich variance (Kauermann-Carroll or Fay-Graubard); K-2 is the stated base case, and subtracting extra cluster-level covariates is a sensible extension rather than something the cited paper tested.",
 "reason":"I read Li & Redden (PMC copy): they state that with two arms 'the degrees of freedom can be approximated as K - 2' under an assumption of no covariates, and that the GEE Wald z test should be avoided with few clusters even with bias-corrected sandwiches. Subtracting cluster-level terms (intercept, arm, cluster-constant covariates) follows the cluster-level-analysis / containment logic that only K cluster-level quantities inform those terms; the paper does not discuss covariates, so that part is derivation, not citation. In my simulation (statsmodels GEE, K=8/12/20, icc 0.05, null effect) t on K-2 beat z but with the uncorrected sandwich still undercovered (0.91 at K=8, 0.94 at K=12), whereas with a bias-reduced sandwich it was nominal to slightly conservative (0.97); the claim states only the df rule, which is correct for it.",
 "basis_used":"mixed",
 "citations":[{"cite":"Li P, Redden DT (2015) Small sample performance of bias-corrected sandwich estimators for cluster-randomized trials with binary outcomes. Stat Med 34:281-296, doi:10.1002/sim.6344 (PMC4268228 read: K-2 df for two arms, no covariates; recommends KC/FG-corrected variance with t)","verified":True}],
 "bite":"yes",
 "bite_note":"With a handful of clusters the t critical value (about 2.45 at K=8 versus 1.96 for z) widens the interval by roughly a quarter; at 30+ clusters it hardly matters.",
 "confidence":0.6})
