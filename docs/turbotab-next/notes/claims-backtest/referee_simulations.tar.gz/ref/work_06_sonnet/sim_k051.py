import numpy as np
rng=np.random.default_rng(2)
def poly(x,d=4): return np.column_stack([x**k for k in range(1,d+1)])
def fitcurve(Xnut,E,y,grid_nut,Eterm_mean_row):
    # additive poly(nut)+E ; return fitted nutrient curve at E=Ebar on grid
    D=np.column_stack([np.ones(len(y)),poly(Xnut),E]); b=np.linalg.lstsq(D,y,rcond=None)[0]
    G=np.column_stack([np.ones(len(grid_nut)),poly(grid_nut),np.full(len(grid_nut),Eterm_mean_row)]); return G@b, b
n=200000
E=rng.normal(0,1,n); N=0.7*E+np.sqrt(1-0.49)*rng.normal(0,1,n)
a,bcoef=np.polyfit(E,N,1)[1],np.polyfit(E,N,1)[0]
r=N-(a+bcoef*E)
print("slope of N on E (b):",round(bcoef,3))
h=lambda x: 0.4*x**2-0.0*x     # nonlinear true nutrient effect (truth S)
k=lambda e: 0.3*e
y=h(N)+k(E)+rng.normal(0,0.5,n)
# grid in adjusted-intake scale: N_adj = r + a + b*Ebar(=0)
grid_r=np.linspace(-1.5,1.5,7)
# Standard model: spline(N)+E, curve at E=0 over N grid (N = r + a + b*0)
curS,_=fitcurve(N,E,y,grid_r+a,0.0)
curR,_=fitcurve(r,E,y,grid_r,0.0)
true=h(grid_r+a)
print("TRUTH S (additive in N,E): curve at E=mean")
print(" grid N_adj      ",np.round(grid_r+a,2))
print(" true h          ",np.round(true-true[3],3))
print(" standard spline ",np.round(curS-curS[3],3))
print(" residual spline ",np.round(curR-curR[3],3))
# Linear case equivalence of the nutrient coefficient
y2=0.5*N+0.3*E+rng.normal(0,0.5,n)
D1=np.column_stack([np.ones(n),N,E]); D2=np.column_stack([np.ones(n),r,E])
print("linear: coef on N in standard =",np.linalg.lstsq(D1,y2,rcond=None)[0][1].round(4)," coef on r in residual =",np.linalg.lstsq(D2,y2,rcond=None)[0][1].round(4))
# TRUTH R: Y=f(r)+gE ; substitution contrasts at different E in standard model differ?
f=lambda x: 0.4*x**2
y3=f(r)+0.3*E+rng.normal(0,0.5,n)
curS3,_=fitcurve(N,E,y3,grid_r+a,0.0); curR3,_=fitcurve(r,E,y3,grid_r,0.0)
print("TRUTH R: f(r)+gE")
print(" true f          ",np.round(f(grid_r)-f(grid_r)[3],3))
print(" residual spline ",np.round(curR3-curR3[3],3))
print(" standard spline ",np.round(curS3-curS3[3],3))
