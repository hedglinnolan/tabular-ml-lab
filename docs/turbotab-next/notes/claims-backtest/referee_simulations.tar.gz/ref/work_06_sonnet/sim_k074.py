import numpy as np, time
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold, GroupKFold, cross_val_predict
from sklearn.metrics import r2_score
rng=np.random.default_rng(11)
def make(S,m,icc_sd=1.0):
    sid=np.repeat(np.arange(S),m)
    Z=rng.normal(0,1,(S,4)); u=rng.normal(0,icc_sd,S)      # subject-level covariates and unobserved subject effect
    Xw=rng.normal(0,1,(S*m,2))                              # within-subject covariates
    X=np.column_stack([Z[sid],Xw])
    y=0.5*Z[sid,0]+0.3*Xw[:,0]+u[sid]+rng.normal(0,0.7,S*m)
    return X,y,sid
t0=time.time(); res=[]
for rep in range(8):
    X,y,sid=make(100,10)
    Xn,yn,_=make(100,10)  # brand-new subjects (the deployment case)
    rf=lambda: RandomForestRegressor(n_estimators=60,min_samples_leaf=1,max_features=0.7,n_jobs=1,random_state=0)
    p_ung=cross_val_predict(rf(),X,y,cv=KFold(5,shuffle=True,random_state=rep))
    p_grp=cross_val_predict(rf(),X,y,cv=GroupKFold(5),groups=sid)
    m=rf().fit(X,y); p_new=m.predict(Xn)
    res.append((r2_score(y,p_ung),r2_score(y,p_grp),r2_score(yn,p_new)))
res=np.array(res)
print("R2  ungrouped-KFold  grouped-KFold  new-subjects-truth")
print(res.mean(0).round(3), "sd", res.std(0).round(3)); print(time.time()-t0)
