from emit import emit
emit({
 "id":"K-129","truth":"false",
 "failing_part":"\"quintiles ... estimate its dose-response as efficiently as a restricted cubic spline and without its modeling assumptions, so they rank above the spline as the primary form\"",
 "narrowest_regime":"Quintiles are defensible only as a descriptive or secondary presentation (and for a trend test across categories), or when the exposure is too coarsely measured for a smooth curve; they are not more efficient or assumption-free as the primary form.",
 "reason":"Categorizing a continuous exposure discards within-category information (loss of power and residual confounding, the point of Royston-Altman-Sauerbrei 2006, whose abstract I verified is about dichotomization but whose argument extends to coarse categories), and a quintile model is itself an assumption: a step function with constant risk within each fifth. In my simulation (normal exposure, noise sd 2, truth plateau, quadratic, linear or threshold), the quintile step function had 2.1x to 4.8x the integrated MSE of a 4-knot restricted cubic spline at n=500 and 2000, and lower power for the overall association in the harder cases (0.67 vs 0.86; 0.88 vs 0.99 at n=500). The cited paper argues the opposite of the claim's direction.",
 "basis_used":"mixed",
 "citations":[{"cite":"Royston P, Altman DG, Sauerbrei W (2006) Dichotomizing continuous predictors in multiple regression: a bad idea. Stat Med 25:127-141 (abstract verified via Europe PMC: considerable loss of power and residual confounding)","verified":True}],
 "bite":"yes",
 "bite_note":"Ranking quintiles above the spline as the primary functional form changes the main model a nutrition researcher reports, trading a smooth, more precise curve for a coarse step curve with wider uncertainty and weaker detection of non-linearity.",
 "confidence":0.92})
