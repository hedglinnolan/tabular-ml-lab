from emit import emit
emit({
 "id":"K-092","truth":"overstated",
 "failing_part":"\"implies the covariates were measured at baseline, before the outcome\"",
 "narrowest_regime":"As a default guess for one-row-per-person data from a cohort or trial where covariates are collected at enrolment and the outcome later; it is a probabilistic reading of the outcome's name that the user must confirm, not an implication.",
 "reason":"An outcome's name says when the outcome was measured, not when the covariates were. Counterexamples are common: a time-to-event table with covariates taken at diagnosis or at the end of follow-up, a '12m' or 'final' outcome with covariates (adherence, current intake, concurrent labs) measured at 12 months or the end, a 'change' score with mean on-study exposure, and time-varying covariates in event-time data. The author's own basis says the name only leads a guess the user confirms and cites no methods source, so 'implies' overstates it. The distinction the guess feeds is sound, though: a baseline measure of the outcome is a legitimate pre-outcome covariate (ANCOVA-type adjustment) whereas a same-time measure is a proxy of the outcome, and the with-and-without pair is a reasonable hedge. The remark that occasion labels (v1, t0, w2) do not determine timing is correct.",
 "basis_used":"derivation",
 "citations":[],
 "bite":"yes",
 "bite_note":"Switches whether a second measure of the outcome is left out or run with-and-without, which can change the adjusted effect noticeably (baseline adjustment vs not); mitigated because the user confirms the guess.",
 "confidence":0.6})
emit({
 "id":"K-028","truth":"true",
 "failing_part":"",
 "narrowest_regime":"Plausibility screens of the usual form (fixed absolute energy bounds or ratio-to-requirement cutoffs) applied to a population where most people are within the plausible range; populations that are truly extreme (very-low-energy-diet trials, inpatient or anorexia cohorts) can exceed half, which is why the refusal asks for a unit statement rather than forbidding removal outright.",
 "reason":"Published plausibility screens (e.g. Willett-type bounds of roughly 500-3,500 kcal/day for women and 800-4,200 for men) are designed to flag a few percent of respondents; if one flags a majority, the bound itself no longer applies to the data. The three listed mechanisms all shift the whole column and so flag most rows at once: kJ read as kcal multiplies values by about 4.18, a multi-day total multiplies by the number of days, and a child's or athlete's intake sits systematically outside adult bounds, whereas it is implausible that most real respondents are mis-reporters. The 0.5 cut-off itself is a convention (a smaller fraction could also signal a unit error), but the direction and the 'ask the unit first' action are sound and cheap to override.",
 "basis_used":"derivation",
 "citations":[],
 "bite":"yes",
 "bite_note":"Prevents silently discarding more than half of a dataset and prompts the unit question, which changes both sample size and every energy-related quantity (energy adjustment, ratios) afterwards.",
 "confidence":0.65})
