import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(1); n=500
E=rng.normal(size=n); M=rng.integers(0,2,n)
y=1+0.5*E+0.3*M+0.4*E*M+rng.normal(size=n)
for lab,m in [("M",M),("1-M",1-M)]:
    X=sm.add_constant(np.column_stack([E,m,E*m])); f=sm.OLS(y,X).fit()
    print(lab, f.params.round(3), f.conf_int()[1].round(3))
# +-1 coding
for lab,m in [("pm",2*M-1),("-pm",1-2*M)]:
    X=sm.add_constant(np.column_stack([E,m,E*m])); f=sm.OLS(y,X).fit()
    print(lab, f.params.round(3), f.conf_int()[1].round(3))
