import numpy as np, time
from scipy import stats
t0=time.process_time()
rng=np.random.default_rng(7)
n,K,R=200,10,10; reps=400
def ols_mse(Xtr,ytr,Xte,yte):
    A=np.c_[np.ones(len(Xtr)),Xtr]; b=np.linalg.lstsq(A,ytr,rcond=None)[0]
    return np.mean((yte-np.c_[np.ones(len(Xte)),Xte]@b)**2)
rej_corr=rej_naive=0; meansA=[]; naiveSE=[]; corrSE=[]
for r in range(reps):
    X=rng.normal(size=(n,10)); y=X[:,:5].sum(1)*0.4+X[:,5:].sum(1)*0.4+rng.normal(size=n)*2
    d=[]; a=[]
    for rr in range(R):
        idx=rng.permutation(n); folds=np.array_split(idx,K)
        for f in folds:
            tr=np.setdiff1d(idx,f)
            mA=ols_mse(X[tr][:,:5],y[tr],X[f][:,:5],y[f]); mB=ols_mse(X[tr][:,5:],y[tr],X[f][:,5:],y[f])
            d.append(mA-mB); a.append(mA)
    d=np.array(d); a=np.array(a); J=K*R
    s2=d.var(ddof=1)
    tc=d.mean()/np.sqrt((1/J+1/(K-1))*s2); tn=d.mean()/np.sqrt(s2/J)
    pc=2*stats.t.sf(abs(tc),J-1); pn=2*stats.t.sf(abs(tn),J-1)
    rej_corr+=pc<0.05; rej_naive+=pn<0.05
    meansA.append(a.mean()); naiveSE.append(a.std(ddof=1)/np.sqrt(J)); corrSE.append(np.sqrt((1/J+1/(K-1))*a.var(ddof=1)))
print("TypeI corrected",rej_corr/reps,"naive",rej_naive/reps)
print("true SD of CV MSE across datasets",np.std(meansA),"mean naive SE",np.mean(naiveSE),"mean corrected SE",np.mean(corrSE))
print("cpu",time.process_time()-t0)
