import re, zlib, sys
data=open(sys.argv[1],'rb').read()
out=[]
for m in re.finditer(rb'stream\r?\n(.*?)\r?\nendstream', data, re.S):
    s=m.group(1)
    try: d=zlib.decompress(s)
    except Exception: continue
    if b'BT' not in d: continue
    # extract text from TJ arrays and Tj
    txt=[]
    for t in re.finditer(rb'\[(.*?)\]\s*TJ|\((.*?)(?<!\\)\)\s*Tj|(T\*|Td|TD|ET)', d, re.S):
        if t.group(1) is not None:
            parts=re.findall(rb'\((.*?)(?<!\\)\)|(-?\d+\.?\d*)', t.group(1), re.S)
            line=b''
            for p,num in parts:
                if p: line+=p
                elif num and float(num)<-200: line+=b' '
            txt.append(line)
        elif t.group(2) is not None:
            txt.append(t.group(2))
        else:
            txt.append(b'\n')
    out.append(b''.join(txt))
s=b'\n=====\n'.join(out).decode('latin-1')
open(sys.argv[2],'w').write(s)
print(len(s))
