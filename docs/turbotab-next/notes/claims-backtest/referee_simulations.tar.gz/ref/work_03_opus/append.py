import json, sys
OUT = "/private/tmp/claude-501/-Users-nhedglin-tabular-ml-lab/a12607bd-3f0c-4a23-8d52-bda4a2c1292e/scratchpad/ref/out/merits_03_opus.jsonl"
obj = json.loads(sys.stdin.read())
keys = ["id","truth","failing_part","narrowest_regime","reason","basis_used","citations","bite","bite_note","confidence"]
assert set(obj) == set(keys), set(obj) ^ set(keys)
assert obj["truth"] in {"true","overstated","false","not_established"}
assert obj["bite"] in {"yes","no"}
with open(OUT, "a") as f:
    f.write(json.dumps({k: obj[k] for k in keys}) + "\n")
print("appended", obj["id"])
