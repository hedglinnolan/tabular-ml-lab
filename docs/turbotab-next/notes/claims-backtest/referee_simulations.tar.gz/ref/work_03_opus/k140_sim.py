import numpy as np, sys
from scipy import stats
rng=np.random.default_rng(int(sys.argv[1]) if len(sys.argv)>1 else 7)

def symsqrt_inv(M):
    w,U=np.linalg.eigh(M); w=np.clip(w,1e-12,None); return (U/np.sqrt(w))@U.T

def gee(X,y,g,family):
    groups=np.unique(g); idx=[np.flatnonzero(g==k) for k in groups]
    p=X.shape[1]; beta=np.zeros(p); rho=0.0
    if family=="gaussian": beta=np.linalg.lstsq(X,y,rcond=None)[0]
    for it in range(25):
        eta=X@beta
        if family=="gaussian": mu=eta; A=np.ones_like(mu); dmu=np.ones_like(mu)
        else: mu=1/(1+np.exp(-eta)); A=mu*(1-mu); dmu=A
        r=(y-mu)/np.sqrt(A); N=len(y)
        phi=np.sum(r**2)/(N-p)
        num=0; den=0
        for ii in idx:
            s=r[ii].sum(); num+=(s*s-np.sum(r[ii]**2))/2; m=len(ii); den+=m*(m-1)/2
        rho=num/(phi*(den-p)); rho=min(max(rho,-0.05),0.95)
        Bm=np.zeros((p,p)); sc=np.zeros(p); cache=[]
        for ii in idx:
            m=len(ii); R=(1-rho)*np.eye(m)+rho*np.ones((m,m))
            sA=np.sqrt(A[ii]); V=phi*(sA[:,None]*R*sA[None,:])
            L=np.linalg.cholesky(V); D=dmu[ii][:,None]*X[ii]
            Xs=np.linalg.solve(L,D); es=np.linalg.solve(L,y[ii]-mu[ii])
            Bm+=Xs.T@Xs; sc+=Xs.T@es; cache.append((ii,Xs,es))
        step=np.linalg.solve(Bm,sc); beta=beta+step
        if np.max(np.abs(step))<1e-8: break
    return beta,Bm,cache

def cr2_bm(beta,Bm,cache,j):
    p=len(beta); Binv=np.linalg.inv(Bm); c=np.zeros(p); c[j]=1
    Xs_all=np.vstack([x for _,x,_ in cache]); N=Xs_all.shape[0]
    H=Xs_all@Binv@Xs_all.T; IH=np.eye(N)-H
    v=0; cols=[]; start=0
    for ii,Xs,es in cache:
        m=len(ii); sl=slice(start,start+m)
        Ag=symsqrt_inv(np.eye(m)-H[sl,sl])
        q=Ag@Xs@Binv@c
        v+=(q@es)**2
        a=np.zeros(N); a[sl]=q; cols.append(IH@a)
        start+=m
    Gm=np.column_stack(cols); M=Gm.T@Gm
    df=np.trace(M)**2/np.sum(M*M)
    # naive CR0 too
    meat=sum(np.outer(Xs.T@es,Xs.T@es) for _,Xs,es in cache)
    v0=(Binv@meat@Binv)[j,j]
    return v,df,v0

def sim(family,icc,design,G=12,reps=2000,sizes="equal"):
    rej=0; rej0=0; dfs=[]
    for r in range(reps):
        m=np.full(G,10) if sizes=="equal" else rng.integers(4,17,G)
        g=np.repeat(np.arange(G),m); N=len(g)
        if design=="cluster_bal": a=np.repeat(rng.permutation(np.r_[np.ones(G//2),np.zeros(G-G//2)]),m)
        elif design=="cluster_unbal": a=np.repeat(rng.permutation(np.r_[np.ones(3),np.zeros(G-3)]),m)
        else: a=np.repeat(rng.normal(0,1,G),m)*0.7+rng.normal(0,0.7,N)
        x=rng.normal(0,1,N)+np.repeat(rng.normal(0,0.5,G),m)
        X=np.column_stack([np.ones(N),a,x])
        if family=="gaussian":
            u=np.repeat(rng.normal(0,np.sqrt(icc),G),m); y=0.5*x+u+rng.normal(0,np.sqrt(1-icc),N)
        else:
            s2=icc*(np.pi**2/3)/(1-icc); u=np.repeat(rng.normal(0,np.sqrt(s2),G),m)
            eta=-0.85+0.5*x+u; y=(rng.random(N)<1/(1+np.exp(-eta))).astype(float)
        try:
            beta,Bm,cache=gee(X,y,g,family); v,df,v0=cr2_bm(beta,Bm,cache,1)
        except np.linalg.LinAlgError:
            continue
        t=beta[1]/np.sqrt(v); rej+= abs(t)>stats.t.ppf(0.975,df); dfs.append(df)
        rej0+= abs(beta[1]/np.sqrt(v0))>stats.norm.ppf(0.975)
    n=len(dfs)
    return rej/n, rej0/n, np.median(dfs), n

fam=sys.argv[2]; icc=float(sys.argv[3]); design=sys.argv[4]; G=int(sys.argv[5]) if len(sys.argv)>5 else 12
sizes=sys.argv[6] if len(sys.argv)>6 else "equal"
r,r0,md,n=sim(fam,icc,design,G=G,sizes=sizes)
print(f"{fam} icc={icc} {design} G={G} {sizes}: CR2-BM type I={r:.3f} (mc se {np.sqrt(.05*.95/n):.3f}), CR0-normal={r0:.3f}, median BM df={md:.1f}, reps={n}")
