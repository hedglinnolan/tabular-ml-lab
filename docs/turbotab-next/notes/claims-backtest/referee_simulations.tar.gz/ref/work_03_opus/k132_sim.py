import numpy as np
rng = np.random.default_rng(1)
def clr_pairs(D):
    # 1:1 conditional logistic = logistic of y=1 on within-pair differences, no intercept
    b=np.zeros(D.shape[1])
    for _ in range(30):
        p=1/(1+np.exp(-D@b)); g=D.T@(1-p); H=(D*(p*(1-p))[:,None]).T@D
        b=b+np.linalg.solve(H,g)
    return b
def run(caliper, reps=10, ncase=5000):
    out=[]
    for r in range(reps):
        N=200000
        age=rng.uniform(40,80,N)
        E=rng.random(N) < 1/(1+np.exp(-(-0.5+0.08*(age-60))))
        Y=rng.random(N) < 1/(1+np.exp(-(-4.0+0.10*(age-60))))
        cases=rng.choice(np.flatnonzero(Y),ncase,replace=False); ctrls=np.flatnonzero(~Y)
        order=np.argsort(age[ctrls]); sa=age[ctrls][order]
        lo=np.searchsorted(sa,age[cases]-caliper); hi=np.searchsorted(sa,age[cases]+caliper)
        pick=ctrls[order[(lo+rng.random(ncase)*(hi-lo)).astype(int)]]
        D=np.column_stack([E[cases].astype(float)-E[pick], age[cases]-age[pick]])
        out.append((clr_pairs(D[:,[0]])[0], clr_pairs(D)[0], np.mean(age[cases]-age[pick])))
    o=np.array(out); return o.mean(0), o.std(0)/np.sqrt(len(o))
for cal in [1,2.5,5,10]:
    m,se=run(cal)
    print(f"caliper +-{cal}: logOR CLR(E)={m[0]:.3f}(se {se[0]:.3f}) CLR(E+age)={m[1]:.3f}(se {se[1]:.3f}) mean age diff case-ctrl={m[2]:.2f}; true 0")
