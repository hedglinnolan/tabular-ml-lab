import numpy as np
rng=np.random.default_rng(3)
def macro_f1(y,p,C):
    f=[]
    for c in range(C):
        tp=np.sum((y==c)&(p==c)); fp=np.sum((y!=c)&(p==c)); fn=np.sum((y==c)&(p!=c))
        f.append(0 if tp==0 else 2*tp/(2*tp+fp+fn))
    return np.mean(f)
def scen(prev, conf, n, reps=4000):
    prev=np.array(prev); conf=np.array(conf); C=len(prev)
    k=int(round(prev.min()*n))
    vals=[]
    for _ in range(reps):
        y=rng.choice(C,n,p=prev)
        u=rng.random(n); cum=np.cumsum(conf[y],axis=1); p=(u[:,None]>cum).sum(1)
        vals.append(macro_f1(y,p,C))
    vals=np.array(vals)
    return k, vals.mean(), 1.96*vals.std(), 1.96*np.sqrt(0.25/k)
S=[("binary prev .1, n=500",[.9,.1],[[.9,.1],[.3,.7]],500),
   ("binary prev .5, n=200",[.5,.5],[[.8,.2],[.2,.8]],200),
   ("binary prev .05, n=400, weak",[.95,.05],[[.85,.15],[.5,.5]],400),
   ("3-class .6/.3/.1, n=300",[.6,.3,.1],[[.8,.15,.05],[.2,.7,.1],[.2,.2,.6]],300),
   ("5-class rare .05, n=1000",[.35,.25,.2,.15,.05],np.full((5,5),.1)+np.eye(5)*.5,1000),
   ("3-class .45/.45/.1 n=100",[.45,.45,.1],[[.7,.2,.1],[.2,.7,.1],[.3,.3,.4]],100)]
for name,prev,conf,n in S:
    k,m,hw,wc=scen(prev,conf,n)
    print(f"{name}: k={k} macroF1={m:.3f} true 95% half-width={hw:.3f} claimed worst-case={wc:.3f} ratio claimed/true={wc/hw:.2f}")
# Hanley-McNeil SE vs AUC
def hm(A,n1,n0):
    Q1=A/(2-A); Q2=2*A*A/(1+A)
    return np.sqrt((A*(1-A)+(n1-1)*(Q1-A*A)+(n0-1)*(Q2-A*A))/(n1*n0))
for A in [0.55,0.65,0.75,0.85,0.95]:
    print(f"HM SE A={A}: n1=50,n0=450 -> {hm(A,50,450):.4f}; n1=20,n0=80 -> {hm(A,20,80):.4f}")
