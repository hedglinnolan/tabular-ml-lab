import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(5); n=2000
x=rng.normal(size=n); z=rng.normal(size=n)
y=np.exp(1+0.2*x+0.3*z+rng.normal(scale=0.6,size=n))
c=np.quantile(y,0.8)
X=sm.add_constant(np.column_stack([x,z]))
b=sm.OLS(y,X).fit().params[1]; lo=sm.OLS(np.minimum(y,c),X).fit().params[1]; hi=sm.OLS(np.maximum(y-c,0),X).fit().params[1]
print(b,lo,hi,lo+hi, hi/b)
# survival-integral interpretation: d/dx E[(Y-c)+] = int_c^inf dS(t|x)/dx dt
