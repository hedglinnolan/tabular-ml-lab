import numpy as np
rng=np.random.default_rng(0)
y=rng.normal(size=500); p=0.6*y+rng.normal(scale=0.8,size=500)
for shift in [0,0.5,1.0]:
    q=p+shift
    r2=np.corrcoef(q,y)[0,1]**2; R2=1-((y-q)**2).sum()/((y-y.mean())**2).sum()
    print(shift, round(r2,3), round(R2,3))
