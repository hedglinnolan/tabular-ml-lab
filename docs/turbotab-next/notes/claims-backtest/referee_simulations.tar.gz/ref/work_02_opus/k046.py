import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(1)
n=200
X=rng.normal(size=(n,4)); X[:,1]+=0.7*X[:,0]
y=1+0.5*X[:,0]+0.3*X[:,1]-0.2*X[:,2]+rng.normal(size=n)
a=sm.OLS(y,sm.add_constant(X)).fit()
perm=[3,2,1,0]
b=sm.OLS(y,sm.add_constant(X[:,perm])).fit()
print(a.params[1],b.params[4],a.bse[1],b.bse[4],a.pvalues[1],b.pvalues[4])
print(a.get_robustcov_results('HC3').bse[1], b.get_robustcov_results('HC3').bse[4])
