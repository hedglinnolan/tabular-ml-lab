import numpy as np, statsmodels.api as sm, time
from scipy import stats
t0=time.process_time()
rng=np.random.default_rng(9)
def cover(G,m=20,reps=1000):
    hit_z=hit_t=0
    for _ in range(reps):
        g=np.repeat(np.arange(G),m)
        xc=rng.lognormal(size=G)[g]  # skewed cluster-level regressor
        x=xc+0.3*rng.normal(size=G*m)
        e=rng.normal(size=G)[g]+rng.normal(size=G*m)
        y=0.0*x+e
        f=sm.OLS(y,sm.add_constant(x)).fit(cov_type='cluster',cov_kwds={'groups':g})
        se=f.bse[1]; b=f.params[1]
        hit_z+=abs(b/se)<1.96; hit_t+=abs(b/se)<stats.t.ppf(.975,G-1)
    return hit_z/reps, hit_t/reps
for G in [5,11,20,50]:
    print(G, cover(G))
print("cpu",time.process_time()-t0)
