import numpy as np, statsmodels.api as sm
def smd(a,b): return abs(a.mean()-b.mean())/np.sqrt((a.var(ddof=1)+b.var(ddof=1))/2)
def run(n, share, cov_shift, misreport, rng):
    z=rng.normal(size=n)                     # adjustment covariate (e.g., BMI)
    excl=rng.random(n)<share
    z=z+cov_shift*excl                       # excluded rows differ on covariate
    x_true=0.5*z+rng.normal(size=n)          # true intake
    y=0.3*x_true+0.5*z+rng.normal(size=n)
    x=x_true.copy()
    if misreport:                            # excluded rows misreport intake: flat-slope noise
        x[excl]=0.3*x_true[excl]+rng.normal(scale=1.0,size=excl.sum())
    X=lambda m: sm.add_constant(np.column_stack([x[m],z[m]]))
    keep=~excl
    fk=sm.OLS(y[keep],X(keep)).fit(); fa=sm.OLS(y,X(np.ones(n,bool))).fit()
    hw=1.96*fk.bse[1]
    pred=share*smd(z[excl],z[keep])
    return pred, (fa.params[1]-fk.params[1])/hw
rng=np.random.default_rng(11)
for label,args in [("A: big covariate SMD, no misreport",(5000,0.2,1.0,False)),
                   ("B: no covariate SMD, misreport",(5000,0.2,0.0,True)),
                   ("C: same as B, n=500",(500,0.2,0.0,True)),
                   ("D: same as B, n=20000",(20000,0.2,0.0,True))]:
    res=np.array([run(*args,rng) for _ in range(30)])
    print(label, "predictor mean %.3f" % res[:,0].mean(), "move in half-widths: mean %.2f sd %.2f" % (res[:,1].mean(), res[:,1].std()))
