import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(3)
n=4000
sex=rng.integers(0,2,n)
E=np.where(sex==1, rng.normal(2600,500,n), rng.normal(1900,400,n))
# nutrient: sex-specific slope on energy
N=np.where(sex==1, 5+0.030*E, 2+0.045*E)+rng.normal(0,15,n)
Y=10+0.08*N+0.002*E+3*sex+rng.normal(0,5,n)
def coef(cols,y,idx=1):
    return sm.OLS(y,sm.add_constant(np.column_stack(cols))).fit()
# standard models
std=coef([N,E],Y).params[1]; std_s=coef([N,E,sex],Y).params[1]
# pooled residual
rp=N-sm.OLS(N,sm.add_constant(E)).fit().fittedvalues
pooled=coef([rp,E],Y).params[1]
# within-strata residual
rs=np.empty(n)
for s in (0,1):
    m=sex==s; rs[m]=N[m]-sm.OLS(N[m],sm.add_constant(E[m])).fit().fittedvalues
strat=coef([rs,E],Y).params[1]; strat_s=coef([rs,E,sex],Y).params[1]
strat_full=coef([rs,E,sex,sex*E],Y).params[1]; std_full=coef([N,E,sex,sex*E],Y).params[1]
print("standard N+E", std, " standard N+E+sex", std_s)
print("pooled resid + E", pooled)
print("strat resid + E", strat, " strat resid+E+sex", strat_s)
print("strat resid+E+sex+sexE", strat_full, " std N+E+sex+sexE", std_full)
# SE of std
f=coef([N,E,sex],Y); print("SE std+sex", f.bse[1])
# equal slopes case
N2=np.where(sex==1, 15+0.04*E, 2+0.04*E)+rng.normal(0,15,n)
Y2=10+0.08*N2+0.002*E+3*sex+rng.normal(0,5,n)
rs2=np.empty(n)
for s in (0,1):
    m=sex==s; rs2[m]=N2[m]-sm.OLS(N2[m],sm.add_constant(E[m])).fit().fittedvalues
print("equal slopes: std N+E", coef([N2,E],Y2).params[1], "strat+E", coef([rs2,E],Y2).params[1], "std+sex", coef([N2,E,sex],Y2).params[1], "strat+E+sex", coef([rs2,E,sex],Y2).params[1])
