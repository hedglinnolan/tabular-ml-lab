import json, sys
rec=json.load(sys.stdin)
with open('/private/tmp/claude-501/-Users-nhedglin-tabular-ml-lab/a12607bd-3f0c-4a23-8d52-bda4a2c1292e/scratchpad/ref/out/merits_02_opus.jsonl','a') as f:
    f.write(json.dumps(rec, ensure_ascii=False)+"\n")
print("appended", rec["id"])
