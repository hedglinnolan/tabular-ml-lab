import numpy as np, time, sys
from scipy.stats import qmc
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score
t0=time.process_time()
seed=int(sys.argv[1]); reps=int(sys.argv[2])
rng=np.random.default_rng(seed); p=8
def f(X): return 0.35*X.sum(1)
def gen(n):
    X=rng.normal(size=(n,p)); return X, f(X)+rng.normal(scale=2.0,size=n)
Xt,yt=gen(5000)
default=dict(max_features=0.33,min_samples_leaf=5)
out=[]
for r in range(reps):
    X,y=gen(300)
    s=qmc.Sobol(2,scramble=True,seed=seed*100+r).random(8)
    cands=[default]+[dict(max_features=float(0.1+0.9*a),min_samples_leaf=int(1+round(b*19))) for a,b in s]
    scores=[]
    for c in cands:
        sc=[]
        for tr,te in KFold(5,shuffle=True,random_state=r).split(X):
            m=RandomForestRegressor(n_estimators=60,n_jobs=1,random_state=0,**c).fit(X[tr],y[tr]); sc.append(r2_score(y[te],m.predict(X[te])))
        scores.append(np.mean(sc))
    best=cands[int(np.argmax(scores))]
    tb=r2_score(yt,RandomForestRegressor(n_estimators=60,n_jobs=1,random_state=0,**best).fit(X,y).predict(Xt))
    td=r2_score(yt,RandomForestRegressor(n_estimators=60,n_jobs=1,random_state=0,**default).fit(X,y).predict(Xt))
    out.append((tb,td))
o=np.array(out); print(seed, "tuned-default test R2 diffs:", np.round(o[:,0]-o[:,1],4).tolist()); print("cpu",time.process_time()-t0)
