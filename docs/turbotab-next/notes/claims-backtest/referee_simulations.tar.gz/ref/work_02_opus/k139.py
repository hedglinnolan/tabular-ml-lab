import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(7); n=200000
x=rng.normal(size=n); z=0.5*x+rng.normal(size=n)
eta=-1+0.7*x+0.4*z; y=rng.random(n)<1/(1+np.exp(-eta))
# x missing with prob depending on y only
pm=np.where(y,0.6,0.1); obs=rng.random(n)>pm
f=sm.Logit(y[obs].astype(float),sm.add_constant(np.column_stack([x[obs],z[obs]]))).fit(disp=0)
print("logistic, missingness depends on Y only:", f.params)
# linear: missingness depends on Y
yl=1+0.7*x+0.4*z+rng.normal(size=n)
obs2=rng.random(n)>1/(1+np.exp(-(yl-1)))
g=sm.OLS(yl[obs2],sm.add_constant(np.column_stack([x[obs2],z[obs2]]))).fit()
print("linear, missingness depends on Y:", g.params)
