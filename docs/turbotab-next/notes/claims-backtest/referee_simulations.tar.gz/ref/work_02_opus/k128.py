import numpy as np, statsmodels.api as sm
rng=np.random.default_rng(2); n=200000
t=rng.integers(0,2,n); z=rng.normal(size=n)
y=(rng.random(n)<1/(1+np.exp(-(-0.5+0.6*t+1.5*z)))).astype(float)
u=sm.Logit(y,sm.add_constant(t.astype(float))).fit(disp=0)
a=sm.Logit(y,sm.add_constant(np.column_stack([t,z]).astype(float))).fit(disp=0)
print("unadj logOR %.3f se %.4f | adj logOR %.3f se %.4f" % (u.params[1],u.bse[1],a.params[1],a.bse[1]))
print("z-stats", u.params[1]/u.bse[1], a.params[1]/a.bse[1])
