import numpy as np, time
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold
t0=time.process_time()
rng=np.random.default_rng(4); p=10
beta=np.array([0.8,0.5,0.3]+[0]*(p-3))
def gen(n):
    X=rng.normal(size=(n,p)); y=(rng.random(n)<1/(1+np.exp(-(-1+X@beta)))).astype(int); return X,y
Xt,yt=gen(20000)
def mk(kind): return RandomForestClassifier(n_estimators=100,min_samples_leaf=1,n_jobs=1,random_state=0) if kind=="rf" else LogisticRegression(max_iter=1000)
def evalrep(kind,n=300,B=30):
    X,y=gen(n)
    m=mk(kind).fit(X,y); app=roc_auc_score(y,m.predict_proba(X)[:,1]); true=roc_auc_score(yt,m.predict_proba(Xt)[:,1])
    opt=[]
    for b in range(B):
        i=rng.integers(0,n,n)
        if len(set(y[i]))<2: continue
        mb=mk(kind).fit(X[i],y[i])
        opt.append(roc_auc_score(y[i],mb.predict_proba(X[i])[:,1])-roc_auc_score(y,mb.predict_proba(X)[:,1]))
    boot=app-np.mean(opt)
    cvs=[]
    for r in range(2):
        for tr,te in StratifiedKFold(5,shuffle=True,random_state=r).split(X,y):
            mm=mk(kind).fit(X[tr],y[tr]); cvs.append(roc_auc_score(y[te],mm.predict_proba(X[te])[:,1]))
    return true,app,boot,np.mean(cvs)
for kind,reps in [("rf",5),("lr",5)]:
    R=np.array([evalrep(kind) for _ in range(reps)])
    print(kind,"true %.3f apparent %.3f boot-corrected %.3f repCV %.3f" % tuple(R.mean(0)), "| boot-true %.3f cv-true %.3f" % ((R[:,2]-R[:,0]).mean(),(R[:,3]-R[:,0]).mean()))
print("cpu",time.process_time()-t0)
