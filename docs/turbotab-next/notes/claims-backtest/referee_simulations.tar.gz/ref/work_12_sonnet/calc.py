import numpy as np
# K-048: MB bound q^2/((2tau-1)p) with q=floor((2tau-1)p)
tau=0.6
for p in [5,10,50,100,1000,5000]:
    q=int(np.floor((2*tau-1)*p))
    b=q**2/((2*tau-1)*p) if q>0 else float('nan')
    qstar=np.sqrt((2*tau-1)*p)
    print("p",p,"q",q,"bound",round(b,2),"q for bound<=1:",round(qstar,2))
# K-081 E-value
for rr in [1.5,2,3]:
    print(rr, "claimed", rr+np.sqrt(rr-1), "correct", rr+np.sqrt(rr*(rr-1)))
