import json
out="/private/tmp/claude-501/-Users-nhedglin-tabular-ml-lab/a12607bd-3f0c-4a23-8d52-bda4a2c1292e/scratchpad/ref/out/merits_12_sonnet.jsonl"
R=[]
def add(**k): R.append(k)

add(id="K-001", truth="false",
 failing_part="mtry floor(p/3) for a class outcome and floor(sqrt(p)) for a numeric outcome",
 narrowest_regime="Swap the two: randomForest uses floor(sqrt(p)) for classification and max(floor(p/3),1) for regression; ranger uses floor(sqrt(p)) for every tree type (no p/3 anywhere). 500 trees and full-size bootstrap with replacement are correct for both.",
 reason="The mtry assignment is reversed. The CRAN reference manuals give randomForest mtry = floor(sqrt(ncol(x))) for classification and max(floor(ncol(x)/3),1) for regression, and ranger documents sqrt(p) for all types. ntree/num.trees = 500 and replace = TRUE with sampsize = n are right, so only the mtry clause fails, but it is the clause a researcher would act on.",
 basis_used="literature",
 citations=[{"cite":"randomForest CRAN reference manual (ntree=500; mtry classification floor(sqrt(p)), regression max(floor(p/3),1); replace=TRUE; sampsize=nrow)","verified":True},
            {"cite":"ranger CRAN reference manual (num.trees=500; mtry = floor(sqrt(p)) for all tree types; replace=TRUE; sample.fraction=1)","verified":True},
            {"cite":"Liaw & Wiener 2002 R News 2:18-22","verified":False},
            {"cite":"Wright & Ziegler 2017 J Stat Softw 77(1)","verified":False}],
 bite="yes",
 bite_note="With a numeric outcome and p=90 the app would use mtry 9 instead of 30 (and 30 instead of 9 for a class outcome), a large change to tree decorrelation and to the fitted forest; it also misdescribes what 'R defaults' means.",
 confidence=0.97)

add(id="K-043", truth="true",
 failing_part="",
 narrowest_regime="Holds as a rationale for caution: under-reporting rises with BMI and with dietary restraint, so a screen on reported energy relative to expenditure selects on a variable that the adiposity outcome itself influences.",
 reason="DLW-validation reviews document that under-reporting is systematic and rises with BMI and weight-consciousness (Livingstone & Black 2003). A screen on reported-energy plausibility therefore drops a non-random part of the sample whose reporting is partly caused by the outcome, which is a selection mechanism for diet-adiposity analyses. The empirical literature is mixed on how much it matters (Huang 2005 found exclusion strengthened diet-BMI associations; Rhee 2015 found similar results across methods), and keeping everyone leaves differential measurement error, but the claim asserts only the non-random slice and that many analyses keep everyone, both reasonable.",
 basis_used="mixed",
 citations=[{"cite":"Livingstone & Black 2003 J Nutr 133(S3):895S-920S","verified":True},
            {"cite":"Huang, Roberts, Howarth, McCrory 2005 Obes Res (effect of screening out implausible energy intake reports on diet-BMI relationships)","verified":True},
            {"cite":"Rhee, Sampson, Cho, Hughes, Hu, Willett 2015 Am J Epidemiol (comparison of methods to account for implausible reporting)","verified":True}],
 bite="yes",
 bite_note="Decides whether the researcher drops flagged under-reporters or keeps them (with sensitivity analysis); the literature shows results can change, though Rhee 2015 found often modest differences.",
 confidence=0.6)

add(id="K-048", truth="false",
 failing_part="q = floor((2*tau - 1)*p) ... keeps the expected number of falsely selected predictors at or below 1",
 narrowest_regime="E(V) <= 1 needs q^2/((2*tau-1)p) <= 1, i.e. q <= sqrt((2*tau-1)p); at tau=0.6 that is about sqrt(0.2p) (4 for p=100, 14 for p=1000). The stated q = (2*tau-1)p gives the bound (2*tau-1)p = 0.2p.",
 reason="Substituting the claimed q into the cited bound gives q^2/((2tau-1)p) = (2tau-1)p, which at tau=0.6 is 0.2p (about 18 for p=100, 198 for p=1000), not 1. The q that delivers a bound of 1 is the square root of that. The bound is only an upper bound, but the stated guarantee of at most one false selection does not follow from these settings. (Shah & Samworth's complementary-pairs bound has the same q^2/((2tau-1)p) form.)",
 basis_used="mixed",
 citations=[{"cite":"Meinshausen & Buhlmann 2010 JRSS B 72:417-473, Theorem 1: E(V) <= q^2/((2*pi_thr-1)p)","verified":False},
            {"cite":"Shah & Samworth 2013 JRSS B 75:55-80","verified":False}],
 bite="yes",
 bite_note="The default q is about q = 0.2p per half instead of about sqrt(0.2p), so the procedure selects up to a fifth of the predictors per half-sample and the advertised 'at most 1 false selection' guarantee is replaced by a vacuous bound; the selected set and the error-control message to the researcher both change.",
 confidence=0.95)

add(id="K-005", truth="true",
 failing_part="",
 narrowest_regime="Partition model in which other-source energy is computed as total minus exposure energy.",
 reason="If other-source energy = total - exposure kcal, then holding other sources fixed while adding Dx units of exposure forces total to rise by Dx*kcal_per_unit. Leaving total fixed would instead lower other-source energy by the same amount, which is the substitution contrast (a different estimand: beta_exposure - beta_other*kcal). This matches Willett's partition model, whose exposure coefficient is the effect of adding energy without displacing other energy.",
 basis_used="derivation",
 citations=[{"cite":"Willett, Nutritional Epidemiology 3rd ed. 2013, ch. 11 (energy partition model)","verified":False}],
 bite="yes",
 bite_note="If the high setting left total energy untouched the g-computation would return the substitution contrast, a different number whenever the exposure and other-source coefficients differ.",
 confidence=0.85)

add(id="K-002", truth="overstated",
 failing_part="cannot be predicted from individually matched case-control sets, as a limit of the design",
 narrowest_regime="Holds when only the matched sample is in hand with no cohort-level information (no known sampling fractions, risk-set sizes or external incidence by matching stratum).",
 reason="The conditional likelihood does drop set intercepts, so the sample alone carries no baseline risk. But individually matched designs such as nested case-control sets do allow absolute risk estimates once cohort information is supplied (Langholz & Borgan 1997, 'Estimation of absolute risk from nested case-control data', Biometrics 53:767), so it is a limit of the data on hand, not of the design. The cited Janes & Pepe 2008 is about matching in classification-accuracy studies (unadjusted accuracy summaries, efficiency, incremental value), not a result that absolute risk is inestimable.",
 basis_used="literature",
 citations=[{"cite":"Langholz & Borgan 1997 Biometrics 53(2):767-774","verified":True},
            {"cite":"Janes & Pepe 2008 Biometrics 64(1):1-9 (abstract read: matching and classification accuracy, not absolute risk)","verified":True}],
 bite="yes",
 bite_note="Refusing is right when the researcher only has the matched sets; but a researcher with cohort totals or registry incidence would be blocked from a valid absolute-risk estimate. The refusal message should name the missing ingredient rather than call it impossible.",
 confidence=0.65)

add(id="K-081", truth="false",
 failing_part="the E-value is RR + sqrt(RR - 1), so a risk ratio of 2 has an E-value of 3",
 narrowest_regime="Correct formula: E = RR + sqrt(RR*(RR - 1)) for RR > 1, so RR = 2 gives 2 + sqrt(2) = 3.41.",
 reason="VanderWeele & Ding define the E-value as RR + sqrt(RR x (RR - 1)). The claim drops the RR factor under the root, which understates the E-value (3.00 vs 3.41 at RR = 2, 4.41 vs 5.45 at RR = 3). The worked example and the 'risk ratios of 3' statement are therefore wrong too.",
 basis_used="mixed",
 citations=[{"cite":"VanderWeele & Ding 2017 Ann Intern Med 167:268-274","verified":False}],
 bite="yes",
 bite_note="The reported E-value (and the confounder strength a researcher is told would explain away the result) would be too small at every RR, which makes results look more fragile than they are.",
 confidence=0.97)

add(id="K-111", truth="true",
 failing_part="",
 narrowest_regime="Prediction development sample size on the training rows; the inference clause is an application convention, not Riley's own use.",
 reason="Riley et al. count candidate predictor parameters (not variables): k-1 for a k-level factor, every spline or interaction column, including terms considered and then dropped. A restricted cubic spline with k knots has k-1 columns, so k-2 beyond the linear term, which matches the stated rule, and counting these when a data-driven spline or inner-CV choice is on is consistent with 'candidate'. Using the rarer class for events, smallest class for several classes (conservative relative to the multinomial method), and the training rows as the development sample are consistent. The knot-count rule (Harrell, effective size) and the inference counting are conventions I could not verify against a primary text.",
 basis_used="mixed",
 citations=[{"cite":"Riley et al. BMJ 2020;368:m441","verified":True},
            {"cite":"Riley et al. Stat Med 2019 Part II (PMC6519266): predictor parameters = coefficients, including categorical and non-linear terms","verified":True},
            {"cite":"Pate, Riley et al. 2023 Stat Methods Med Res (multinomial)","verified":True},
            {"cite":"Harrell, Regression Modeling Strategies 2015 (knots by effective sample size)","verified":False}],
 bite="yes",
 bite_note="Undercounting spline/dummy columns would lower the Riley minimum and let the shelf order put flexible families first when the sample cannot support them.",
 confidence=0.6)

add(id="K-076", truth="overstated",
 failing_part="a blank frequently means 'never', especially among older participants ... standard multiple imputation ... is an improvement",
 narrowest_regime="Rarely consumed food items, where blanks are enriched for true zeros; for commonly eaten foods most blanks are non-zero.",
 reason="Fraser et al. 2009 (Adventist Health Study-2) recontacted respondents with blanks: recovered values showed excess zeros, and data were 'usually not missing at random', but most missing values were not true zeros and frequently eaten foods were predominantly non-zero; older participants had higher missingness rates, not shown to have more 'never'. Whether MI is an improvement depends on the baseline (zero-fill is nearly unbiased for rare foods) so the sentence overgeneralises.",
 basis_used="literature",
 citations=[{"cite":"Fraser, Yan, Butler, Jaceldo-Siegl, Beeson, Chan 2009 Epidemiology 20(2):289-294","verified":True}],
 bite="yes",
 bite_note="Chooses between blank-as-zero, imputation and complete cases for FFQ items; the right choice differs by item frequency and amount of missingness.",
 confidence=0.5)

add(id="K-102", truth="not_established",
 failing_part="median follow-up time of the training rows is an appropriate default horizon",
 narrowest_regime="Defensible only as a stability-motivated fallback when the horizon is inside the observed follow-up with enough events and subjects at risk; a clinically declared horizon should override it.",
 reason="No methods argument is given that the median follow-up is a good evaluation time; it is a convention. Brier and calibration at time t need adequate events by t and a stable censoring-weight estimate at t, neither of which the median guarantees (with a 5% event rate the Brier score and calibration plot at the median are nearly uninformative). Also 'median follow-up' is ambiguous: a median of observed times (events included) is not the reverse-Kaplan-Meier median usually reported and can sit well below the usable range.",
 basis_used="derivation",
 citations=[],
 bite="yes",
 bite_note="Calibration slope, Brier score and the model ranking can differ materially between horizons, so the default decides which risk predictions get scored.",
 confidence=0.6)

add(id="K-088", truth="overstated",
 failing_part="each site gets its own intercept (as a default for sites, households or batches)",
 narrowest_regime="Site intercepts are right when site confounds, the exposure varies within site, and clusters are large or the outcome is continuous; with a binary outcome and small clusters (households) use conditional likelihood or another approach.",
 reason="Confounding by a site that differs in exposure and outcome, anti-conservative independence-based intervals, the need for cluster-robust inference with small-sample corrections for few groups, 'cluster-only' not removing between-group confounding, and group-wise validation under prediction are all sound. But dummy-intercepts are not a safe general default: a site-level exposure is absorbed and unidentifiable, and in a non-linear model with small clusters the incidental-parameters problem biases the coefficient. In my simulation (true logit beta = 1) the dummy-intercept MLE averaged 2.01 for clusters of 2, 1.60 for 3, 1.30 for 5, 1.15 for 10, 1.06 for 20.",
 basis_used="mixed",
 citations=[{"cite":"Neyman & Scott 1948 Econometrica 16:1-32 (incidental parameters); Andersen 1973 (conditional likelihood)","verified":False},
            {"cite":"Cameron & Miller 2015 J Hum Resour 50:317-372 (cluster-robust inference, few clusters)","verified":False}],
 bite="yes",
 bite_note="For household-type groupings with a binary outcome the default intercept-per-group fit can nearly double the log odds ratio; for a group-level exposure it silently drops the exposure.",
 confidence=0.55)

add(id="K-099", truth="overstated",
 failing_part="Multiple imputation with the outcome in the imputation model is invalid under prediction ... blanks must be filled in each training fold without the outcome",
 narrowest_regime="Invalid when held-out rows are imputed using their own outcomes (leakage) or when the deployed model will meet missing predictors with no outcome available; including the outcome when imputing the training fold for coefficient estimation is valid if deployment data are complete.",
 reason="Leakage and the deployment mismatch are real: validation or imputation of a held-out row that uses its own outcome is optimistic, and a new patient has no outcome. But Moons et al. 2006 showed that outcome-inclusive imputation yields coefficients close to the truth, and omitting it attenuates them, so 'invalid' and 'must' are too strong. Sisk et al. 2023 conclude only that standard MI principles may not carry over to prediction when data can be missing at deployment, and that strategies should be chosen case by case.",
 basis_used="literature",
 citations=[{"cite":"Sisk, Sperrin, Peek, van Smeden, Martin 2023 Stat Methods Med Res 32(8):1461-1477","verified":True},
            {"cite":"Moons et al. 2006 J Clin Epidemiol 59:1092-1101","verified":True},
            {"cite":"Sperrin, Martin, Sisk, Peek 2020 J Clin Epidemiol 125:183-187","verified":True},
            {"cite":"Hoogland et al. 2020 Stat Med 39:3591-3607","verified":True}],
 bite="yes",
 bite_note="The app refuses the option outright; a researcher whose deployment data will be complete loses a valid, better-coefficient strategy, while one with missingness at deployment is rightly pushed to in-fold, outcome-free filling.",
 confidence=0.6)

add(id="K-126", truth="true",
 failing_part="",
 narrowest_regime="Taylor-linearized variance with with-replacement PSU approximation and t df = PSUs - strata containing the domain's rows (NHANES convention).",
 reason="The NCHS Analytic Guidelines 2011-2016, section 3.2.3.1 state that the entire dataset must be kept and the subgroup flagged (SUBPOPN/DOMAIN), section 3.2.3.2 that df should be based on the number of strata and PSUs containing the observations of interest (PSUs minus strata), and that NCHS uses Taylor Series Linearization. Deleting rows removes PSUs and strata from the variance computation, which is the standard domain-estimation result (Lumley; Korn & Graubard). The with-replacement first stage is the standard approximation behind the linearization.",
 basis_used="literature",
 citations=[{"cite":"NCHS NHANES Analytic Guidelines 2011-2014 and 2015-2016, sections 3.2.1, 3.2.3.1, 3.2.3.2","verified":True},
            {"cite":"Korn & Graubard 1999 Analysis of Health Surveys, Wiley","verified":False}],
 bite="yes",
 bite_note="Dropping rows instead of flagging a domain changes the standard errors and df, and so the intervals and tests for every subgroup result.",
 confidence=0.85)

with open(out,"a") as f:
    for r in R:
        f.write(json.dumps(r)+"\n")
from collections import Counter
print(Counter(r["truth"] for r in R))
print([ (r["id"],r["truth"],r["confidence"]) for r in R])
