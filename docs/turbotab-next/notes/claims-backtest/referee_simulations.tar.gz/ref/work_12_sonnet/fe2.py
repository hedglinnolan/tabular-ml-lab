import numpy as np
from scipy.optimize import minimize_scalar
rng=np.random.default_rng(3)
def profile_nll(beta,x,y):
    G,m=x.shape
    a=np.zeros(G)
    for _ in range(40):
        p=1/(1+np.exp(-(a[:,None]+beta*x)))
        g=(y-p).sum(1); h=(p*(1-p)).sum(1)
        a=a+np.clip(g/np.maximum(h,1e-9),-3,3)
    eta=a[:,None]+beta*x
    return -(y*eta-np.log1p(np.exp(eta))).sum()
def est(G,m,beta=1.0):
    a=rng.normal(0,1,G); x=rng.normal(size=(G,m))
    y=(rng.random((G,m))<1/(1+np.exp(-(a[:,None]+beta*x)))).astype(float)
    keep=(y.sum(1)>0)&(y.sum(1)<m)
    x,y=x[keep],y[keep]
    return minimize_scalar(lambda b:profile_nll(b,x,y),bounds=(-1,5),method='bounded').x
for m in [2,3,5,10,20]:
    e=[est(2000//m*1,m) for _ in range(40)]
    print("cluster size",m,"G",2000//m,"mean FE-dummy logit beta (truth 1.0):",round(np.mean(e),3))
