import numpy as np, statsmodels.api as sm, warnings
warnings.filterwarnings("ignore")
rng=np.random.default_rng(1)
def sim(G,m,beta=1.0,reps=25):
    est=[]
    for r in range(reps):
        a=rng.normal(0,1,G)
        x=rng.normal(size=(G,m))
        eta=a[:,None]+beta*x
        y=(rng.random((G,m))<1/(1+np.exp(-eta))).astype(int)
        # drop clusters with no variation not needed for dummy MLE but they're fine; use sparse-ish dummies
        g=np.repeat(np.arange(G),m)
        D=np.zeros((G*m,G)); D[np.arange(G*m),g]=1
        X=np.column_stack([x.ravel(),D])
        try:
            res=sm.Logit(y.ravel(),X).fit(disp=0,method='bfgs',maxiter=300) if False else sm.GLM(y.ravel(),X,family=sm.families.Binomial()).fit(maxiter=100)
            est.append(res.params[0])
        except Exception as e:
            pass
    return np.mean(est),len(est)
for m in [2,3,5,10]:
    print("cluster size",m,"true beta=1 -> mean FE-dummy logit est",sim(60,m))
