import numpy as np, time
rng=np.random.default_rng(11)
def ols(X,y):
    A=np.column_stack([np.ones(len(y)),X]); XtX=A.T@A; b=np.linalg.solve(XtX,A.T@y)
    r=y-A@b; s2=r@r/(len(y)-A.shape[1]); se=np.sqrt(s2*np.linalg.inv(XtX)[1,1]); return b[1],se
def run(n,share,misreport,reps=300):
    out=[]
    for _ in range(reps):
        C=rng.standard_normal((n,5)); xt=0.5*C[:,0]+rng.standard_normal(n)
        y=0.1*xt+0.3*C.sum(1)+rng.standard_normal(n)
        leave=rng.random(n)<share   # leavers independent of C and exposure
        xr=xt.copy()
        if misreport: xr[leave]=0.6*xt[leave]+0.0  # leavers under-report the exposure proportionally
        # SMD on adjustment set: max over covariates
        smd=np.max(np.abs((C[leave].mean(0)-C[~leave].mean(0))/np.sqrt((C[leave].var(0)+C[~leave].var(0))/2)))
        prod=leave.mean()*smd
        b_keep,se_keep=ols(np.column_stack([xr[~leave],C[~leave]]),y[~leave])  # screen applied
        b_all,se_all=ols(np.column_stack([xr,C]),y)                            # screen removed
        out.append((prod, abs(b_all-b_keep)/(1.96*se_keep)))
    o=np.array(out); m=o[:,0]<0.003697
    print(f"n={n} share={share} misreport={misreport}: frac prod<thr={m.mean():.2f}; among those, median shift/halfwidth={np.median(o[m,1]) if m.any() else float('nan'):.3f}, P(shift>=0.1 hw)={(o[m,1]>=0.1).mean() if m.any() else float('nan'):.2f}")
t0=time.time()
run(40000,0.10,False); run(40000,0.10,True); run(40000,0.03,True); run(10000,0.05,False)
print(round(time.time()-t0,1),'s')
