import numpy as np, time, sys
from scipy import stats
rng=np.random.default_rng(int(sys.argv[4]))
n=int(sys.argv[1]); pnoise=int(sys.argv[2]); reps=int(sys.argv[3])
K=5;R=10; n2=n//K; n1=n-n2
pA=5;pB=5+pnoise
mu=(1+1/n1)*(n1-2)*(1/(n1-pA-2)-1/(n1-pB-2))
def gen(m):
    X=rng.standard_normal((m,pB)); y=X[:,:5].sum(1)*0.4+rng.standard_normal(m); return X,y
def fp(Xtr,ytr,Xte):
    A=np.column_stack([np.ones(len(Xtr)),Xtr]); b=np.linalg.solve(A.T@A,A.T@ytr)
    return np.column_stack([np.ones(len(Xte)),Xte])@b
t0=time.time(); cov=0; cov_lo=0; cov_hi=0
for rep in range(reps):
    X,y=gen(n); d=[]
    for r in range(R):
        perm=rng.permutation(n); folds=np.array_split(perm,K)
        for k in range(K):
            te=folds[k]; tr=np.setdiff1d(perm,te)
            d.append(np.mean((y[te]-fp(X[tr][:,:5],y[tr],X[te][:,:5]))**2)-np.mean((y[te]-fp(X[tr],y[tr],X[te]))**2))
    d=np.array(d); J=len(d)
    se=np.sqrt((1/J+n2/n1)*d.var(ddof=1)); c=stats.t.ppf(0.975,J-1)
    ok=abs(d.mean()-mu)<=c*se; cov+=ok
    if not ok:
        if d.mean()>mu: cov_hi+=1
        else: cov_lo+=1
print('n',n,'pnoise',pnoise,'mu',round(mu,3),'coverage',cov/reps,'miss above',cov_hi,'miss below',cov_lo, round(time.time()-t0,1),'s')
