import re, zlib, sys
data=open(sys.argv[1],'rb').read()
out=[]
for m in re.finditer(rb'stream\r?\n', data):
    st=m.end()
    try:
        d=zlib.decompressobj().decompress(data[st:st+3000000])
    except Exception:
        continue
    if not (b'Tj' in d or b'TJ' in d): continue
    txt=[]
    for t in re.finditer(rb'\[(.*?)\]\s*TJ|\(((?:\\.|[^\\)])*)\)\s*Tj|(T\*|Td|TD)', d, re.S):
        if t.group(1) is not None:
            parts=re.findall(rb'\(((?:\\.|[^\\)])*)\)|(-?\d+\.?\d*)', t.group(1))
            line=b''
            for p,num in parts:
                if p: line+=p
                elif num and float(num)<-200: line+=b' '
            txt.append(line)
        elif t.group(2) is not None:
            txt.append(t.group(2))
        else:
            txt.append(b' ')
    out.append(b''.join(txt))
s=b'\n=====PAGE=====\n'.join(out).decode('latin-1').replace('\\(','(').replace('\\)',')')
open(sys.argv[2],'w').write(s); print(len(s))
