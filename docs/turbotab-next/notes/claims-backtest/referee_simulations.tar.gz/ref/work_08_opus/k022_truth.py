import numpy as np, time, sys
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import LinearRegression
rng=np.random.default_rng(7)
def gen(n):
    X=rng.standard_normal((n,5)); y=X[:,0]+0.5*X[:,1]**2+rng.standard_normal(n); return X,y
Xt,yt=gen(20000)
n1=int(sys.argv[1]); M=int(sys.argv[2])
d=[]
t0=time.time()
for m in range(M):
    X,y=gen(n1)
    a=LinearRegression().fit(X,y).predict(Xt); b=DecisionTreeRegressor(random_state=0).fit(X,y).predict(Xt)
    d.append(np.mean((yt-a)**2)-np.mean((yt-b)**2))
d=np.array(d); print(n1, d.mean(), d.std()/np.sqrt(M), time.time()-t0)
