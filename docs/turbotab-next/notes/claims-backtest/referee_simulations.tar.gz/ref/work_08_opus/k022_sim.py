import numpy as np, time
from scipy import stats
rng=np.random.default_rng(1)

def fitpred(Xtr,ytr,Xte):
    A=np.column_stack([np.ones(len(Xtr)),Xtr])
    b,*_=np.linalg.lstsq(A,ytr,rcond=None)
    return np.column_stack([np.ones(len(Xte)),Xte])@b

def run(n,pA,snr_b,R=10,K=5,reps=1500,loss='mse',noise=1.0):
    rej=0;rej_naive=0
    for rep in range(reps):
        p=2*pA
        X=rng.standard_normal((n,p))
        y=X.sum(1)*snr_b+noise*rng.standard_normal(n)
        if loss=='01':
            y=(y+0.0*rng.standard_normal(n)>0).astype(float)
        d=[]
        for r in range(R):
            perm=rng.permutation(n)
            folds=np.array_split(perm,K)
            for k in range(K):
                te=folds[k]; tr=np.setdiff1d(perm,te)
                pa=fitpred(X[tr][:,:pA],y[tr],X[te][:,:pA])
                pb=fitpred(X[tr][:,pA:],y[tr],X[te][:,pA:])
                if loss=='mse':
                    la=np.mean((y[te]-pa)**2); lb=np.mean((y[te]-pb)**2)
                else:
                    la=np.mean((pa>0.5)!=y[te]); lb=np.mean((pb>0.5)!=y[te])
                d.append(la-lb)
        d=np.array(d); J=len(d)
        n2=n/K; n1=n-n2
        s2=d.var(ddof=1)
        if s2==0: continue
        t=d.mean()/np.sqrt((1/J+n2/n1)*s2)
        tn=d.mean()/np.sqrt(s2/J)
        c=stats.t.ppf(0.975,J-1)
        rej+= abs(t)>c; rej_naive+= abs(tn)>c
    return rej/reps, rej_naive/reps

t0=time.time()
for (n,pA,b,loss) in [(200,5,0.3,'mse'),(100,5,0.3,'mse'),(60,12,0.3,'mse'),(500,5,0.3,'mse'),(200,5,0.3,'01'),(60,12,0.5,'01')]:
    r=run(n,pA,b,loss=loss,reps=1000)
    print(n,pA,b,loss,'corrected size',r[0],'naive size',r[1], round(time.time()-t0,1),'s',flush=True)
