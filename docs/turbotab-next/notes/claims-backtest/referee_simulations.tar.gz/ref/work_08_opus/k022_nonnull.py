import numpy as np, time, sys
from scipy import stats
rng=np.random.default_rng(int(sys.argv[4]))
n=int(sys.argv[1]); pnoise=int(sys.argv[2]); reps=int(sys.argv[3])
K=5;R=10; n2=n//K; n1=n-n2
def gen(m):
    X=rng.standard_normal((m,5+pnoise)); y=X[:,:5].sum(1)*0.4+rng.standard_normal(m); return X,y
def fp(Xtr,ytr,Xte):
    A=np.column_stack([np.ones(len(Xtr)),Xtr]); b=np.linalg.lstsq(A,ytr,rcond=None)[0]
    return np.column_stack([np.ones(len(Xte)),Xte])@b
t0=time.time()
# truth
Xt,yt=gen(4000); dd=[]
for m in range(3000):
    X,y=gen(n1)
    dd.append(np.mean((yt-fp(X[:,:5],y,Xt[:,:5]))**2)-np.mean((yt-fp(X,y,Xt))**2))
mu=np.mean(dd); print('mu',mu,'mc se',np.std(dd)/np.sqrt(3000), round(time.time()-t0,1),flush=True)
cov=0
for rep in range(reps):
    X,y=gen(n); d=[]
    for r in range(R):
        perm=rng.permutation(n); folds=np.array_split(perm,K)
        for k in range(K):
            te=folds[k]; tr=np.setdiff1d(perm,te)
            d.append(np.mean((y[te]-fp(X[tr][:,:5],y[tr],X[te][:,:5]))**2)-np.mean((y[te]-fp(X[tr],y[tr],X[te]))**2))
    d=np.array(d); J=len(d)
    se=np.sqrt((1/J+n2/n1)*d.var(ddof=1)); c=stats.t.ppf(0.975,J-1)
    cov+= abs(d.mean()-mu)<=c*se
print('n',n,'pnoise',pnoise,'coverage',cov/reps, round(time.time()-t0,1),'s')
