import numpy as np, time
from sklearn.linear_model import LinearRegression, RidgeCV
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.model_selection import cross_val_score, KFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
rng=np.random.default_rng(3)
n=2000
E=rng.lognormal(np.log(2000),0.3,n)          # kcal
dens=rng.normal(15,3,n)                        # nutrient density per 1000 kcal
N=dens*E/1000                                   # nutrient intake
age=rng.normal(50,10,n)
y=0.2*dens+0.002*E+0.05*age+rng.normal(0,2,n)  # outcome depends on density (one plausible truth)
def resid(N,E):
    b=np.polyfit(E,N,1); return N-np.polyval(b,E)
designs={'standard N+E':np.column_stack([N,E,age]),
         'residual r+E':np.column_stack([resid(N,E),E,age]),
         'density N/E+E':np.column_stack([N/E,E,age])}
cv=KFold(5,shuffle=True,random_state=0)
t0=time.time()
for name,mdl in [('OLS',LinearRegression()),('ridge',make_pipeline(StandardScaler(),RidgeCV(alphas=np.logspace(-2,3,20)))),('HGB',HistGradientBoostingRegressor(max_iter=100,random_state=0))]:
    for d,X in designs.items():
        s=cross_val_score(mdl,X,y,cv=cv,scoring='r2',n_jobs=1)
        print(f"{name:6s} {d:15s} CV R2={s.mean():.4f}")
print(round(time.time()-t0,1),'s')
