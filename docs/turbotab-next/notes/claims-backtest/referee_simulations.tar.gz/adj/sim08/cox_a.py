import sys, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.filterwarnings("ignore")
from turbotab.core.models.survival import cox_table, OUTCOME_DTYPE
from turbotab.core.models.inference import Clusters
def Y(t, e):
    y = np.zeros(len(t), dtype=OUTCOME_DTYPE); y["time"] = t; y["event"] = e; y["entry"] = 0.0; return y
for seed in range(3, 9):
    rng = np.random.default_rng(seed)
    n = 60
    g = np.repeat([0, 1], n // 2).astype(float)
    t = rng.exponential(1, n)
    e = np.where(g == 1, False, rng.random(n) < 0.7)
    tab = cox_table(pd.DataFrame({"grp": g, "age": rng.normal(size=n)}), Y(t, e), Clusters())
    print(seed, "refused:", tab.info.get("refused"))
    print("   ", tab.rows[0])
print(tab.info.keys()); print(tab.concerns)
print({k: v for k, v in tab.info.items()})
print(tab.rows[1])
