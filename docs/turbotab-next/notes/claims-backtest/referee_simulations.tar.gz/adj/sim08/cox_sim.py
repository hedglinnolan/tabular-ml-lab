import sys, warnings
import numpy as np
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.filterwarnings("ignore")
from turbotab.core.models.survival import cox_fit, OUTCOME_DTYPE
rng = np.random.default_rng(3)
def Y(t, e):
    y = np.zeros(len(t), dtype=OUTCOME_DTYPE); y["time"] = t; y["event"] = e; y["entry"] = 0.0; return y
def show(name, X, y):
    f = cox_fit(X, y); sd = X.std(axis=0)
    print(f"{name:55s} converged={f.converged} beta*sd={np.round(f.beta*sd,2)} iters={f.iterations}")
n = 60
g = np.repeat([0, 1], n // 2).astype(float)
t = rng.exponential(1, n)
# (a) group 1 has no events
e = np.where(g == 1, False, rng.random(n) < 0.7); show("(a) group with no events", g[:, None], Y(t, e))
# (b) group 1: every row has the event, other half-censored, interleaved times
e = np.where(g == 1, True, rng.random(n) < 0.5); show("(b) group with every row an event (interleaved)", g[:, None], Y(t, e))
# (c) both groups all events
e = np.ones(n, bool); show("(c) every row an event in both groups", g[:, None], Y(t, e))
# (d) group 1 all events earlier than any group-0 event (true monotone)
t2 = np.where(g == 1, rng.uniform(0, 1, n), rng.uniform(2, 3, n)); e = np.ones(n, bool)
show("(d) group 1 events all before group 0 (monotone)", g[:, None], Y(t2, e))
# (e) continuous covariate perfectly ordering event times (monotone)
x = rng.normal(size=n); t3 = np.exp(-3 * x) ; t3 = np.argsort(np.argsort(-x)).astype(float) + 1
show("(e) continuous x perfectly orders event times", x[:, None], Y(t3, np.ones(n, bool)))
# (f) near-monotone continuous with one swap
t4 = t3.copy(); i, j = np.argsort(x)[n//2], np.argsort(x)[n//2+1]; t4[i], t4[j] = t4[j], t4[i]
show("(f) continuous, one adjacent swap (finite MLE)", x[:, None], Y(t4, np.ones(n, bool)))
# (g) collinear-ish ill-conditioning but finite: two nearly identical columns
z = rng.normal(size=n); X = np.column_stack([z, z + 1e-4 * rng.normal(size=n)]); tt = rng.exponential(np.exp(-0.5 * z))
show("(g) two near-identical columns (finite)", X, Y(tt, rng.random(n) < 0.8))
print("---- cox_table outputs ----")
import pandas as pd
from turbotab.core.models.survival import cox_table
from turbotab.core.models.inference import Clusters
rng = np.random.default_rng(3)
n = 60
g = np.repeat([0, 1], n // 2).astype(float)
t = rng.exponential(1, n)
e = np.where(g == 1, False, rng.random(n) < 0.7)
cl = Clusters()
for label, M, yy in [("(a) no events in group", pd.DataFrame({"grp": g}), Y(t, e)),
                     ("(f) near-monotone continuous", pd.DataFrame({"x": x}), Y(t4, np.ones(n, bool))),
                     ("(g) near-identical columns", pd.DataFrame({"z1": X[:,0], "z2": X[:,1]}), Y(tt, rng.random(n) < 0.8))]:
    tab = cox_table(M, yy, cl)
    print(label, "| refused:", tab.info.get("refused"), "| reason:", (tab.info.get("reason") or tab.info.get("refusal") or "")[:200])
    for r in tab.rows:
        print("    ", {k: r.get(k) for k in ("feature", "estimate", "ci_low", "ci_high", "p", "se")})
