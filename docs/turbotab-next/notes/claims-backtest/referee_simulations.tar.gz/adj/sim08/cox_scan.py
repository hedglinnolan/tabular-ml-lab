import sys, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.filterwarnings("ignore")
from turbotab.core.models.survival import cox_table, OUTCOME_DTYPE
from turbotab.core.models.inference import Clusters
def Y(t, e):
    y = np.zeros(len(t), dtype=OUTCOME_DTYPE); y["time"] = t; y["event"] = e; y["entry"] = 0.0; return y
for n, prev, extra in [(60, .5, False), (60, .5, True), (200, .1, True), (500, .05, True), (500, .05, False), (1000, .2, True)]:
    counts = {"refused": 0, "p=0/zero-width": 0, "ci None, unrefused": 0, "finite ci": 0}
    for seed in range(40):
        rng = np.random.default_rng(seed)
        g = (rng.random(n) < prev).astype(float)
        t = rng.exponential(1, n)
        e = np.where(g == 1, False, rng.random(n) < 0.6)
        cols = {"grp": g}
        if extra: cols["age"] = rng.normal(size=n)
        tab = cox_table(pd.DataFrame(cols), Y(t, e), Clusters())
        r = tab.rows[0]
        if tab.info.get("refused"): counts["refused"] += 1
        elif r["ci_low"] is None: counts["ci None, unrefused"] += 1
        elif r["p"] == 0.0 or r["ci_high"] - r["ci_low"] < 1e-6: counts["p=0/zero-width"] += 1
        else: counts["finite ci"] += 1
    print(n, prev, "with age" if extra else "grp only", counts)
