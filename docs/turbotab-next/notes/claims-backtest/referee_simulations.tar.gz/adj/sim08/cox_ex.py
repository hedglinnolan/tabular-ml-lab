import sys, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.filterwarnings("ignore")
from turbotab.core.models.survival import cox_table, OUTCOME_DTYPE
from turbotab.core.models.inference import Clusters
def Y(t, e):
    y = np.zeros(len(t), dtype=OUTCOME_DTYPE); y["time"] = t; y["event"] = e; y["entry"] = 0.0; return y
shown = 0
for seed in range(40):
    n, prev = 500, .05
    rng = np.random.default_rng(seed)
    g = (rng.random(n) < prev).astype(float); t = rng.exponential(1, n)
    e = np.where(g == 1, False, rng.random(n) < 0.6)
    tab = cox_table(pd.DataFrame({"grp": g, "age": rng.normal(size=n)}), Y(t, e), Clusters())
    r = tab.rows[0]
    if not tab.info.get("refused") and r["ci_low"] is not None and r["p"] != 0.0:
        print(seed, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in r.items()}); shown += 1
    if shown >= 3: break
