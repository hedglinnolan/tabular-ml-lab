import sys, time, warnings
import numpy as np, pandas as pd
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.filterwarnings("ignore")
import turbotab.core.models.inference as inf
from turbotab.core.models.inference import Clusters
from turbotab.core.models.repeated import gee_table

def clusters(codes):
    codes = pd.factorize(pd.Series(codes))[0].astype(np.int64)
    return Clusters(column="pid", codes=codes, n_clusters=int(codes.max()) + 1)

def row(rows, f):
    return next(r for r in rows if r["feature"] == f)

mode = sys.argv[1]; reps = int(sys.argv[2])
rng = np.random.default_rng(int(sys.argv[3]) if len(sys.argv) > 3 else 1)
t0 = time.time(); rej = 0; done = 0; nanp = 0
if mode.startswith("small"):
    G = int(mode[5:])
    inf.min_clusters = lambda: 2   # bypass the floor to see the interval that is withheld
for _ in range(reps):
    if mode == "rare12":
        G = 12
        codes = np.repeat(np.arange(G), rng.integers(15, 26, G))
        z = np.isin(np.arange(G), rng.choice(G, 3, replace=False))[codes].astype(float)
        x = rng.normal(size=len(codes))
        lp = -3.2 + rng.normal(0, 0.8, G)[codes] + 0.3 * x
        y = (rng.random(len(codes)) < 1 / (1 + np.exp(-lp))).astype(int)
        if y.sum() < 2: continue
        t = gee_table(pd.DataFrame({"z": z, "x": x}), y, clusters(codes), "binary", classes=[0, 1])
    else:
        codes = np.repeat(np.arange(G), rng.integers(6, 11, G))
        z = np.isin(np.arange(G), rng.choice(G, G // 2, replace=False))[codes].astype(float)
        x = rng.normal(size=len(codes))
        y = rng.normal(0, 1.2, G)[codes] + 0.4 * x + rng.normal(size=len(codes))
        t = gee_table(pd.DataFrame({"z": z, "x": x}), y, clusters(codes), "regression")
    p = row(t.rows, "z").get("p")
    if p is None or not np.isfinite(p):
        nanp += 1; continue
    rej += p < 0.05; done += 1
print(mode, "reps", done, "refused/nan", nanp, "reject", round(rej / max(done,1), 3), "secs", round(time.time() - t0, 1))
