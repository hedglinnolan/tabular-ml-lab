import sys, time, warnings
import numpy as np
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
warnings.filterwarnings("ignore")
from turbotab.core.models.validation import corrected_t
from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import KFold
n = int(sys.argv[1]); D = int(sys.argv[2]); kind = sys.argv[3]
rng = np.random.default_rng(11); t0 = time.time(); rej = 0
for d in range(D):
    X = rng.normal(size=(n, 5)); y = X[:, 0] + rng.normal(size=n)
    a, b = [], []
    for r in range(10):
        for tr, te in KFold(10, shuffle=True, random_state=1000 * d + r).split(X):
            if kind == "tree":
                ma = DecisionTreeRegressor(max_features=0.6, random_state=2 * r).fit(X[tr], y[tr])
                mb = DecisionTreeRegressor(max_features=0.6, random_state=2 * r + 1).fit(X[tr], y[tr])
            else:  # OLS on two exchangeable feature sets (x0 + one noise column each)
                ma = LinearRegression().fit(X[tr][:, [0, 1]], y[tr]); mb = LinearRegression().fit(X[tr][:, [0, 2]], y[tr])
            pa = ma.predict(X[te] if kind == "tree" else X[te][:, [0, 1]])
            pb = mb.predict(X[te] if kind == "tree" else X[te][:, [0, 2]])
            a.append(float(np.mean((y[te] - pa) ** 2))); b.append(float(np.mean((y[te] - pb) ** 2)))
    t = corrected_t(a, b, test_share=None, repeats=10, higher_is_better=False)
    rej += not (t.ci_low <= 0 <= t.ci_high)
print(kind, "n", n, "datasets", D, "'ahead' rate", round(rej / D, 3), "secs", round(time.time() - t0, 1))
