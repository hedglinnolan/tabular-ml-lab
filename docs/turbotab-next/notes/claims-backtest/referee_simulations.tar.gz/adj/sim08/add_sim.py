import numpy as np, time
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_score, KFold
rng = np.random.default_rng(5); t0 = time.time()
n, p, R = 60, 2000, 150
cv_add, true_add, cv_base, true_base, cv_infold = [], [], [], [], []
Xf = rng.normal(size=(5000, p)); yf = rng.normal(size=5000)
for r in range(R):
    X = rng.normal(size=(n, p)); y = rng.normal(size=n)
    declared = [0, 1, 2, 3, 4]
    corr = np.abs((X - X.mean(0)).T @ (y - y.mean())) ; corr[declared] = -1
    top = int(np.argmax(corr))
    kf = KFold(10, shuffle=True, random_state=r)
    for cols, cvl, tl in [(declared + [top], cv_add, true_add), (declared, cv_base, true_base)]:
        cvl.append(-cross_val_score(LinearRegression(), X[:, cols], y, cv=kf, scoring="neg_mean_squared_error").mean())
        m = LinearRegression().fit(X[:, cols], y); tl.append(float(np.mean((yf - m.predict(Xf[:, cols])) ** 2)))
    # the same addition rerun inside each training fold (the rule the doc's section 1 requires)
    errs = []
    for tr, te in kf.split(X):
        c = np.abs((X[tr] - X[tr].mean(0)).T @ (y[tr] - y[tr].mean())); c[declared] = -1
        cols = declared + [int(np.argmax(c))]
        m = LinearRegression().fit(X[tr][:, cols], y[tr]); errs.append(np.mean((y[te] - m.predict(X[te][:, cols])) ** 2))
    cv_infold.append(np.mean(errs))
f = lambda v: round(float(np.mean(v)), 3)
print("added on all rows: CV", f(cv_add), "true", f(true_add), "| declared only: CV", f(cv_base), "true", f(true_base), "| addition rerun in-fold: CV", f(cv_infold), "| secs", round(time.time()-t0,1))
