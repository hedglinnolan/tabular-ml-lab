import numpy as np, math
from scipy import stats
rng=np.random.default_rng(3)
def dl(th,se,hk=False):
    k=len(th); w=1/se**2; f=(w*th).sum()/w.sum(); q=(w*(th-f)**2).sum(); c=w.sum()-(w**2).sum()/w.sum()
    t2=max(0,(q-(k-1))/c); ws=1/(se**2+t2); mu=(ws*th).sum()/ws.sum(); sm=math.sqrt(1/ws.sum())
    if hk:
        v=(ws*(th-mu)**2).sum()/((k-1)*ws.sum()); sm2=math.sqrt(v); h=stats.t.ppf(.975,k-1)*sm2
    else: h=1.96*sm
    return mu,mu-h,mu+h
k=8
for n,lsd in [(100,0.0),(100,0.3),(1000,0.0),(1000,0.15),(2500,0.15),(2500,0.3)]:
    R=2000; res={'idDLz':[], 'logHK':[]}; cov={'idDLz':0,'logHK':0,'logHK_vs_mean':0}
    truemean=math.exp(lsd**2/2)  # mean of true cycle MSEs (lognormal median 1)
    for r in range(R):
        true=np.exp(rng.normal(0,lsd,k))
        # per-cycle MSE estimate from n squared normal errors
        mse=np.array([np.mean((rng.normal(0,math.sqrt(t),n))**2) for t in true])
        se=mse*math.sqrt(2/n)
        m,lo,hi=dl(mse,se); res['idDLz'].append(m); cov['idDLz']+= lo<=truemean<=hi
        lm,llo,lhi=dl(np.log(mse),np.full(k,math.sqrt(2/n)),hk=True)
        res['logHK'].append(math.exp(lm)); cov['logHK']+= llo<=0<=lhi  # covers the median (1)
        cov['logHK_vs_mean']+= math.exp(llo)<=truemean<=math.exp(lhi)
    print(f"n={n} lsd={lsd} truemean={truemean:.3f} idDL={np.mean(res['idDLz']):.3f} cov(mean)={cov['idDLz']/R:.3f} | logHK={np.mean(res['logHK']):.3f} cov(median)={cov['logHK']/R:.3f} cov(mean)={cov['logHK_vs_mean']/R:.3f}")
