import sys, time, math
import numpy as np
sys.path.insert(0, "/Users/nhedglin/tabular-ml-lab")
from turbotab.core.models import time_varying as tv
from turbotab.core.tests.acceptance.timevary_fixtures import gformula_cohort
from turbotab.core.tests.acceptance.test_timevary import GTRUTH_SPEC as SPEC
t0 = time.process_time()
d = gformula_cohort(n=600, visits=4, seed=11)
models = tv.fit_gformula(tv._prepared(d, SPEC), SPEC)  # warm
def run(n_sim, seed):
    r = tv.gformula(d, SPEC, n_sim=n_sim, seed=seed, natural=False)
    return r.final("always"), r.final("never"), r.mc_se["always"], r.mc_se["never"]
n_units = d[SPEC.id].nunique()
for label, n_sim in (("resampled base n_sim=3000", 3000), ("units themselves n_sim=units", n_units)):
    out = np.array([run(n_sim, s) for s in range(300)])
    sd_a, sd_n = out[:, 0].std(ddof=1), out[:, 1].std(ddof=1)
    sd_diff = (out[:, 0] - out[:, 1]).std(ddof=1)
    rep = np.maximum(out[:, 2], out[:, 3])
    print(f"{label}: true MC SD always={sd_a:.5f} never={sd_n:.5f} diff={sd_diff:.5f}; "
          f"reported max(se) mean={rep.mean():.5f}; share of runs reported < true max SD: "
          f"{np.mean(rep < max(sd_a, sd_n)):.2f}")
print("cpu s", round(time.process_time() - t0, 1))
