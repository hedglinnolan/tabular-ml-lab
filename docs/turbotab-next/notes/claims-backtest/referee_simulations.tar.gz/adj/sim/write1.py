import json
OUT = "/private/tmp/claude-501/-Users-nhedglin-tabular-ml-lab/a12607bd-3f0c-4a23-8d52-bda4a2c1292e/scratchpad/adj/out/adj_04.jsonl"
recs = [
 {"id": "A-011", "outcome": "inventory_misstatement", "severity": None,
  "fix": "No code change; correct the inventory to add the forest out-of-bag path (tuning.py:1737, pipeline.py:540-541) and the time-to-event refusal of tuned families (pipeline.py:528-532), and cite the stronger tests (test_tuning_engine.py::test_t3_*, test_elastic_net_penalty.py::test_the_inner_curve_*) instead of the arithmetic-only one.",
  "evidence": "Both referees judged the claim true, and the code matches it: pooled_loss is sum(w*loss)/sum(w) over every inner row (tuning.py:998-1013), Loss admits only mse/log_loss/rps (tuning.py:88), and choose() takes the rounded argmin (tuning.py:1016). The only gap is the inventory's: a forest with one row per unit, no time order, the sample answer and no outcome-reading step pools its out-of-bag predictions instead, which is still a pooled strictly proper loss, so the app's real claim holds (audit's corrected statement accepted).",
  "confidence": 0.85},
 {"id": "A-081", "outcome": "inventory_misstatement", "severity": None,
  "fix": "No code change; restate the inventory as 'a box of narrowed conventions with XGBoost's defaults always a candidate' (xgboost_family.py:482-515, RECIPES §4.1), and optionally give the Dimension source strings at xgboost_family.py:484-497 a 'narrowed from' prefix so the registry does not attribute depth 2-10 or rounds 25-1,000 to Probst.",
  "evidence": "The app never says the box 'contains the well-performing settings': users see only 'Its settings are searched inside every training fold, with XGBoost's defaults always among the candidates' (xgboost_family.py:513), and RECIPES calls the ranges 'conventions, narrowed'; the per-dimension source strings feed only the citation-registry check (base.py:687-702), not user text. Referee A is right that Probst's Table 3 puts tuned depth (5.6-14) and rounds (920-4,551) partly outside the box, but rounds are searched without early stopping only below an effective size of 1,500 (tuning.py:94), where lr up to 0.3 x 1,000 rounds is ample, and Referee B's equal-budget simulation found no loss.",
  "confidence": 0.75},
 {"id": "A-117", "outcome": "defect", "severity": "S2",
  "fix": "Reword the refusal at decisions.py:4832-4836 to the regime Sisk et al. support: 'a new row can arrive with blanks and has no outcome, and when it can, Sisk et al. 2023 found leaving the outcome out of the imputation preferred'; also note that with complete data at deployment they recommend the opposite, and say 'unless the purpose is inference' rather than 'under prediction' since the check also fires when no purpose is set (decisions.py:4830).",
  "evidence": "Both referees and the audit agree that Sisk et al. 2023 recommend putting the outcome in development-data MI when deployment data are complete, and prefer leaving it out only when missingness is allowed at deployment. So citing them for an unconditional rule overstates the source. The refusal itself is defensible in the main regime: the app's MI is whole-table and outcome-inclusive, which would leak a held-out row's outcome, and the deployed pipeline must fill blanks without an outcome. In-fold outcome-inclusive MI isn't implemented, so no valid estimate is being withheld, only overstated in its scope.",
  "confidence": 0.7},
 {"id": "B-028", "outcome": "convention_unlabeled", "severity": "S3",
  "fix": "At percent_energy.py:62-64 say 'every value is at most 1, which reads as fractions (0.35 for 35%)' instead of 'it holds fractions', and add an exit at decisions.py:4548-4552 that confirms the values are genuine percentages.",
  "evidence": "The 0-100 bound is definitional; the max <= 1 rule is a data-sanity heuristic stated to the user as fact, as both referees say. The false-positive regime is narrow in this app: the name gate admits only protein, carbohydrate, fat (including trans and SFA/PUFA), alcohol, fiber and sugars (EPA, DHA, ALA and omega-3 names are not admitted, as I checked with is_percent_of_energy), and at the default 5-point step (decisions.py:816) a genuine column with max <= 1 has no rows on support anyway. A refusal only bites for trans fat or alcohol in a small low-intake sample with a user-reduced step.",
  "confidence": 0.75},
]
with open(OUT, "a") as f:
    for r in recs:
        f.write(json.dumps(r, ensure_ascii=False) + "\n")
print("ok", len(recs))
