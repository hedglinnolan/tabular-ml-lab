import os, time
os.environ["OMP_NUM_THREADS"] = "1"
import numpy as np
from sklearn.ensemble import RandomForestRegressor, HistGradientBoostingRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import cross_val_score, KFold
t0 = time.time()
rng = np.random.default_rng(1)
def make(n, p, signal="density"):
    E = np.exp(rng.normal(np.log(2000), 0.3, n))
    d = rng.normal(0, 1, (n, p))            # person-level composition (z-scored density)
    N = E[:, None] * np.exp(0.25 * d) / 20   # nutrients proportional to energy, composition varies
    if signal == "density":
        y = d[:, :min(p, 3)].sum(1) * 0.6 + 0.3 * (np.log(E) - np.log(2000)) / 0.3 + rng.normal(0, 1.0, n)
    else:  # absolute amount
        y = (np.log(N[:, :min(p, 3)]).sum(1) - np.log(N[:, :min(p,3)]).sum(1).mean()) / 0.4 + rng.normal(0, 1.0, n)
    return E, N, y
def feats(E, N, form):
    if form == "standard": return np.column_stack([N, E])
    if form == "residual":
        R = np.empty_like(N)
        for j in range(N.shape[1]):
            b = np.polyfit(E, N[:, j], 1); R[:, j] = N[:, j] - np.polyval(b, E) + np.polyval(b, E.mean())
        return np.column_stack([R, E])
    if form == "density": return np.column_stack([N / E[:, None], E])
cv = KFold(5, shuffle=True, random_state=0)
models = {"OLS": lambda: LinearRegression(),
          "RF": lambda: RandomForestRegressor(200, min_samples_leaf=5, max_features=1/3, n_jobs=1, random_state=0),
          "GBM": lambda: HistGradientBoostingRegressor(max_iter=200, random_state=0)}
for p in (1, 5, 20):
    for signal in ("density", "amount"):
        E, N, y = make(1000, p, signal)
        row = []
        for m, mk in models.items():
            s = {f: cross_val_score(mk(), feats(E, N, f), y, cv=cv, scoring="r2").mean() for f in ("standard", "residual", "density")}
            row.append(f"{m}: " + " ".join(f"{k[:3]} {v:.3f}" for k, v in s.items()))
        print(f"p={p:2d} signal={signal:7s} | " + " | ".join(row), flush=True)
print("secs", round(time.time() - t0, 1))
