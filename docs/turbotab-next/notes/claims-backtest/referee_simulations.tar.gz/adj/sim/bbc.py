import numpy as np, time
t=time.time()
rng=np.random.default_rng(1)
def bbc(Li, Lf, B=500):
    n=len(Li); diffs=[]
    for _ in range(B):
        d=rng.integers(0,n,n); times=np.bincount(d,minlength=n)
        if times.all(): continue
        out=times==0
        if out.sum()<2: continue
        inb=(Lf*times[None,:]).sum(1)/times.sum()
        k=np.argmin(inb)
        diffs.append(Lf[k,out].mean()-Li[out].mean())
    diffs=np.array(diffs)
    return diffs.mean(), np.percentile(diffs,2.5), np.percentile(diffs,97.5)
for n,delta in [(30,0.0),(100,0.0),(100,0.25),(300,0.15)]:
    cover=0; span=0; naive_span=0; R=300 if n<300 else 150
    for r in range(R):
        # per-row loss: interpretable loss = flexible + delta noise; 3 flexible equal families
        base=rng.normal(0,1,n)
        Lf=np.stack([base+rng.normal(0,0.5,n) for _ in range(3)])
        Li=base+rng.normal(0,0.5,n)+delta   # interp worse by delta: cost = Lf - Li = -delta
        m,lo,hi=bbc(Li,Lf,300)
        true=-delta
        cover+= lo<=true<=hi; span+= lo<=0<=hi
        # naive paired 95% CI vs a single flexible family (oracle, no selection)
        dd=Lf[0]-Li; se=dd.std(ddof=1)/np.sqrt(n)
        naive_span+= abs(dd.mean())<1.96*se
    print(n,delta,'coverage',cover/R,'spans0',span/R,'paired95 spans0',naive_span/R)
print('sec',time.time()-t)
