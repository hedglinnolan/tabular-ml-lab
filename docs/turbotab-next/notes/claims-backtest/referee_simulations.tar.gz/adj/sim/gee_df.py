import numpy as np, time
from scipy import stats
from scipy.linalg import sqrtm
rng=np.random.default_rng(1)
def kc_se(X,y,codes,K):
    XtX_inv=np.linalg.inv(X.T@X)
    b=XtX_inv@X.T@y
    r=y-X@b
    meat=np.zeros((X.shape[1],)*2)
    for g in range(K):
        idx=codes==g
        Xg=X[idx]; Hg=Xg@XtX_inv@Xg.T
        A=np.real(sqrtm(np.linalg.inv(np.eye(idx.sum())-Hg)))
        u=Xg.T@(A@r[idx])
        meat+=np.outer(u,u)
    V=XtX_inv@meat@XtX_inv
    return b,np.sqrt(np.diag(V))
def run(K,m,pcov,icc_x,reps):
    codes=np.repeat(np.arange(K),m)
    arm=np.repeat((np.arange(K)<K//2).astype(float),m)
    rej={}
    for _ in range(reps):
        cx=rng.normal(size=(K,pcov))[codes]*np.sqrt(icc_x)
        ix=rng.normal(size=(K*m,pcov))*np.sqrt(1-icc_x)
        Z=cx+ix
        y=rng.normal(size=K)[codes]*np.sqrt(0.1)+rng.normal(size=K*m)*np.sqrt(0.9)+Z@np.full(pcov,0.5)
        X=np.column_stack([np.ones(K*m),arm,Z])
        b,se=kc_se(X,y,codes,K)
        t=b[1]/se[1]
        for name,df in (("K-2",K-2),("K-p",K-2-pcov)):
            if df<1: continue
            rej[name]=rej.get(name,0)+(abs(t)>stats.t.ppf(0.975,df))
    return {k:v/reps for k,v in rej.items()}
t0=time.process_time()
for K in (8,12):
    for icc_x in (0.0,0.3,0.8):
        print(K,"pcov=3 icc_x",icc_x,run(K,15,3,icc_x,1200), flush=True)
print("cpu",time.process_time()-t0)
