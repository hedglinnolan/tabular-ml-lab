import os, sys, time, numpy as np
os.environ["OMP_NUM_THREADS"]="1"
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold
R2 = float(sys.argv[1]); reps = int(sys.argv[2]); n = int(sys.argv[3]); learner = sys.argv[4]
rng = np.random.default_rng(int(R2*1000)+n)
def mfun(X): return 2*np.sin(X[:,0]) + X[:,1]**2 - 1 + 0.5*X[:,2]*X[:,3]
Xbig = rng.normal(size=(200000,5)); vm = mfun(Xbig).var()
sdv = np.sqrt(vm*(1-R2)/R2)
def fit_pred(Xtr, ytr, Xte):
    if learner == "rf":
        return RandomForestRegressor(n_estimators=100, min_samples_leaf=5, n_jobs=1, random_state=0).fit(Xtr,ytr).predict(Xte)
    else:  # OLS main terms
        A = np.column_stack([np.ones(len(Xtr)), Xtr]); b = np.linalg.lstsq(A, ytr, rcond=None)[0]
        return np.column_stack([np.ones(len(Xte)), Xte]) @ b
t0=time.process_time(); est=[]; cov=0; r2s=[]; ses=[]
for r in range(reps):
    X = rng.normal(size=(n,5)); m = mfun(X); D = m + sdv*rng.normal(size=n)
    Y = 1.0*D + np.cos(X[:,0]) + X[:,1] + X[:,4]**2 + rng.normal(size=n)
    lh = np.empty(n); mh = np.empty(n)
    for tr, te in KFold(5, shuffle=True, random_state=r).split(X):
        lh[te] = fit_pred(X[tr], Y[tr], X[te]); mh[te] = fit_pred(X[tr], D[tr], X[te])
    v = D - mh; u = Y - lh
    th = np.sum(v*u)/np.sum(v*v)
    psi = (u - th*v)*v; J = np.mean(v*v); se = np.sqrt(np.mean(psi**2)/J**2/n)
    est.append(th); ses.append(se); cov += abs(th-1) < 1.96*se
    r2s.append(1 - np.sum(v*v)/np.sum((D-D.mean())**2))
est=np.array(est)
print(f"R2true={R2} n={n} {learner}: crossfit R2={np.mean(r2s):.3f} mean theta={est.mean():.3f} bias={est.mean()-1:+.3f} sd={est.std():.3f} meanSE={np.mean(ses):.3f} cover={cov/reps:.2f} reps={reps} cpu={time.process_time()-t0:.1f}s")
