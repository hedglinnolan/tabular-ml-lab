import os, time, numpy as np
os.environ["OMP_NUM_THREADS"]="1"
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import ElasticNetCV, LinearRegression
from sklearn.preprocessing import StandardScaler
rng=np.random.default_rng(7); t0=time.process_time()
def draw(n):
    X=rng.normal(size=(n,10)); X[:,1]=0.95*X[:,0]+np.sqrt(1-0.95**2)*X[:,1]
    f=X[:,0]+0.5*X[:,1]+X[:,2]+1.5*(X[:,3]**2-1)+np.sin(2*X[:,4])
    return X, f+rng.normal(size=n)
res={k:[] for k in ("rf_all","rf_enet","ols_all","ols_enet")}; kept=[]
for r in range(10):
    X,y=draw(500); Xt,yt=draw(5000)
    sc=StandardScaler().fit(X); en=ElasticNetCV(l1_ratio=0.5,cv=5,random_state=r).fit(sc.transform(X),y)
    keep=np.flatnonzero(en.coef_!=0); kept.append(keep)
    for name,cols in (("all",np.arange(10)),("enet",keep)):
        rf=RandomForestRegressor(n_estimators=150,min_samples_leaf=5,n_jobs=1,random_state=r).fit(X[:,cols],y)
        res["rf_"+name].append(np.mean((rf.predict(Xt[:,cols])-yt)**2))
        ols=LinearRegression().fit(X[:,cols],y); res["ols_"+name].append(np.mean((ols.predict(Xt[:,cols])-yt)**2))
for k,v in res.items(): print(k, round(float(np.mean(v)),3))
print("X3 (U-shaped) kept in", sum(3 in k for k in kept), "of 10; X0,X1 both kept in", sum((0 in k) and (1 in k) for k in kept))
print("cpu", round(time.process_time()-t0,1))
